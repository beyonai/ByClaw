import os
from pathlib import Path

# SAU_BASE_DIR 环境变量支持 pip install 部署：
# 设置 SAU_BASE_DIR=/opt/sau 后，cookie/日志等文件都会存到 /opt/sau 下，
# 而不是 site-packages 目录。未设置时沿用项目根目录（兼容 git clone 开发模式）。
BASE_DIR = Path(os.environ.get("SAU_BASE_DIR", "") or str(Path(__file__).parent.resolve()))
XHS_SERVER = "http://127.0.0.1:11901"  # only used by xhs-related flows
LOCAL_CHROME_PATH = ""  # optional, e.g. C:/Program Files/Google/Chrome/Application/chrome.exe
LOCAL_CHROME_HEADLESS = True  # default headless behavior for uploader/examples
DEBUG_MODE = True  # default debug behavior
# Optional proxy for the YouTube uploader. Where youtube.com is blocked, direct
# connections time out and the (patchright) chromium does NOT use the system proxy.
# Point this at your local proxy port, e.g. "http://127.0.0.1:7890". None = no proxy.
YT_PROXY = None
