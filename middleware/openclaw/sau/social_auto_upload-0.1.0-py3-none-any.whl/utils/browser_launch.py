import os
from pathlib import Path

from conf import LOCAL_CHROME_PATH


def _patchright_chromium_available() -> bool:
    browser_roots = []
    if os.environ.get("PLAYWRIGHT_BROWSERS_PATH"):
        browser_roots.append(Path(os.environ["PLAYWRIGHT_BROWSERS_PATH"]))

    browser_roots.extend(
        [
            Path.home() / ".cache" / "ms-playwright",
            Path.home() / "Library" / "Caches" / "ms-playwright",
            Path("/opt/playwright"),
        ]
    )

    for root in browser_roots:
        if not root.exists():
            continue
        for executable_pattern in (
            "chromium-*/chrome-linux/chrome",
            "chromium-*/chrome-mac/Chromium.app/Contents/MacOS/Chromium",
            "chromium-*/chrome-win/chrome.exe",
        ):
            if any(path.is_file() for path in root.glob(executable_pattern)):
                return True

    return False


def chromium_launch_kwargs(headless: bool, executable_path: str | None = None, **kwargs) -> dict:
    launch_kwargs = {"headless": headless, **kwargs}
    if _patchright_chromium_available():
        launch_kwargs["channel"] = "chromium"
        return launch_kwargs

    chrome_path = LOCAL_CHROME_PATH if executable_path is None else executable_path
    if chrome_path:
        launch_kwargs["executable_path"] = chrome_path
    else:
        launch_kwargs["channel"] = "chromium"
    return launch_kwargs
