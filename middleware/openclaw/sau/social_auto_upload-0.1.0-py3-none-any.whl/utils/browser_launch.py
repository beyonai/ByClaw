from conf import LOCAL_CHROME_PATH


def chromium_launch_kwargs(headless: bool, executable_path: str | None = None, **kwargs) -> dict:
    launch_kwargs = {"headless": headless, **kwargs}
    chrome_path = LOCAL_CHROME_PATH if executable_path is None else executable_path
    if chrome_path:
        launch_kwargs["executable_path"] = chrome_path
    else:
        launch_kwargs["channel"] = "chromium"
    return launch_kwargs
