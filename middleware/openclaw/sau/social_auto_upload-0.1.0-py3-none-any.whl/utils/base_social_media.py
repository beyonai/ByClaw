from pathlib import Path
from typing import List

SOCIAL_MEDIA_DOUYIN = "douyin"
SOCIAL_MEDIA_TENCENT = "tencent"
SOCIAL_MEDIA_TIKTOK = "tiktok"
SOCIAL_MEDIA_BILIBILI = "bilibili"
SOCIAL_MEDIA_KUAISHOU = "kuaishou"


def get_supported_social_media() -> List[str]:
    return [SOCIAL_MEDIA_DOUYIN, SOCIAL_MEDIA_TENCENT, SOCIAL_MEDIA_TIKTOK, SOCIAL_MEDIA_KUAISHOU]


def get_cli_action() -> List[str]:
    return ["upload", "login", "watch"]


def stealth_js_path() -> Path:
    # 包内只读资源，按 __file__ 定位，与 BASE_DIR 解耦。
    # pip install 后无论 SAU_BASE_DIR 指向哪里，都能正确读到 site-packages/utils/stealth.min.js
    return Path(__file__).parent / "stealth.min.js"


async def set_init_script(context):
    await context.add_init_script(path=stealth_js_path())
    return context
