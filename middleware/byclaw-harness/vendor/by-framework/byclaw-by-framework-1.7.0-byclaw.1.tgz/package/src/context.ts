import { Redis } from 'ioredis';
import { v4 as uuidv4 } from 'uuid';
import {
    DEFAULT_ASK_USER_TIMEOUT_MS,
    DEFAULT_REPLY_TIMEOUT_MS,
    QueueNames,
    TASK_GROUP_FIELD_ABORTED,
    TASK_GROUP_FIELD_TOTAL,
    TASK_GROUP_FIELD_COMPLETED,
    TASK_GROUP_TTL_SECONDS,
} from './constants';
import { registerWait } from './liveness/wait_registration';
import { SYNTHESIZED_BY_DISPATCH, failureReplyData, standInReply } from './liveness/wait_reply';
import type { ResumeCommand } from './protocol/commands';
import { createRedisCallAgentDeps, callAgent as publishCallAgent } from './dispatch/dispatch_ask_agent';
import { RoutePolicy, type RoutePolicy as RoutePolicyType } from './availability';
import type { CallAgentPublishInput } from './dispatch/types';
import { EventType } from './protocol/event_type';
import { AgentState } from './protocol/agent_state';
import { AskAgentCommand } from './protocol/commands';
import { MessageHeader } from './protocol/message_header';
import {
    StateChangeEvent,
    StreamChunkEvent,
    ArtifactEvent,
    AskUserEvent,
} from './protocol/events';

import { GatewayDataEmitter } from './emitter';
import { AgentConfig } from './extensions/agent_config';
import type { PluginRegistry } from './extensions/registry';
import { HistoryProvider } from './history';
import { SpanRecorder, spanIdHex, TraceSpan } from './trace/span_recorder';

export class TaskCancelledError extends Error {
    constructor(message: string = 'task cancelled') {
        super(message);
        this.name = 'TaskCancelledError';
    }
}

interface CancelSignalLegacy {
    readonly aborted?: boolean;
    readonly is_set?: boolean;
    readonly reason?: string;
}

export interface CallAgentResult {
    status: string;
    messageId: string;
    parentMessageId?: string;
    targetAgentType: string;
    error?: string;
    error_code?: string;
}

export interface CallAgentParams {
    readonly targetAgentType: string;
    readonly content: unknown;
    readonly extraPayload?: Readonly<Record<string, unknown>>;
    /** @deprecated Use extraPayload. */
    readonly payload?: Readonly<Record<string, unknown>>;
    readonly waitForReply?: boolean;
    readonly metadata?: Readonly<Record<string, unknown>>;
    readonly messageId?: string;
    readonly parentMessageId?: string;
    readonly routePolicy?: RoutePolicyType;
    readonly availabilityTimeoutMs?: number;
    readonly region?: string;
    readonly priority?: number;
    /**
     * How long this execution may stay suspended waiting for the reply before
     * the liveness sweep resolves it. Only meaningful when waitForReply is
     * true (the caller does not suspend otherwise); defaults to
     * DEFAULT_REPLY_TIMEOUT_MS.
     */
    readonly replyTimeoutMs?: number;
}

interface DispatchedTask {
    message_id: string;
    target_agent_type: string;
}

interface DispatchGroupResult {
    status: string;
    taskGroupId: string;
    dispatchedTasks: DispatchedTask[];
}

interface GroupResult {
    message_id: string;
    status: string;
    reply_data: unknown;
    content?: string;
}

export class AgentContext {
    private emitter: GatewayDataEmitter;
    private agentConfigs: ReadonlyArray<AgentConfig> = [];
    private prevAgentConfigs: ReadonlyArray<AgentConfig> = [];
    private responseBuffer: ReadonlyArray<string> = [];
    private historySaved = false;
    private _isSuspended = false;
    /**
     * WHY this execution is suspended, as the AgentState it is waiting in
     * (WAITING_AGENT / WAITING_USER), or '' when it is not suspended.
     *
     * The framework persists this instead of whatever non-terminal status the
     * business returned, so a suspended caller is distinguishable from one that
     * is merely QUEUED behind a worker. A plain boolean cannot carry that
     * distinction, and the distinction is what a sweep's triage keys off:
     * "waiting on a human" is never compensated, "waiting on an agent" is.
     * Kept in lockstep with `_isSuspended` — both are set together.
     */
    private _suspendedState = '';
    private _permissionTransferred = false;
    /**
     * Stand-in replies for Task Group members that never reached a worker,
     * queued here instead of being sent from the dispatch loop.
     *
     * See liveness/wait_reply.flushPendingGroupReplies for why not inline: a
     * reply sent inside dispatchGroup lands on the caller's own control stream
     * strictly before the caller suspends, which turns a rare race into a
     * certain one.
     */
    private _pendingGroupReplies: ResumeCommand[] = [];
    private _isStreamFinished = false;
    private _isFinalAnswerEmitted = false;

    public readonly executionId: string;
    public readonly spanRecorder: SpanRecorder;
    public _chunkCount: number = 0;
    private _tokenUsage: Record<string, any> = {};
    private _traceParentObservationId: string = '';

    constructor(
        public readonly sessionId: string,
        public readonly traceId: string,
        private readonly redis: Redis,
        private readonly currentAgentType: string = '',
        private readonly currentMessageId: string = '',
        public readonly currentCommand?: unknown,
        private readonly cancelSignal?: AbortSignal | CancelSignalLegacy,
        private readonly cancelReason: string = '',
        public readonly pluginRegistry?: PluginRegistry,
        executionId?: string,
        spanRecorder?: SpanRecorder,
    ) {
        this.emitter = new GatewayDataEmitter(this.redis);
        this.executionId = executionId || '';
        this.spanRecorder = spanRecorder || new SpanRecorder(redis);
    }

    get traceParentObservationId(): string {
        return this._traceParentObservationId;
    }

    set traceParentObservationId(id: string) {
        this._traceParentObservationId = id || '';
    }

    setAgentConfigs(newConfigs: ReadonlyArray<AgentConfig>): void {
        this.agentConfigs = [...newConfigs];
    }

    listAgentConfigs(): ReadonlyArray<AgentConfig> {
        return Object.freeze([...this.agentConfigs]);
    }

    getAgentConfig(agentId: string): AgentConfig | undefined {
        return this.agentConfigs.find((c) => c.agent_id === agentId);
    }

    freezePrevAgentConfigs(): void {
        this.prevAgentConfigs = [...this.agentConfigs];
    }

    getPrevAgentConfigs(): ReadonlyArray<AgentConfig> {
        return this.prevAgentConfigs;
    }

    isSuspended(): boolean {
        return this._isSuspended;
    }

    /**
     * The AgentState a suspended execution is waiting in (WAITING_AGENT /
     * WAITING_USER), or '' when it is not suspended.
     */
    suspendedState(): string {
        return this._suspendedState;
    }

    isPermissionTransferred(): boolean {
        return this._permissionTransferred;
    }

    /**
     * Hand over the queued dispatch-failure stand-ins, clearing the queue.
     *
     * Draining rather than reading is deliberate: whoever takes them owns
     * delivering them, and a second flush (the worker path and a nested
     * processor path both call it) must not send a duplicate of a reply that is
     * already on the wire — the gate would then drop the *real* sibling reply
     * that follows as "already consumed".
     */
    takePendingGroupReplies(): ResumeCommand[] {
        const pending = this._pendingGroupReplies;
        this._pendingGroupReplies = [];
        return pending;
    }

    isStreamFinished(): boolean {
        return this._isStreamFinished;
    }

    /** Mark a channel-owned FINAL_ANSWER so GatewayWorker does not emit it twice. */
    setFinalAnswerEmitted(emitted: boolean): void {
        this._isFinalAnswerEmitted = emitted;
    }

    isFinalAnswerEmitted(): boolean {
        return this._isFinalAnswerEmitted;
    }

    setStreamFinished(finished: boolean): void {
        this._isStreamFinished = finished;
    }

    recordTokenUsage(params: { promptTokens?: number; completionTokens?: number; model?: string }): void {
        const { promptTokens = 0, completionTokens = 0, model } = params;
        this._tokenUsage['prompt_tokens'] = (this._tokenUsage['prompt_tokens'] || 0) + Math.max(0, promptTokens);
        this._tokenUsage['completion_tokens'] = (this._tokenUsage['completion_tokens'] || 0) + Math.max(0, completionTokens);
        this._tokenUsage['total_tokens'] = this._tokenUsage['prompt_tokens'] + this._tokenUsage['completion_tokens'];
        if (model) {
            this._tokenUsage['model'] = model;
        }
    }

    getTokenUsage(): Record<string, any> {
        return { ...this._tokenUsage };
    }

    async callTool(name: string, kwargs: Readonly<Record<string, unknown>> = {}): Promise<unknown> {
        for (const config of this.agentConfigs) {
            const tool = config.tools?.[name];
            if (typeof tool === 'function') {
                return await tool(kwargs);
            }
        }
        throw new Error(`Tool '${name}' not found in any agent config`);
    }

    isCancelRequested(): boolean {
        return Boolean(this.cancelSignal && (
            (this.cancelSignal as CancelSignalLegacy).aborted ||
            (this.cancelSignal as CancelSignalLegacy).is_set
        ));
    }

    /** Return the runner-owned abort signal so workers can bridge cancellation to nested work. */
    getCancellationSignal(): AbortSignal | undefined {
        const signal = this.cancelSignal;
        if (!signal || typeof (signal as AbortSignal).addEventListener !== 'function') {
            return undefined;
        }
        return signal as AbortSignal;
    }

    async checkCancelled(): Promise<void> {
        if (this.isCancelRequested()) {
            const signalReason = this.cancelSignal && 'reason' in this.cancelSignal
                ? String((this.cancelSignal as { reason?: string }).reason || '')
                : '';
            throw new TaskCancelledError(this.cancelReason || signalReason || 'task cancelled');
        }
    }

    async getActiveWorkers(): Promise<Record<string, unknown>> {
        const { WorkerRegistry } = await import('./registry');
        const registry = new WorkerRegistry(this.redis);
        return registry.getAllWorkers() as unknown as Record<string, unknown>;
    }

    async updateExecutionState(status: string): Promise<void> {
        const { WorkerRegistry } = await import('./registry');
        const registry = new WorkerRegistry(this.redis);
        await registry.updateExecutionStatusByMessage(this.currentMessageId, this.sessionId, status);
    }

    private generateMessageId(): string {
        return `msg-${uuidv4().slice(0, 8)}`;
    }

    private async emitEvent(params: {
        readonly eventType: string;
        readonly data?: Readonly<Record<string, unknown>>;
        readonly stateMsg?: string;
        readonly artifactUrl?: string;
        readonly metadata?: Readonly<Record<string, unknown>>;
    }): Promise<void> {
        await this.emitter.emitEvent({
            sessionId: this.sessionId,
            traceId: this.traceId,
            sourceAgentType: this.currentAgentType,
            messageId: this.currentMessageId,
            parentMessageId: this.resolveCurrentParentMessageId(),
            ...params
        });
    }

    async emitChunk(event: StreamChunkEvent | string, eventType?: string): Promise<void> {
        const content = typeof event === 'string' ? event : (event.content || '');
        if (content) {
            this.responseBuffer = [...this.responseBuffer, content];
        }
        this._chunkCount += 1;
        await this.emitter.emitChunk(this.sessionId, this.traceId, event, {
            sourceAgentType: this.currentAgentType,
            messageId: this.currentMessageId,
            parentMessageId: this.resolveCurrentParentMessageId(),
            eventType: eventType as EventType
        });
        if (eventType === EventType.APP_STREAM_RESPONSE) {
            this._isStreamFinished = true;
            await this.flushToHistory();
        }
    }

    async emitState(event: StateChangeEvent | string, eventType?: string): Promise<void> {
        await this.emitter.emitState(this.sessionId, this.traceId, event, {
            sourceAgentType: this.currentAgentType,
            messageId: this.currentMessageId,
            parentMessageId: this.resolveCurrentParentMessageId(),
            eventType: eventType as EventType
        });
    }

    private resolveCurrentParentMessageId(): string {
        const command = this.currentCommand as { header?: { parentMessageId?: unknown } } | undefined;
        const parentMessageId = command?.header?.parentMessageId;
        return typeof parentMessageId === 'string' && parentMessageId.trim()
            ? parentMessageId.trim()
            : '-1';
    }

    async emitArtifact(event: ArtifactEvent | string, eventType?: string): Promise<void> {
        await this.emitter.emitArtifact(this.sessionId, this.traceId, event, {
            sourceAgentType: this.currentAgentType,
            messageId: this.currentMessageId,
            parentMessageId: this.resolveCurrentParentMessageId(),
            eventType: eventType as EventType
        });
    }

    /**
     * Suspend execution and ask the user for a prompt.
     *
     * `replyTimeoutMs` bounds how long this execution may stay suspended before
     * the liveness sweep resolves it; it defaults to
     * DEFAULT_ASK_USER_TIMEOUT_MS, which is deliberately much larger than
     * callAgent's default because this one waits on a human.
     *
     * Wait-index convention (mirrored by the Python/Java ports): an askUser
     * wait has no sub-task, so its member's `childMessageId` is the empty
     * string, and its `parentMessageId` is this execution's own message_id —
     * which is what the client's ResumeCommand carries as `header.messageId`
     * when the user answers.
     */
    async askUser(
        event: AskUserEvent | string,
        options: { readonly replyTimeoutMs?: number } = {}
    ): Promise<{ readonly status: string }> {
        // Registered BEFORE the prompt goes out, for the same reason the
        // dispatch pipeline registers before its xadd: the answer can come back
        // the instant the prompt is visible, and an answer that arrives before
        // the entry exists passes the gate as unregistered and then leaves the
        // entry behind it with nothing left to clear it.
        await registerWait(this.redis, {
            sessionId: this.sessionId,
            parentMessageId: this.currentMessageId,
            childMessageId: '',
            taskGroupId: '',
            timeoutMs: options.replyTimeoutMs ?? DEFAULT_ASK_USER_TIMEOUT_MS,
        });
        await this.emitter.askUser(this.sessionId, this.traceId, event, {
            sourceAgentType: this.currentAgentType,
            messageId: this.currentMessageId,
            parentMessageId: this.resolveCurrentParentMessageId(),
        });
        this._isSuspended = true;
        this._suspendedState = AgentState.WAITING_USER;
        return { status: AgentState.WAITING_USER };
    }

    async flushToHistory(): Promise<void> {
        if (this.historySaved || this.responseBuffer.length === 0) {
            return;
        }
        const fullContent = this.responseBuffer.join('');
        await HistoryProvider.saveMessage(this.sessionId, 'assistant', fullContent, {
            trace_id: this.traceId,
            agent_id: this.currentAgentType,
            message_id: this.currentMessageId,
        });
        this.historySaved = true;
    }

    async callAgent(params: CallAgentParams): Promise<CallAgentResult> {
        const { WorkerRegistry } = await import('./registry');
        const registry = new WorkerRegistry(this.redis);
        const deps = createRedisCallAgentDeps({ redis: this.redis, registry, queueNames: QueueNames });

        // Pre-generate messageId so we can compute trace span IDs before dispatch
        const messageId = params.messageId || this.generateMessageId();
        const callParentSpanId = `${messageId}:client.dispatch`;
        const traceParentSpanId = this._resolveCallTraceParentSpanId(callParentSpanId);

        const mergedMetadata: Record<string, unknown> = {
            ...(params.metadata || {}),
            trace_parent_span_id: traceParentSpanId,
            framework_parent_span_id: callParentSpanId,
        };

        const currentHeader = this.currentCommand instanceof AskAgentCommand
            ? this.currentCommand.header
            : undefined;
        const input: CallAgentPublishInput = {
            sessionId: this.sessionId,
            traceId: this.traceId,
            sourceAgentType: this.currentAgentType,
            defaultParentMessageId: this.currentMessageId,
            targetAgentType: params.targetAgentType,
            content: params.content,
            extraPayload: params.extraPayload ?? params.payload,
            waitForReply: params.waitForReply,
            userCode: currentHeader?.userCode,
            userName: currentHeader?.userName,
            taskGroupId: currentHeader?.taskGroupId,
            metadata: mergedMetadata,
            messageId,
            parentMessageId: params.parentMessageId,
            routePolicy: params.routePolicy,
            availabilityTimeoutMs: params.availabilityTimeoutMs,
            region: params.region,
            priority: params.priority,
            // Only consulted when waitForReply is true; the pipeline registers
            // the wait-index entry itself, next to initializeExecution and
            // before the ctrl publish.
            replyTimeoutMs: params.replyTimeoutMs,
            langfuseParentObservationId: this.traceParentObservationId || '',
        };

        if (this.pluginRegistry) {
            await this.pluginRegistry.onCallAgentStart(this, params);
        }

        const dispatchStartTs = Date.now();
        let raw: any;
        try {
            raw = await publishCallAgent(deps, input);
        } catch (error: any) {
            if (this.pluginRegistry) {
                await this.pluginRegistry.onCallAgentError(this, params, error instanceof Error ? error : new Error(String(error)));
            }
            throw error;
        }

        await this._recordAgentDispatchSpan({
            messageId: raw.messageId || messageId,
            parentMessageId: params.parentMessageId || this.currentMessageId,
            sourceAgentType: params.waitForReply !== false ? this.currentAgentType : '',
            targetAgentType: raw.targetAgentType || params.targetAgentType,
            routePolicy: params.routePolicy ?? RoutePolicy.FAIL_FAST,
            routeStatus: raw.routeStatus || raw.status,
            startTs: dispatchStartTs,
            endTs: Date.now(),
        });

        if (raw.status === AgentState.FAILED) {
            if (this.pluginRegistry) {
                await this.pluginRegistry.onCallAgentError(this, params, new Error(raw.error || 'Agent type unavailable'));
            }
            return {
                status: raw.status, messageId: raw.messageId, parentMessageId: raw.parentMessageId,
                targetAgentType: raw.targetAgentType, error: raw.error, error_code: raw.error_code,
            };
        }

        // NOTE: this assignment sits AFTER the availability-rejection early
        // return above, so a dispatch that never happened cannot leave the
        // context looking suspended. Python needed an explicit snapshot/rollback
        // here precisely because its equivalent runs before the check — do not
        // "port" that rollback back into this file, and do not hoist this.
        if (raw.runtimeHint === 'suspend' || params.waitForReply !== false) {
            this._isSuspended = true;
            this._suspendedState = AgentState.WAITING_AGENT;
        } else if (raw.runtimeHint === 'transfer') {
            this._permissionTransferred = true;
        }

        const result: CallAgentResult = {
            status: raw.status,
            messageId: raw.messageId,
            parentMessageId: raw.parentMessageId,
            targetAgentType: raw.targetAgentType,
            error: raw.error,
            error_code: raw.error_code,
        };

        if (this.pluginRegistry) {
            await this.pluginRegistry.onCallAgentComplete(this, params, result);
        }

        return result;
    }

    private async _recordAgentDispatchSpan(params: {
        messageId: string;
        parentMessageId: string;
        sourceAgentType: string;
        targetAgentType: string;
        routePolicy?: string;
        routeStatus?: string;
        workerId?: string;
        startTs: number;
        endTs: number;
    }): Promise<void> {
        const parentSpanId = this.executionId
            ? `${this.executionId}:worker.execute`
            : `${this.currentMessageId}:worker.execute`;
        try {
            await this.spanRecorder.recordSpan({
                traceId: this.traceId,
                spanId: `${params.messageId}:client.dispatch`,
                parentSpanId,
                operation: 'client.dispatch',
                component: 'agent_context',
                startTs: params.startTs,
                endTs: params.endTs,
                status: 'COMPLETED',
                sessionId: this.sessionId,
                messageId: params.messageId,
                parentMessageId: params.parentMessageId,
                workerId: params.workerId || '',
                sourceAgentType: params.sourceAgentType,
                targetAgentType: params.targetAgentType,
                routePolicy: params.routePolicy || '',
                routeStatus: params.routeStatus || '',
            } as TraceSpan);
        } catch (err) {
            // best effort
        }
    }

    private _resolveCallTraceParentSpanId(callParentSpanId: string): string {
        return spanIdHex(callParentSpanId);
    }

    /**
     * Dispatch multiple tasks concurrently as a group (Scatter-Gather).
     */
    async dispatchGroup(params: {
        readonly tasks: ReadonlyArray<{
            readonly targetAgentType: string;
            readonly content: string;
            readonly payload?: Readonly<Record<string, unknown>>;
            readonly metadata?: Readonly<Record<string, unknown>>;
        }>;
        readonly waitForReply?: boolean;
        readonly messageId?: string;
        readonly parentMessageId?: string;
        /**
         * Per-sub-task reply deadline; each member of the group gets its own
         * wait-index entry with this timeout, since each can go missing
         * independently. Defaults to DEFAULT_REPLY_TIMEOUT_MS.
         */
        readonly replyTimeoutMs?: number;
    }): Promise<DispatchGroupResult> {
        const { tasks, waitForReply = true, messageId, parentMessageId, replyTimeoutMs } = params;

        if (!tasks || tasks.length === 0) {
            return { status: 'EMPTY', taskGroupId: '', dispatchedTasks: [] };
        }

        const taskGroupId = `tg-${uuidv4().slice(0, 8)}`;
        const wait = waitForReply ?? true;
        const groupDispatchStartTs = Date.now();

        // Setup Redis counters if waiting for replies
        if (wait) {
            const groupKey = QueueNames.task_group(taskGroupId);
            await this.redis.hset(groupKey, {
                [TASK_GROUP_FIELD_TOTAL]: tasks.length.toString(),
                [TASK_GROUP_FIELD_COMPLETED]: '0',
                source_agent_type: this.currentAgentType,
            });
            await this.redis.expire(groupKey, TASK_GROUP_TTL_SECONDS);
            this._isSuspended = true;
            this._suspendedState = AgentState.WAITING_AGENT;
        } else {
            this._permissionTransferred = true;
        }

        const dispatchedTasks: DispatchedTask[] = [];
        const { WorkerRegistry } = await import('./registry');
        const dispatchRegistry = new WorkerRegistry(this.redis);

        for (const task of tasks) {
            const currentMessageId = this.generateMessageId();
            const currentParentMessageId = parentMessageId || this.currentMessageId;

            // Compute trace span IDs for this sub-task
            const callParentSpanId = `${currentMessageId}:client.dispatch`;
            const traceParentSpanId = this._resolveCallTraceParentSpanId(callParentSpanId);

            const taskMetadata: Record<string, unknown> = {
                ...(task.metadata || {}),
                trace_parent_span_id: traceParentSpanId,
                framework_parent_span_id: callParentSpanId,
            };

            const mergedPayload: Record<string, unknown> = { ...(task.payload || {}) };
            if (wait) {
                mergedPayload.wait_for_reply = true;
            }

            const command = new AskAgentCommand(
                new MessageHeader(currentMessageId, this.sessionId, this.traceId, {
                    sourceAgentType: wait ? this.currentAgentType : '',
                    targetAgentType: task.targetAgentType,
                    parentMessageId: currentParentMessageId,
                    taskGroupId: taskGroupId,
                    metadata: taskMetadata,
                    traceParentSpanId,
                    langfuseParentObservationId: this.traceParentObservationId || '',
                }),
                task.content,
                wait,
                Object.fromEntries(Object.entries(mergedPayload).filter(([key]) => key !== 'wait_for_reply'))
            );

            if (this.pluginRegistry) {
                await this.pluginRegistry.onCallAgentStart(this, command);
            }

            // Availability check, waiting members only. A member whose target
            // agent type has no online worker used to be XADDed into a control
            // stream nobody consumes: the group's `completed` could then never
            // reach `total` and the caller hung with no dispatch-time signal at
            // all. Probed only when `wait` is true because that is the only case
            // with group accounting to starve — a fire-and-forget fan-out keeps
            // its previous behaviour exactly.
            const memberOnline = wait ? await this._probeGroupMemberOnline(task.targetAgentType) : null;
            if (memberOnline && !memberOnline.ok) {
                // Recorded FAILED rather than QUEUED: this is the record a sweep
                // reads to decide the member provably cannot answer. Mirrors the
                // REJECT branch of the single-dispatch pipeline.
                await dispatchRegistry.initializeExecution({
                    execution_id: `exec-${uuidv4().slice(0, 8)}`,
                    message_id: currentMessageId,
                    parent_message_id: currentParentMessageId,
                    session_id: this.sessionId,
                    trace_id: this.traceId,
                    source_agent_type: this.currentAgentType,
                    task_group_id: taskGroupId,
                    // Same reason as task_group_id: the sweeper's synthesized
                    // failure reads this member's metadata back off its own
                    // execution record, so the caller's metadata rides on the
                    // stand-in reply exactly as it would on a real one.
                    metadata: { ...taskMetadata },
                    stream_name: QueueNames.ctrl_stream(task.targetAgentType),
                    worker_id: '',
                    target_agent_type: task.targetAgentType,
                    status: AgentState.FAILED,
                    availability_error: memberOnline.error,
                    availability_error_code: memberOnline.errorCode,
                    cancel_requested: false,
                    cancel_reason: '',
                });
                await this._queueUndispatchedMemberFailure({
                    taskGroupId,
                    callerMessageId: currentParentMessageId,
                    childMessageId: currentMessageId,
                    targetAgentType: task.targetAgentType,
                    error: memberOnline.error,
                    errorCode: memberOnline.errorCode,
                    metadata: taskMetadata,
                    replyTimeoutMs,
                });
                if (this.pluginRegistry) {
                    await this.pluginRegistry.onCallAgentError(
                        this, command, new Error(memberOnline.error)
                    );
                }
                // Still reported as dispatched: the group has `tasks.length`
                // members and exactly one accounting event is coming for this
                // one (the stand-in), same as for every sibling.
                dispatchedTasks.push({
                    message_id: currentMessageId,
                    target_agent_type: task.targetAgentType,
                });
                continue;
            }

            // Initialize execution record for each dispatched task
            await dispatchRegistry.initializeExecution({
                execution_id: `exec-${uuidv4().slice(0, 8)}`,
                message_id: currentMessageId,
                parent_message_id: currentParentMessageId,
                session_id: this.sessionId,
                trace_id: this.traceId,
                source_agent_type: wait ? this.currentAgentType : '',
                // Needed on resume: a sub-task that itself suspends recovers its
                // caller and its group from this record, never from the resume
                // header (which describes the hop that woke it).
                task_group_id: taskGroupId,
                // Same reason, same reader: this is the only durable record of
                // the caller's original dispatch metadata, which resolveReplyCommand
                // restores as the base layer of a resumed member's reply. Without
                // it a group member that suspends before replying loses the
                // caller's metadata even though a non-suspending sibling keeps it.
                metadata: { ...taskMetadata },
                stream_name: QueueNames.ctrl_stream(task.targetAgentType),
                worker_id: '',
                target_agent_type: task.targetAgentType,
                status: 'QUEUED',
                cancel_requested: false,
                cancel_reason: '',
            });

            if (wait) {
                // One entry per sibling — each sub-task can go missing
                // independently, and childMessageId is the only per-sibling
                // unique field, so a shared entry would be claimed once and the
                // rest of the group would hang. Registered before the xadd for
                // the same reason as the single-dispatch path.
                await registerWait(this.redis, {
                    sessionId: this.sessionId,
                    parentMessageId: currentParentMessageId,
                    childMessageId: currentMessageId,
                    taskGroupId,
                    timeoutMs: replyTimeoutMs ?? DEFAULT_REPLY_TIMEOUT_MS,
                });
            }

            const dispatchStartTs = Date.now();
            try {
                await this.redis.xadd(
                    QueueNames.ctrl_stream(task.targetAgentType),
                    '*',
                    'data',
                    JSON.stringify(command.toDict())
                );
            } catch (error: any) {
                if (this.pluginRegistry) {
                    await this.pluginRegistry.onCallAgentError(this, command, error instanceof Error ? error : new Error(String(error)));
                }
                // A genuine dispatch-time failure (not an availability-check
                // rejection, which the branch above already turns into a
                // stand-in reply instead of throwing). Stop fanning out and mark
                // the group aborted, so the siblings already sent don't later
                // resume this — now failed — caller execution, and so a sweep
                // cleans their orphaned wait entries up instead of compensating
                // them. Stand-ins queued so far die with the throw: the worker
                // only flushes them once processCommand returns normally.
                // Mirrors Python context.py's dispatch_group.
                if (wait) {
                    try {
                        await this.redis.hset(
                            QueueNames.task_group(taskGroupId),
                            TASK_GROUP_FIELD_ABORTED,
                            '1'
                        );
                    } catch (markError) {
                        console.warn(
                            `[AgentContext] Could not mark Task Group ${taskGroupId} aborted: ${markError}`
                        );
                    }
                }
                throw error;
            }

            await this._recordAgentDispatchSpan({
                messageId: currentMessageId,
                parentMessageId: currentParentMessageId,
                sourceAgentType: wait ? this.currentAgentType : '',
                targetAgentType: task.targetAgentType,
                routePolicy: 'SEND_ANYWAY',
                routeStatus: 'GROUP_DISPATCH',
                startTs: dispatchStartTs,
                endTs: Date.now(),
            });

            const taskResult = {
                status: AgentState.QUEUED,
                messageId: currentMessageId,
                parentMessageId: currentParentMessageId,
                targetAgentType: task.targetAgentType,
            };
            if (this.pluginRegistry) {
                await this.pluginRegistry.onCallAgentComplete(this, command, taskResult);
            }

            dispatchedTasks.push({
                message_id: currentMessageId,
                target_agent_type: task.targetAgentType,
            });
        }

        // Record aggregate span for the entire group dispatch
        const groupParentSpanId = this.executionId
            ? `${this.executionId}:worker.execute`
            : `${this.currentMessageId}:worker.execute`;
        try {
            await this.spanRecorder.recordSpan({
                traceId: this.traceId,
                spanId: `${taskGroupId}:agent.dispatch_group`,
                parentSpanId: groupParentSpanId,
                operation: 'agent.dispatch_group',
                component: 'agent_context',
                startTs: groupDispatchStartTs,
                endTs: Date.now(),
                status: 'COMPLETED',
                sessionId: this.sessionId,
                executionId: this.executionId,
                messageId: this.currentMessageId,
                targetAgentType: this.currentAgentType,
                metadata: {
                    task_group_id: taskGroupId,
                    task_count: tasks.length,
                    wait_for_reply: wait,
                },
            } as TraceSpan);
        } catch (err) {
            // best effort
        }

        return {
            status: 'GROUP_QUEUED',
            taskGroupId,
            dispatchedTasks,
        };
    }

    /**
     * Is there an online worker for this group member's target agent type?
     *
     * Fail-soft in the *dispatch* direction: if the probe itself errors we
     * report the member as reachable and let the XADD go out. A probe outage
     * must not turn every member of every group into a synthesized failure.
     */
    private async _probeGroupMemberOnline(
        targetAgentType: string
    ): Promise<{ ok: boolean; error: string; errorCode: string }> {
        try {
            const { WorkerRegistry } = await import('./registry');
            const [online] = await new WorkerRegistry(this.redis).hasOnlineAgentType(targetAgentType);
            if (online) {
                return { ok: true, error: '', errorCode: '' };
            }
            return {
                ok: false,
                error: `No alive worker found with agent type '${targetAgentType}'`,
                errorCode: 'AGENT_TYPE_NOT_FOUND',
            };
        } catch (error) {
            console.warn(
                `[AgentContext] Availability probe failed for agent type '${targetAgentType}', `
                + `dispatching anyway: ${error}`
            );
            return { ok: true, error: '', errorCode: '' };
        }
    }

    /**
     * Handle a group member whose target agent type was unavailable.
     *
     * No worker will ever reply for this sub-task, so the group needs one more
     * result from somewhere. It must NOT be booked here. Writing
     * task_group_results and HINCRBYing `completed` from the dispatch loop is a
     * second implementation of the accounting that lives in GatewayWorker's
     * Group Join, and when *that* copy is the increment that reaches `total`
     * there is no reply left to trigger the join and the caller stays suspended
     * forever. Two paths reach it: every target being unavailable, and a sibling
     * replying fast enough that a later unavailable target's increment is the
     * one that fills the group.
     *
     * So the compensation is a *reply* — the one a sub-agent would have sent had
     * it started and failed — and the join stores it, counts it and aggregates
     * through the single path it already owns. The last accounting event is then
     * always a reply, so the join always runs.
     *
     * A wait-index entry is registered for it as well, even though nothing was
     * dispatched. It costs one ZADD, and it buys the only backstop this path
     * has: if the stand-in is never delivered (the flush is fail-soft by
     * necessity — see flushPendingGroupReplies), the sweep finds this member's
     * execution recorded FAILED and compensates it like any other lost reply,
     * instead of the group hanging on a member that provably cannot answer.
     * Relying on the gate's ALLOW_UNREGISTERED instead would mean a lost
     * stand-in leaves nothing at all behind, i.e. this fix opening a new hole of
     * its own.
     *
     * Mirrors Python context.py's _queue_undispatched_member_failure.
     */
    private async _queueUndispatchedMemberFailure(params: {
        readonly taskGroupId: string;
        readonly callerMessageId: string;
        readonly childMessageId: string;
        readonly targetAgentType: string;
        readonly error: string;
        readonly errorCode: string;
        readonly metadata?: Readonly<Record<string, unknown>>;
        readonly replyTimeoutMs?: number;
    }): Promise<void> {
        await registerWait(this.redis, {
            sessionId: this.sessionId,
            parentMessageId: params.callerMessageId,
            childMessageId: params.childMessageId,
            taskGroupId: params.taskGroupId,
            timeoutMs: params.replyTimeoutMs ?? DEFAULT_REPLY_TIMEOUT_MS,
        });
        if (!this.currentAgentType) {
            // Nothing to address the reply to: this context has no agent type,
            // so a real sub-agent could not have replied either (its dispatch
            // carried an empty sourceAgentType). The wait entry above is what
            // gets this group unstuck.
            console.warn(
                `[AgentContext] Task Group ${params.taskGroupId} sub-task ${params.childMessageId} `
                + `cannot be compensated inline: this context has no agent type to address the `
                + `reply to. Leaving it to the wait-index sweep.`
            );
            return;
        }
        const currentHeader = this.currentCommand instanceof AskAgentCommand
            ? this.currentCommand.header
            : undefined;
        this._pendingGroupReplies.push(standInReply({
            sessionId: this.sessionId,
            callerMessageId: params.callerMessageId,
            callerAgentType: this.currentAgentType,
            childMessageId: params.childMessageId,
            childAgentType: params.targetAgentType,
            taskGroupId: params.taskGroupId,
            traceId: this.traceId,
            status: AgentState.FAILED,
            replyData: failureReplyData({
                error: params.error,
                errorCode: params.errorCode || 'AGENT_TYPE_UNAVAILABLE',
                childMessageId: params.childMessageId,
            }),
            metadata: (params.metadata ?? {}) as Record<string, any>,
            errorCode: params.errorCode,
            synthesizedBy: SYNTHESIZED_BY_DISPATCH,
            userCode: currentHeader?.userCode,
            userName: currentHeader?.userName,
        }));
    }

    /**
     * Collect results from all tasks in a group.
     */
    async collectGroupResults(taskGroupId: string, timeout: number = 30): Promise<GroupResult[]> {
        if (!taskGroupId) {
            return [];
        }

        const resultsKey = QueueNames.task_group_results(taskGroupId);
        const groupKey = QueueNames.task_group(taskGroupId);

        const totalStr = await this.redis.hget(groupKey, TASK_GROUP_FIELD_TOTAL);
        const total = totalStr ? parseInt(totalStr, 10) : Infinity;

        const results: GroupResult[] = [];
        const startTime = Date.now();

        while (results.length < total) {
            const elapsed = (Date.now() - startTime) / 1000;
            if (elapsed >= timeout) {
                break;
            }

            const rawResults = await this.redis.hgetall(resultsKey);
            if (rawResults) {
                for (const [msgId, data] of Object.entries(rawResults)) {
                    try {
                        const parsed = JSON.parse(data as string);
                        results.push({
                            message_id: msgId,
                            status: parsed.status || '',
                            reply_data: parsed.reply_data,
                            content: parsed.content,
                        });
                    } catch {
                        // Skip invalid JSON
                    }
                }
                if (results.length >= total) {
                    break;
                }
            }

            // Wait 100ms before polling again
            await new Promise(resolve => setTimeout(resolve, 100));
        }

        return results;
    }
}
