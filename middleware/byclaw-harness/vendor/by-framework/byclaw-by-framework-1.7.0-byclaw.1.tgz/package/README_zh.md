# By-Framework for TypeScript

<div align="center">

[![NPM](https://img.shields.io/npm/v/@byclaw/by-framework?color=blue)](https://www.npmjs.com/package/@byclaw/by-framework)
[![Node](https://img.shields.io/badge/node-18+-green.svg)](https://nodejs.org/)
[![Redis](https://img.shields.io/badge/redis-7.0+-red.svg)](https://redis.io/)
[![License](https://img.shields.io/badge/license-Apache_2.0-green.svg)](LICENSE)

</div>

<div align="center">

[**English**](README.md) | [**中文**](README_zh.md)

**重要链接：** [文档](https://beyonai.github.io/by-framework-docs) · [Java 版本](https://beyonai.github.io/by-framework-java) · [Python 版本](https://beyonai.github.io/by-framework-python)

</div>

---

**By-Framework** 是一个基于 Redis Streams 构建的分布式高性能 Agent 调度引擎，专为多 Agent 系统设计。

## 传统架构的困境

传统 AI 应用架构在面对 Agent 场景时常面临三大挑战：

- **全链路同步阻塞 $\rightarrow$ 迫使用户“人肉盯看”** — 前端与后端强绑定，页面关闭即任务中断。用户无法跨端切换，工作流极易因网络波动或意外打断而前功尽弃。
- **无法支撑超长任务 $\rightarrow$ 导致系统“全程陪同”** — 面对数分钟甚至小时级的推理，调用方必须持续阻塞线程等待，不仅面临网关超时截断，更造成了严重的计算资源空转与浪费。
- **多 Agent 编排的中断恢复困局** — 在复杂级联调用中，一旦出现超时或中断，系统难以精准定位状态并恢复，开发者往往需自建极其复杂的持久化状态机。

## By-Framework 的方案

![Architecture Overview](./assets/img/architecture_zh.png)

By-Framework 通过**控制与数据平面分离**的异步架构解决上述问题：

- **指令异步化**：APP 通过 **Gateway Client** 将用户请求转化为控制指令并投入 **Control Queue**。由于是异步解耦，APP 无需阻塞等待，后端线程立即释放。
- **Agent 集群消费**：分布式的 **Agents** 集群竞争消费控制队列中的消息。通过逻辑寻址（Agent Type）自动实现负载均衡，天然支持动态扩缩容。
- **过程数据回传**：Agent 在执行过程中，将流式文本（Chunk）、状态变更（State）及产物（Artifact）异步推送到 **Data Queue**。APP 通过 **Gateway Client** 实时监听以获取任务进度，从而原生支持超长任务。
- **原生编排与中断恢复**：当 Agent 需要调用其他 Agent（编排）时，它会将新指令发往 **Control Queue**。这种基于消息的机制允许 Agent 在等待期间释放资源，并在收到回复后精准恢复上下文。

## 亮点

- 🚀 **异步与事件驱动** — 控制与数据分离于独立 Redis Stream，Worker 扩缩容与数据投递路径解耦
- 🧩 **类型安全** — 完整的 TypeScript 类型支持，确保分布式场景下的开发体验与系统健壮性
- 🔌 **插件系统** — 支持热加载插件机制，提供生命周期钩子、工具、提示词和子 Agent 配置
- 🤝 **多 Agent 编排** — 内置 `callAgent`、`scatter-gather` 扇出和人机交互模式
- 🛡️ **生产就绪** — 竞争消费、优雅退出、消息持久化与执行状态追踪


---

## 核心架构

SDK 当前以 `agent_type` 为主要路由维度：

- **控制流**：`GatewayClient` 将 `AskAgentCommand` / `ResumeCommand` / `CancelTaskCommand` 写入 Redis Stream。普通任务进入 `byai_gateway:ctrl:agent_type:{agentType}`，定向控制命令进入 `byai_gateway:ctrl:worker:{workerId}`。
- **执行流**：`WorkerRunner` 为 Worker 创建消费组、抢占 `workerId` 在线租约、启动心跳，并通过 `runner.start()` 自动轮询、处理、ACK、更新执行状态。
- **数据流**：`AgentContext` / `GatewayDataEmitter` 将流式回答、思考状态、文件产物、用户输入请求写入 `byai_gateway:session:{sessionId}:data_stream`。
- **注册与状态**：`WorkerRegistry` 维护 Worker 能力、在线租约，以及按 `sessionId` 聚合的 execution 记录和 `messageId -> executionId` 映射。
- **扩展能力**：包含插件注册、拦截器、会话历史、工作区、HookSandbox、文件存储和服务发现模块。

## 模块结构

- `src/client.ts`：业务端发起任务、发送自定义命令、取消任务。
- `src/worker.ts`：`GatewayWorker` 抽象基类与 `AnonymousWorker`。
- `src/runner.ts`：Worker 生命周期、消费组、自动处理、取消控制流。
- `src/context.ts`：Worker 处理任务时使用的 `AgentContext`，负责推流、调用下游 Agent、取消检查等。
- `src/emitter.ts`：独立数据流上报器 `GatewayDataEmitter`。
- `src/registry.ts`：Worker 在线状态和 execution 生命周期记录。
- `src/protocol/`：命令、事件、状态、响应、消息协议类型。
- `src/extensions/`：插件和 Agent 配置。
- `src/runtime/`：历史、文件存储、运行态辅助模块。
- `src/discovery/`：服务发现客户端和注册器。
- `examples/`：本地运行示例。
- `tests/`：Jest 测试。

`dist/` 是构建产物，不要手工编辑。

## 安装

环境要求：Node.js 18+

```bash
npm install @byclaw/by-framework
```

本仓库开发命令：

```bash
npm run build
npm test
npm run dev
```

## 快速开始

### 创建 Worker

推荐让 `WorkerRunner.start()` 托管 Worker 生命周期。它会初始化 Stream、启动心跳、处理任务、自动 ACK，并在任务结束时更新 execution 状态。

```typescript
import {
    AgentContext,
    AgentState,
    AskAgentCommand,
    GatewayWorker,
    WorkerRunner,
} from '@byclaw/by-framework';

class DemoWorker extends GatewayWorker {
    getAgentTypes(): string[] {
        return ['demo-agent-ts'];
    }

    async processCommand(command: AskAgentCommand, context: AgentContext): Promise<any> {
        await context.emitState('processing');
        await context.emitChunk(`Echo: ${command.content}`);

        return {
            status: AgentState.COMPLETED,
            content: `Echo: ${command.content}`,
            replyData: { ok: true },
        };
    }
}

const worker = new DemoWorker('worker-ts-01');
const runner = new WorkerRunner(worker, {
    fetchCount: 10,
});

await runner.start({ handleSignals: true });
```

### 发送任务

`sendMessage` 默认要求目标 `agentType` 当前有在线 Worker。若需要“先入队、后启动 Worker”的调试模式，可传 `requireOnlineWorker: false`。

```typescript
import { GatewayClient, WorkerRegistry, createRedis } from '@byclaw/by-framework';

const redis = createRedis({ host: 'localhost', port: 6379, db: 0 });
const registry = new WorkerRegistry(redis);
const client = new GatewayClient(registry, redis);

const res = await client.sendMessage({
    targetAgentType: 'demo-agent-ts',
    sessionId: 'test-session',
    content: 'Hello!',
    userCode: 'test-tenant',
    metadata: { requestId: 'req-1' },
});

console.log(res);
await redis.quit();
```

### 取消任务

取消逻辑以 `sessionId + messageId` 查找 execution。若任务已被 Worker 领取，会向该 Worker 的控制流发送 `CancelTaskCommand`；若还在队列中，会将 execution 标记为 `CANCELLING`，后续 Worker 领取时会跳过业务处理并标记为 `CANCELLED`。

```typescript
const cancelRes = await client.cancelTask({
    messageId: res.message_id,
    sessionId: 'test-session',
    reason: 'user aborted',
    requestedBy: 'frontend',
    cancelMode: 'graceful',
});
```

Worker 业务代码应在长任务中周期性检查取消信号：

```typescript
for (const item of items) {
    await context.checkCancelled();
    await doWork(item);
}
```

### 调用下游 Agent

在 Worker 内可以通过 `AgentContext` 继续派发任务：

```typescript
const child = await context.callAgent({
    targetAgentType: 'child-agent',
    content: 'Please continue this task',
    waitForReply: true,
    payload: { priority: 'normal' },
});
```

也支持 Scatter-Gather：

```typescript
const group = await context.dispatchGroup({
    tasks: [
        { targetAgentType: 'agent-a', content: 'task A' },
        { targetAgentType: 'agent-b', content: 'task B' },
    ],
    waitForReply: true,
});

const results = await context.collectGroupResults(group.taskGroupId, 30);
```

## 核心 API

### Redis

```typescript
createRedis(options?: {
    mode?: 'standalone' | 'cluster';
    host?: string;
    port?: number;
    db?: number;
    username?: string;
    password?: string;
    clusterNodes?: { host: string; port: number }[];
})
```

默认读取：

| 变量名 | 说明 |
|--------|------|
| `REDIS_MODE` | `standalone`（默认）或 `cluster` |
| `REDIS_HOST` | Redis 主机，默认 `localhost` |
| `REDIS_PORT` | Redis 端口，默认 `6379` |
| `REDIS_DATABASE` | Redis DB，默认 `0`（`REDIS_DB` 作为过期兼容 fallback 仍可用，会打印一条 warning 日志） |
| `REDIS_USERNAME` | Redis 用户名，可选 |
| `REDIS_PASSWORD` | Redis 密码，可选。以 `{cipher}` 开头的值会按与 byclaw-be 及 Java/Python SDK 一致的 RSA 格式解密 |
| `REDIS_CLUSTER_HOST` | 逗号分隔的 `host:port` 列表；只要配置了这个变量就会自动切换为集群模式并推断 key schema 为 `v2`，不需要再单独设置 `REDIS_MODE=cluster`/`REDIS_KEY_SCHEMA_VERSION=v2`（如果显式设置了对应变量，仍以显式值为准） |
| `REDIS_CLUSTER_NODES` | 逗号分隔的 `host:port` 列表，`mode=cluster` 且未设置 `REDIS_CLUSTER_HOST` 时使用 |
| `REDIS_KEY_SCHEMA_VERSION` | `v1`（默认，不带前缀的 key 格式）或 `v2`（hash-tag key 格式）；`cluster` 模式要求为 `v2`。未显式设置时，只要配置了 `REDIS_CLUSTER_HOST` 就会自动推断为 `v2` |

`runWorker` 还会读取：

| 变量名 | 说明 |
|--------|------|
| `BYAI_WORKER_FETCH_COUNT` | 每次读取任务数，默认 `10` |
| `BYAI_REDIS_MAX_CONNECTIONS` | 与 Python SDK 对齐的连接数配置语义 |

### GatewayClient

```typescript
new GatewayClient(
    registry?: WorkerRegistry,
    redisClient?: Redis,
    interceptors?: GatewayInterceptor[]
)
```

#### `client.sendMessage(params)`

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| `targetAgentType` | `string` | 是 | 目标 Agent 类型 |
| `sessionId` | `string` | 是 | 会话 ID |
| `content` | `string \| BaiYingMessage \| BaiYingMessage[]` | 是 | 消息内容 |
| `sourceAgentType` | `string` | 否 | 来源 Agent 类型，设置后用于 Agent 间回调 |
| `traceId` | `string` | 否 | 追踪 ID，默认自动生成 |
| `userCode` | `string` | 否 | 租户或用户编码 |
| `userName` | `string` | 否 | 用户名 |
| `actionType` | `ActionType` | 否 | 默认 `ActionType.ASK_AGENT`，也可为 `ActionType.RESUME` |
| `extraPayload` | `Record<string, unknown>` | 否 | 协议 `body.extra_payload` |
| `metadata` | `Record<string, unknown>` | 否 | 协议 `header.metadata` |
| `parentMessageId` | `string` | 否 | 父消息 ID |
| `messageId` | `string` | 否 | 消息 ID，默认自动生成 |
| `targetWorkerId` | `string` | 否 | 直接投递到指定 Worker 控制流 |
| `requireOnlineWorker` | `boolean` | 否 | 是否要求在线 Worker，默认 `true` |

返回：

```typescript
interface SendMessageResponse {
    success: boolean;
    message_id: string;
    trace_id: string;
    target_worker_id: string;
    timestamp: number;
    status: string;
    error?: string;
    error_code?: string;
}
```

#### `client.sendCommand(command, streamName?)`

发送 `BaseCommand` 或自定义命令。未传 `streamName` 时按 `command.header.targetAgentType` 投递到 `agent_type` 控制流。

#### `client.cancelTask(params)`

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| `messageId` | `string` | 是 | 要取消的消息 ID |
| `sessionId` | `string` | 是 | 会话 ID |
| `reason` | `string` | 否 | 取消原因 |
| `targetAgentType` | `string` | 否 | 目标 Agent 类型，通常可省略 |
| `requestedBy` | `string` | 否 | 请求方，默认 `client` |
| `cancelMode` | `'graceful' \| 'force'` | 否 | 默认 `graceful` |

返回：

```typescript
interface CancelTaskResponse {
    success: boolean;
    message_id: string;
    execution_id: string;
    worker_id: string;
    status: string;
    timestamp: number;
    error?: string;
    cancelled_count?: number;
}
```

### WorkerRunner

```typescript
new WorkerRunner(
    workerOrOptions:
        | GatewayWorker
        | { workerId: string; agentTypes: string[]; registry?: WorkerRegistry },
    options?: {
        redisClient?: Redis;
        groupName?: string;
        fetchCount?: number;
    }
)
```

常用方法：

| 方法 | 说明 |
|------|------|
| `initialize()` | 抢占 Worker ID、创建 Stream 消费组、启动心跳和控制流循环 |
| `start({ handleSignals? })` | 推荐入口，自动初始化、轮询、处理、ACK、释放资源 |
| `stop()` | 停止主循环和控制流循环 |
| `release()` | 停止心跳、释放 Worker ID、关闭 Runner 拥有的 Redis 连接 |
| `poll({ count?, block? })` | 手动从 agent type 控制流读取消息 |
| `processAndAck(streamName, msgId, data)` | 执行业务处理并 ACK，同时维护 execution 状态 |
| `ack(streamName, msgId)` | 手动 ACK |
| `runControlOnce(block?)` | 手动读取一次 Worker 控制流 |
| `subscribe(handler, options?)` | 低层订阅模式，需要调用者处理和 ACK |
| `subscribeCancel(handler, options?)` | 注册取消指令回调 |

多数业务应使用 `start()`；只有需要完全自定义消费循环时才使用 `poll()` / `subscribe()`。

### GatewayWorker

继承 `GatewayWorker` 时需要实现：

```typescript
abstract getAgentTypes(): ReadonlyArray<string>;
abstract processCommand(command: GatewayCommand, context: AgentContext): Promise<ProcessCommandResult>;
```

`processCommand` 可以返回：

- `AgentTaskResult`
- `{ status, content, replyData, metadata, extraPayload }`
- 任意 JSON 可序列化对象，此时会作为 `replyData`
- `AgentState` 字符串

Worker 基类会自动处理：

- 保存用户消息到历史记录。
- 创建 `AgentContext`。
- 注入会话历史到命令的 `extraPayload.history`。
- 捕获取消并返回 `CANCELLED`。
- 任务完成时发送 `FINAL_ANSWER` 和必要的 `APP_STREAM_RESPONSE`。
- 有 `sourceAgentType` 时将结果封装为 `ResumeCommand` 回调给上游 Agent。

#### 挂起前后的 `header.metadata`

Agent 一旦挂起（`askUser`，或 `waitForReply` 的 `callAgent`）就会结束本次执行，
之后由一条 `ResumeCommand` 重新拉起。metadata 在两个方向上被还原，
规则是**刻意不同**的：

- **你的 handler 读到的**（恢复后那次调用的 `command.header.metadata`）：
  本次执行**最初被派发时**携带的 metadata，与唤醒消息自身的 metadata 合并，
  同名键以唤醒消息为准（它是更新、更具体的那一跳）。
  没有这层还原的话，你被派发时收到的一切会在第一次挂起时全部消失 ——
  回来只看得到 `askUser` 答复的 metadata，或者子调用回复的 metadata。
- **你的调用方收到的**：**它**派发你时带的那份 metadata，整体替换，
  再叠加你在返回值 `metadata` 里给出的内容。唤醒你的那条消息只是那一跳的
  管道数据，永远不会流到你的调用方——尽管你自己看得到它。

三个框架注入的键 —— `trace_parent_span_id`、`framework_parent_span_id`、
`langfuse_parent_observation_id` —— 始终描述当前这一跳，不会从记录里还原。

### AgentContext

| 方法 | 说明 |
|------|------|
| `emitChunk(event, eventType?)` | 推送流式回答，默认 `answerDelta` |
| `emitState(event, eventType?)` | 推送状态或思考日志，默认 `reasoningLogDelta` |
| `emitArtifact(event, eventType?)` | 推送文件产物 |
| `askUser(event)` | 向用户请求输入，并将当前任务标记为等待用户 |
| `callAgent(params)` | 调用单个下游 Agent |
| `dispatchGroup(params)` | 并发派发多个下游任务 |
| `collectGroupResults(taskGroupId, timeout?)` | 收集任务组结果 |
| `checkCancelled()` | 若任务已取消则抛出 `TaskCancelledError` |
| `isCancelRequested()` | 查询取消信号 |
| `updateExecutionState(status)` | 更新当前 execution 状态 |
| `getActiveWorkers()` | 获取在线 Worker |
| `callTool(name, kwargs?)` | 调用插件 Agent 配置中的工具 |

### GatewayDataEmitter

```typescript
new GatewayDataEmitter(redisClient?: Redis, params?: {
    sourceAgentType?: string;
    dataStreamName?: string;
})
```

| 方法 | 默认事件 | 默认内容类型 | 说明 |
|------|----------|--------------|------|
| `emitEvent(params)` | 自定义 | 自定义 | 底层事件上报 |
| `emitChunk(sessionId, traceId, event, options?)` | `EventType.ANSWER_DELTA` | `SseMessageType.text` (`1002`) | 文本或结构化 chunk |
| `emitState(sessionId, traceId, event, options?)` | `EventType.REASONING_LOG_DELTA` | `SseReasonMessageType.think_title` (`3003`) | 状态或思考日志 |
| `emitArtifact(sessionId, traceId, event, options?)` | `EventType.REASONING_LOG_DELTA` | `SseReasonMessageType.task_create_file` (`3010`) | 文件 URL |
| `askUser(sessionId, traceId, event, options?)` | `EventType.REASONING_LOG_DELTA` | `SseReasonMessageType.task_user_input` (`3013`) | 用户输入表单 |

所有事件默认写入 `QueueNames.session_data_stream(sessionId)`，构造时传入 `dataStreamName` 可固定写入指定流。

### WorkerRegistry

Worker 在线状态：

| 方法 | 说明 |
|------|------|
| `registerWorker(workerId, agentTypes)` | 注册 Worker 能力并发送一次心跳 |
| `registerWorkerMembership(workerId, agentTypes)` | 只注册能力，不改变在线租约 |
| `heartbeatWorker(workerId, leaseTtlSeconds?)` | 刷新在线租约 |
| `unregisterWorker(workerId)` | 移除在线状态和能力成员关系 |
| `markWorkerInactive(workerId, token?)` | 移除在线租约 |
| `unregisterWorkerMembership(workerId)` | 移除能力成员关系 |
| `claimWorkerId(workerId, ttlSeconds?)` | 抢占 Worker ID，防止重复启动 |
| `refreshWorkerIdLock(workerId, ttlSeconds?)` | 刷新抢占锁 |
| `releaseWorkerId(workerId, token?)` | 释放抢占锁 |
| `isWorkerOnline(workerId)` | 判断 Worker 是否在线 |
| `hasOnlineAgentType(agentType)` | 获取某类 Agent 的在线 Worker |
| `getOnlineWorkers(agentType)` | 获取在线 Worker 列表 |
| `getTargetWorker(agentType)` | 随机获取一个在线 Worker |
| `getAllWorkers()` | 获取当前在线 Worker 信息 |

Execution 状态：

| 方法 | 说明 |
|------|------|
| `initializeExecution(execution)` | 初始化 execution，包含时间线字段 |
| `saveExecution(execution)` | 保存或覆盖 execution |
| `getExecution(executionId, sessionId)` | 查询 execution |
| `getExecutionByMessageId(messageId, sessionId)` | 通过消息 ID 查询 execution |
| `getAllSessionExecutions(sessionId)` | 查询会话下全部 execution |
| `updateExecutionStatus(executionId, sessionId, status, extra?)` | 更新状态和时间线 |
| `updateExecutionStatusByMessage(messageId, sessionId, status)` | 按消息 ID 更新状态 |
| `markExecutionCancelling(executionId, sessionId, reason)` | 标记取消中 |
| `markCancelRequested(executionId, sessionId, reason?)` | 只设置取消请求，不改状态 |
| `markExecutionFinished(executionId, sessionId, status)` | 标记终态并写入完成时间 |

## 协议枚举

```typescript
enum ActionType {
    ASK_AGENT = "ASK_AGENT",
    RESUME = "RESUME",
    CANCEL_TASK = "CANCEL_TASK",
    ASK_USER = "ASK_USER",
}

enum AgentState {
    STARTING = "STARTING",
    CANCELLING = "CANCELLING",
    CANCELLED = "CANCELLED",
    COMPLETED = "COMPLETED",
    FAILED = "FAILED",
    RESUMED = "RESUMED",
    WAITING_AGENT = "WAITING_AGENT",
    WAITING_USER = "WAITING_USER",
    QUEUED = "QUEUED",
    CALLING_AGENT = "CALLING_AGENT",
}

enum EventType {
    ANSWER_DELTA = "answerDelta",
    REASONING_LOG_DELTA = "reasoningLogDelta",
    REASONING_LOG_START = "reasoningLogStart",
    REASONING_LOG_END = "reasoningLogEnd",
    APP_STREAM_RESPONSE = "appStreamResponse",
    FINAL_ANSWER = "finalAnswer",
    TASK_CREATE = "taskCreate",
    STEP_COMPLETE = "stepComplete",
    TASK_STOP = "taskStop",
}
```

## 相关示例

- [examples/demo_worker.ts](examples/demo_worker.ts)：继承 `GatewayWorker` 的 Worker 示例。
- [examples/send_test.ts](examples/send_test.ts)：发送任务示例。
- [examples/pubsub_usage_demo.ts](examples/pubsub_usage_demo.ts)：低层 Pub/Sub 风格示例。
- [examples/cancel_task_demo.ts](examples/cancel_task_demo.ts)：取消任务示例。
- [examples/custom_command_demo.ts](examples/custom_command_demo.ts)：自定义 Command 示例。
- [examples/atomic_usage_demo.ts](examples/atomic_usage_demo.ts)：原子化使用示例。

## 开发提示

- 修改消息路由、Redis 行为、Worker 生命周期或取消逻辑后，请运行 `npm test`。
- 协议字段保持 snake_case，例如 `target_agent_type`、`message_id`、`extra_payload`。
- SDK 源码使用 strict TypeScript、CommonJS 输出、4 空格缩进、单引号和分号。

### 异步消息分发

自动消费循环不再设置任务并发上限，未完成的业务任务不会阻止后续请求或回复被读取。旧 `maxConcurrency` 参数保留类型兼容性，但不再生效；`BYAI_WORKER_CONCURRENCY` 不再读取。`fetchCount` 只控制每个 Stream 的读取批量，不限制未完成任务总数。

Redis 阻塞读取使用独立的异步连接，空闲时仍等待消息。ACK、取消、租约续期、健康检查和正常退出时等待在途任务均保留；消费循环停滞不会因为还有未完成任务而被视为健康。业务准入及模型、工具资源控制由应用负责。持续超载时，无上限分发会增加内存占用和 Redis 待确认记录，不能据此保证生产容量。
