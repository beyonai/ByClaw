#!/usr/bin/env python3
"""校验 ContentBrief：先验它**是不是合法 YAML**，再验字段。

## 为什么需要它

ContentBrief 是选题阶段手写的 YAML，此前**全程无人校验**——
`scripts/` 下有 `validate_material_pass.py`、`validate_topic_clusters.py`，
唯独没有验这份交付物本身的。于是它能交付一份下游根本解析不了的文件。

实测（2026-09-11 一次大纲会话）：brief 的 `promise_audit` 那一行用 `"…"` 包整行，
内部又出现未转义的 `"先回答七个问题"`，引号嵌套破了。下游 `write-article` 读不了，
**花掉 9 次工具调用**去诊断和打补丁：`cp` 一份、`cat -A` 看不可见字符、
`awk NR==52`、三轮 `python replace`……而那 9 次里没有一次在写内容。

顺带还查出：`promise_audit` **根本不在契约里**，是选题侧自己造的字段。

## 一条纪律：解析失败的报错必须能直接照着改

「YAML 解析失败」这五个字等于没说——上次的代价就是从这句话到「第 52 行引号没闭合」
之间那 9 次调用。所以解析失败时要给出行号、原文、以及最常见的那个成因。
"""

from __future__ import annotations

import argparse
import io
import json
import sys
from pathlib import Path
from typing import Any
from .local_sources import bound_source

try:
    import yaml
except ImportError as exc:  # pragma: no cover - environment failure
    raise SystemExit("需要 PyYAML 才能校验 ContentBrief") from exc


SCHEMA_VERSION = "1.6"

#: 媒介无关的粗粒度类型。**不是**八份文章模板——ContentBrief 下游有
#: 文章、图文、视频三条线，这个字段对三条都要成立。
CONTENT_TYPES = {"analysis", "story", "tutorial", "comparison",
                 "announcement", "retrospective"}

#: 文章侧的写法模板提示。是**提示不是指令**，两可时留空比勉强填一个好。
TEMPLATE_HINTS = {"反常识观点", "场景化故事", "对比拆解", "深度解读",
                  "技术教程", "踩坑复盘", "产品发布", "离职故事"}

#: 契约认的顶层键。多出来的一律报出来——`promise_audit` 就是这么混进去的，
#: 而自造字段下游没人读，等于白写，还会让人以为那件事已经有人管了。
TOP_LEVEL_KEYS = {
    "profile_id",
    "brief_id", "topic_id", "schema_version", "workflow", "producer",
    "source_artifacts", "selection_status", "target_account", "series_context",
    "topic", "topic_clarity", "audience", "publishing", "positioning", "claims",
    "narrative", "evidence_pack", "production_requirements",
    "distribution_requirements", "modality_hints",
}

#: 五层必填，与 `references/content-brief-contract.md` 的「必须覆盖五层」对齐。
#: 每项是 (点分路径, 人话说明)。
REQUIRED = [
    ("topic.core_judgment", "唯一中心判断"),
    ("topic.working_title", "工作标题"),
    ("topic.distribution_title", "传播标题"),
    ("topic.content_type", "内容类型（媒介无关）"),
    ("target_account.channel_code", "渠道代码"),
    ("target_account.app_id", "账号 app_id"),
    ("audience.primary", "目标读者"),
    ("audience.current_problem", "读者当前问题"),
    ("narrative.central_question", "全文核心问题"),
    ("narrative.opening_tension", "开头张力"),
    ("topic_clarity.plain_language_judgment", "普通语言判断"),
    ("topic_clarity.status", "选题清晰度门禁结论"),
]


def dig(node: Any, path: str) -> Any:
    for key in path.split("."):
        if not isinstance(node, dict):
            return None
        node = node.get(key)
    return node


def _quote_hint(text: str, line_no: int) -> list[str]:
    """解析失败时，把最可能的那个成因指出来。

    **最常见的一种：整行用 `"…"` 包起来，内部又有未转义的 `"`。**
    这不是罕见花样——中文写作里「引号套引号」是常态，而 YAML 的双引号串
    必须把内部的 `"` 写成 `\\"`。
    """
    hints: list[str] = []
    lines = text.splitlines()
    lo, hi = max(0, line_no - 3), min(len(lines), line_no + 2)
    for idx in range(lo, hi):
        raw = lines[idx]
        value = raw.split(":", 1)[1].strip() if ":" in raw else raw.strip()
        quotes = value.count('"')
        if value.startswith('"') and quotes > 2:
            hints.append(
                "第 %d 行：值以 %s 开头，行内却有 %d 个双引号——"
                "**整行被双引号包起来时，内部的每个 %s 都要转义成 %s**。"
                "更省事的办法：改用单引号包整行，或者干脆不加引号。"
                % (idx + 1, '"', quotes, '"', '\\"'))
    if not hints:
        hints.append(
            "检查这几行的引号与缩进：值里含 `\"` `:` `#` `-` 时要整体加引号；"
            "**加了双引号就得把内部的 `\"` 转义**。")
    return hints


def load(path: Path) -> tuple[dict[str, Any] | None, list[str]]:
    with io.open(path, encoding="utf-8") as handle:
        text = handle.read()
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        line_no = (mark.line + 1) if mark else 0
        head = [f"ContentBrief 不是合法 YAML：{getattr(exc, 'problem', exc)}"]
        if line_no:
            lines = text.splitlines()
            head.append(f"位置：第 {line_no} 行第 {mark.column + 1} 列")
            for idx in range(max(0, line_no - 2), min(len(lines), line_no + 1)):
                head.append(f"  {idx + 1:>4} | {lines[idx][:160]}")
        head.extend(_quote_hint(text, line_no))
        head.append("⛔ **在这一步修好，不要交给下游去补**——"
                    "下游只能靠 `cat -A` 猜哪个字符坏了，实测为此烧掉 9 次调用。")
        return None, head
    if not isinstance(data, dict):
        return None, ["ContentBrief 顶层必须是映射（键值对），当前不是"]
    return data, []


def validate(brief: dict[str, Any], *, brief_path: Path | None = None) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    version = str(brief.get("schema_version") or "").strip()
    if not version:
        errors.append("schema_version 不能为空")
    elif version != SCHEMA_VERSION:
        warnings.append(
            f"schema_version={version}，当前契约是 {SCHEMA_VERSION}。"
            "低版本可继续使用，但 content_type 与 template_hint 可能缺失——"
            "下游按缺失处理，不会报错。")

    profile = brief.get("profile_id")
    if profile is not None and profile not in {"generic.article", "wechat.public_article"}:
        errors.append("profile_id 必须为 generic.article|wechat.public_article")
    if profile == "generic.article" and brief.get("target_account"):
        errors.append("generic.article 不应绑定发布账号；需要账号时使用渠道 profile")
    for path, label in REQUIRED:
        if profile == "generic.article" and path.startswith("target_account."):
            continue
        if not str(dig(brief, path) or "").strip():
            errors.append(f"{path} 不能为空（{label}）")

    unknown = sorted(set(brief) - TOP_LEVEL_KEYS)
    if unknown:
        warnings.append(
            "出现契约之外的顶层字段：" + "、".join(unknown)
            + "。**下游没人读自造字段**，等于白写，还会让人以为那件事已经有人管了。"
            "确实需要就先改契约（references/content-brief-contract.md）。")

    content_type = str(dig(brief, "topic.content_type") or "").strip()
    if content_type and content_type not in CONTENT_TYPES:
        errors.append(
            f"topic.content_type={content_type!r} 不合法，只能是 "
            + "|".join(sorted(CONTENT_TYPES))
            + "。**这是媒介无关的粗粒度类型**，不是八份文章模板之一——"
            "文章该用哪份模板填 modality_hints.article.template_hint。")
    if content_type in TEMPLATE_HINTS:
        errors.append(
            f"topic.content_type={content_type!r} 填的是**文章模板名**。"
            "ContentBrief 是媒介无关任务书，下游还有图文与视频两条线；"
            "模板提示请填到 modality_hints.article.template_hint。")

    hint = str(dig(brief, "modality_hints.article.template_hint") or "").strip()
    if hint:
        if hint not in TEMPLATE_HINTS:
            errors.append(
                f"modality_hints.article.template_hint={hint!r} 不合法，只能是 "
                + "|".join(sorted(TEMPLATE_HINTS)) + "，或留空。")
        elif not str(dig(brief, "modality_hints.article.template_hint_basis") or "").strip():
            errors.append(
                "填了 template_hint 就要填 template_hint_basis 说明依据。"
                "**两可时留空更好**——写错的提示会把下游往错方向推。")

    options = dig(brief, "topic_clarity.title_framing_review.options")
    if isinstance(options, list) and options and not 4 <= len(options) <= 10:
        errors.append(
            f"title_framing_review.options 当前 {len(options)} 项，契约要求 4—10 项。"
            "同一 core_judgment 的不同入口，不是不同的选题。")

    claims = brief.get("claims")
    if isinstance(claims, list) and not claims:
        warnings.append("claims 为空：没有支撑主张，下游拆不出章节与证据映射。")

    errors.extend(_source_path_errors(brief, brief_path=brief_path))

    return errors, warnings


def _source_path_errors(brief: dict[str, Any], *, brief_path: Path | None = None) -> list[str]:
    """证据来源必须是路径或链接，**不能是文章标题**。

    云盘目录名被剥过非法字符——`本体 AS 代码：…「全栈」.md` 在云盘上实际是
    `本体AS代码：…全栈.md`（无空格、无书名号）。按标题写，下游拿不到路径，
    只能枚举加模糊比对；实测为此多跑了好几轮。

    这个字段还是下游 `verification_source` 的直接输入：这一步写对，
    写作那一步能一路用到底。
    """
    out: list[str] = []
    for origin in ("internal_refs", "external_refs"):
        for index, item in enumerate(dig(brief, f"evidence_pack.{origin}") or []):
            if not isinstance(item, dict):
                continue
            for pos, source in enumerate(item.get("sources") or []):
                url = str((source or {}).get("url") or "").strip() \
                    if isinstance(source, dict) else str(source or "").strip()
                if not url:
                    continue
                if brief.get("profile_id") == "generic.article" and bound_source(
                        url, brief.get("source_artifacts", []), brief_path):
                    continue
                if url.startswith("/") or url.lower().startswith(("http://", "https://")):
                    continue
                out.append(
                    f"evidence_pack.{origin}[{index}].sources[{pos}].url=「{url[:40]}」"
                    "看着是标题不是路径。填 metadata-search 返回的 filePath 原值"
                    "（/成品/…、/素材/…）或 http(s) 链接——**云盘文件名被剥过空格与书名号，"
                    "按标题写下游对不上**。")
    return out


def main() -> int:
    parser = argparse.ArgumentParser(
        description="校验 ContentBrief：先验 YAML 合法性，再验必填与枚举。")
    parser.add_argument("--input", required=True, help="ContentBrief YAML 路径")
    args = parser.parse_args()

    path = Path(args.input)
    if not path.is_file():
        print(json.dumps({"status": "fail", "failures": [f"文件不存在：{path}"]},
                         ensure_ascii=False))
        return 2

    brief, parse_errors = load(path)
    if brief is None:
        print(json.dumps({"status": "fail", "failures": parse_errors},
                         ensure_ascii=False, indent=2))
        return 1

    errors, warnings = validate(brief, brief_path=path)
    print(json.dumps({"status": "fail" if errors else "pass",
                      "failures": errors, "warnings": warnings},
                     ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
