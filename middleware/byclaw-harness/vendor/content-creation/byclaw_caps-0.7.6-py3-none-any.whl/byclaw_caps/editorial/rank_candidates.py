#!/usr/bin/env python3
"""Run overlap analysis, candidate review planning, and editorial scoring together."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from . import check_overlap
from . import score_editorial
from .topic_cli_io import read_json, write_json


DEFAULT_MAX_REQUIRED_PER_CANDIDATE = 2
DEFAULT_MAX_BODY_REQUESTS = 2
VALID_SELECTION_METHODS = {"lexical", "agent_semantic"}


def _identifier(item: dict[str, Any]) -> str:
    value = item.get("topic_id") or item.get("instance_id") or item.get("id")
    return str(value).strip() if value is not None else ""


def _unique(values: list[str]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = str(value).strip()
        if normalized and normalized not in seen:
            output.append(normalized)
            seen.add(normalized)
    return output


def _required_matches(
    result: dict[str, Any],
    review_threshold: float,
    maximum: int,
) -> list[str]:
    matches = [
        item for item in result.get("top_matches", [])
        if isinstance(item, dict) and item.get("history_id")
    ]
    if not matches or not result.get("semantic_review_required"):
        return []
    top_score = float(matches[0].get("score") or 0)
    if top_score < review_threshold:
        return []
    selected = [str(matches[0]["history_id"])]
    relative_floor = top_score * 0.8
    for match in matches[1:maximum]:
        score = float(match.get("score") or 0)
        if score >= review_threshold and score >= relative_floor:
            selected.append(str(match["history_id"]))
    return _unique(selected)


def _history_options(result: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "history_id": str(item["history_id"]),
            "title": item.get("title"),
            "lexical_score": float(item.get("score") or 0),
        }
        for item in result.get("top_matches", [])[:3]
        if isinstance(item, dict) and item.get("history_id")
    ]


def _prepare_candidates(
    candidates: list[dict[str, Any]],
    overlap_result: dict[str, Any],
    reviewed_history_ids: set[str],
    max_required_per_candidate: int,
) -> list[dict[str, Any]]:
    overlap_by_id = {
        str(item["candidate_id"]): item
        for item in overlap_result.get("results", [])
        if isinstance(item, dict) and item.get("candidate_id")
    }
    scope = str(overlap_result["comparison_scope"])
    review_threshold = float(overlap_result["review_threshold"])
    corpus_ids = set(overlap_result["history_ids"])
    prepared: list[dict[str, Any]] = []
    for index, raw_candidate in enumerate(candidates):
        candidate = deepcopy(raw_candidate)
        candidate_id = str(
            candidate.get("candidate_id")
            or candidate.get("topic_id")
            or f"candidate-{index + 1}"
        )
        result = overlap_by_id[candidate_id]
        semantic_required = bool(result.get("semantic_review_required"))
        explicit_review = candidate.get("history_review")
        if not isinstance(explicit_review, dict):
            explicit_review = {}
        explicit_required = _unique([
            str(value) for value in explicit_review.get("required_history_ids") or []
        ])
        invalid_required = set(explicit_required) - corpus_ids
        if invalid_required:
            raise ValueError(
                f"{candidate_id}.required_history_ids 不在历史语料中: "
                f"{', '.join(sorted(invalid_required))}"
            )
        explicit_method = str(explicit_review.get("selection_method") or "").strip()
        explicit_reason = str(explicit_review.get("selection_reason") or "").strip()
        explicit_valid = (
            semantic_required
            and bool(explicit_required)
            and explicit_method == "agent_semantic"
            and bool(explicit_reason)
        )
        lexical_required = _required_matches(
            result, review_threshold, max_required_per_candidate
        )
        if not semantic_required:
            required_ids = []
            selection_method = "not_required"
            selection_basis = "claim_aware_history"
            selection_reason = "历史语料已具备完整核心判断且无需追加正文"
            selection_confidence = "not_required"
            semantic_selection_required = False
        elif explicit_valid:
            required_ids = explicit_required
            selection_method = "agent_semantic"
            selection_basis = "agent_semantic_judgment_before_body_injection"
            selection_reason = explicit_reason
            selection_confidence = "sufficient"
            semantic_selection_required = False
        elif lexical_required:
            required_ids = lexical_required
            selection_method = "lexical"
            selection_basis = "lexical_top_matches_before_body_injection"
            selection_reason = (
                f"最高词面相似度 {float(result.get('max_overlap') or 0):.4f} "
                f"达到阈值 {review_threshold:.4f}"
            )
            selection_confidence = "sufficient"
            semantic_selection_required = False
        else:
            required_ids = []
            selection_method = "pending"
            selection_basis = "lexical_candidates_require_semantic_judgment"
            selection_reason = "词面相似度不足，需结合候选核心判断与历史标题进行语义选择"
            selection_confidence = "insufficient"
            semantic_selection_required = semantic_required
        reviewed_ids = [value for value in required_ids if value in reviewed_history_ids]
        selection_valid = not semantic_required or selection_confidence == "sufficient"
        completed = (
            not semantic_required
            or (
                selection_valid
                and bool(required_ids)
                and set(required_ids).issubset(reviewed_history_ids)
            )
        )
        if not semantic_required:
            coverage = "full" if scope == "claim_aware" else "sufficient"
        elif completed and required_ids:
            coverage = "sufficient"
        elif reviewed_ids:
            coverage = "targeted"
        else:
            coverage = "none"
        candidate["history_review"] = {
            "comparison_scope": scope,
            "semantic_review_required": semantic_required,
            "semantic_review_completed": completed,
            "review_coverage": coverage,
            "selection_basis": selection_basis,
            "selection_method": selection_method,
            "selection_reason": selection_reason,
            "selection_confidence": selection_confidence,
            "semantic_selection_required": semantic_selection_required,
            "history_options": _history_options(result),
            "required_history_ids": required_ids,
            "reviewed_history_ids": reviewed_ids,
        }
        confidence_checks = deepcopy(candidate.get("confidence_checks") or {})
        confidence_checks["history_claim_dedup"] = completed
        candidate["confidence_checks"] = confidence_checks
        prepared.append(candidate)
    return prepared


def _semantic_selection_plan(
    score_result: dict[str, Any],
    prepared_candidates: list[dict[str, Any]],
) -> dict[str, Any]:
    candidate_by_id = {
        str(item.get("candidate_id") or item.get("topic_id")): item
        for item in prepared_candidates
    }
    items = []
    for candidate_id in score_result.get("tiebreak_review_candidate_ids", []):
        review = candidate_by_id[str(candidate_id)]["history_review"]
        if review.get("semantic_selection_required"):
            items.append({
                "candidate_id": str(candidate_id),
                "history_options": review.get("history_options", []),
                "required_patch": {
                    "selection_method": "agent_semantic",
                    "selection_reason": "说明该历史文章与候选核心判断为何相关",
                    "required_history_ids": [],
                },
            })
    return {
        "required": bool(items),
        "items": items,
    }


def _retrieval_plan(
    score_result: dict[str, Any],
    prepared_candidates: list[dict[str, Any]],
    history: list[dict[str, Any]],
    reviewed_history_ids: set[str],
    maximum: int,
) -> dict[str, Any]:
    candidate_by_id = {
        str(item.get("candidate_id") or item.get("topic_id")): item
        for item in prepared_candidates
    }
    history_by_id = {_identifier(item): item for item in history if _identifier(item)}
    missing: list[str] = []
    for candidate_id in score_result.get("tiebreak_review_candidate_ids", []):
        review = candidate_by_id[str(candidate_id)]["history_review"]
        missing.extend(
            value for value in review["required_history_ids"]
            if value not in reviewed_history_ids
        )
    selected_ids = _unique(missing)[:maximum]
    items = []
    for history_id in selected_ids:
        source = history_by_id.get(history_id, {})
        items.append({
            "history_id": history_id,
            "object_code": source.get("object_code") or "WritingOutput",
            "kb_resource_id": source.get("kb_resource_id"),
            "kb_file_path": source.get("kb_file_path"),
            "title": source.get("title") or source.get("name"),
        })
    return {
        "required": bool(selected_ids),
        "blocked_by_semantic_selection": any(
            candidate_by_id[str(candidate_id)]["history_review"].get(
                "semantic_selection_required"
            )
            for candidate_id in score_result.get("tiebreak_review_candidate_ids", [])
        ),
        "candidate_ids": score_result.get("tiebreak_review_candidate_ids", []),
        "history_ids": selected_ids,
        "items": items,
        "limit": maximum,
        "unresolved_history_ids": _unique(missing)[maximum:],
    }


def run(params: dict[str, Any]) -> dict[str, Any]:
    candidates = params.get("candidates") or []
    history = params.get("history") or []
    if not isinstance(candidates, list) or not all(isinstance(item, dict) for item in candidates):
        raise ValueError("candidates 必须是对象数组")
    if not isinstance(history, list) or not all(isinstance(item, dict) for item in history):
        raise ValueError("history 必须是对象数组")
    reviewed_history_ids = {
        str(value).strip() for value in params.get("reviewed_history_ids", [])
        if str(value).strip()
    }
    max_required = int(
        params.get("max_required_history_per_candidate", DEFAULT_MAX_REQUIRED_PER_CANDIDATE)
    )
    max_body_requests = int(params.get("max_body_requests", DEFAULT_MAX_BODY_REQUESTS))
    if not 1 <= max_required <= 3:
        raise ValueError("max_required_history_per_candidate 必须在 1..3 之间")
    if not 1 <= max_body_requests <= 2:
        raise ValueError("max_body_requests 必须在 1..2 之间")

    overlap_result = check_overlap.analyze({
        "candidates": candidates,
        "history": history,
        "threshold": params.get("threshold", 0.55),
        "review_threshold": params.get("review_threshold", 0.15),
    })
    prepared_candidates = _prepare_candidates(
        candidates, overlap_result, reviewed_history_ids, max_required
    )
    history_context = {
        key: overlap_result[key]
        for key in (
            "history_count",
            "history_with_claim_context_count",
            "history_ids",
            "comparison_scope",
        )
    }
    score_result = score_editorial.run({
        "history_context": history_context,
        "candidates": prepared_candidates,
    })
    semantic_selection_plan = _semantic_selection_plan(
        score_result, prepared_candidates
    )
    return {
        "ok": True,
        "overlap": overlap_result,
        "prepared_candidates": prepared_candidates,
        "scoring": score_result,
        "semantic_selection_plan": semantic_selection_plan,
        "body_retrieval_plan": _retrieval_plan(
            score_result,
            prepared_candidates,
            history,
            reviewed_history_ids,
            max_body_requests,
        ),
    }


if __name__ == "__main__":
    write_json(run(read_json()))
