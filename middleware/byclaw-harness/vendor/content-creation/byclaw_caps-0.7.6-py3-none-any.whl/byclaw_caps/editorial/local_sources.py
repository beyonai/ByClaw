"""Resolve local editorial evidence against an article task ledger."""
from pathlib import Path
import hashlib

import yaml


def bound_source(source: str, bindings: list, context_path: Path | None) -> bool:
    if context_path is None:
        return False
    root = next((p for p in context_path.resolve().parents
                 if (p / ".runtime/artifacts.yaml").is_file()), None)
    if root is None:
        return False
    try:
        ledger = yaml.safe_load((root / ".runtime/artifacts.yaml").read_text(encoding="utf-8"))["artifacts"]
        target = (root / source).resolve()
        if not target.is_relative_to(root) or not target.is_file():
            return False
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        for binding in bindings:
            if (root / binding["relative_path"]).resolve() != target:
                continue
            registered = ledger[binding["artifact_id"]]
            if (digest == binding["sha256"] == registered["sha256"]
                    and (root / registered["path"]).resolve() == target):
                return True
    except (OSError, ValueError, KeyError, TypeError, yaml.YAMLError):
        return False
    return False
