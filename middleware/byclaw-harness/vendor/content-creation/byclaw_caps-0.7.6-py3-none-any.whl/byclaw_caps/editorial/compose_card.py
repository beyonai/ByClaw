#!/usr/bin/env python3
"""把横版素材装配成 3:4 竖版卡片。

文章里的 16:9 流程图塞进 1080×1440 卡片，拉伸会变形、裁切会丢内容——两者都不可接受。
但一律重画也不合理：那张图**内容是对的、事实是核过的**，重画既费钱又可能引入新错。

正确做法是把横版素材当作卡片里的**一个区块**：

```
┌──────────────────────┐ 1080×1440
│  标题带   280px       │  卡片标题
├──────────────────────┤
│  素材区 1080×608      │  16:9 素材等宽放置，等比缩放不裁切
├──────────────────────┤
│  说明带   552px       │  一句话说清读者要带走什么
└──────────────────────┘
```

与视频侧的竖屏三段式布局（`byclaw_caps.video vertical`）同一思路：
素材尺寸各异，由确定性脚本收敛，不靠模型。

归一化用 FFmpeg 而不是 Pillow，与项目「只用标准库 + ffmpeg 子进程」的零依赖约定一致。
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

try:
    from byclaw_caps.shared.channel_specs import MEDIUM_IMAGE_TEXT_POST, PORTRAIT_SIZE, resolve_channel_size
except ImportError:  # direct script execution
    from byclaw_caps.shared.channel_specs import (  # type: ignore
        MEDIUM_IMAGE_TEXT_POST,
        PORTRAIT_SIZE,
        resolve_channel_size,
    )

VERSION = "1.0.0"

CARD_WIDTH, CARD_HEIGHT = PORTRAIT_SIZE

PAD_COLOR = "white"
BACKGROUND_COLOR = "white"

_TITLE_HEIGHT = 280


def _even(value: int) -> int:
    """向上取偶：yuv420p 与多数编码器要求偶数尺寸。"""
    return value if value % 2 == 0 else value + 1


def band_layout() -> dict[str, dict[str, int]]:
    """三条带的 y 偏移与高度，自上而下：标题、素材、说明。"""
    asset_height = _even(round(CARD_WIDTH * 9 / 16))
    title_height = _even(_TITLE_HEIGHT)
    caption_height = CARD_HEIGHT - title_height - asset_height
    if caption_height <= 0 or caption_height % 2 != 0:
        raise ValueError("三段式高度分配无法满足偶数约束，请调整 _TITLE_HEIGHT")

    return {
        "title": {"y": 0, "height": title_height, "width": CARD_WIDTH},
        "asset": {"y": title_height, "height": asset_height, "width": CARD_WIDTH},
        "caption": {
            "y": title_height + asset_height,
            "height": caption_height,
            "width": CARD_WIDTH,
        },
    }


def build_filter() -> str:
    """把横版素材合入竖版卡片；输入 0 为素材，输出标签 `[card]`。

    标题与说明文字由 HTML 渲染层叠加，此处只负责画布与素材区。
    """
    asset = band_layout()["asset"]
    return (
        f"[0:v]scale={CARD_WIDTH}:{asset['height']}"
        ":force_original_aspect_ratio=decrease,"
        f"pad={CARD_WIDTH}:{asset['height']}:(ow-iw)/2:(oh-ih)/2:{PAD_COLOR},"
        "setsar=1[asset];"
        f"color=c={BACKGROUND_COLOR}:s={CARD_WIDTH}x{CARD_HEIGHT}[bg];"
        f"[bg][asset]overlay=0:{asset['y']}[card]"
    )


class ComposeError(RuntimeError):
    """卡片装配失败。"""


def _resolve_ffmpeg(explicit: str | None = None) -> str:
    candidate = explicit or shutil.which("ffmpeg")
    if not candidate:
        raise ComposeError("未找到 ffmpeg；卡片装配依赖 FFmpeg，请先安装或显式传入路径")
    return candidate


def compose(source: Path, target: Path, *, ffmpeg: str | None = None) -> Path:
    """把单张横版素材装配为竖版卡片底图。"""
    if not source.is_file():
        raise ComposeError(f"素材不存在: {source}")
    binary = _resolve_ffmpeg(ffmpeg)
    target.parent.mkdir(parents=True, exist_ok=True)
    command = [
        binary, "-y", "-loglevel", "error",
        "-i", str(source),
        "-filter_complex", build_filter(),
        "-map", "[card]",
        "-frames:v", "1",
        str(target),
    ]
    try:
        completed = subprocess.run(command, capture_output=True, text=True)
    except OSError as exc:
        raise ComposeError(f"调用 ffmpeg 失败: {type(exc).__name__}") from exc
    if completed.returncode != 0:
        detail = (completed.stderr or "").strip().splitlines()
        raise ComposeError(
            f"ffmpeg 装配失败（退出码 {completed.returncode}）："
            f"{detail[-1] if detail else '无错误输出'}"
        )
    if not target.is_file():
        raise ComposeError(f"ffmpeg 未产出输出文件: {target}")
    return target


def describe(channel_ref: str = "wechat_public_account") -> dict[str, object]:
    width, height = resolve_channel_size(channel_ref, MEDIUM_IMAGE_TEXT_POST)
    return {
        "schema_version": "1.0",
        "producer": {"skill": "write-image-text-post", "version": VERSION},
        "channel_ref": channel_ref,
        "card": [width, height],
        "bands": band_layout(),
        "filter_complex": build_filter(),
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="把横版素材装配为 3:4 竖版卡片底图（等比缩放 + 白底补边）"
    )
    parser.add_argument("--source", help="横版素材路径")
    parser.add_argument("--output", help="卡片底图输出路径")
    parser.add_argument("--channel-ref", default="wechat_public_account")
    parser.add_argument("--ffmpeg", help="显式 ffmpeg 路径")
    parser.add_argument("--describe", action="store_true", help="只输出版式参数，不执行")
    args = parser.parse_args()

    if args.describe:
        print(json.dumps(describe(args.channel_ref), ensure_ascii=False, indent=2))
        return 0
    if not args.source or not args.output:
        print(
            json.dumps(
                {
                    "status": "failed",
                    "error_code": "missing_arguments",
                    "message": "--source 与 --output 必填，或使用 --describe",
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 2

    try:
        written = compose(Path(args.source), Path(args.output), ffmpeg=args.ffmpeg)
    except ComposeError as exc:
        print(
            json.dumps(
                {"status": "failed", "error_code": "compose_failed", "message": str(exc)},
                ensure_ascii=False,
                indent=2,
            )
        )
        return 2

    print(
        json.dumps(
            {"status": "ok", "output": str(written), "card": [CARD_WIDTH, CARD_HEIGHT]},
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
