"""原写作 Skills 迁入的公共专业程序；通过 python -m byclaw_caps.editorial.<模块> 调用。"""

# 公共命令JSON固定UTF-8，兼容Windows管道捕获。
import sys
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(encoding="utf-8")
