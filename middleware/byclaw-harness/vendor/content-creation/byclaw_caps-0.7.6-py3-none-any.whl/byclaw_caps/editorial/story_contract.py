"""Story-specific contracts shared by planning and article validation.

Omitted content_kind keeps the historical analysis path. Fictional characters
never exempt real product claims from the existing staged fact checks.
"""
from __future__ import annotations

from collections.abc import Mapping
import re

CONTENT_KINDS = frozenset({"analysis", "story_marketing", "short_fiction"})
STORY_KINDS = CONTENT_KINDS - {"analysis"}
TRUTH_MODES = frozenset({"real_case", "adapted_case", "fictional_scenario"})
BODY_FORMATS = frozenset({"headings", "scenes"})
SUMMARY_MODES = frozenset({"visible", "hidden"})
READING_PROFILE_VALUES = frozenset({"default", "story_modern", "story_kaiti", "story_serif"})
SCENE_ID_RE = re.compile(r"section-[A-Za-z0-9_-]+\Z")


def content_kind(plan: Mapping) -> str:
    return str(plan.get("content_kind") or "analysis")


def is_story(plan: Mapping) -> bool:
    return content_kind(plan) in STORY_KINDS


def _narrative(plan: Mapping) -> Mapping:
    value = plan.get("narrative_plan")
    return value if isinstance(value, Mapping) else {}


def body_format(plan: Mapping) -> str:
    return str(_narrative(plan).get("body_format") or ("scenes" if is_story(plan) else "headings"))


def summary_mode(plan: Mapping) -> str:
    return str(_narrative(plan).get("summary_mode") or ("hidden" if is_story(plan) else "visible"))


def _text(value) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _strings(value, *, nonempty: bool = True) -> bool:
    return (isinstance(value, list) and (bool(value) or not nonempty)
            and all(_text(item) for item in value))


def validate_story_contract(plan: Mapping) -> list[str]:
    errors: list[str] = []
    kind = content_kind(plan)
    if kind not in CONTENT_KINDS:
        return ["content_kind 必须为 analysis|story_marketing|short_fiction"]
    if body_format(plan) not in BODY_FORMATS:
        errors.append("narrative_plan.body_format 必须为 headings|scenes")
    if summary_mode(plan) not in SUMMARY_MODES:
        errors.append("narrative_plan.summary_mode 必须为 visible|hidden")
    if not is_story(plan):
        if body_format(plan) != "headings" or summary_mode(plan) != "visible":
            errors.append("analysis 继续使用 headings + visible；故事正文请显式选择故事 content_kind")
        return errors

    truth = str(plan.get("truth_mode") or "")
    if truth not in TRUTH_MODES:
        errors.append("故事 truth_mode 必须为 real_case|adapted_case|fictional_scenario")
    story = plan.get("story_plan")
    if not isinstance(story, Mapping):
        errors.append("故事必须提供 story_plan 对象")
        story = {}
    for field in ("viewpoint", "protagonist_goal", "central_conflict", "ending_intent"):
        if not _text(story.get(field)):
            errors.append(f"story_plan.{field} 不能为空")
    if truth in {"real_case", "adapted_case"} and not _strings(story.get("source_refs")):
        errors.append("真实/改编故事的 story_plan.source_refs 必须提供非空来源数组")
    if truth == "adapted_case" and not _text(story.get("adaptation_notes")):
        errors.append("改编案例必须填写 story_plan.adaptation_notes，说明改编范围")
    # truth_mode is editorial metadata, not an instruction to add a disclaimer.
    # Whether context misrepresents fiction as customer evidence is a semantic
    # review decision; a mandatory sentence cannot establish that boundary.

    sections = _narrative(plan).get("sections")
    if not isinstance(sections, list) or not sections:
        errors.append("故事 narrative_plan.sections 必须是非空数组")
        sections = []
    for index, section in enumerate(sections, 1):
        if not isinstance(section, Mapping):
            errors.append(f"narrative_plan.sections[{index}] 必须是对象")
            continue
        sid = str(section.get("section_id") or "")
        if body_format(plan) == "scenes" and not SCENE_ID_RE.fullmatch(sid):
            errors.append(f"场景 section_id 必须匹配 section-[A-Za-z0-9_-]+：{sid!r}")
        section_kind = str(section.get("section_kind", "scene"))
        if section_kind not in {"scene", "explanation"}:
            errors.append(f"{sid}.section_kind 必须为 scene|explanation")
        elif section_kind == "scene":
            scene = section.get("scene")
            if not isinstance(scene, Mapping):
                scene = {}
            for field in ("goal", "obstacle", "action", "change"):
                if not _text(scene.get(field)):
                    errors.append(f"{sid}.scene.{field} 不能为空")
        else:
            for field in ("section_judgment", "evidence_summary"):
                if not _text(section.get(field)):
                    errors.append(f"{sid}.{field} 不能为空（说明段仍需判断与依据）")

    if kind != "story_marketing":
        return errors
    marketing = plan.get("marketing_plan")
    if not isinstance(marketing, Mapping):
        errors.append("story_marketing 必须提供 marketing_plan 对象")
        marketing = {}
    for field in ("reader_problem", "product_role", "introduction_trigger",
                  "conversion_goal", "cta", "offer_terms"):
        if not _text(marketing.get(field)):
            errors.append(f"marketing_plan.{field} 不能为空")
    claim_ids = marketing.get("product_claim_ids")
    if not _strings(claim_ids):
        errors.append("marketing_plan.product_claim_ids 必须列出真实产品主张的非空 ID 数组")
        return errors
    if len(set(claim_ids)) != len(claim_ids):
        errors.append("marketing_plan.product_claim_ids 不能重复")
    argument = plan.get("argument_plan") or {}
    production = plan.get("production_plan") or {}
    claims = {c.get("claim_id"): c for c in argument.get("supporting_claims", [])
              if isinstance(c, Mapping)}
    checks = {c.get("check_id"): c for c in production.get("fact_checks", [])
              if isinstance(c, Mapping)}
    for cid in claim_ids:
        claim = claims.get(cid)
        if claim is None:
            errors.append(f"产品主张 {cid} 未在 argument_plan.supporting_claims 中定义")
            continue
        if not _strings(claim.get("evidence_refs")):
            errors.append(f"产品主张 {cid}.evidence_refs 不能为空；虚构情节不能替代产品证据")
        fact_ids = claim.get("fact_check_ids")
        if not _strings(fact_ids):
            errors.append(f"产品主张 {cid}.fact_check_ids 必须关联真实核验项")
            continue
        for fid in fact_ids:
            check = checks.get(fid)
            if check is None:
                errors.append(f"产品主张 {cid} 引用不存在的 fact check：{fid}")
            elif check.get("status") not in {"verified", "unresolved"}:
                errors.append(f"产品核验 {fid} 必须 verified|unresolved，不能 not_applicable")
    return errors
