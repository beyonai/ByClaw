#!/usr/bin/env python3
"""校验 material_first_pass 的 from_material 是否逐条可在素材中定位。

`fact_vs_inference` 把素材事实与编辑推断分开，其价值全部依赖前者**可机器验证**。
平台实跑中它退化成了概括：5 条只有 1 条逐字命中，其余最长连续匹配仅 10%–37%。
内容忠实、没有编造，但无法与原文比对——"事实"与"推断"的分界随之失效。

因此这里做硬校验：去掉空白与标点后，引文必须是素材的连续子串。
标点、引号、空格差异容忍；把多个分句揉成一句总结不容忍。
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

try:
    from .topic_cli_io import read_json, write_json
except ImportError:  # direct script execution
    from .topic_cli_io import read_json, write_json  # type: ignore

# `[文字](链接)` / `![alt](链接)` **先归约成文字**，把 URL 整段扔掉。
# 光靠 _NOISE 剥 `[](` 是不够的——URL 本身是真字符，会卡在引文中间：
#   源文 `See [Object types](/素材/…/object-types.md) for details`
#   去噪 `SeeObjecttypes/素材/…/objecttypesmdfordetails`
#   引文 `SeeObjecttypesfordetails`  → 不连续，落空。
_LINK = re.compile(r"!?\[([^\]]*)\]\([^)]*\)")

# 抄录时常见的无害差异，**三类**：
#   ① 空白　② 中英文标点、引号、括号　③ **markdown 标记**
#
# ③ 是补进来的。原先只认 ①②，于是 `*` `_` 反引号被**当成内容**——
# 源文 `An **action type** defines…` 去噪后是 `An**actiontype**defines…`，
# 而人抄的是 `Anactiontypedefines…`，**永远不是子串**。
# 英文 markdown 技术文档满篇粗体与链接，实测六种常见形态四种落空，
# 而报错只说「不要概括」，把人指向完全错误的方向。
#
# 标记既不是内容，也不是标点，是**第三类**。两边同样剥掉，不会放过编造的引文。
_NOISE = re.compile(r"""[\s，。、；：？！,.;:?!'"“”‘’（）()\[\]【】《》—\-·*_`>|~#]+""")


def normalize(text: Any) -> str:
    return _NOISE.sub("", _LINK.sub(r"\1", str(text or "")))


#: `from_material` 的条数上限。六个判断，一个判断一条来源，留一条余量。
MAX_FROM_MATERIAL = 6


def locate(quote: Any, source: Any) -> bool:
    """引文去噪后必须是素材去噪后的连续子串。"""
    needle = normalize(quote)
    if not needle:
        return False
    return needle in normalize(source)


def _longest_fragment(needle: str, joined: str) -> tuple[int, int]:
    """needle 里**最长的、能在素材中找到的连续片段**，返回 (起点, 长度)。

    对每个起点二分长度。`needle` 是一句引文（几十到二百字），
    调用次数是 len × log(len)，几百次子串查找，够快。
    """
    best_at, best_len = 0, 0
    for i in range(len(needle)):
        if len(needle) - i <= best_len:
            break                      # 剩下的再长也超不过已有的
        lo, hi = best_len, len(needle) - i
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if needle[i:i + mid] in joined:
                lo = mid
            else:
                hi = mid - 1
        if lo > best_len:
            best_at, best_len = i, lo
    return best_at, best_len


def diagnose(needle: str, joined: str, *, window: int = 20) -> dict[str, Any]:
    """不命中时，说清**差在哪几个字**、素材里那处到底写的是什么。

    **只说「引文未逐字出现」是不够的。** 实测：一个字之差（把「账号主要围绕」
    抄成「本号主要围绕」），调用方猜了 8 轮原因——先怀疑省略号、再怀疑弯引号、
    最后怀疑素材根本没落盘，全是错的。**判据对了，但没告诉它差在哪。**

    锚点用**最长可匹配片段**而不是最长前缀：开头就差的时候，前缀法只能报
    「前 1 字对得上」——那 1 个字多半是撞上的，指不出问题。
    """
    at, length = _longest_fragment(needle, joined)
    info: dict[str, Any] = {"matched_chars": length, "total_chars": len(needle)}

    if length < 6:
        info["diverged_at"] = (
            "整句都对不上（最长只匹配 %d 字）——多半是 source 指错了文件，"
            "或者这句是你概括出来的，素材里没有原句。" % length)
        return info

    src_at = joined.find(needle[at:at + length])
    before_you = needle[:at]
    after_you = needle[at + length:]
    before_src = joined[max(0, src_at - window):src_at]
    after_src = joined[src_at + length:src_at + length + window]

    info["matched_fragment"] = needle[at:at + length]
    info["source_says"] = before_src + "【" + needle[at:at + length] + "】" + after_src
    problems = []
    if before_you:
        problems.append(f"你写的开头「{before_you}」，素材里那处是「…{before_src[-8:]}」")
    if after_you:
        problems.append(f"你写的结尾「{after_you}」，素材里那处是「{after_src[:8]}…」")
    info["diverged_at"] = (
        f"第 {at + 1}–{at + length} 字对得上（共 {len(needle)} 字）。"
        + ("；".join(problems) if problems
           else "但整句连起来在素材里不连续——中间被你删掉了东西"))
    return info


def validate(payload: dict[str, Any]) -> dict[str, Any]:
    sources = payload.get("sources") or []
    if not isinstance(sources, list) or not sources:
        raise ValueError("缺少 sources：必须给出素材文件路径，否则无从校验")

    corpus = []
    missing_files = []
    for item in sources:
        raw = str(item)
        path = Path(raw).expanduser()
        if not path.is_file():
            missing_files.append(raw)
            continue
        corpus.append(path.read_text(encoding="utf-8", errors="replace"))
    if missing_files:
        raise ValueError(f"素材文件不存在：{'、'.join(missing_files)}")

    joined = normalize("\n".join(corpus))

    passage = payload.get("material_first_pass") or {}
    entries = ((passage.get("fact_vs_inference") or {}).get("from_material")) or []
    if not isinstance(entries, list):
        raise ValueError("from_material 必须是数组")

    # **3–6 条，超了直接判失败。**
    # `from_material` 是**给六个判断各锚一条来源**，不是把素材摘录一遍。
    # 实测出过一次：面对 138 篇素材写了 25→29 条，而每条都是一次独立的失败机会——
    # 每轮必然有几条落空、每轮只修掉一部分，十几轮还没收敛。
    # **难度由单条决定，轮数由条数决定，两个是乘起来的。**
    if len(entries) > MAX_FROM_MATERIAL:
        raise ValueError(
            f"from_material 有 {len(entries)} 条，上限 {MAX_FROM_MATERIAL} 条。"
            "它是给六个判断各锚一条来源（素材稀缺度 / 最尖锐的问题 / 从业者痛点 / "
            "最原创的判断 / 事实与推断 / 触发细节），**不是素材摘录**。"
            "留下真正支撑判断的那几条，其余删掉——"
            "支撑不了任何一个判断的引文，多写一条只是多一次失败机会。")

    located, unlocated = 0, []
    for index, entry in enumerate(entries):
        quote = entry.get("quote") if isinstance(entry, dict) else entry
        needle = normalize(quote)
        if needle and needle in joined:
            located += 1
            continue
        entry_out = {
            "index": index,
            "quote": str(quote or "")[:120],
            "reason": ("引文未在素材中逐字出现。看 diverged_at 与 source_says 定位，"
                       "**不要靠猜**。标点、引号、空白与 markdown 标记（`**` `` ` `` "
                       "`>` `|`）都不计，链接按显示文字算——所以对不上通常是"
                       "**真的抄错了字**，或者跨行拼接时漏了中间的内容。"),
        }
        if needle:
            entry_out.update(diagnose(needle, joined))
        unlocated.append(entry_out)

    return {
        "ok": not unlocated and bool(entries),
        "checked": len(entries),
        "located": located,
        "unlocated": unlocated,
        "note": (
            f"from_material 逐字抄录素材原句，**最多 {MAX_FROM_MATERIAL} 条**——"
            "给六个判断各锚一条来源，不是摘录。"
            "标点、引号、空白与 markdown 标记（`**` `_` 反引号 `>` `|` `#`）差异不计，"
            "`[文字](链接)` 按显示文字算。"
            "⚠️ 省略号（……）**不在忽略之列**——它正意味着你省掉了原文，那就是概括。"
            "要么整句抄，要么拆成两条各自抄。"
            "不命中时看 diverged_at 与 source_says，**不要靠猜原因、更不要去读本脚本源码**。"
        ),
    }


if __name__ == "__main__":
    try:
        result = validate(read_json())
    except ValueError as exc:
        write_json({"ok": False, "error": str(exc)})
        raise SystemExit(2) from None
    write_json(result)
    raise SystemExit(0 if result["ok"] else 1)
