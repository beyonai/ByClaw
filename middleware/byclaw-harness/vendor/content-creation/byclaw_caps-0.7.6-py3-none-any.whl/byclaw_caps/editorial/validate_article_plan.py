#!/usr/bin/env python3
"""Validate deterministic invariants in a write-article ArticlePlan."""

from __future__ import annotations

import argparse
from collections.abc import Mapping
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import sys
from typing import Any
from .local_sources import bound_source as _bound_local_source

pass  # 包内使用相对导入，避免污染其他兼容入口

try:
    import yaml
except ImportError as exc:  # pragma: no cover - environment failure
    raise SystemExit("PyYAML is required to validate ArticlePlan YAML") from exc

# 大纲侧的词表 = 共享红线 + 本阶段额外收紧的两词。理由见 amplifiers.py。
# `sys.path` 上面已经插了本脚本目录，所以这条平铺 import 在直接跑脚本时也成立。
from .amplifiers import PLAN_AMPLIFIERS as RISKY_AMPLIFIERS
from .story_contract import (
    BODY_FORMATS, CONTENT_KINDS, READING_PROFILE_VALUES, SUMMARY_MODES, TRUTH_MODES,
    content_kind, is_story, validate_story_contract,
)


#: PyYAML 的 ``width`` 默认 80 列，超出就把标量折成多行。长中文串被折行后，
#: 后续一切按字面匹配的编辑都会失效——实测一次会话为此连续四次改不动同一个
#: 值，最后只能读原始字节。写回是本脚本的常规动作，所以这里必须给足。
YAML_DUMP_WIDTH = 10 ** 9

RISKY_TEMPORAL = re.compile(r"当前仍|目前仍|截至目前|现在仍|已经进入|当前已经")
GENERIC_REMOVAL = {"", "文章不完整", "缺少这一节", "结构不完整", "内容不完整"}
LENGTH_UNITS = {"chinese_characters", "words"}
LENGTH_SHAPES = {
    "front_light_core_heavy_end_light",
    "case_led",
    "progressive_tutorial",
    "argument_counterargument",
    "narrative_arc",
    "comparison",
    "list_based",
    "custom",
}
LENGTH_ROLES = {
    "opening",
    "setup",
    "case",
    "core_proof",
    "step",
    "argument",
    "counterargument",
    "synthesis",
    "development",
    "climax",
    "comparison",
    "boundary",
    "conclusion",
    "resolution",
    "item",
}
#: 版式与主题的**权威定义在能力层**（`byclaw_caps.compile` 的 LAYOUT_PROFILES /
#: THEME_PROFILES），那里才是渲染真正读的表。这里 import 得到就用它。
#:
#: **取不到时兜底到字面值，而不是整个校验失败。** 本脚本在没装轮子的环境里也要能跑——
#: 为了一个版式枚举让整份 ArticlePlan 校验不了，代价不对等。
#: 兜底与能力层的一致性由 tests/test_presentation_enums.py 强制，不靠人记得两处一起改。
try:  # pragma: no cover - 取决于环境是否装了能力层
    from byclaw_caps.compile import (
        DEFAULT_LAYOUT_PROFILE, DEFAULT_THEME_PROFILE,
        LAYOUT_PROFILES, THEME_PROFILES,
    )
    LAYOUT_PROFILE_VALUES = frozenset(LAYOUT_PROFILES)
    THEME_PROFILE_VALUES = frozenset(THEME_PROFILES)
except ModuleNotFoundError:  # pragma: no cover
    LAYOUT_PROFILE_VALUES = frozenset({"balanced", "compact", "comfortable", "column"})
    THEME_PROFILE_VALUES = frozenset({
        "warm", "minimal", "tech_blue",
        "wemd-eastern-notes",
        "wemd-morandi-forest",
        "wemd-data-blueprint",
        "wemd-modern-editorial",
        "wemd-receipt",
        "wemd-luxury-gold",
        "wenyan-lapis",
        "wenyan-orangeheart",
        "wenyan-pie",
        "wenyan-phycat",
        "mdnice-blueCyan",
        "mdnice-ink",
        "mdnice-shanchui",
        "mdnice-rose",
        "doocs-default",
        "doocs-grace",
        "xiaohu-terracotta",
        "xiaohu-newspaper",
        "xiaohu-swiss-grid",
        "xiaohu-kaiti-journal",
    })
    DEFAULT_LAYOUT_PROFILE = "balanced"
    DEFAULT_THEME_PROFILE = "warm"

PLAN_SCHEMA_VERSION = "1.18"
LEGACY_PLAN_SCHEMA_VERSIONS = {"1.10", "1.11", "1.12", "1.13", "1.14", "1.15",
                               "1.16", "1.17"}

#: 写法模板绑定的三组枚举。
#:
#: **拆成「如何选中」与「如何采用」两问，是因为一问答不了。**
#: 上一版只有"选中"一问，配一条"`formula` 必填且逐字出自模板"的门禁——
#: 而兜底模板 `兜底-公众号深度论证结构.md` 本身没有开头公式（它反过来让你去查
#: `WritingAsset`）。于是**兜底路径过不了自己定的门禁**；用户自定结构、
#: 模板不适用、云盘取不到，同样没有合法状态可填。
TEMPLATE_SELECTIONS = {"explicit", "matched", "fallback", "none"}
TEMPLATE_ADOPTIONS = {"full", "adapted", "not_applicable", "fetch_failed"}
#: 开头来源独立于模板：`derived`（自主推导）是**合法**的，不必假装出自模板。
OPENING_SOURCES = {"template", "opening_asset", "derived"}
MANIFEST_SCHEMA_VERSION = "1.2"
LEGACY_MANIFEST_SCHEMA_VERSION = "1.1"
ASSET_STATUSES = {"not_applicable", "pending", "complete", "unresolved"}
VISUAL_GOALS = {
    "relationship",
    "process",
    "comparison",
    "trend",
    "structure",
    "instruction",
    "concept",
    "scene",
    "evidence_capture",
}
ASSET_ROLES = {"cover", "body", "social", "storyboard"}
RENDER_PREFERENCES = {"auto", "deterministic", "ai", "source"}
LEGACY_VISUAL_TYPE_MAP = {
    "relationship_diagram": ("relationship", "network"),
    "flow_diagram": ("process", "flowchart"),
    "comparison": ("comparison", "comparison"),
    "data_chart": ("trend", ""),
    "information_graphic": ("structure", "hierarchy"),
    "screenshot": ("evidence_capture", ""),
    "other": ("", ""),
}


def _mapping_at(parent: dict[str, Any], key: str) -> dict[str, Any]:
    """取 parent[key] 这个映射；键缺失、为 None 或不是映射时统一重建。

    不能用 dict.setdefault：YAML 里写成 `contract_validation:`（空值）时键**存在**但值为
    None，setdefault 会原样返回 None，随后 `validation["status"] = ...` 直接抛
    TypeError: 'NoneType' object does not support item assignment。
    实测这个空值让一次大纲会话反复卡住约 25 轮——模板留白是完全合法的 YAML 写法，
    校验器必须容得下。
    """
    value = parent.get(key)
    if not isinstance(value, dict):
        value = {}
        parent[key] = value
    return value


def _validate_image_asset_manifests(manifest: dict[str, Any], manifest_path: Path) -> list[str]:
    """Require synchronized ImageAssetManifest 1.1 before publication ready."""
    if manifest.get("visual_asset_status") != "complete":
        return []
    slots = [item for item in (manifest.get("visual_slot_map") or []) if isinstance(item, dict)]
    if not slots:
        return ["ArticleManifest.visual_asset_status=complete 时 visual_slot_map 不能为空"]
    errors: list[str] = []
    asset_roots: set[Path] = set()
    for item in slots:
        if item.get("slot_status") != "embedded":
            errors.append("图片资产 complete 时所有视觉槽位必须为 embedded")
            continue
        asset_path = str(item.get("asset_path") or "").strip()
        if not asset_path:
            errors.append("embedded 视觉槽位缺少 asset_path")
            continue
        resolved = (manifest_path.parent / asset_path).resolve()
        if not resolved.is_file():
            errors.append(f"ArticleManifest 图片不存在: {resolved}")
        asset_roots.add(resolved.parent)
    if errors:
        return errors
    if len(asset_roots) != 1:
        return ["当前文章的 ImageAssetManifest 要求视觉资产位于同一目录"]

    asset_root = next(iter(asset_roots))
    json_path = asset_root / "image-asset-manifest.json"
    yaml_path = asset_root / "image-asset-manifest.yaml"
    if not json_path.is_file() or not yaml_path.is_file():
        return ["图片资产 complete 时 ImageAssetManifest JSON 和 YAML 必须同时存在"]
    try:
        image_json = json.loads(json_path.read_text(encoding="utf-8"))
        image_yaml = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, yaml.YAMLError) as exc:
        return [f"ImageAssetManifest 无法读取: {exc}"]
    if not isinstance(image_json, dict) or not isinstance(image_yaml, dict):
        return ["ImageAssetManifest 根节点必须是对象"]
    if image_json != image_yaml:
        errors.append("ImageAssetManifest JSON 与 YAML 内容不一致")
    if str(image_json.get("schema_version") or "") != "1.1":
        errors.append("ImageAssetManifest.schema_version 必须为 1.1")
    if image_json.get("status") != "validated":
        errors.append("ImageAssetManifest.status 必须为 validated")
    slot_ids = [str(item.get("visual_id") or "") for item in slots]
    image_assets = [item for item in (image_json.get("assets") or []) if isinstance(item, dict)]
    if [str(item.get("asset_id") or "") for item in image_assets] != slot_ids:
        errors.append("ImageAssetManifest.assets 必须按顺序覆盖 ArticleManifest.visual_slot_map")
        return errors
    for slot, asset in zip(slots, image_assets):
        if asset.get("status") != "validated":
            errors.append(f"ImageAssetManifest.{asset.get('asset_id')}.status 必须为 validated")
        image_file = (asset_root / str(asset.get("file_path") or "")).resolve()
        article_file = (manifest_path.parent / str(slot.get("asset_path") or "")).resolve()
        if image_file != article_file:
            errors.append(f"ImageAssetManifest.{asset.get('asset_id')}.file_path 与 ArticleManifest 不一致")
        validation = asset.get("validation") or {}
        if not str(validation.get("sha256") or "").strip():
            errors.append(f"ImageAssetManifest.{asset.get('asset_id')} 缺少 sha256")
    return errors


def sync_claim_ids(plan: Mapping[str, Any]) -> list[str]:
    """从 `claim_section_map` 反推每个章节的 `claim_ids`，就地改写，返回改了哪些。

    **这两处存的是同一份信息。** `claim_section_map` 带角色
    （`introduced_at` / `primary_proof_section` / `supporting_sections` /
    `referenced_by_sections`），`section.claim_ids` 只是它按章节的投影——
    **可以完全算出来，不该让人手写第二遍**。

    实测代价：一次 ArticlePlan 为了对齐这两处改了 **13 轮**。而且是**级联**的——
    删掉 `section-03` 的 `claim-001`，`claim-009` 的 `supporting_sections` 就空了，
    于是 `section-05` 那条引用又冒出来。**改一条冒一条，看不到头。**

    map 是**唯一真相**：它有角色信息，投影没有。所以永远由 map 推 claim_ids，
    不反过来——反过来会把角色丢掉。
    """
    # ⚠️ **章节在 `narrative_plan.sections`下**，不是 `structure_plan`——
    # 后者在 ArticlePlan 里**根本不存在**。最初就是这么写错的：
    # 读到空列表 → 一条也不同步 → **不报错**，
    # 而报错文案还写着「加 --write-back 会自动补齐」——
    # 调用方照做了，然后发现没用。**静默为真的成功。**
    sections = (plan.get("narrative_plan") or {}).get("sections") or []
    section_ids = [s.get("section_id") for s in sections if isinstance(s, Mapping)]
    known = {sid for sid in section_ids if sid}

    derived: dict[Any, list[Any]] = {sid: [] for sid in known}
    mappings = (plan.get("narrative_plan") or {}).get("claim_section_map") or []
    for item in mappings:
        if not isinstance(item, Mapping):
            continue
        claim_id = item.get("claim_id")
        if not claim_id:
            continue
        locations = {item.get("introduced_at"), item.get("primary_proof_section")}
        locations |= set(item.get("supporting_sections") or [])
        locations |= set(item.get("referenced_by_sections") or [])
        for location in locations:
            # 落在未知章节上的映射是**另一条错**，那边会报；这里只管能对上的。
            if location in derived and claim_id not in derived[location]:
                derived[location].append(claim_id)

    changed: list[str] = []
    for section in sections:
        if not isinstance(section, Mapping):
            continue
        sid = section.get("section_id")
        if sid not in derived:
            continue
        want = derived[sid]
        have = list(section.get("claim_ids") or [])
        if sorted(map(str, want)) != sorted(map(str, have)):
            section["claim_ids"] = want
            changed.append(
                "{0}.claim_ids: {1} → {2}".format(
                    sid, have or "[]", want or "[]"))
    return changed


#: `verification_scope=as_of_source_date` 认哪些来源类型。
#: `official_snapshot` 是对外公告的存档；`internal_snapshot` 是**带日期的内部文档**
#: （某月的会议纪要、某次盘点的落盘结果）——两者都是「某个时点为真」，
#: 区别只在是不是对外的。**刚跑出来的枚举不属于这里**，那是 current。
DATED_SOURCE_KINDS = frozenset({"official_snapshot", "internal_snapshot"})


def _looks_like_a_read_file(source: str) -> bool:
    """`verification_source` 像不像一个真的取过的来源。

    只做形状检查——云盘绝对路径、或 http(s) 链接。**验不了「真读过」**，
    但能挡住「随手写一句话冒充来源」，那是实测里真实发生过的那一种。
    """
    text = source.strip()
    return text.startswith("/") or text.lower().startswith(("http://", "https://"))


#: 本次任务的**输入**，不是证据。
#:
#: 选题简报、选题决策、人工选题视图——它们是「要写什么」的交代，
#: 而 `verification_source` 要回答的是「这条事实在哪儿核过的」。
#: 拿输入当来源是循环论证：**这条事实成立，因为我自己的任务书这么写的。**
TASK_INPUT_MARKERS = ("/10-topic/",)
TASK_INPUT_BASENAMES = ("content-brief.yaml", "topic-decision-result.yaml", "选题决策.md")


def _is_own_task_input(source: str) -> bool:
    """`verification_source` 指的是不是本次任务自己的输入。

    **形状检查拦不住它**——`/by/.sessions/…/10-topic/content-brief.yaml`
    是个堂堂正正的绝对路径，`_looks_like_a_read_file` 照单全收。

    实测出过一次：一次大纲三条 fact_check 全部标 verified，
    `verification_source` 一律填本会话的 `content-brief.yaml`，
    于是 `drafting_status=ready`、`合同校验 pass、无失败项`——
    **而整篇大纲零次素材检索、零次实体检索**。
    上一次同类任务在这里是 `needs_fact_verification`，这次「过了」。

    这与选题侧栽过的那个跟头是同一个：**参照物被当成了输入**
    （那次是拿地图和账号档案冒充素材去抄引文）。
    """
    text = source.strip().replace("\\", "/")
    if any(marker in text for marker in TASK_INPUT_MARKERS):
        return True
    return text.rsplit("/", 1)[-1] in TASK_INPUT_BASENAMES


#: 参照物不是事实出处：
#:
#: - `/知识/领域知识/`：领域地图，三列词表（一级/二级/描述）。它回答
#:   「这个领域怎么分类」，不回答「这个事实成不成立」。
SECONDARY_SOURCE_MARKERS = (
    ("/知识/领域知识/", "领域地图是三列词表，是参照物不是证据"),
)


def _secondary_source_reason(source: str) -> str:
    """`verification_source` 是否指向只提供分类口径的参照物。"""
    text = source.strip().replace("\\", "/")
    for marker, reason in SECONDARY_SOURCE_MARKERS:
        if marker in text:
            return reason
    return ""


def field_specs() -> dict[str, dict[str, Any]]:
    """字段 → 合法取值与要点。**`--explain` 的数据源。**

    ## 为什么需要它

    实测（2026-09-12 11:07）：一次大纲 39 次 exec 里 **17 次在 `sed`/`grep` 校验器源码**，
    连着读了约 700 行，grep 的是 `RISKY_AMPLIFIERS`、`COVER_COPY_SOURCES`、
    `UNCHECKED_ROLE_WARN_SHARE`、`_validate_cover`、`_validate_length_plan`……
    而 `SKILL.md:600` 明令「不要读脚本源码推断入参」。

    **它不是不守规矩，是没有别的路。** 必填字段的报错一直很清楚（骨架 37 条里
    24 条是「这一节要写什么」），真正逼它去读源码的是**后触发的规则**：
    枚举取值、占比区间、强度词表——这些只有填错了才会现身，
    而"填错一次再改"在几十个字段上会滚成很多轮。

    所以给一条比 `sed 700 行` 便宜的路：一次调用把某个字段的合法取值问出来。

    ## 一条纪律：取值从常量取，不手写

    这个仓库反复栽的跟头是「文档一份、代码一份，改了一处忘另一处」。
    下面每一项的取值都直接引用校验器自己用的那个常量——**改了那边，这里自动跟上**。
    """
    def enum(values: Any, note: str) -> dict[str, Any]:
        return {"legal_values": sorted(values), "note": note}

    return {
        "content_kind": enum(CONTENT_KINDS, "缺省 analysis；故事营销和短篇使用独立叙事规则"),
        "truth_mode": enum(TRUTH_MODES, "故事必填；虚构人物不豁免真实产品主张"),
        "narrative_plan.body_format": enum(BODY_FORMATS, "故事缺省 scenes，以隐藏场景锚点映射"),
        "narrative_plan.summary_mode": enum(SUMMARY_MODES, "故事缺省 hidden；分享 digest 独立维护"),
        "distribution_plan.presentation.reading_profile": enum(
            READING_PROFILE_VALUES, "阅读预设独立于视觉主题；default 兼容历史版式"),
        "length_plan.length_unit": enum(
            LENGTH_UNITS, "中文内容用 chinese_characters，英文用 words"),
        "length_plan.length_shape": enum(
            LENGTH_SHAPES,
            "先按内容选，再分配章节。比例是护栏不是定律，"
            "确有依据可填 shape_exception.status=defined"),
        "narrative_plan.sections[].length_role": enum(
            LENGTH_ROLES,
            "⛔ 不要用 core 这类缩写。**每种 shape 只约束其中几个角色**，"
            "把大块篇幅挂到不受约束的角色上会出 warning（见 shape_checked_roles）"),
        "narrative_plan.template_selection": enum(
            TEMPLATE_SELECTIONS,
            "none 是合法状态（用户自定结构 / 判定无模板适用），不是失败"),
        "narrative_plan.template_adoption": enum(
            TEMPLATE_ADOPTIONS,
            "!= full 时必须填 adoption_notes；fetch_failed 要记 data_gaps"),
        "narrative_plan.opening_strategy.opening_source": enum(
            OPENING_SOURCES,
            "derived 合法，不必假装出自模板。只有 template 才填 formula，"
            "且须逐字抄自模板快照"),
        "distribution_plan.cover_hook.copy_source": enum(
            COVER_COPY_SOURCES, "防止封面上现编一句正文里没有的话"),
        "distribution_plan.cover_hook.hook_type": enum(
            COVER_HOOK_TYPES, "cover_copy 上限 14 字，且不得与 final_title 逐字相同"),
        "production_plan.fact_checks[].status": enum(
            {"verified", "unresolved", "not_applicable"},
            "⛔ unresolved 的意思是「**查过了**，素材里没有」——"
            "必须在 data_gaps 记一条带 check_id 的说明"),
        "production_plan.fact_checks[].verification_source": {
            "legal_values": ["云盘绝对路径（/素材/…、/成品/…）", "http(s) 链接"],
            "note": "⛔ 两类不收：本次任务的输入（10-topic/…）和领域地图"
                    "（/知识/领域知识/，参照物）。"
                    "取回时落盘在 <会话根>/.runtime/retrieval/<云盘路径>，填那个",
        },
        "visual_plan[].asset_role": enum(ASSET_ROLES, "封面画幅与正文配图不同，不要混"),
        "visual_plan[].visual_goal": enum(VISUAL_GOALS, ""),
        "visual_plan[].render_preference": enum(
            RENDER_PREFERENCES,
            "⛔ 关系/流程/比较/趋势/结构/步骤图**不得用 ai**——模型会编造数字"),
        "readiness.publication_asset_status": enum(ASSET_STATUSES, ""),
        "truth_strength_review.risky_amplifiers": {
            "legal_values": list(RISKY_AMPLIFIERS),
            "note": "这些词出现在中心句、标题或章节判断里就要有逐字证据；"
                    "没有就改措辞，**不能只把状态写成 pass**",
        },
        "length_plan.shape_checked_roles": {
            "legal_values": [f"{shape}: {'、'.join(sorted(roles))}"
                             for shape, roles in sorted(SHAPE_CHECKED_ROLES.items())],
            "note": f"每种 shape 实际受比例约束的角色。单个不受约束的角色占比 "
                    f"≥{UNCHECKED_ROLE_WARN_SHARE:.0%} 会出 warning",
        },
    }


def explain(path: str | None) -> dict[str, Any]:
    """回答「这个字段要什么」。给不全的路径时做后缀匹配，给空时列全部。"""
    specs = field_specs()
    if not path:
        return {"status": "ok", "paths": sorted(specs),
                "hint": "加字段路径查具体取值，如 --explain length_plan.length_shape"}
    if path in specs:
        return {"status": "ok", "path": path, **specs[path]}
    hits = sorted(k for k in specs if path in k)
    if len(hits) == 1:
        return {"status": "ok", "path": hits[0], **specs[hits[0]]}
    return {"status": "unknown", "path": path, "candidates": hits or sorted(specs),
            "hint": "没有这个字段的枚举说明。**必填类字段看校验器报错就够**——"
                    "报错自带字段路径与要求；`--explain` 只管枚举与阈值这类"
                    "「填错了才现身」的规则。⛔ 仍然不要去读脚本源码。"}


def _fact_check_id(item: Mapping[str, Any], index: int) -> str:
    """取 fact_check 的标识；缺失时回落到位置，**不回落到 None**。

    回落值要能被人定位到具体哪一条，也要能进阻断集合——缺 id 不该让这条
    核验从 `drafting_status` 的判定里消失。
    """
    return str(item.get("check_id") or "").strip() or f"fact_checks[{index}]"


def dump_yaml_compatible(plan: dict[str, Any]) -> str:
    """Serialize with stable key order while supporting PyYAML 3.x."""
    try:
        return yaml.safe_dump(plan, allow_unicode=True, sort_keys=False,
                              width=YAML_DUMP_WIDTH)
    except TypeError as exc:
        if "sort_keys" not in str(exc):
            raise
        return yaml.safe_dump(plan, allow_unicode=True, width=YAML_DUMP_WIDTH)


def _manifest_asset_state(
    plan: dict[str, Any], manifest: dict[str, Any]
) -> tuple[str, set[str], list[str]]:
    """Derive publication asset state from the article manifest."""
    errors: list[str] = []
    manifest_schema = str(manifest.get("schema_version"))
    if manifest_schema not in {MANIFEST_SCHEMA_VERSION, LEGACY_MANIFEST_SCHEMA_VERSION}:
        errors.append(f"ArticleManifest.schema_version 必须为 {MANIFEST_SCHEMA_VERSION}")
    if "visual_slot_map" not in manifest:
        errors.append("ArticleManifest.visual_slot_map 不能为空")
    if "visual_asset_status" not in manifest:
        errors.append("ArticleManifest.visual_asset_status 不能为空")
    for key in ("article_id", "brief_id", "topic_id"):
        if str(manifest.get(key) or "") != str(plan.get(key) or ""):
            errors.append(f"ArticleManifest.{key} 与 ArticlePlan 不一致")
    if manifest_schema == MANIFEST_SCHEMA_VERSION:
        if manifest.get("content_status") not in {"draft", "revised", "final_candidate"}:
            errors.append("ArticleManifest.content_status 必须为 draft|revised|final_candidate")
        if manifest.get("publication_status") != (plan.get("readiness") or {}).get("publication_status"):
            errors.append("ArticleManifest.publication_status 与 ArticlePlan 不一致")
        revision = manifest.get("revision")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            errors.append("ArticleManifest.revision 必须为正整数")
        elif revision > 1 and not str(manifest.get("supersedes_manifest_path") or "").strip():
            errors.append("ArticleManifest.revision>1 时 supersedes_manifest_path 不能为空")
        planned_title = str(manifest.get("planned_title") or "").strip()
        plan_title = str((plan.get("distribution_plan") or {}).get("final_title") or "").strip()
        if planned_title != plan_title:
            errors.append("ArticleManifest.planned_title 与 ArticlePlan.distribution_plan.final_title 不一致")
        if str(manifest.get("title") or "").strip() != planned_title:
            errors.append("ArticleManifest.title 必须等于已审计的 planned_title；微调标题后先更新 ArticlePlan")

    visual_status = plan.get("visual_plan_status")
    visual_ids = [
        str(item.get("visual_id") or "")
        for item in (plan.get("visual_plan") or [])
        if isinstance(item, dict) and item.get("status") == "defined"
    ]
    slot_map = manifest.get("visual_slot_map") or []
    mapped_ids = [str(item.get("visual_id") or "") for item in slot_map if isinstance(item, dict)]
    pending_ids = {
        str(item.get("visual_id") or "")
        for item in slot_map
        if isinstance(item, dict) and item.get("slot_status") == "placeholder"
    }
    invalid_slot_statuses = [
        str(item.get("slot_status") or "")
        for item in slot_map
        if not isinstance(item, dict) or item.get("slot_status") not in {"placeholder", "embedded"}
    ]
    if invalid_slot_statuses:
        errors.append("ArticleManifest.visual_slot_map 含非法 slot_status")

    if visual_status == "defined":
        if mapped_ids != visual_ids:
            errors.append("ArticleManifest.visual_slot_map 必须按顺序覆盖 ArticlePlan.visual_plan")
        all_embedded = bool(visual_ids) and len(mapped_ids) == len(visual_ids) and all(
            isinstance(item, dict) and item.get("slot_status") == "embedded"
            for item in slot_map
        )
        expected_status = "complete" if all_embedded else "pending"
    elif visual_status == "not_applicable":
        expected_status = "not_applicable"
        pending_ids = set()
        if slot_map:
            errors.append("视觉计划不适用时 ArticleManifest.visual_slot_map 必须为空")
    else:
        expected_status = "unresolved"
        pending_ids = set()
        if slot_map:
            errors.append("视觉计划未解析时不得提前登记图片位置")

    if manifest.get("visual_asset_status") != expected_status:
        errors.append(f"ArticleManifest.visual_asset_status 应为 {expected_status}")
    pending_ids.discard("")
    return expected_status, pending_ids, errors


def _upgrade_legacy_plan(plan: dict[str, Any], manifest: dict[str, Any] | None) -> bool:
    """Upgrade a 1.10-1.14 plan while preserving every visual decision."""
    if str(plan.get("schema_version")) not in LEGACY_PLAN_SCHEMA_VERSIONS:
        return False
    previous_schema = str(plan.get("schema_version"))
    readiness = _mapping_at(plan, "readiness")
    if manifest is not None:
        asset_status, pending_ids, _ = _manifest_asset_state(plan, manifest)
    else:
        visual_status = plan.get("visual_plan_status")
        visual_ids = {
            str(item.get("visual_id") or "")
            for item in (plan.get("visual_plan") or [])
            if isinstance(item, dict) and item.get("status") == "defined"
        }
        visual_ids.discard("")
        asset_status = {
            "defined": "pending",
            "not_applicable": "not_applicable",
            "unresolved": "unresolved",
        }.get(visual_status, "unresolved")
        pending_ids = visual_ids if asset_status == "pending" else set()
    readiness.setdefault("publication_asset_status", asset_status)
    readiness.setdefault("pending_asset_ids", sorted(pending_ids))
    title_review = _mapping_at(_mapping_at(plan, "distribution_plan"), "title_review")
    title_review.setdefault("status", "not_run")
    title_review.setdefault("thesis_alignment_status", "not_run")
    title_review.setdefault("title_promise", "")
    title_review.setdefault("thesis_connection", "")
    title_review.setdefault("distribution_strength_status", "not_run")
    title_review.setdefault("reader_value", "")
    title_review.setdefault("propagation_hook", "")
    title_review.setdefault("sharing_reason", "")
    title_review.setdefault("unsupported_promises", [])
    title_review.setdefault("clickbait_risks", [])
    title_review.setdefault("revision_actions", [])
    sections = ((plan.get("narrative_plan") or {}).get("sections") or [])
    for visual in plan.get("visual_plan") or []:
        if not isinstance(visual, dict):
            continue
        legacy_type = str(visual.get("type") or "").strip()
        goal, subtype = LEGACY_VISUAL_TYPE_MAP.get(legacy_type, ("", ""))
        visual.setdefault("asset_role", "body")
        visual.setdefault("visual_goal", goal)
        visual.setdefault("diagram_subtype", subtype)
        visual.setdefault("key_message", visual.get("understanding_task") or "")
        if "evidence_refs" not in visual:
            refs: list[str] = []
            visual_id = visual.get("visual_id")
            for section in sections:
                if visual_id in (section.get("visual_refs") or []):
                    for ref in section.get("evidence_refs") or []:
                        if ref not in refs:
                            refs.append(ref)
            visual["evidence_refs"] = refs
        default_must_include = []
        if goal in {"relationship", "process", "comparison", "trend", "structure", "instruction"}:
            basis = str(visual.get("basis") or "").strip()
            if basis:
                default_must_include = [basis]
        visual.setdefault("must_include", default_must_include)
        visual.setdefault("must_avoid", [])
        visual.setdefault("render_preference", "auto")
    # 1.13 → 1.14 新增封面文案门禁。默认 unresolved 而不是 not_applicable：
    # 存量计划只是还没做过封面决策，不等于「本文不需要封面」——后者是个结论，
    # 替作者下这个结论会让问题就此消失在绿灯里。
    distribution = _mapping_at(plan, "distribution_plan")
    distribution.setdefault("cover_copy_status", "unresolved")
    distribution.setdefault("cover_copy", "")
    cover_hook = _mapping_at(distribution, "cover_hook")
    for field in ("hook_type", "copy_source", "reader_takeaway"):
        cover_hook.setdefault(field, "")
    # 1.14 → 1.15 新增 target_account。**刻意留空而不填一个默认号。**
    # 项目里可能有多个号，替作者猜一个的后果是整篇按错误的读者画像写且不报错——
    # 那正是这个字段要根治的问题。留空会被校验拦下，作者必须显式声明。
    plan.setdefault("target_account", {"channel_code": "", "account_code": ""})

    # 分发承诺三项同批纳入门禁，同样默认 unresolved 而不是 not_applicable。
    for field, status_field, is_list, _label in DISTRIBUTION_GATED_FIELDS:
        distribution.setdefault(status_field, "unresolved")
        distribution.setdefault(field, [] if is_list else "")

    # 1.16 → 1.17 新增排版意图。**这里给缺省值而不是留空**，与 target_account 相反。
    #
    # target_account 留空是因为「替作者猜一个号，整篇会按错误的读者画像写且不报错」——
    # 那是个改变内容的决策。版式不改变任何事实、任何读者模型，且投递前可重编译，
    # 代价不对等；而 balanced + warm 正是现行行为（排版那边「未指定用均衡版 + 暖色，
    # 不追问」），给缺省值等于存量计划升级后零回归。
    presentation = _mapping_at(distribution, "presentation")
    presentation.setdefault("layout_profile", DEFAULT_LAYOUT_PROFILE)
    presentation.setdefault("theme_profile", DEFAULT_THEME_PROFILE)
    presentation.setdefault("rationale", "")

    # 1.17 → 1.18 新增 term_glossary。**默认空数组，不从 terminology 推导。**
    # terminology 是给人看的自由文本（实测样例里有「禁止出现：…」这种条目），
    # 机械转过来就是把禁用词清单当成术语表。留空 = 不划线，零回归。
    _mapping_at(plan, "production_plan").setdefault("term_glossary", [])

    plan["schema_version"] = PLAN_SCHEMA_VERSION
    plan["_upgraded_from_schema_version"] = previous_schema
    return True


COVER_HOOK_TYPES = {"cost_reveal", "contrast", "question", "counter_intuition"}
COVER_COPY_SOURCES = {"core_hook", "reader_facing_thesis", "central_thesis"}
# 公众号首图 900x383。实测 14 个中文字是不被裁、在信息流缩略下仍可读的上限；
# 再多不是「挤一点」，是读者根本看不清，等于没有封面文案。
COVER_COPY_MAX_CHARS = 14


ACCOUNT_CODE_PATTERN = re.compile(r"^[a-z0-9_]+$")


def _validate_target_account(
    plan: dict[str, Any],
    brief: dict[str, Any] | None,
    errors: list[str],
) -> None:
    """这篇写给哪个号。

    一个项目里可以有多个公众号，各自读者不同。没有这个字段，下游只能查整棵
    `成品/` 树：A 号的查重会撞上 B 号的文章（那不构成重复——读者根本不重叠），
    A 号的风格会照着 B 号的读者画像写（**这条不报错，每篇都歪**）。

    与 ContentBrief 必须逐字一致。中途换号意味着读者全变了，画像、查重范围、
    标题写法都要重来，不能靠改一个字段悄悄完成——要换就回选题重来。
    """
    profile = plan.get("profile_id")
    if profile is not None and profile not in {"generic.article", "wechat.public_article"}:
        errors.append("profile_id 必须为 generic.article|wechat.public_article")
    if brief and (brief.get("profile_id") or profile) != profile:
        errors.append("profile_id 与 ContentBrief 不一致")
    if profile == "generic.article":
        if plan.get("target_account") or (brief or {}).get("target_account"):
            errors.append("generic.article 不应绑定发布账号；需要账号时使用渠道 profile")
        return
    account = plan.get("target_account")
    if not isinstance(account, Mapping):
        errors.append("target_account 必须是对象，含 channel_code 与 app_id（兼容旧 account_code）")
        return

    brief_account = (brief or {}).get("target_account")
    brief_account = brief_account if isinstance(brief_account, Mapping) else {}
    identity_field = "app_id" if account.get("app_id") or brief_account.get("app_id") else "account_code"
    for field in ("channel_code", identity_field):
        value = str(account.get(field) or "").strip()
        if not value:
            errors.append("target_account.%s 不能为空——它决定查重范围与读者画像" % field)
        elif not ACCOUNT_CODE_PATTERN.fullmatch(value):
            # 与 deliver 的 secret_env 推导同一套约束：这两个 code 还要做目录名，
            # 大小写与非 ASCII 在 Linux 上会出岔子。
            errors.append(
                "target_account.%s=%r 只能是小写字母、数字与下划线"
                "（它同时用作目录名与环境变量后缀）" % (field, value)
            )

    if brief:
        for field in ("channel_code", "app_id", "account_code"):
            mine = str(account.get(field) or "").strip()
            theirs = str(brief_account.get(field) or "").strip()
            if theirs and mine != theirs:
                errors.append(
                    "target_account.%s 与 ContentBrief 不一致（%s ≠ %s）："
                    "换号要回选题重来，不能在计划里改" % (field, mine, theirs)
                )


# 与封面同病的三个分发字段：模板里有、大纲渲染器打印、三个校验器一处不查。
# 键 = 字段名，值 = (状态字段, 是否列表, 人话说明)
DISTRIBUTION_GATED_FIELDS = (
    ("retention_points", "retention_points_status", True,
     "中段留存点：读者读到一半为什么不走"),
    ("sharing_reason", "sharing_reason_status", False,
     "转发理由：读者为什么愿意转给同类人"),
    ("closing_action", "closing_action_status", False,
     "文末行动：读完这篇该做什么"),
)


def _validate_distribution_commitments(
    plan: dict[str, Any],
    errors: list[str],
    warnings: list[str],
) -> None:
    """分发承诺三项的门禁。

    这三项与 `cover_copy` 是同一个病：字段在模板里、被大纲渲染器打印给人看，
    但三个校验器一处都不查——于是可以永远是空值而全流程绿灯。它们决定读者
    读不读完、转不转发、读完做什么，空着等于这三个问题没人回答过。

    与封面一致的三态语义：`defined` 要求内容，`not_applicable` 是人下的结论（不告警），
    `unresolved` 是还没决策（放行但留痕）。
    """
    distribution = plan.get("distribution_plan") or {}
    for field, status_field, is_list, label in DISTRIBUTION_GATED_FIELDS:
        status = distribution.get(status_field)
        if status not in {"defined", "not_applicable", "unresolved"}:
            errors.append(
                "distribution_plan.%s 必须为 defined|not_applicable|unresolved" % status_field
            )
            continue

        value = distribution.get(field)
        if is_list:
            items = [str(item).strip() for item in value] if isinstance(value, list) else None
            if value is not None and items is None:
                errors.append("distribution_plan.%s 必须为字符串数组" % field)
                continue
            filled = bool(items) and all(items)
            has_any = bool(items)
        else:
            text = str(value or "").strip()
            filled = bool(text)
            has_any = filled

        if status == "defined":
            if not filled:
                errors.append(
                    "%s=defined 时 %s 不能为空（%s）" % (status_field, field, label)
                )
        else:
            if has_any:
                errors.append(
                    "%s=%s 时 %s 必须为空——留一条没人负责的承诺比留空更危险"
                    % (status_field, status, field)
                )
            if status == "unresolved":
                warnings.append("%s=unresolved：%s 尚未决策" % (status_field, label))


def _validate_term_glossary(plan: dict[str, Any], errors: list[str],
                            warnings: list[str]) -> None:
    """术语清单：机器要拿它去正文里逐字 find，所以形状必须干净。

    **为什么不复用 `terminology`。** 那个字段是给人看的用词约束，实测样例里的真实内容是：

        - "本体（Ontology）、语义层（Semantic Layer）、知识图谱、GraphRAG、MCP"
        - "禁止出现：pip源、global.index-url、ceph、4A 等一切技术名词"

    第一条是七个顿号分隔的词挤在一起，整条拿去 find 必然找不到——**静默无下划线**，
    而调用方以为自己传了术语表。第二条更糟：那是**禁用词清单**，
    拿它做高亮的语义正好相反。

    所以这里只收「一项一个词」，并且**把像整句话的条目拦下来**。
    """
    glossary = (plan.get("production_plan") or {}).get("term_glossary")
    if glossary is None:
        return
    if not isinstance(glossary, list):
        errors.append(
            "production_plan.term_glossary 必须是数组，一项一个术语。"
            "给人看的用词约束写在 terminology，两者不要合用一个字段"
        )
        return
    for index, item in enumerate(glossary):
        if not isinstance(item, str) or not item.strip():
            errors.append(
                f"production_plan.term_glossary[{index}] 必须是非空字符串"
            )
            continue
        term = item.strip()
        # 顿号／逗号分隔说明一条里塞了多个词；冒号说明它是「禁止出现：…」
        # 这类约束句。两种都不是术语，照原样拿去 find 永远找不到。
        if any(sep in term for sep in ("、", "，", ",", "：", ":", "；", ";")):
            errors.append(
                f"production_plan.term_glossary[{index}] 含分隔符或冒号："
                f"「{term[:20]}」。**一项只能是一个术语**——"
                "多个词就拆成多项；「禁止出现：…」这类用词约束属于 terminology"
            )
        elif len(term) > 20:
            warnings.append(
                f"production_plan.term_glossary[{index}] 长达 {len(term)} 字："
                f"「{term[:20]}…」。术语通常是个词，整句话在正文里找不到逐字匹配"
            )


def _validate_presentation(plan: dict[str, Any], errors: list[str]) -> None:
    """排版意图：两个枚举，取值非法即拒。

    **为什么不允许自由色值。** 曾经的方案想让作者填 `primary_color: "#4caf50"`，
    那会绕过色板边界——布局与主题契约写着「不得根据文章内容临时生成新颜色；
    新增主题必须进入代码、测试和版本契约」。每块装饰各自取色，单看都成立，
    放一篇里就散。所以这里只收枚举，颜色由主题决定。

    **为什么拼错要拦而不是回落缺省。** 回落是静默的：作者写了 `tech-blue`
    （连字符），拿到的是暖色，而他以为自己选了科技蓝——要到公众号后台才看得出来。
    """
    presentation = (plan.get("distribution_plan") or {}).get("presentation")
    if not isinstance(presentation, dict):
        errors.append(
            "distribution_plan.presentation 缺失或不是映射。"
            "填 layout_profile 与 theme_profile 两个枚举；"
            "拿不准就用 balanced + warm，那是缺省组合"
        )
        return
    layout = presentation.get("layout_profile")
    if layout not in LAYOUT_PROFILE_VALUES:
        errors.append(
            "distribution_plan.presentation.layout_profile 必须为 %s"
            % "|".join(sorted(LAYOUT_PROFILE_VALUES))
        )
    theme = presentation.get("theme_profile")
    if theme not in THEME_PROFILE_VALUES:
        errors.append(
            "distribution_plan.presentation.theme_profile 必须为 %s"
            % "|".join(sorted(THEME_PROFILE_VALUES))
        )
    if presentation.get("reading_profile", "default") not in READING_PROFILE_VALUES:
        errors.append("distribution_plan.presentation.reading_profile 必须为 %s"
                      % "|".join(sorted(READING_PROFILE_VALUES)))


def _validate_cover(
    plan: dict[str, Any],
    errors: list[str],
    warnings: list[str],
    visuals: list[Any],
) -> None:
    """封面文案与封面资产的门禁。

    封面和标题是**两次独立的触达**——读者在信息流里先看到哪个都有可能。此前
    `cover_copy` 只被大纲渲染器打印给人看，三个校验器一处都不查，于是它可以
    永远是空串而全流程绿灯，封面就退化成一张与内容无关的装饰图。

    `defined` 与「必须有一张 cover 资产」互为条件：文案要印在图上，没有图的
    文案不会到达任何读者。反过来 `visual_plan_status=not_applicable` 时
    visual_plan 必须为空，此处自然会因为找不到封面而报错，那也是对的。
    """
    distribution = plan.get("distribution_plan") or {}
    status = distribution.get("cover_copy_status")
    if status not in {"defined", "not_applicable", "unresolved"}:
        errors.append("distribution_plan.cover_copy_status 必须为 defined|not_applicable|unresolved")
        return

    copy_text = str(distribution.get("cover_copy") or "").strip()
    hook = distribution.get("cover_hook")
    hook = hook if isinstance(hook, Mapping) else {}

    if status != "defined":
        if copy_text:
            errors.append(
                "cover_copy_status=%s 时 cover_copy 必须为空——"
                "留一句没人负责的文案比留空更危险" % status
            )
        # 只对 unresolved 告警。not_applicable 是作者明确下过的结论——
        # 对一个已经做出的决定反复提醒是噪音，而噪音会让真正的告警被忽略。
        if status == "unresolved":
            warnings.append(
                "cover_copy_status=unresolved：封面文案尚未决策，"
                "这篇会带着一张没人设计过的封面进入信息流"
            )
        return

    if not copy_text:
        errors.append("cover_copy_status=defined 时 cover_copy 不能为空")
    elif len(copy_text) > COVER_COPY_MAX_CHARS:
        errors.append(
            "cover_copy 超过 %d 字（当前 %d 字）：公众号首图会裁掉或缩到看不清"
            % (COVER_COPY_MAX_CHARS, len(copy_text))
        )

    final_title = str(distribution.get("final_title") or "").strip()
    if copy_text and final_title and copy_text == final_title:
        errors.append(
            "cover_copy 与 final_title 逐字相同：标题和封面是两次触达机会，"
            "重复等于浪费一次"
        )

    if hook.get("hook_type") not in COVER_HOOK_TYPES:
        errors.append(
            "cover_hook.hook_type 必须为 %s" % "|".join(sorted(COVER_HOOK_TYPES))
        )
    if hook.get("copy_source") not in COVER_COPY_SOURCES:
        errors.append(
            "cover_hook.copy_source 必须为 %s" % "|".join(sorted(COVER_COPY_SOURCES))
        )
    if not str(hook.get("reader_takeaway") or "").strip():
        errors.append("cover_hook.reader_takeaway 不能为空")

    # 封面是传播面最大的一句话，强度词在这里最危险；沿用与正文同一条红线。
    for term in RISKY_AMPLIFIERS:
        if term in copy_text:
            warnings.append("distribution_plan.cover_copy 出现需核验强度词：%s" % term)

    # 契约一直允许 asset_role=cover，却没有任何地方要求它存在，
    # 而 compile 的默认值是 body——不填就静默没有封面。
    covers = [
        item for item in visuals
        if isinstance(item, Mapping) and item.get("asset_role") == "cover"
    ]
    if len(covers) != 1:
        errors.append(
            "cover_copy_status=defined 时 visual_plan 必须恰好有一项 asset_role=cover"
            "（当前 %d 项）" % len(covers)
        )


def _strings_for_truth_check(plan: dict[str, Any]) -> list[tuple[str, str]]:
    editorial = plan.get("editorial_core") or {}
    argument = plan.get("argument_plan") or {}
    audience = plan.get("audience_plan") or {}
    distribution = plan.get("distribution_plan") or {}
    values = [
        ("editorial_core.reader_facing_thesis", editorial.get("reader_facing_thesis", "")),
        ("editorial_core.thirty_second_summary", editorial.get("thirty_second_summary", "")),
        ("audience_plan.why_now", audience.get("why_now", "")),
        ("audience_plan.cognitive_change", audience.get("cognitive_change", "")),
        ("audience_plan.action_change", audience.get("action_change", "")),
        ("argument_plan.central_thesis", argument.get("central_thesis", "")),
        ("distribution_plan.final_title", distribution.get("final_title", "")),
        ("distribution_plan.summary", distribution.get("summary", "")),
    ]
    if is_story(plan):
        # 虚构标题、情绪和人物对白中的“唯一”等不是产品承诺。
        # 真实能力即使出现在对白里也必须登记 claim，由同一词法检查核验。
        values = [(f"section:{section.get('section_id', '?')}", section.get("section_judgment", ""))
                  for section in (plan.get("narrative_plan") or {}).get("sections", [])
                  if section.get("section_kind", "scene") == "explanation"]
    for claim in argument.get("supporting_claims") or []:
        values.append((f"claim:{claim.get('claim_id', '?')}", claim.get("statement", "")))
    return [(location, value) for location, value in values if isinstance(value, str)]


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _between(value: float, minimum: float, maximum: float) -> bool:
    return minimum <= value <= maximum


#: 每种篇幅策略**实际受比例约束**的角色。
#:
#: 校验器按角色聚合算占比，而每种 shape 只检查其中几个——落在其余角色上的篇幅
#: **完全不受约束**。这本身没错（`boundary`、`case` 这类本来就该有余地），
#: 但它同时是一个可以被当成逃逸舱用的口子：把最大的一节挂到不受检的角色上，
#: 剩下的就容易凑进区间。
SHAPE_CHECKED_ROLES = {
    "front_light_core_heavy_end_light": {"opening", "core_proof", "conclusion"},
    "case_led": {"opening", "case", "core_proof", "argument", "conclusion", "resolution"},
    "progressive_tutorial": {"step", "conclusion", "resolution"},
    "argument_counterargument": {"argument", "counterargument", "synthesis"},
    "narrative_arc": {"opening", "setup", "development", "climax",
                      "conclusion", "resolution"},
    "comparison": {"comparison", "synthesis", "conclusion"},
    "list_based": {"item", "opening", "conclusion"},
}

#: 单个不受检角色占到这个比例以上就出 warning。
#:
#: 30% 不是拍的：`front_light_core_heavy_end_light` 的核心证明下限是 45%，
#: 开头上限 15%、结尾上限 12%——一个不受检角色超过 30%，意味着全文近三分之一
#: 既不算开头也不算核心证明，**"轻开头重核心"这个描述已经名不副实了**。
UNCHECKED_ROLE_WARN_SHARE = 0.30


def _unchecked_role_warnings(shape: str, role_shares: dict[str, float]) -> list[str]:
    """把"大块篇幅落在不受检角色上"这件事**说出来**，但不阻断。

    ⛔ **不能改成 error。** 结构由素材推导定、模板只用来校准——这是 SKILL.md 的红线，
    强制角色分配等于把红线废掉。真实素材就是会出现大段的 `development`、`boundary`。

    但它该**可见**。实测出过一次：一篇 `front_light_core_heavy_end_light` 的大纲，
    全文最大的一节（35%）挂在 `development` 上，而该 shape 只检查
    opening / core_proof / conclusion 三个角色——于是 core_proof 只要凑到 47% 就通过了，
    35% 那块**一个字都没被约束过**，报告里也看不出来。

    出了 warning，就得在 `length_rationale` 里回答一句：这一大块凭什么不算核心证明。
    """
    checked = SHAPE_CHECKED_ROLES.get(shape)
    if not checked:
        return []
    flagged = sorted(
        ((role, value) for role, value in role_shares.items()
         if role not in checked and value >= UNCHECKED_ROLE_WARN_SHARE),
        key=lambda item: -item[1])
    return [
        f"length_role={role} 占 {value:.0%}，而 {shape} 只对 "
        + "、".join(sorted(checked))
        + " 作比例约束——**这一块不在任何区间检查内**。"
        "确实该独立成段就在该节 length_rationale 说明它为什么不算核心证明；"
        "若它其实承担了主要论证，改成 core_proof（或该 shape 的承重角色）更诚实。"
        for role, value in flagged
    ]


def _profile_violations(
    shape: str,
    role_shares: dict[str, float],
    role_lengths: dict[str, float],
) -> list[str]:
    """Return violations for the selected editorial shape only."""
    violations: list[str] = []

    def share(*roles: str) -> float:
        return sum(role_shares.get(role, 0.0) for role in roles)

    def require_range(label: str, value: float, minimum: float, maximum: float) -> None:
        if not _between(value, minimum, maximum):
            violations.append(f"{label} 占比应在 {minimum:.0%}—{maximum:.0%}，实际为 {value:.1%}")

    def require_role(role: str, label: str) -> None:
        if role_lengths.get(role, 0) <= 0:
            violations.append(f"{label}需要至少一个 length_role={role} 的章节")

    if shape == "front_light_core_heavy_end_light":
        require_role("opening", "轻开头、重核心、轻结尾结构")
        require_role("core_proof", "轻开头、重核心、轻结尾结构")
        require_role("conclusion", "轻开头、重核心、轻结尾结构")
        if share("opening") > 0.15:
            violations.append(f"开头占比应不高于 15%，实际为 {share('opening'):.1%}")
        require_range("核心证明", share("core_proof"), 0.45, 0.65)
        if share("conclusion") > 0.12:
            violations.append(f"结尾占比应不高于 12%，实际为 {share('conclusion'):.1%}")
    elif shape == "case_led":
        require_role("case", "案例驱动结构")
        require_range("开头与案例", share("opening", "case"), 0.18, 0.35)
        require_range("核心证明", share("core_proof", "argument"), 0.30, 0.55)
        if share("conclusion", "resolution") > 0.18:
            violations.append("案例驱动结构的收束部分不应超过全文 18%")
    elif shape == "progressive_tutorial":
        require_role("step", "递进教程结构")
        require_range("操作步骤", share("step"), 0.55, 0.85)
        step_lengths = [value for role, value in role_lengths.items() if role == "step" and value > 0]
        # role_lengths is aggregated, so per-section balance is checked separately below.
        if not step_lengths:
            violations.append("递进教程结构缺少操作步骤篇幅")
        require_range("结尾", share("conclusion", "resolution"), 0.05, 0.15)
    elif shape == "argument_counterargument":
        require_role("argument", "正反论证结构")
        require_role("counterargument", "正反论证结构")
        require_role("synthesis", "正反论证结构")
        require_range("正方论证", share("argument"), 0.20, 0.40)
        require_range("反方论证", share("counterargument"), 0.20, 0.40)
        require_range("综合判断", share("synthesis"), 0.12, 0.25)
    elif shape == "narrative_arc":
        require_role("development", "叙事弧结构")
        require_role("climax", "叙事弧结构")
        require_range("开场与背景", share("opening", "setup"), 0.15, 0.30)
        require_range("发展", share("development"), 0.20, 0.40)
        require_range("高潮", share("climax"), 0.20, 0.35)
        require_range("结尾与解决", share("conclusion", "resolution"), 0.08, 0.20)
    elif shape == "comparison":
        require_role("comparison", "对比结构")
        require_range("对比主体", share("comparison"), 0.45, 0.70)
        require_range("综合与结论", share("synthesis", "conclusion"), 0.10, 0.25)
    elif shape == "list_based":
        require_role("item", "清单结构")
        require_range("清单主体", share("item"), 0.60, 0.85)
        require_range("开头与结尾", share("opening", "conclusion"), 0.12, 0.30)

    return violations


def _validate_template_binding(plan: dict[str, Any], *, plan_path: Path | None
                               ) -> tuple[list[str], list[str]]:
    """写法模板绑定：**全部是条件校验，没有一条是无条件必填。**

    门禁要验的是「你说了什么，就得对上什么」，不是「必须用模板」。四种非常规
    情况——兜底、用户自定、模板不适用、云盘取不到——都要有合法状态，否则规则
    会逼着模型**假装**开头来自模板，而那正是门禁本来要防的东西。

    快照绑在 ArticlePlan 自身，不绑 ArticleManifest：**`plan_only` 阶段还没有
    Manifest**（它在正文流程才产生）。云盘取回时 `_fetch` 本来就先落盘再进上下文
    并算好 sha256，所以校验器读的是本地文件，不联网、不依赖云盘可达。
    """
    errors: list[str] = []
    warnings: list[str] = []
    narrative = plan.get("narrative_plan") or {}

    selection = narrative.get("template_selection")
    adoption = narrative.get("template_adoption")
    opening = narrative.get("opening_strategy") or {}
    source = opening.get("opening_source")

    # 1.15 及更早没有这三个键。**缺失记 warning，不报错**——升级不能把在途 plan 判死。
    if selection is None and adoption is None and source is None:
        warnings.append("narrative_plan 缺少写法模板绑定字段（1.15 及更早的 plan），"
                        "本次不校验模板绑定；重跑 article_plan_scaffold.py 可补齐")
        return errors, warnings

    if selection not in TEMPLATE_SELECTIONS:
        errors.append("narrative_plan.template_selection 必须为 "
                      + "|".join(sorted(TEMPLATE_SELECTIONS)))
    if adoption not in TEMPLATE_ADOPTIONS:
        errors.append("narrative_plan.template_adoption 必须为 "
                      + "|".join(sorted(TEMPLATE_ADOPTIONS)))
    if source not in OPENING_SOURCES:
        errors.append("narrative_plan.opening_strategy.opening_source 必须为 "
                      + "|".join(sorted(OPENING_SOURCES)))
    if errors:
        return errors, warnings

    snapshot = narrative.get("structure_template") or {}
    remote, local, digest = (str(snapshot.get(k) or "").strip()
                             for k in ("remote_path", "snapshot_path", "sha256"))

    if selection == "none":
        if adoption not in {"not_applicable"}:
            errors.append("template_selection=none 时 template_adoption 只能是 not_applicable")
        if remote or local or digest:
            errors.append("template_selection=none 时不应有 structure_template 快照")
        # **合法，但必须看得见。** 不绑模板是允许的（自定结构、无适用模板），
        # 可它不该悄悄成为默认路径——骨架的初值就是 none，不出声就等于九份模板白接。
        # 这条 warning 会出现在大纲确认节点上，由人决定是不是该去取一份。
        warnings.append("本篇未绑定写法模板（template_selection=none）。"
                        "若非用户自定结构，请在大纲前取一份模板校准骨架")
    elif adoption == "fetch_failed":
        # 取不到是**现实**，不是违规：记 data_gaps、warning 不阻断大纲。
        if not _data_gap_mentions_template(plan):
            errors.append("template_adoption=fetch_failed 时必须在 data_gaps 记一条写法模板取回失败")
        warnings.append("写法模板取回失败，本篇结构未经模板校准")
    else:
        missing = [name for name, value in
                   (("remote_path", remote), ("snapshot_path", local), ("sha256", digest))
                   if not value]
        if missing:
            errors.append("structure_template 缺少：" + "、".join(missing)
                          + "。remote_path 取 metadata-search 返回的 filePath 原值，"
                          "**不要自己拼路径**；snapshot_path 与 sha256 由取回时落盘产生")

    if adoption != "full" and not str(narrative.get("adoption_notes") or "").strip():
        errors.append(f"template_adoption={adoption} 时必须填 adoption_notes："
                      "拆了/并了/删了哪些结构功能，为什么")
    if selection == "fallback" and not str(narrative.get("adoption_notes") or "").strip():
        errors.append("template_selection=fallback 时必须在 adoption_notes 说明为何无类型模板可用")

    formula = str(opening.get("formula") or "").strip()
    if source == "template":
        if adoption != "full":
            # 采用方式都改了，还声称开头逐字出自模板，两者对不上。
            errors.append("opening_source=template 仅在 template_adoption=full 时成立；"
                          "有调整请改用 opening_asset 或 derived")
        elif not formula:
            errors.append("opening_source=template 时 opening_strategy.formula 必填，"
                          "且须逐字抄自模板的「开头公式」")
        else:
            errors.extend(_formula_in_snapshot(formula, local, plan_path=plan_path))
    elif formula:
        errors.append(f"opening_source={source} 时不应填 formula —— "
                      "它专指逐字抄自模板的那一句")

    return errors, warnings


def _data_gaps_blob(plan: dict[str, Any]) -> str:
    """把 `data_gaps` 摊平成一段文本。

    它可能是字符串数组，也可能是映射数组（带 `gap`/`reason` 之类的键），
    调用方只关心「有没有提到某个东西」，不关心形状。
    """
    gaps = plan.get("data_gaps") or []
    if not isinstance(gaps, list):
        return str(gaps)
    return " ".join(str(item) for item in gaps)


def _data_gap_mentions_template(plan: dict[str, Any]) -> bool:
    blob = _data_gaps_blob(plan)
    return "模板" in blob or "写法" in blob


def _data_gap_mentions(plan: dict[str, Any], token: str) -> bool:
    """`data_gaps` 里有没有点名这一条。

    只做**字面包含**，不解析结构——记一条 `fact-002：查过 成品 域…` 就够，
    不逼调用方去学一套 data_gaps 的子契约。门禁要的是「留下痕迹」，
    不是「按我的格式留痕迹」。
    """
    return bool(token) and token in _data_gaps_blob(plan)


def _formula_in_snapshot(formula: str, snapshot_path: str, *, plan_path: Path | None
                         ) -> list[str]:
    """`formula` 必须**逐字**出现在快照文件里。

    与 `section_judgment`「Markdown 必须原样读取，不得另行生成」同一种门禁：
    校验器验不了模板是否真被遵循，但至少能验这一句不是编的。

    快照读不到时报错而不是放过——放过等于这条门禁在最需要它的时候静默失效。
    """
    if not snapshot_path:
        return []
    candidate = Path(snapshot_path)
    if not candidate.is_absolute() and plan_path is not None:
        candidate = (plan_path.parent / snapshot_path).resolve()
    if not candidate.is_file():
        return [f"structure_template.snapshot_path 指向的文件不存在：{snapshot_path}。"
                "取回时必须先落盘再进上下文，校验器读的是这份本地快照"]
    text = candidate.read_text(encoding="utf-8", errors="replace")
    if formula not in text:
        return [f"opening_strategy.formula 未在模板快照中逐字出现：{formula!r}。"
                "原样抄模板的「开头公式」那一行，不要改写"]
    return []


def _validate_length_plan(plan: dict[str, Any], sections: list[dict[str, Any]],
                          brief: dict[str, Any] | None = None) -> tuple[list[str], list[str]]:
    """Validate and calculate a unit-aware, shape-aware length plan."""
    errors: list[str] = []
    warnings: list[str] = []
    length_plan = plan.get("length_plan") or {}
    unit = length_plan.get("length_unit")
    shape = length_plan.get("length_shape")
    target_total = length_plan.get("target_total")
    allowed = length_plan.get("allowed_range") or {}
    front = length_plan.get("front_matter_length", 0)
    back = length_plan.get("back_matter_length", 0)

    if unit not in LENGTH_UNITS:
        errors.append("length_plan.length_unit 必须为 chinese_characters 或 words")
    if shape not in LENGTH_SHAPES:
        errors.append("length_plan.length_shape 不是支持的篇幅策略")
    if not _is_number(target_total) or target_total <= 0:
        errors.append("length_plan.target_total 必须为正数")
        target_total = 0
    for field, value in (("front_matter_length", front), ("back_matter_length", back)):
        if not _is_number(value) or value < 0:
            errors.append(f"length_plan.{field} 必须为非负数")
    minimum, maximum = allowed.get("min"), allowed.get("max")
    if not _is_number(minimum) or not _is_number(maximum) or minimum <= 0 or maximum < minimum:
        errors.append("length_plan.allowed_range 必须给出有效的 min 和 max")
    elif target_total and not minimum <= target_total <= maximum:
        errors.append("length_plan.target_total 必须位于 allowed_range 内")
    # **`allowed_range` 不能自己说了算——它要落在选题定的预算里。**
    # 原来这里只校内部自洽（`target_total ∈ allowed_range`），而 `allowed_range` 本身
    # 是计划自己写的。实测撞过：正文压不下来，就把 `allowed_range` 往外放，
    # 校验器照样通过。`--brief` 其实一直在传，但只用来核 `target_account`，
    # 没人看 `modality_hints.article.target_word_count_range` —— 选题定的体量预算空着没用。
    if brief is not None and _is_number(minimum) and _is_number(maximum) and minimum > 0:
        hinted = (((brief.get("modality_hints") or {}).get("article") or {})
                  .get("target_word_count_range") or {})
        brief_min, brief_max = hinted.get("min"), hinted.get("max")
        if (_is_number(brief_min) and _is_number(brief_max)
                and brief_min > 0 and brief_max >= brief_min):
            # **只拦放宽，不拦收紧。** 把上限往外挪是在松门禁（实测就是这么过关的）；
            # 把下限收紧是自律——`article_plan_scaffold.py` 的既定优先级也是
            # 「显式 --target-total > brief 区间 > 默认值」，收紧属于正常用法。
            if maximum > brief_max:
                errors.append(
                    f"length_plan.allowed_range 上限 {int(maximum)} 超出 ContentBrief 的体量预算上限 "
                    f"{int(brief_max)}（modality_hints.article.target_word_count_range）。"
                    "**选题定的体量是上游契约，写作期不得自行放宽**——"
                    "预算内怎么调都行；确实需要写更长，回选题改 ContentBrief，不要在这里放线。")
            elif minimum < brief_min:
                warnings.append(
                    f"length_plan.allowed_range 下限 {int(minimum)} 低于 ContentBrief 预算下限 "
                    f"{int(brief_min)}：比选题定的体量更紧是允许的，确认这是有意收紧。")
    if not str(length_plan.get("selection_reason") or "").strip():
        errors.append("length_plan.selection_reason 不能为空")

    section_total = 0.0
    role_lengths: dict[str, float] = {}
    per_role_section_lengths: dict[str, list[float]] = {}
    for section in sections:
        section_id = section.get("section_id", "?")
        role = section.get("length_role")
        target = section.get("target_length")
        rationale = section.get("length_rationale") or {}
        scene_section = is_story(plan) and section.get("section_kind", "scene") == "scene"
        if not scene_section and not str(section.get("section_judgment") or "").strip():
            errors.append(f"{section_id}.section_judgment 不能为空")
        if not scene_section and not str(section.get("evidence_summary") or "").strip():
            errors.append(f"{section_id}.evidence_summary 不能为空")
        if role not in LENGTH_ROLES:
            errors.append(f"{section_id}.length_role 不是支持的篇幅角色")
        if not _is_number(target) or target <= 0:
            errors.append(f"{section_id}.target_length 必须为正数")
            continue
        section_total += target
        if role in LENGTH_ROLES:
            role_lengths[role] = role_lengths.get(role, 0.0) + target
            per_role_section_lengths.setdefault(role, []).append(target)
        for key in (() if scene_section else ("evidence_density", "reasoning_load", "reader_difficulty")):
            if rationale.get(key) not in {"low", "medium", "high"}:
                errors.append(f"{section_id}.length_rationale.{key} 必须为 low|medium|high")
        if not str(rationale.get("explanation") or "").strip():
            errors.append(f"{section_id}.length_rationale.explanation 不能为空")
        section["length_share"] = round(target / target_total, 4) if target_total else 0

    total_with_matter = section_total + (front if _is_number(front) else 0) + (back if _is_number(back) else 0)
    if target_total and abs(total_with_matter - target_total) > 0.5:
        errors.append("章节、前置与后置篇幅合计必须等于 length_plan.target_total")

    if _is_number(front) and front > 0 and target_total:
        role_lengths["opening"] = role_lengths.get("opening", 0.0) + front
    if _is_number(back) and back > 0 and target_total:
        role_lengths["conclusion"] = role_lengths.get("conclusion", 0.0) + back
    role_shares = {
        role: round(value / target_total, 4) if target_total else 0
        for role, value in sorted(role_lengths.items())
    }

    profile_violations = _profile_violations(shape, role_shares, role_lengths) if shape in LENGTH_SHAPES else []
    # ⚠️ **warning 不是 violation**：它进 warnings，不进 profile_violations，
    # 也就不会被 shape_exception 豁免——例外豁免的是"比例超界"，
    # 而这条说的是"这块篇幅根本没进任何区间检查"，两件事。
    if shape in LENGTH_SHAPES and not is_story(plan):
        warnings.extend(_unchecked_role_warnings(shape, role_shares))
    if shape == "progressive_tutorial":
        steps = per_role_section_lengths.get("step", [])
        if len(steps) >= 2 and max(steps) / min(steps) > 1.75:
            profile_violations.append("递进教程各步骤篇幅最大值与最小值之比不应超过 1.75")
    if shape == "list_based":
        items = per_role_section_lengths.get("item", [])
        if len(items) >= 2 and max(items) / min(items) > 1.5:
            profile_violations.append("清单各项篇幅最大值与最小值之比不应超过 1.5")

    exception = length_plan.get("shape_exception") or {}
    if exception.get("status") not in {"not_applicable", "defined"}:
        errors.append("length_plan.shape_exception.status 必须为 not_applicable 或 defined")
    exception_defined = exception.get("status") == "defined" and len(str(exception.get("reason") or "").strip()) >= 8
    if exception.get("status") == "defined" and not exception_defined:
        errors.append("shape_exception.status=defined 时必须给出具体原因")
    invalid_affected_roles = set(exception.get("affected_roles") or []) - LENGTH_ROLES
    if invalid_affected_roles:
        errors.append("shape_exception.affected_roles 包含不支持的篇幅角色")
    if shape == "custom" and not exception_defined:
        errors.append("length_shape=custom 时必须定义 shape_exception 并说明原因")
    if profile_violations:
        if is_story(plan) and shape == "narrative_arc":
            warnings.extend(f"叙事篇幅参考（非硬门禁）：{item}" for item in profile_violations)
        elif exception_defined:
            warnings.extend(f"篇幅策略例外：{item}" for item in profile_violations)
        else:
            errors.extend(profile_violations)

    positive_lengths = [item.get("target_length") for item in sections if _is_number(item.get("target_length")) and item.get("target_length") > 0]
    evenness_ratio = round(max(positive_lengths) / min(positive_lengths), 2) if positive_lengths else None
    length_plan["calculated"] = {
        "section_total": section_total,
        "total_with_matter": total_with_matter,
        "role_shares": role_shares,
        "section_max_min_ratio": evenness_ratio,
    }
    length_plan["validation"] = {
        "status": "fail" if errors else "pass",
        "violations": list(errors),
        "warnings": list(warnings),
    }
    plan["length_plan"] = length_plan
    return errors, warnings


def validate(
    plan: dict[str, Any],
    manifest: dict[str, Any] | None = None,
    brief: dict[str, Any] | None = None,
    *,
    plan_path: Path | None = None,
) -> tuple[list[str], list[str]]:
    # `plan_path` 只用来把 `structure_template.snapshot_path` 的相对路径解析成
    # 绝对路径。给 None 时相对快照路径查不到文件——这会如实报错，不静默放过。
    errors: list[str] = []
    warnings: list[str] = []

    errors.extend(validate_story_contract(plan))
    upgraded = _upgrade_legacy_plan(plan, manifest)
    if upgraded:
        previous_schema = plan.pop("_upgraded_from_schema_version", "旧版本")
        warnings.append(
            f"ArticlePlan 已从 {previous_schema} 兼容升级为 {PLAN_SCHEMA_VERSION}；"
            "使用 --write-back 保存升级结果，补齐 target_account 与新增标题审计"
        )
    if str(plan.get("schema_version")) != PLAN_SCHEMA_VERSION:
        errors.append(f"schema_version 必须为 {PLAN_SCHEMA_VERSION}")

    _validate_target_account(plan, brief, errors)

    generation_mode = plan.get("generation_mode")
    expected_stop_after = {
        "plan_only": "ArticlePlan",
        "full_article": "ArticleAcceptanceReport",
        "revise_article": "ArticleAcceptanceReport",
    }.get(generation_mode)
    if expected_stop_after is None:
        errors.append("generation_mode 必须为 plan_only|full_article|revise_article")
    elif plan.get("stop_after") != expected_stop_after:
        errors.append(f"generation_mode={generation_mode} 时 stop_after 应为 {expected_stop_after}")

    readiness = plan.get("readiness") or {}
    outline_status = readiness.get("outline_status")
    if plan.get("plan_status") != outline_status:
        errors.append("plan_status 必须等于 readiness.outline_status")

    completeness = plan.get("completeness_review") or {}
    truth = plan.get("truth_strength_review") or {}
    logic = plan.get("logic_review") or {}
    editorial = plan.get("editorial_core") or {}
    argument = plan.get("argument_plan") or {}
    distribution = plan.get("distribution_plan") or {}
    title_review = distribution.get("title_review") or {}
    if str(argument.get("central_thesis") or "").strip() != str(editorial.get("reader_facing_thesis") or "").strip():
        errors.append("argument_plan.central_thesis 必须等于 editorial_core.reader_facing_thesis")
    if not str(distribution.get("final_title") or "").strip():
        errors.append("distribution_plan.final_title 不能为空")
    for field in ("title_promise", "thesis_connection", "reader_value", "propagation_hook", "sharing_reason"):
        if not str(title_review.get(field) or "").strip():
            errors.append(f"distribution_plan.title_review.{field} 不能为空")
    if title_review.get("status") not in {"pass", "needs_revision", "blocked"}:
        errors.append("distribution_plan.title_review.status 必须为 pass|needs_revision|blocked")
    if title_review.get("thesis_alignment_status") not in {"pass", "fail"}:
        errors.append("distribution_plan.title_review.thesis_alignment_status 必须为 pass|fail")
    if title_review.get("distribution_strength_status") not in {"pass", "needs_revision"}:
        errors.append("distribution_plan.title_review.distribution_strength_status 必须为 pass|needs_revision")
    if title_review.get("status") == "pass":
        if title_review.get("thesis_alignment_status") != "pass":
            errors.append("标题审计通过时 thesis_alignment_status 必须为 pass")
        if title_review.get("distribution_strength_status") != "pass":
            errors.append("标题审计通过时 distribution_strength_status 必须为 pass")
        if title_review.get("unsupported_promises"):
            errors.append("标题审计通过时 unsupported_promises 必须为空")
        if title_review.get("clickbait_risks"):
            errors.append("标题审计通过时 clickbait_risks 必须为空")
    if outline_status == "ready":
        if completeness.get("required_fields_status") != "pass":
            errors.append("outline_status=ready 时 required_fields_status 必须为 pass")
        if truth.get("status") != "pass":
            errors.append("outline_status=ready 时 truth_strength_review.status 必须为 pass")
        if logic.get("status") != "ready":
            errors.append("outline_status=ready 时 logic_review.status 必须为 ready")
        if title_review.get("status") != "pass":
            errors.append("outline_status=ready 时 distribution_plan.title_review.status 必须为 pass")

    fact_checks = (plan.get("production_plan") or {}).get("fact_checks") or []
    for index, item in enumerate(fact_checks, start=1):
        check_id = _fact_check_id(item, index)
        if not str(item.get("check_id") or "").strip():
            errors.append(
                f"fact_checks[{index}] 缺少 check_id。字段名必须逐字是 check_id——"
                "写成 fact_check_id 之类的别名，这条核验会被整条忽略，"
                "drafting_status 与 publication_status 随之算成「没有待核验事实」"
            )
        status = item.get("status")
        stage = item.get("required_stage")
        if status not in {"verified", "unresolved", "not_applicable"}:
            errors.append(f"{check_id}.status 必须为 verified|unresolved|not_applicable")
        if stage not in {"required_before_drafting", "required_before_publication"}:
            errors.append(f"{check_id}.required_stage 非法")
        if status == "unresolved" and not _data_gap_mentions(plan, check_id):
            # **`unresolved` 不是"没查"，是"查过了、素材里没有"。** SKILL.md 原话。
            #
            # 这条门禁是补上来的，补的原因是**逃生口在迁移**：
            #   · 把 verification_source 指向本次任务的 brief   → 已堵
            #   · 指向领域地图（参照物）                         → 已堵
            #   · **直接标 unresolved 走人**                    → 就是这一条
            #
            # 实测（2026-09-12 11:07）：两条 fact_check 全标 unresolved、
            # `verification_source` 为空、`data_gaps` **也是空的**，而整篇大纲
            # **零次素材检索、零次成品检索**。其中一条还是
            # 「已发文章是否实质重复」——那是 `成品` 域的本职，一次调用的事。
            errors.append(
                f"{check_id}.status=unresolved 但 data_gaps 里没有它。"
                "**`unresolved` 的意思是「查过了，素材里没有」，不是「没查」**——"
                f"在 data_gaps 记一条带 {check_id} 的说明：查了哪几个域、"
                "用的什么检索词、为什么判定没有。"
                "（查重回 `成品`、产品事实查询相关内部资料、"
                "外部时效事实走《外部事实：一律转调研》。）"
                "**一次都没查就标 unresolved，等于把门禁从正门挪到后门。**")
        if status == "verified":
            scope = item.get("verification_scope")
            if scope not in {"current", "as_of_source_date"}:
                # **一次把整套搭配说完。** 这三个字段是联动的，原来分三条报：
                # 先报 scope 非法，改完再报 source_freshness_status 不对，
                # 再改又报 source_kind 不在白名单——实测为这一组字段来回跑了三轮校验。
                errors.append(
                    f"{check_id}.verification_scope 必须为 current 或 as_of_source_date。"
                    "**两套搭配整组填，不要逐个试**：\n"
                    "  · 当场读到的云盘素材 / 刚跑的枚举 = 当前状态 → "
                    "`verification_scope: current` + `source_freshness_status: current_verified`"
                    "（不需要 source_date / original_statement）\n"
                    "  · 引用一份带日期的旧快照（官方公告存档、某月纪要）→ "
                    "`verification_scope: as_of_source_date` + `source_freshness_status: dated_only` + "
                    f"`source_kind` ∈ {'|'.join(sorted(DATED_SOURCE_KINDS))} + "
                    "`source_date: YYYY-MM-DD` + `original_statement`（收窄前的原问题），"
                    "且 `statement` 不得写成当前状态\n"
                    "  两套都要 `verification_source`（实际读到的云盘绝对路径或 http(s) 链接）与 `verified_at`。")
            source = str(item.get("verification_source") or "").strip()
            if not source:
                errors.append(f"{check_id}.verification_source 不能为空")
            elif not (_looks_like_a_read_file(source) or (
                    plan.get("profile_id") == "generic.article" and
                    _bound_local_source(source, plan.get("source_artifacts", []), plan_path))):
                # **校验器验不了「你真读过」，但能验「你填的像不像一个文件」。**
                # 实测出过一次：三条产品事实一次检索都没做，全标成 verified 走
                # `as_of_source_date` 快照降级，`verification_source` 是自己写的一句话，
                # 校验器照单全收——**正文里于是印着没核过的 beta 状态与 TTL 天数**。
                # 要求填云盘路径或 URL，至少让「没查过」这件事留下痕迹。
                errors.append(
                    f"{check_id}.verification_source 要填**你实际读到的那个来源**："
                    "云盘绝对路径（/素材/…、/KnowledgeEntity/….md）或 http(s) 链接。"
                    f"当前是「{source[:40]}」——那是一句描述，不是来源。"
                    "**没实际读到就不要标 verified**，标 unresolved 并写进 data_gaps，"
                    "同时把正文里那句话降级或删掉。"
                    "（『正文阶段不联网』指外部网络，**云盘随时可查**。）")
            elif _secondary_source_reason(source):
                errors.append(
                    f"{check_id}.verification_source 指向**二手来源**"
                    f"（「{source[-46:]}」）——{_secondary_source_reason(source)}。"
                    "它是分类参照物，不是事实出处。读取能够支持该事实的资料，"
                    "`verification_source` 填实际读取文件的落盘路径；"
                    "没有可用来源就标 unresolved 并写进 data_gaps。")
            elif _is_own_task_input(source):
                errors.append(
                    f"{check_id}.verification_source 指向本次任务自己的输入"
                    f"（「{source[-48:]}」）——**那是交代要写什么，不是证据**。"
                    "拿它当来源是循环论证：这条事实成立，因为我自己的任务书这么写的。"
                    "到相关知识域检索并读取能够支持该事实的资料，"
                    "`verification_source` 填**取回时落盘的那个路径**。"
                    "云盘里确实没有就标 unresolved 写进 data_gaps，"
                    "**不要用简报把门禁填过去**。")
            if not str(item.get("verified_at") or "").strip():
                errors.append(f"{check_id}.verified_at 不能为空")
            if scope == "current" and item.get("source_freshness_status") != "current_verified":
                errors.append(f"{check_id} 当前状态核验必须使用 source_freshness_status=current_verified")
            if scope == "as_of_source_date":
                if item.get("source_kind") not in DATED_SOURCE_KINDS:
                    # **报错要给出路。** 原来只说「只接受 official_snapshot」，
                    # 于是一次真实的云盘枚举（内部盘点、当场跑的）被卡住——
                    # 调用方只剩两条路：把内部盘点谎报成官方快照，或者放弃这条核验。
                    # 实测就撞上了：`source_kind=byclaw_metadata_enumeration` 被拒。
                    errors.append(
                        f"{check_id}.source_kind={item.get('source_kind')!r} 不在 "
                        f"{'|'.join(sorted(DATED_SOURCE_KINDS))} 内。"
                        "**先看是不是走错了 scope**："
                        "刚跑出来的云盘枚举 / 刚读到的素材是**当前状态**，"
                        "应当用 `verification_scope=current` + "
                        "`source_freshness_status=current_verified`，不走历史时点降级。"
                        "只有引用一份**带日期的旧快照**（官方公告存档、某月的内部纪要）"
                        "才用 as_of_source_date。")
                if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(item.get("source_date") or "")):
                    errors.append(f"{check_id}.source_date 必须为 YYYY-MM-DD")
                if item.get("source_freshness_status") != "dated_only":
                    errors.append(f"{check_id} 历史时点降级必须使用 source_freshness_status=dated_only")
                if not str(item.get("original_statement") or "").strip():
                    errors.append(f"{check_id}.original_statement 必须保留收窄前的问题")
                if RISKY_TEMPORAL.search(str(item.get("statement") or "")):
                    errors.append(f"{check_id}.statement 不得把带日期快照写成当前状态")
                warnings.append(f"{check_id} 仅核验到 {item.get('source_date')} 的官方快照，不代表当前状态")
        if status == "not_applicable" and item.get("verification_scope") not in {"not_applicable", None, ""}:
            errors.append(f"{check_id} 不适用时 verification_scope 应为 not_applicable")
    # 缺 check_id 的条目**照样计入**阻断集合（用位置占位）。原先这里裸取
    # `item.get("check_id")` 再 `discard(None)`，字段名一写错整条核验就消失，
    # 校验器转而报「drafting_status 应为 ready」——照着改就得到一份「校验通过、
    # 三个待核验事实凭空不见」的 plan。那是静默失效，比报错难发现得多。
    unresolved_drafting = {
        _fact_check_id(item, index)
        for index, item in enumerate(fact_checks, start=1)
        if item.get("status") == "unresolved" and item.get("required_stage") == "required_before_drafting"
    }
    unresolved_publication = {
        _fact_check_id(item, index)
        for index, item in enumerate(fact_checks, start=1)
        if item.get("status") == "unresolved"
        and item.get("required_stage") in {"required_before_drafting", "required_before_publication"}
    }

    expected_drafting = "blocked" if outline_status != "ready" else (
        "needs_fact_verification" if unresolved_drafting else "ready"
    )
    if readiness.get("drafting_status") != expected_drafting:
        errors.append(f"drafting_status 应为 {expected_drafting}")

    acceptance = readiness.get("article_acceptance_status")
    if acceptance not in {"not_started", "pass", "pass_with_warnings", "fail"}:
        errors.append("article_acceptance_status 必须为 not_started|pass|pass_with_warnings|fail")

    visual_status_for_assets = plan.get("visual_plan_status")
    defined_visual_ids = {
        str(item.get("visual_id") or "")
        for item in (plan.get("visual_plan") or [])
        if isinstance(item, dict) and item.get("status") == "defined"
    }
    defined_visual_ids.discard("")
    asset_status = readiness.get("publication_asset_status")
    pending_asset_id_list = readiness.get("pending_asset_ids") or []
    if not isinstance(pending_asset_id_list, list):
        errors.append("pending_asset_ids 必须为数组")
        pending_asset_ids: set[Any] = set()
    else:
        try:
            pending_asset_ids = set(pending_asset_id_list)
        except TypeError:
            pending_asset_ids = set()
            errors.append("pending_asset_ids 只能包含字符串 visual_id")
    if isinstance(pending_asset_id_list, list) and len(pending_asset_ids) != len(pending_asset_id_list):
        errors.append("pending_asset_ids 不得重复")
    if asset_status not in ASSET_STATUSES:
        errors.append("publication_asset_status 必须为 not_applicable|pending|complete|unresolved")
    invalid_pending_asset_ids = pending_asset_ids - defined_visual_ids
    if invalid_pending_asset_ids:
        errors.append("pending_asset_ids 包含未定义 visual_id")

    if manifest is not None:
        expected_asset_status, expected_pending_ids, manifest_errors = _manifest_asset_state(plan, manifest)
        errors.extend(manifest_errors)
        if asset_status != expected_asset_status:
            errors.append(f"publication_asset_status 应与 ArticleManifest 一致为 {expected_asset_status}")
        if pending_asset_ids != expected_pending_ids:
            errors.append("pending_asset_ids 必须等于 ArticleManifest 中仍为 placeholder 的视觉项")
    elif generation_mode in {"full_article", "revise_article"} and acceptance in {"pass", "pass_with_warnings"}:
        errors.append("终稿验收完成后必须使用 --manifest 联合校验发布资产状态")
    elif visual_status_for_assets == "defined":
        if asset_status != "pending":
            errors.append("尚无 ArticleManifest 时，已定义视觉计划的 publication_asset_status 应为 pending")
        if pending_asset_ids != defined_visual_ids:
            errors.append("尚无 ArticleManifest 时，pending_asset_ids 应包含全部已定义视觉项")
    elif visual_status_for_assets == "not_applicable":
        if asset_status != "not_applicable" or pending_asset_ids:
            errors.append("视觉计划不适用时资产状态应为 not_applicable 且 pending_asset_ids 为空")
    elif visual_status_for_assets == "unresolved":
        if asset_status != "unresolved" or pending_asset_ids:
            errors.append("视觉计划未解析时资产状态应为 unresolved 且 pending_asset_ids 为空")

    if outline_status != "ready" or unresolved_publication or acceptance == "fail":
        expected_publication = "blocked"
    elif acceptance in {"pass", "pass_with_warnings"} and asset_status in {"complete", "not_applicable"}:
        expected_publication = "ready"
    else:
        expected_publication = "pending_article"
    if readiness.get("publication_status") != expected_publication:
        errors.append(f"publication_status 应为 {expected_publication}")

    drafting_ids = set(readiness.get("drafting_blocker_ids") or [])
    publication_ids = set(readiness.get("publication_blocker_ids") or [])
    union_ids = set(readiness.get("blocking_fact_check_ids") or [])
    if drafting_ids != unresolved_drafting:
        errors.append("drafting_blocker_ids 与未解决的正文前核验项不一致")
    if publication_ids != unresolved_publication:
        errors.append("publication_blocker_ids 与未解决的发布阻断项不一致")
    if union_ids != drafting_ids | publication_ids:
        errors.append("blocking_fact_check_ids 必须是两类 blocker 的并集")

    narrative = plan.get("narrative_plan") or {}
    sections = narrative.get("sections") or []
    ordered_section_ids = [item.get("section_id") for item in sections]
    section_ids = {item for item in ordered_section_ids if item}
    if len(section_ids) != len(ordered_section_ids):
        errors.append("narrative_plan.sections 的 section_id 必须非空且唯一")
    if logic.get("section_count") != len(sections):
        errors.append("logic_review.section_count 与实际章节数不一致")
    recommended = logic.get("recommended_section_range") or {}
    minimum, maximum = recommended.get("min"), recommended.get("max")
    if isinstance(minimum, int) and isinstance(maximum, int):
        if not minimum <= len(sections) <= maximum and not logic.get("section_count_exception"):
            errors.append("章节数超出建议范围但未提供结构例外")

    template_errors, template_warnings = _validate_template_binding(plan, plan_path=plan_path)
    errors.extend(template_errors)
    warnings.extend(template_warnings)

    length_errors, length_warnings = _validate_length_plan(plan, sections, brief)
    errors.extend(length_errors)
    warnings.extend(length_warnings)

    supporting_claims = (plan.get("argument_plan") or {}).get("supporting_claims") or []
    # 证据池只收字符串 ID。ContentBrief 的 evidence_pack 里是 {claim, strength,
    # sources} 这样的映射，直接抄过来会被这里静默滤掉，池变空，随后 visual 的
    # 引用全被判成「未登记」——错报在下游，根因在这里。所以显式拦一次。
    dict_form_refs = [
        f"{item.get('claim_id') or item.get('section_id') or '?'}"
        for item in [*supporting_claims, *sections]
        for ref in (item.get("evidence_refs") or [])
        if not isinstance(ref, str)
    ]
    if dict_form_refs:
        errors.append(
            "evidence_refs 必须是字符串 ID（如 ev-001），不是 ContentBrief 里的"
            "{{claim, strength, sources}} 映射。ArticlePlan 的证据池由 "
            "supporting_claims 与 sections 的 evidence_refs 汇总而成，"
            "映射形态会被整条忽略、池变空，visual 的引用随后全判为未登记。"
            "先把 brief 的每条证据编成 ev-XXX 再引用（骨架的 evidence_pool 已给出编号）。"
            "当前有映射形态的位置：{where}".format(
                where="、".join(sorted(set(dict_form_refs))[:5]),
            )
        )
    known_evidence_ids = {
        ref
        for item in [*supporting_claims, *sections]
        for ref in (item.get("evidence_refs") or [])
        if isinstance(ref, str) and ref
    }
    claim_id_list = [item.get("claim_id") for item in supporting_claims]
    claims = {item for item in claim_id_list if item}
    if len(claims) != len(claim_id_list):
        errors.append("supporting_claims 的 claim_id 必须非空且唯一")
    for item in supporting_claims:
        claim_id = item.get("claim_id", "?")
        if not str(item.get("proof_obligation") or "").strip():
            errors.append(f"{claim_id}.proof_obligation 不能为空且只能描述一个主要证明任务")

    mappings = (plan.get("narrative_plan") or {}).get("claim_section_map") or []
    mapped_claim_id_list = [item.get("claim_id") for item in mappings]
    mapped_claims = {item for item in mapped_claim_id_list if item}
    if len(mapped_claims) != len(mapped_claim_id_list):
        errors.append("claim_section_map 的 claim_id 必须非空且唯一")
    if claims != mapped_claims:
        errors.append("claim_section_map 必须覆盖且只覆盖 supporting_claims")

    section_claims: dict[Any, set[Any]] = {}
    for section in sections:
        section_id = section.get("section_id")
        claim_ids = section.get("claim_ids") or []
        claim_id_set = set(claim_ids)
        section_claims[section_id] = claim_id_set
        if len(claim_id_set) != len(claim_ids):
            errors.append(f"{section_id}.claim_ids 不能重复")
        invalid_claim_ids = claim_id_set - claims
        if invalid_claim_ids:
            errors.append(f"{section_id}.claim_ids 包含未定义 claim")

    mapped_locations: dict[Any, set[Any]] = {}
    for item in mappings:
        claim_id = item.get("claim_id", "?")
        introduced = item.get("introduced_at")
        proof = item.get("primary_proof_section")
        supporting = set(item.get("supporting_sections") or [])
        referenced = set(item.get("referenced_by_sections") or [])
        if introduced not in section_ids:
            errors.append(f"{claim_id}.introduced_at 必须引用实际 section-XX，不能使用未计入篇幅的虚拟导语")
        if proof not in section_ids:
            errors.append(f"{claim_id}.primary_proof_section 不是有效章节")
        invalid_support = supporting - section_ids
        if invalid_support:
            errors.append(f"{claim_id}.supporting_sections 包含无效章节")
        invalid_references = referenced - section_ids
        if invalid_references:
            errors.append(f"{claim_id}.referenced_by_sections 包含无效章节")

        locations = {introduced, proof} | supporting | referenced
        mapped_locations[claim_id] = {location for location in locations if location in section_ids}
        for location in locations:
            if location in section_ids and claim_id not in section_claims.get(location, set()):
                errors.append(
                    f"{claim_id} 映射到 {location}，但该章节 claim_ids 未声明该 claim。"
                    "**别手改**——加 --write-back 重跑一次，会按 map 自动补齐")

        if introduced in section_ids:
            introduced_index = ordered_section_ids.index(introduced)
            earlier_locations = [
                location for location in mapped_locations[claim_id]
                if ordered_section_ids.index(location) < introduced_index
            ]
            if earlier_locations:
                errors.append(f"{claim_id}.introduced_at 不是该 claim 最早出现的章节")
        if introduced in section_ids and proof in section_ids:
            if ordered_section_ids.index(proof) < ordered_section_ids.index(introduced):
                errors.append(f"{claim_id}.primary_proof_section 不能早于 introduced_at")
            early_references = [
                location for location in referenced
                if location in section_ids and ordered_section_ids.index(location) < ordered_section_ids.index(proof)
            ]
            if early_references:
                errors.append(f"{claim_id}.referenced_by_sections 不能早于主要证明章节")

    for section_id, section_claim_ids in section_claims.items():
        for claim_id in section_claim_ids:
            if section_id not in mapped_locations.get(claim_id, set()):
                errors.append(
                    f"{section_id}.claim_ids 声明 {claim_id}，但 claim_section_map 未登记该章节角色。"
                    "**别手删 claim_ids**——那只治标：要么在 map 里给它一个角色，"
                    "要么确认这个 claim 不该出现在这节，然后加 --write-back 重跑")

    thesis_location = logic.get("thesis_stated_at")
    if thesis_location not in section_ids and not (is_story(plan) and not thesis_location):
        errors.append("logic_review.thesis_stated_at 必须引用实际 section-XX")

    hook_map = plan.get("hook_payoff_map") or {}
    core_hook = hook_map.get("core_hook") or {}
    if core_hook.get("status") not in {"planned", "defined", "not_applicable"}:
        errors.append("hook_payoff_map.core_hook.status 必须为 planned|defined|not_applicable")
    if core_hook.get("status") != "not_applicable":
        introduced = core_hook.get("introduced_at")
        payoff = core_hook.get("payoff_at")
        if not str(core_hook.get("question") or "").strip():
            errors.append("core_hook 非 not_applicable 时 question 不能为空")
        if introduced not in section_ids:
            errors.append("core_hook.introduced_at 必须引用实际 section-XX")
        if payoff not in section_ids:
            errors.append("core_hook.payoff_at 必须引用实际 section-XX")
        if introduced in section_ids and payoff in section_ids:
            if ordered_section_ids.index(payoff) < ordered_section_ids.index(introduced):
                errors.append("core_hook.payoff_at 不能早于 introduced_at")
    for index, local_hook in enumerate(hook_map.get("local_hooks") or [], 1):
        for field in ("introduced_at", "payoff_at"):
            if local_hook.get(field) not in section_ids:
                errors.append(f"local_hook-{index}.{field} 必须引用实际 section-XX")

    visual_status = plan.get("visual_plan_status")
    visuals = plan.get("visual_plan") or []
    visual_reason = str(plan.get("visual_plan_reason") or "").strip()
    if visual_status not in {"defined", "not_applicable", "unresolved"}:
        errors.append("visual_plan_status 必须为 defined|not_applicable|unresolved")
    if visual_status == "defined" and not visuals:
        errors.append("visual_plan_status=defined 时 visual_plan 不能为空")
    if visual_status in {"not_applicable", "unresolved"} and not visual_reason:
        errors.append(f"visual_plan_status={visual_status} 时必须说明 visual_plan_reason")
    if visual_status == "not_applicable" and visuals:
        errors.append("visual_plan_status=not_applicable 时 visual_plan 必须为空")

    _validate_presentation(plan, errors)
    _validate_term_glossary(plan, errors, warnings)
    _validate_cover(plan, errors, warnings, visuals)
    _validate_distribution_commitments(plan, errors, warnings)

    visual_ids: list[Any] = []
    for index, visual in enumerate(visuals, 1):
        prefix = f"visual_plan[{index}]"
        visual_ids.append(visual.get("visual_id"))
        # `placement` 对封面豁免——**两道门禁都要豁免**，只改下面那条 section-XX
        # 引用检查是不够的：这里还有一道「不能为空」。
        # （这道是写测试时用真校验器跑出来的；手抄规则的测试版本放过了它。）
        required_fields = ("visual_id", "type", "placement", "understanding_task",
                           "basis", "information_gain")
        if visual.get("asset_role") == "cover":
            required_fields = tuple(f for f in required_fields if f != "placement")
        for field in required_fields:
            if not str(visual.get(field) or "").strip():
                errors.append(f"{prefix}.{field} 不能为空")
        if visual.get("status") != "defined":
            errors.append(f"{prefix}.status 必须为 defined")
        if visual.get("asset_role") not in ASSET_ROLES:
            errors.append(f"{prefix}.asset_role 必须为 cover|body|social|storyboard")
        goal = visual.get("visual_goal")
        if goal not in VISUAL_GOALS:
            errors.append(f"{prefix}.visual_goal 非法")
        if not str(visual.get("key_message") or "").strip():
            errors.append(f"{prefix}.key_message 不能为空")
        if visual.get("render_preference") not in RENDER_PREFERENCES:
            errors.append(f"{prefix}.render_preference 必须为 auto|deterministic|ai|source")
        for list_field in ("evidence_refs", "must_include", "must_avoid"):
            value = visual.get(list_field)
            if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
                errors.append(f"{prefix}.{list_field} 必须为字符串数组")
        # 只对字符串做集合运算。上面那条「必须为字符串数组」已经报过错了，
        # 这里再拿原值进 set() 会因 dict 不可哈希直接 TypeError——
        # 报了业务错却仍然崩，人看到的是 traceback 不是那条错。
        visual_refs = {item for item in (visual.get("evidence_refs") or [])
                       if isinstance(item, str)}
        invalid_evidence_refs = visual_refs - known_evidence_ids
        if invalid_evidence_refs:
            errors.append(f"{prefix}.evidence_refs 包含 ArticlePlan 未登记的证据")
        if goal in {"relationship", "process", "comparison", "trend", "structure", "instruction"} and not visual.get("must_include"):
            if upgraded:
                warnings.append(f"{prefix} 来自旧契约且缺少 must_include；配图前应补充关键实体或阶段")
            else:
                errors.append(f"{prefix}.{goal} 必须提供 must_include")
        if goal == "trend" and not visual.get("evidence_refs"):
            errors.append(f"{prefix}.trend 必须提供 evidence_refs，不能凭空生成数据图")
        if goal == "evidence_capture" and visual.get("render_preference") not in {"auto", "source"}:
            errors.append(f"{prefix}.evidence_capture 只能使用 auto|source")
        if goal == "evidence_capture" and not str(visual.get("source_ref") or "").strip():
            errors.append(f"{prefix}.evidence_capture 必须提供真实 source_ref")
        if goal in {"relationship", "process", "comparison", "trend", "structure", "instruction"} and visual.get("render_preference") == "ai":
            errors.append(f"{prefix}.{goal} 不得指定 ai，事实结构图必须确定性渲染")
        # ⛔ **封面没有正文位置，这一条对它不成立。**
        #
        # 两个校验器原先对同一个封面给出互相矛盾的要求：
        #   这里（大纲侧）：每个 visual 的 placement 必须引用真实 section-XX，封面不例外
        #   validate_article（正文侧）：封面在 visual_slot_map 里 section_id 必须为空
        # 于是「封面属于 section-01」和「封面没有 section」同时成立。
        #
        # 实测的后果：调用方为解开这个矛盾**读了六段校验器源码**
        # （`sed -n '595,650p'`、`720,760p`、`1410,1465p'` …），
        # 而 SKILL.md 正好写着「⛔ 不要读脚本源码推断入参」——
        # **规则禁止的动作，恰好是唯一能解开矛盾的动作**。
        # 它最后还删掉了 section-01 的正文配图占位来迁就这套机制。
        #
        # 现在：封面的 `placement` **可以留空**（推荐）。填了也不报错——
        # 存量 plan 都是被上面那条旧规则逼着填的——但给一条 warning 说明它不生效。
        is_cover = visual.get("asset_role") == "cover"
        placement_raw = str(visual.get("placement") or "").strip()
        placement_refs = set(re.findall(r"section-\d+", placement_raw))
        if is_cover:
            if placement_raw:
                warnings.append(
                    f"{prefix} 是封面（asset_role=cover），它的 placement「{placement_raw[:24]}」"
                    "**不参与正文位置映射**——封面是独立头图，在 ArticleManifest.visual_slot_map 里"
                    "固定 `ordinal: 0`、`section_id: \"\"`。建议留空。"
                    "（section-01 另外还需要一张正文配图时，在 visual_plan 里**另开一项** "
                    "`asset_role: body`，不要让封面兼任。）")
            if placement_refs - section_ids:
                errors.append(f"{prefix}.placement 包含无效章节")
        elif not placement_refs:
            errors.append(f"{prefix}.placement 必须引用至少一个实际 section-XX")
        elif placement_refs - section_ids:
            errors.append(f"{prefix}.placement 包含无效章节")
    if any(not item for item in visual_ids) or len(set(visual_ids)) != len(visual_ids):
        errors.append("visual_plan 的 visual_id 必须非空且唯一")
    known_visual_ids = set(visual_ids)
    for section in sections:
        invalid_visual_refs = set(section.get("visual_refs") or []) - known_visual_ids
        if invalid_visual_refs:
            errors.append(f"{section.get('section_id', '?')}.visual_refs 包含无效配图引用")

    for section in sections:
        contribution = section.get("unique_contribution") or {}
        removal = str(contribution.get("removal_consequence") or "").strip("。 ")
        if removal in GENERIC_REMOVAL or len(removal) < 12:
            errors.append(f"{section.get('section_id', '?')} 缺少具体删除后果")

    unsupported = set(truth.get("unsupported_amplifiers") or [])
    supported_items = truth.get("supported_amplifiers") or []
    # 每项必须是 {term, evidence_refs} 的映射。写成裸字符串列表会在这里
    # AttributeError 崩掉——那是脚本 bug 不是内容问题，报错要说清正确形状。
    malformed = [item for item in supported_items if not isinstance(item, Mapping)]
    if malformed:
        errors.append(
            "truth_strength_review.supported_amplifiers 每项必须是映射，"
            "不是裸字符串。正确形状："
            "- term: 全部 / evidence_refs: [ev-001]（登记这个词由哪条证据支持）。"
            "当前有 {n} 项写成了字符串：{sample}".format(
                n=len(malformed),
                sample="、".join(str(item) for item in malformed[:3]),
            )
        )
    supported = {
        item.get("term")
        for item in supported_items
        if isinstance(item, Mapping) and item.get("term") and item.get("evidence_refs")
    }
    truth_strings = _strings_for_truth_check(plan)
    for location, value in truth_strings:
        for term in RISKY_AMPLIFIERS:
            if term in value and term not in supported:
                unsupported.add(term)
                warnings.append(f"{location} 出现需核验强度词：{term}")
    if unsupported and truth.get("status") == "pass":
        # 报错要自己说清「扫哪儿」和「怎么脱困」。原先只有前半句，实测中
        # agent 为此读了一遍校验器源码才知道 canonical_judgment 不在扫描内，
        # 在此之前它已经把一批本来合法的强度词删掉了——那一整轮是白工。
        # 扫描字段从 truth_strings 现取，改了实现文案自动跟着变。
        scanned = [loc for loc, _ in truth_strings if not loc.startswith("claim:")]
        errors.append(
            "存在无证据强度词时 truth_strength_review.status 不能为 pass。"
            "命中：{hit}。两条路二选一——改措辞去掉这些词；"
            "或在 truth_strength_review.supported_amplifiers 里登记该词——"
            "每项是映射不是字符串，形如 `- term: 全部` 配 `evidence_refs: [ev-001]`，"
            "有证据的强度词是允许的。"
            "扫描范围只有对外表达字段（{scanned}，以及每条 supporting_claims.statement）——"
            "editorial_core.canonical_judgment 是选题定的语义基线，"
            "不在扫描内，别去改它。".format(
                hit="、".join(sorted(unsupported)),
                scanned="、".join(scanned),
            )
        )

    if unresolved_publication:
        unsafe_temporal = list(truth.get("unsafe_temporal_claims") or [])
        for location, value in truth_strings:
            if RISKY_TEMPORAL.search(value):
                unsafe_temporal.append(f"{location}: {value}")
        if unsafe_temporal and truth.get("status") == "pass":
            errors.append("存在未核验实时表述时 truth_strength_review.status 不能为 pass")

    return errors, warnings


def _scaffold(args: argparse.Namespace) -> int:
    """生成骨架而不是校验现成的。

    **契约的唯一真相在这个文件里**，所以骨架也从这里出：模板是手抄的一份副本，
    改了这边忘了那边就会产出「看着对、校验不过」的东西。
    """
    from .article_plan_scaffold import (
        ScaffoldError, build_scaffold, parse_shares, todo_list,
    )

    if args.input:
        print("--input 是「校验这一份」，--scaffold 是「生成一份」，"
              "同时给说不清要做哪件", file=sys.stderr)
        return 2
    if not args.out:
        print("--scaffold 需要 --out 指定骨架写到哪里", file=sys.stderr)
        return 2
    out = Path(args.out)
    # 覆盖一份写好的 ArticlePlan 等于抹掉几十个字段的心血，而且不可撤销。
    if out.exists() and not args.force:
        print(f"{out} 已存在。要覆盖请显式加 --force——"
              "一份填好的 ArticlePlan 是几十个字段的活儿，冲掉了没处找",
              file=sys.stderr)
        return 2

    brief = None
    if args.brief:
        brief = yaml.safe_load(Path(args.brief).read_text(encoding="utf-8"))
        if not isinstance(brief, dict):
            print("ContentBrief YAML 根节点必须是对象", file=sys.stderr)
            return 2
    try:
        plan = build_scaffold(
            sections=args.sections, claims=args.claims, visuals=args.visuals,
            target_total=args.target_total, shares=parse_shares(args.shares),
            length_shape=args.length_shape, generation_mode=args.generation_mode,
            article_id=args.article_id, channel_code=args.channel_code,
            account_code=args.account_code, brief=brief,
            content_kind=getattr(args, "content_kind", "analysis"),
            truth_mode=getattr(args, "truth_mode", None))
    except ScaffoldError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(dump_yaml_compatible(plan), encoding="utf-8")
    # 只报**这份骨架里确实还空着**的项。固定清单会把已从 ContentBrief
    # 带过来的字段也念一遍，人得挨个回去确认「这条是不是已经有了」。
    # **枚举随骨架一起给出来，别让人去翻源码。**
    #
    # 必填字段的报错一直够用（字段路径 + 要什么），真正逼人去 `grep` 校验器的是
    # **后触发的规则**：枚举取值、占比区间、强度词表——它们只有填错了才现身，
    # 而"填错一次再改"在几十个字段上会滚成很多轮。实测一次大纲 39 次 exec 里
    # **17 次在 sed/grep 校验器源码**，连读约 700 行。
    #
    # 所以骨架直接带上最常撞的那几组，其余用 `--explain <字段路径>` 单查。
    hot = ("length_plan.length_shape", "narrative_plan.sections[].length_role",
           "narrative_plan.template_selection", "narrative_plan.template_adoption",
           "narrative_plan.opening_strategy.opening_source",
           "production_plan.fact_checks[].status",
           "production_plan.fact_checks[].verification_source",
           "visual_plan[].render_preference")
    specs = field_specs()
    print(json.dumps({
        "status": "scaffold", "plan_path": str(out),
        "sections": args.sections,
        "todo": todo_list(plan),
        "enums": {path: specs[path]["legal_values"] for path in hot if path in specs},
        "hint": "枚举与阈值用 `--explain <字段路径>` 查（如 "
                "`--explain truth_strength_review.risky_amplifiers`）。"
                "⛔ **不要去读校验器源码**——必填项看报错就够，枚举类走 --explain。",
    }, ensure_ascii=False))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", help="ArticlePlan YAML path；校验时必填")
    parser.add_argument("--manifest", help="ArticleManifest YAML path for final publication-state validation")
    parser.add_argument("--brief", help="ContentBrief YAML path；用于核对 target_account 是否与选题一致")
    parser.add_argument("--write-back", action="store_true", help="Write validation status into YAML")
    parser.add_argument("--result-file", help="把含 checked_at 的完整校验结果写到产物之外的这个路径")
    parser.add_argument(
        "--explain", nargs="?", const="", metavar="字段路径",
        help="问某个字段的合法取值与要点，如 --explain length_plan.length_shape；"
             "不给路径就列出所有可查的字段。**用它代替去 grep 校验器源码**")

    from .article_plan_scaffold import add_arguments as _scaffold_arguments

    _scaffold_arguments(parser)
    parser.add_argument("--channel-code", default="",
                        help="如 wechat_public_account；给了 --brief 时可省")
    parser.add_argument("--account-code", default="",
                        help="如 data_ontology；给了 --brief 时可省")
    args = parser.parse_args()

    if args.explain is not None:
        result = explain(args.explain)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("status") == "ok" else 1
    if args.scaffold:
        return _scaffold(args)
    if not args.input:
        parser.error("--input 是必填的（除非用 --scaffold 生成骨架，或用 --explain 查字段）")

    path = Path(args.input)
    plan = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(plan, dict):
        print(json.dumps({"status": "fail", "failures": ["YAML 根节点必须是对象"]}, ensure_ascii=False))
        return 1

    manifest = None
    if args.manifest:
        manifest_path = Path(args.manifest)
        manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(manifest, dict):
            print(json.dumps({"status": "fail", "failures": ["ArticleManifest YAML 根节点必须是对象"]}, ensure_ascii=False))
            return 1

    brief = None
    if args.brief:
        brief = yaml.safe_load(Path(args.brief).read_text(encoding="utf-8"))
        if not isinstance(brief, dict):
            print(json.dumps({"status": "fail", "failures": ["ContentBrief YAML 根节点必须是对象"]},
                             ensure_ascii=False))
            return 1

    synced: list[str] = []
    if args.write_back:
        # **先同步再校验。** 反过来的话，报出来的还是同步前那批交叉引用错，
        # 调用方照着改一遍，下一轮又被 write-back 改回去——白跑。
        synced = sync_claim_ids(plan)

    errors, warnings = validate(plan, manifest, brief, plan_path=path)
    if manifest is not None and args.manifest:
        errors.extend(_validate_image_asset_manifests(manifest, Path(args.manifest).resolve()))
    validation = _mapping_at(plan, "contract_validation")
    validation["status"] = "fail" if errors else "pass"
    validation["failures"] = errors
    validation["warnings"] = warnings
    # checked_at 是运行时墙钟时间，**不得写进产物**：ArticlePlan 会被 sha256 整体哈希并受
    # 不可变机制保护，写入时间戳会让"同样的语义内容"每次校验都产生不同哈希，一旦碰过已提交
    # 的文件就再也无法复现原哈希（时间戳造不出来），从而把工作流永久锁死在
    # IMMUTABLE_ARTIFACT_CHANGED。时间戳只出现在 stdout 与 --result-file。
    validation.pop("checked_at", None)
    if args.write_back:
        path.write_text(dump_yaml_compatible(plan), encoding="utf-8")
    if synced:
        warnings.append(
            "已按 claim_section_map 反推并改写 {0} 个章节的 claim_ids：{1}。"
            "**map 是唯一真相**（它带角色，投影不带），"
            "要改归属改 map，不要手改 claim_ids。".format(len(synced), "；".join(synced)))

    checked_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    report = {
        "status": validation["status"],
        "checked_at": checked_at,
        "plan_path": str(path),
        "failures": errors,
        "warnings": warnings,
    }
    if args.result_file:
        result_path = Path(args.result_file)
        result_path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(report, ensure_ascii=False, indent=2) + chr(10)
        result_path.write_text(payload, encoding="utf-8", newline=chr(10))

    print(json.dumps({"status": validation["status"], "failures": errors, "warnings": warnings}, ensure_ascii=False))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
