#!/usr/bin/env python3
"""生成 ArticlePlan 骨架：机器能算的都算好，只留要人写的。

## 为什么不是照抄模板

`assets/article-plan.yaml` 原样丢给校验器报 **50 条错**。逐条看，只有一小半
是「人得想」的（判断、章节小结、删除后果），其余全是机器自己就能算的：
章节数、篇幅区间、就绪态、ID 交叉引用、枚举默认值。

还有 10 条来自模板自带的**示例块**——一个 `visual_plan` 条目和一个 `fact-001`
条目。它们必须被填满或删掉，而模板不说要删。**模板自带的例子是个陷阱。**

平台实测里 ArticlePlan 那一步花了 11 次调用：写一版、校验、改、再校验、再改，
第三次才过。在这之前 agent 已经读了 40 KB 契约散文——**读散文没能让它一次写对，
真正的规则在校验器里。** 那就让校验器把骨架吐出来。

## 一条纪律：默认值只来自校验器的常量

`LENGTH_ROLES`、`LENGTH_SHAPES`、`PLAN_SCHEMA_VERSION` 一律 import，不手抄。
这个仓库反复栽的跟头就是「文档一份、代码一份，改了一处忘另一处」——
而**代码赢**，文档说得再对也拦不住。

## 另一条：ArticlePlan 有一大半是 ContentBrief 的重述

target_account、核心判断、标题、受众、主张、篇幅区间、术语、表达边界——
这些选题阶段已经定过一次，不该由人再抄一遍。给了 `--brief` 就全带过来。
"""

from __future__ import annotations

import argparse
from typing import Any, Mapping, Sequence

from .validate_article_plan import (
    DEFAULT_LAYOUT_PROFILE, DEFAULT_THEME_PROFILE,
    LENGTH_ROLES, LENGTH_SHAPES, PLAN_SCHEMA_VERSION,
)
from .story_contract import CONTENT_KINDS, STORY_KINDS, TRUTH_MODES, is_story


class ScaffoldError(ValueError):
    """参数说不通，不是内容不对。"""


#: 默认篇幅策略。`custom` 是唯一不对章节角色比例作断言的一种——
#: 骨架阶段还没有内容，`front_light_core_heavy_end_light` 那类会当场要求
#: 「至少一节 core_proof、核心占 45–65%」，那是在替作者做编辑决定。
#:
#: 代价是 `custom` 必须登记 `shape_exception` 并说明原因。给了 `--shares`
#: 时理由是机器能写的（照素材给定的比例）；没给就留空，作者填。
DEFAULT_SHAPE = "custom"

#: 默认成文目标。3800 是公众号深度长文的常见量级，给一个能跑的数比留 0 强。
DEFAULT_TARGET_TOTAL = 3800

#: 允许区间相对目标的宽容度。校验器只要求 min ≤ target ≤ max。
RANGE_TOLERANCE = 0.10

#: 章节数的建议区间。超出要写 `section_count_exception`——
#: 骨架按实际章节数给区间，不制造一条「超出建议范围」的假错误。
SECTION_RANGE_PAD = 1

#: 渠道默认的读者侧出处展示方式。公众号正文外链基本不可点，
#: 「读者点得到的出处」在那个渠道交付不了，因此默认 omitted。
#: 选 omitted 时校验反而更严：所有 fact check 必须 verified。
CITATION_DEFAULTS = {
    "wechat_public_account": "omitted",
    "shipinhao": "omitted",
    "wechat_channels": "omitted",
}
CITATION_FALLBACK = "endnote"


def section_id(index: int, total: int) -> str:
    """`section-01`。位数按总数取齐——`section-9` 与 `section-10` 混排字典序会乱。"""
    width = max(2, len(str(total)))
    return f"section-{index + 1:0{width}d}"


def role_for(index: int, total: int) -> str:
    """按位置给一个合法的篇幅角色。

    首节 `opening`、末节 `conclusion`、中间 `development`——三者都在
    `LENGTH_ROLES` 里，且不对内容作任何假设。作者按实际改。
    单节文章只有 `opening`：一篇文章不可能既是开头又是结尾。
    """
    if total <= 1 or index == 0:
        role = "opening"
    elif index == total - 1:
        role = "conclusion"
    else:
        role = "development"
    # 常量来自校验器。真改了那边而这里没跟上，这一行会当场炸，
    # 而不是产出一份「看着对、校验不过」的骨架。
    assert role in LENGTH_ROLES, f"{role} 不在校验器的 LENGTH_ROLES 里"
    return role


def split_length(total: int, count: int,
                 shares: Sequence[float] | None = None) -> list[int]:
    """把总篇幅分到各节，**余数落到最后一节，不蒸发**。

    校验器要求「章节合计 == target_total」，差 0.5 就报错。
    三等分 4000 若各取 1333，合计 3999——这类错在实测里是要多跑一轮校验的。
    """
    if count <= 0:
        raise ScaffoldError("章节数必须为正")
    if shares is None:
        weights = [1.0] * count
    else:
        if len(shares) != count:
            raise ScaffoldError(
                f"给了 {len(shares)} 个篇幅占比，但有 {count} 节——"
                "占比必须覆盖每一节，少一个就说不清那节该占多少")
        weights = [float(s) for s in shares]
    if sum(weights) <= 0:
        raise ScaffoldError("篇幅占比合计必须为正")
    scale = total / sum(weights)
    lengths = [max(1, int(round(w * scale))) for w in weights]
    lengths[-1] += total - sum(lengths)
    if lengths[-1] < 1:  # 极端参数下最后一节被压穿，说明占比本身不合理
        raise ScaffoldError("按给定占比分配后末节篇幅不足 1，请检查占比或目标字数")
    return lengths


def _text(node: Mapping[str, Any] | None, *path: str) -> str:
    current: Any = node or {}
    for key in path:
        current = (current or {}).get(key) if isinstance(current, Mapping) else None
    return str(current or "").strip()


def _list(node: Mapping[str, Any] | None, *path: str) -> list:
    current: Any = node or {}
    for key in path:
        current = (current or {}).get(key) if isinstance(current, Mapping) else None
    return list(current) if isinstance(current, list) else []


def _evidence_pool_from(brief: Mapping[str, Any] | None) -> list[dict[str, Any]]:
    """把 ContentBrief 的 `evidence_pack` 编成 `ev-XXX` 字符串 ID 池。

    ArticlePlan 的证据池是**字符串 ID**，由 supporting_claims 与 sections 的
    `evidence_refs` 汇总而成；而 brief 里每条证据是 `{claim, strength, sources}`
    映射，两边形态对不上。骨架把 brief 的其它字段都带过来了，唯独证据没带,
    于是作者只能手抄——抄的是 brief 的原生形态，撞上校验器要 ID。实测一次会话
    为此读了三遍校验器源码、把 15 条映射逐条转成 ev-001…ev-015、又回填一遍
    visual 的引用。编号是机器能做的，不该让人做。

    只登记身份与出处，不搬正文——原文留在 `.runtime/retrieval/`，
    搬进来等于把上下文污染又搬回一遍。
    """
    pool: list[dict[str, Any]] = []
    for origin in ("internal_refs", "external_refs"):
        for item in _list(brief, "evidence_pack", origin):
            if not isinstance(item, Mapping):
                continue
            sources = item.get("sources")
            first = sources[0] if isinstance(sources, list) and sources else {}
            pool.append({
                "evidence_id": f"ev-{len(pool) + 1:03d}",
                "origin": origin.replace("_refs", ""),
                "claim": _text(item, "claim"),
                "strength": _text(item, "strength"),
                "source": _text(first, "url") if isinstance(first, Mapping) else "",
            })
    return pool


def _claims_from(brief: Mapping[str, Any] | None) -> list[str]:
    found = []
    for entry in _list(brief, "claims"):
        if isinstance(entry, Mapping):
            found.append(str(entry.get("statement") or "").strip())
        elif isinstance(entry, str):
            found.append(entry.strip())
    return found


def build_scaffold(
    *,
    sections: int,
    claims: int | None = None,
    visuals: int = 0,
    target_total: int | None = None,
    shares: Sequence[float] | None = None,
    length_shape: str | None = None,
    generation_mode: str = "plan_only",
    article_id: str = "article-001",
    channel_code: str = "",
    account_code: str = "",
    brief: Mapping[str, Any] | None = None,
    content_kind: str = "analysis",
    truth_mode: str | None = None,
) -> dict[str, Any]:
    """产出一份「只差自由文本」的 ArticlePlan。

    验收标准写在测试里：把骨架所有空字符串机械填上占位内容，校验必须直接通过。
    漏了任何一个枚举，机械填充会给它塞非法值，校验立刻炸。
    """
    if sections <= 0:
        raise ScaffoldError("--sections 必须为正整数")
    if content_kind not in CONTENT_KINDS:
        raise ScaffoldError("--content-kind 只能是 analysis|story_marketing|short_fiction")
    story_mode = content_kind in STORY_KINDS
    if story_mode and truth_mode not in TRUTH_MODES:
        raise ScaffoldError("故事骨架需显式 --truth-mode real_case|adapted_case|fictional_scenario")
    shape = length_shape or ("narrative_arc" if story_mode else DEFAULT_SHAPE)
    if shape not in LENGTH_SHAPES:
        raise ScaffoldError(
            f"{shape} 不是支持的篇幅策略。可选：{'|'.join(sorted(LENGTH_SHAPES))}")
    if generation_mode not in {"plan_only", "full_article", "revise_article"}:
        raise ScaffoldError(
            "--generation-mode 只能是 plan_only|full_article|revise_article")

    brief_statements = _claims_from(brief)
    claim_count = claims if claims is not None else (len(brief_statements) or (0 if content_kind == "short_fiction" else 1))
    if claim_count < 0 or (claim_count == 0 and content_kind != "short_fiction"):
        raise ScaffoldError("--claims 必须为正整数；纯小说无真实主张时可为 0")

    # 篇幅：显式参数 > brief 的字数区间 > 默认值。
    hinted = _text(brief, "modality_hints", "article", "target_word_count_range")
    hint_range = ((brief or {}).get("modality_hints") or {}).get("article", {}) \
        if isinstance(brief, Mapping) else {}
    hint_range = (hint_range or {}).get("target_word_count_range") or {}
    hint_min, hint_max = hint_range.get("min"), hint_range.get("max")
    if target_total is not None:
        total = int(target_total)
        allowed = {"min": int(total * (1 - RANGE_TOLERANCE)),
                   "max": int(total * (1 + RANGE_TOLERANCE))}
        if isinstance(hint_min, int) and isinstance(hint_max, int) and 0 < hint_min <= hint_max:
            if total > hint_max:
                raise ScaffoldError("--target-total 超出 ContentBrief 篇幅上限；先确认并修改上游预算")
            # 显式目标不能让 ±10% 自动放宽上游上限；更短的目标仍可沿用原有收紧规则。
            allowed["max"] = min(allowed["max"], hint_max)
            if total >= hint_min:
                allowed["min"] = max(allowed["min"], hint_min)
    elif isinstance(hint_min, int) and isinstance(hint_max, int) and hint_min > 0:
        total = (hint_min + hint_max) // 2
        allowed = {"min": hint_min, "max": hint_max}
    else:
        total = DEFAULT_TARGET_TOTAL
        allowed = {"min": int(total * (1 - RANGE_TOLERANCE)),
                   "max": int(total * (1 + RANGE_TOLERANCE))}

    lengths = split_length(total, sections, shares)
    # `custom` 必须登记例外并说明原因。给了占比时理由是事实陈述，机器能写；
    # 没给就留空，让它作为一条编辑待办浮上来——而不是替作者编一句。
    if shape == "custom":
        percent = "/".join(str(round(s)) for s in shares) if shares else ""
        shape_exception = {
            "status": "defined",
            "reason": (f"按素材给定的 {percent} 比例分配，预置形状套不上。"
                       if percent else ""),
            "affected_roles": [],
        }
    else:
        shape_exception = {"status": "not_applicable", "reason": "",
                           "affected_roles": []}
    ids = [section_id(i, sections) for i in range(sections)]
    claim_ids = [f"claim-{n:03d}" for n in range(1, claim_count + 1)]

    # 显式参数优先于 brief：没有 brief 时也得能生成一份能过账号校验的骨架。
    channel = channel_code or _text(brief, "target_account", "channel_code")
    account = account_code or _text(brief, "target_account", "account_code")
    app_id = _text(brief, "target_account", "app_id")
    target_account = {"channel_code": channel}
    if app_id:
        target_account["app_id"] = app_id
    if account or not app_id:
        target_account["account_code"] = account

    # 主张与章节的配对**不预设**。
    #
    # 这里原先按下标硬配：第 n 条主张落在第 n 节。它是「先给一组合法引用」的
    # 好意，实际却是一组必然被推翻的引用——主张顺序本来就不等于叙事顺序。
    # 实测一次会话拿到骨架后立刻重排了全部配对，为了改这两处一致，把整份
    # 三万八千字的 YAML 重写了一遍。给错默认值比留空贵得多：留空只是要填，
    # 给错要先识破、再推翻、再两处同步。
    #
    # 所以 claim_section_map 保留骨架结构（claim_id 列表照给，省手写），
    # 但落点留空并进 todo；sections[].claim_ids 同样留空。**两处必须对上**，
    # 校验器会核对，这是唯一要作者亲自做的编辑决策。

    body = [
        {
            "section_id": ids[index],
            "heading": "",
            "purpose": "",
            "reader_question": "",
            "section_judgment": "",
            "claim_ids": [],
            "key_points": [],
            "evidence_refs": [],
            "evidence_summary": "",
            "fact_analysis_boundary": [],
            "unique_contribution": {
                "causal_role": "",
                "new_question_answered": "",
                "new_evidence_added": "",
                "new_inference_added": "",
                # 校验器专门拦「文章不完整」这类空话，所以这里留空而不是给套话。
                "removal_consequence": "",
                "why_not_merge_with_previous": "",
            },
            "transition_to_next": "",
            "length_role": role_for(index, sections),
            "target_length": lengths[index],
            "length_share": 0,  # 校验器按 target_length / target_total 回写
            "length_rationale": {
                "evidence_density": "medium",
                "reasoning_load": "medium",
                "reader_difficulty": "medium",
                "explanation": "",
            },
            "hook_role": "none",
            "visual_refs": [],
        }
        for index in range(sections)
    ]

    visual_ids = [f"visual-{n:03d}" for n in range(1, visuals + 1)]
    visual_plan = [
        {
            "visual_id": vid,
            "asset_role": "body",
            "visual_goal": "concept",
            "diagram_subtype": "",
            "type": "information_graphic",
            "placement": ids[min(index, sections - 1)],
            "understanding_task": "",
            "key_message": "",
            "basis": "",
            "evidence_refs": [],
            "information_gain": "",
            "must_include": [],
            "must_avoid": [],
            "source_ref": "",
            "render_preference": "auto",
            "status": "defined",
        }
        for index, vid in enumerate(visual_ids)
    ]
    visual_status = "defined" if visual_plan else "not_applicable"
    visual_reason = ("每张图承担一个理解任务，不做装饰性配图。"
                     if visual_plan else "本篇以论证推进为主，不安排配图。")

    plan = {
        "schema_version": PLAN_SCHEMA_VERSION,
        "article_id": article_id,
        "brief_id": _text(brief, "brief_id") or "brief-001",
        "topic_id": _text(brief, "topic_id") or "topic-001",
        "workflow": {
            "workflow_id": "",
            "content_family_id": "",
            "content_id": article_id,
            "revision": 1,
            "allocation_path": "",
            "producer": {"skill": "write-article", "version": "1.0.0"},
        },
        "source_artifacts": [],
        # 证据 ID 池：`evidence_refs` 只认这里的 evidence_id 字符串。
        # 从 ContentBrief 的 evidence_pack 编号带过来，作者直接引 ID，
        # **不要把 brief 的 {claim, strength, sources} 映射抄进 evidence_refs**。
        "evidence_pool": _evidence_pool_from(brief),
        "generation_mode": generation_mode,
        "resolved_selection_status":
            "approved" if _text(brief, "selection_status") == "approved" else "selected",
        "target_account": target_account,
        "plan_status": "ready",
        "readiness": {
            # outline_status 必须等于 plan_status；drafting/publication 由
            # fact_checks 推导——骨架不带 fact check，所以是 ready / pending_article。
            "outline_status": "ready",
            "drafting_status": "ready",
            "publication_status": "pending_article",
            "article_acceptance_status": "not_started",
            "publication_asset_status": "pending" if visual_plan else "not_applicable",
            "pending_asset_ids": list(visual_ids),
            "blocking_fact_check_ids": [],
            "drafting_blocker_ids": [],
            "publication_blocker_ids": [],
            "summary": "",
        },
        "contract_validation": {"status": "not_run", "checked_at": None,
                                "failures": [], "warnings": []},
        "stop_after": ("ArticlePlan" if generation_mode == "plan_only"
                       else "ArticleAcceptanceReport"),
        "delivery": {"canonical_path": "", "human_view_path": ""},
        "editorial_core": {
            "canonical_judgment": _text(brief, "topic", "core_judgment"),
            "reader_facing_thesis": "",
            "thirty_second_summary": "",
            "reader_value": {"before_reading": "", "after_reading": "",
                             "decision_enabled": "", "action_enabled": ""},
            "causal_chain": [{"order": 1, "role": "", "statement": ""}],
        },
        "completeness_review": {
            "required_fields_status": "pass",
            "conditional_fields_status": "complete",
            "unresolved_items": [], "not_applicable_items": [], "blockers": [],
        },
        "truth_strength_review": {
            "canonical_scope": "", "reader_thesis_scope": "",
            "added_claims": [], "unsupported_amplifiers": [],
            "supported_amplifiers": [], "temporal_claims": [],
            "unsafe_temporal_claims": [],
            "status": "pass", "revision_actions": [],
        },
        "audience_plan": {
            "primary": _text(brief, "audience", "primary"),
            "secondary": [],
            "prior_knowledge": _list(brief, "audience", "prior_knowledge"),
            "current_problem": _text(brief, "audience", "current_problem"),
            "why_now_status": "timely" if _text(brief, "topic", "why_now") else "evergreen",
            "why_now": _text(brief, "topic", "why_now"),
            "cognitive_change": _text(brief, "audience", "desired_cognitive_change"),
            "action_change_status": "defined"
                if _text(brief, "audience", "desired_action_change") else "not_applicable",
            "action_change": _text(brief, "audience", "desired_action_change"),
        },
        "argument_plan": {
            # 必须逐字等于 editorial_core.reader_facing_thesis——校验器直接比字符串。
            "central_thesis": "",
            "supporting_claims": [
                {"claim_id": cid,
                 "statement": brief_statements[index] if index < len(brief_statements) else "",
                 "proof_obligation": "", "claim_type": "", "evidence_refs": []}
                for index, cid in enumerate(claim_ids)
            ],
            "counterpoints_status": "defined"
                if _list(brief, "narrative", "counterpoints") else "not_applicable",
            "counterpoints": _list(brief, "narrative", "counterpoints"),
            "counterpoints_reason": "" if _list(brief, "narrative", "counterpoints")
                                    else "本篇不设对立面，核心判断无实质反方。",
            "non_goals": _list(brief, "positioning", "non_goals"),
        },
        "narrative_plan": {
            "claim_section_map": [
                {"claim_id": cid,
                 "introduced_at": "",
                 "primary_proof_section": "",
                 "supporting_sections": [],
                 "referenced_by_sections": []}
                for cid in claim_ids
            ],
            # 写法模板绑定。**骨架必须把这几个键发出来**——此前 `opening_strategy`
            # 是这里硬编码的两个键，于是"只改 assets/article-plan.yaml"的改动
            # 永远到不了真实草稿：大纲由本脚本生成，不是照模板手抄的。
            # **默认是"没绑模板"，不是空字符串。**
            #
            # 空枚举会让骨架当场炸出三条硬错误，而骨架的契约是「可机械填充即通过」。
            # 更要紧的是：**不用模板本来就是合法状态**——兜底模板没有开头公式、
            # 用户可以自定结构、云盘可能取不到。把"未绑定"写成非法，
            # 等于逼着把自主推导的开头**假装**成模板来的。
            #
            # 取回模板后由写作流程覆盖这几个键；没覆盖时校验器会出一条
            # 「未绑定写法模板」的 warning——**合法，但看得见**。
            "template_selection": "none",
            "template_adoption": "not_applicable",
            "adoption_notes": "骨架生成时未取写法模板；取回后改 template_selection 与 template_adoption",
            "structure_template": {"remote_path": "", "snapshot_path": "", "sha256": ""},
            "opening_strategy": {"opening_source": "derived", "formula": "",
                                 "type": "", "content": ""},
            "central_question": _text(brief, "narrative", "central_question"),
            "sections": body,
            "title_payoff": _text(brief, "narrative", "title_payoff"),
            "closing_takeaway": _text(brief, "narrative", "closing_takeaway"),
        },
        "logic_review": {
            "thesis_clarity": "pass",
            "reader_value_clarity": "pass",
            "causal_chain_complete": True,
            "thesis_stated_early": True,
            "thesis_stated_at": ids[0],
            "title_concept_defined_early": True,
            "title_concept_definition": "",
            "section_count": sections,
            # 按实际章节数给区间，不制造一条「超出建议范围」的假错误。
            "recommended_section_range": {"min": max(1, sections - SECTION_RANGE_PAD),
                                          "max": sections + SECTION_RANGE_PAD},
            "section_count_exception": "",
            "repeated_sections": [],
            "section_unique_contributions": [],
            "status": "ready",
            "revision_actions": [],
        },
        "length_plan": {
            "length_unit": "chinese_characters",
            "length_shape": shape,
            "selection_reason": "",
            "target_total": total,
            "allowed_range": allowed,
            "front_matter_length": 0,
            "back_matter_length": 0,
            "shape_exception": shape_exception,
            "calculated": {"section_total": 0, "total_with_matter": 0,
                           "role_shares": {}, "section_max_min_ratio": None},
            "validation": {"status": "not_run", "violations": [], "warnings": []},
        },
        "visual_plan": visual_plan,
        "visual_plan_status": visual_status,
        "visual_plan_reason": visual_reason,
        "hook_payoff_map": {
            "core_hook": {"question": "", "introduced_at": ids[0],
                          "payoff_at": ids[-1], "status": "planned"},
            "local_hooks": [],
        },
        "production_plan": {
            "sources": [],
            "material_plan": {
                "official_sources": {"status": "not_applicable", "items": [], "handling": ""},
                "cases": {"status": "not_applicable", "items": [], "handling": ""},
                "data": {"status": "not_applicable", "items": [], "handling": ""},
                "quotes": {"status": "not_applicable", "items": [], "handling": ""},
            },
            # 示例块是陷阱：它必须被填满或删掉，而模板不说要删。
            # 真有要核验的事实，由作者按 references/article-planning.md 增补。
            "fact_checks": [],
            "tone": {"style": "", "technical_density": "", "avoid": []},
            "terminology": _list(brief, "production_requirements", "terminology"),
            # **不从 terminology 推导。** 那是给人看的自由文本（样例里有
            # 「禁止出现：…」这类条目），机械转过来就是把禁用词清单当术语表。
            # 由写正文的人填——他最清楚自己在哪定义了哪个词。
            "term_glossary": [],
            "expression_boundaries":
                _list(brief, "production_requirements", "expression_boundaries"),
        },
        "distribution_plan": {
            "final_title": _text(brief, "topic", "distribution_title"),
            "title_review": {
                # 校验器规定 `outline_status=ready` 时这里必须是 `pass`。
                # 骨架把「完成态」的开关先摆好，作者只填内容——摆成
                # `needs_revision` 会连带 readiness 四个字段一起要改，
                # 而那正是实测里多跑一轮校验的原因。
                #
                # 这不是替评审签字：标题承诺、读者价值、传播钩子五项仍然空着，
                # 校验一样过不去。**开关可以预置，内容不能代笔。**
                "status": "pass",
                "thesis_alignment_status": "pass",
                "title_promise": "", "thesis_connection": "", "reader_value": "",
                "propagation_hook": "", "sharing_reason": "",
                "distribution_strength_status": "pass",
                "unsupported_promises": [], "clickbait_risks": [],
                "revision_actions": [],
            },
            # 排版意图：缺省组合直接摆好。与 title_review 的开关预置同理——
            # **开关可以预置，内容不能代笔**：rationale 留空，要换组合时由作者写。
            "presentation": {
                "layout_profile": DEFAULT_LAYOUT_PROFILE,
                "theme_profile": DEFAULT_THEME_PROFILE,
                "rationale": "",
            },
            "citation_display": CITATION_DEFAULTS.get(channel, CITATION_FALLBACK),
            "cover_copy_status": "unresolved",
            "cover_copy": "",
            "cover_hook": {"hook_type": "", "copy_source": "", "reader_takeaway": ""},
            "summary": "",
            "first_screen_hook": "",
            "retention_points_status": "unresolved",
            "retention_points": [],
            "sharing_reason_status": "defined"
                if _text(brief, "distribution_requirements", "sharing_reason")
                else "unresolved",
            "sharing_reason": _text(brief, "distribution_requirements", "sharing_reason"),
            "closing_action_status": "defined"
                if _text(brief, "distribution_requirements", "desired_action")
                else "unresolved",
            "closing_action": _text(brief, "distribution_requirements", "desired_action"),
            "success_criteria": [],
        },
        "acceptance_criteria": [],
    }
    if story_mode:
        plan["content_kind"] = content_kind
        plan["truth_mode"] = truth_mode
        plan["story_plan"] = {
            "style": "", "viewpoint": "", "protagonist_goal": "",
            "central_conflict": "", "ending_intent": "",
            "source_refs": [], "adaptation_notes": "",
        }
        plan["narrative_plan"].update(body_format="scenes", summary_mode="hidden")
        plan["logic_review"].update(thesis_stated_early=False, thesis_stated_at="")
        plan["distribution_plan"]["digest"] = ""
        plan["distribution_plan"]["presentation"]["reading_profile"] = "story_modern"
        plan["visual_plan_reason"] = "本篇按场景推进，无额外配图。" if not visual_plan else visual_reason
        for section in body:
            section["section_kind"] = "scene"
            section["scene"] = {"goal": "", "obstacle": "", "action": "", "change": ""}
            section.pop("section_judgment", None)
            section.pop("evidence_summary", None)
            section["length_rationale"] = {"explanation": ""}
        if content_kind == "story_marketing":
            plan["marketing_plan"] = {
                "reader_problem": "", "product_role": "", "introduction_trigger": "",
                "conversion_goal": "", "cta": "", "offer_terms": "", "product_claim_ids": [],
            }
            for claim in plan["argument_plan"]["supporting_claims"]:
                claim["fact_check_ids"] = []
    return plan


#: 还差什么。**按「打开文件就能照着填」的顺序给**，不只报个数字——
#: 实测里 agent 拿到「50 条错」之后是逐条回头猜的，那才是花时间的地方。
TODO_HINTS = (
    ("editorial_core.canonical_judgment", "本文唯一的中心判断（选题定过就照抄）"),
    ("editorial_core.reader_facing_thesis", "给读者看的那句话；必须逐字等于 argument_plan.central_thesis"),
    ("argument_plan.central_thesis", "同上，逐字一致"),
    ("argument_plan.supporting_claims[].statement", "每条支撑主张一句话"),
    ("argument_plan.supporting_claims[].proof_obligation", "这条主张由哪一节完成证明"),
    ("narrative_plan.claim_section_map[].primary_proof_section",
     "这条主张主要由哪一节证明——顺手把同一节的 sections[].claim_ids 也写上，校验器核对两处一致"),
    ("narrative_plan.sections[].claim_ids",
     "这一节要证明哪几条主张；与 claim_section_map 必须互相对上"),
    ("narrative_plan.sections[].heading", "小标题"),
    ("narrative_plan.sections[].section_judgment", "本节只需证明的一句话判断"),
    ("narrative_plan.sections[].evidence_summary", "面向读者的来源说明，不暴露内部证据 ID"),
    ("narrative_plan.sections[].unique_contribution.removal_consequence",
     "删掉这一节，读者具体缺什么——写「文章不完整」会被拦"),
    ("narrative_plan.sections[].length_rationale.explanation", "这一节为什么占这么多字"),
    ("length_plan.selection_reason", "为什么选这个篇幅形状"),
    ("length_plan.shape_exception.reason",
     "用 custom 时为什么预置形状套不上——给了 --shares 就已自动写好"),
    ("distribution_plan.final_title", "传播标题"),
    ("distribution_plan.title_review.*", "标题承诺、与中心思想的对应、读者价值、传播钩子、转发理由"),
    ("hook_payoff_map.core_hook.question", "开篇抛出、结尾兑现的那个问题"),
)


def todo_list(plan: Mapping[str, Any]) -> list[str]:
    """只报**这份骨架里确实还空着**的项。

    固定清单会把已经从 ContentBrief 带过来的字段也念一遍，
    人得挨个回去确认「这条是不是已经有了」——那正是要省掉的动作。
    """
    remaining = []
    for path, hint in TODO_HINTS:
        if is_story(plan) and path in {
            "narrative_plan.sections[].section_judgment",
            "narrative_plan.sections[].evidence_summary",
            "narrative_plan.sections[].claim_ids",
        }:
            continue
        if _still_blank(plan, path):
            remaining.append(f"{path} —— {hint}")
    if is_story(plan):
        from .story_contract import validate_story_contract
        remaining.extend(validate_story_contract(plan))
        if not (plan.get("distribution_plan") or {}).get("digest"):
            remaining.append("distribution_plan.digest —— 独立分享摘要，交代处境而不揭晓结局")
    return remaining


def _still_blank(plan: Mapping[str, Any], path: str) -> bool:
    if path.endswith(".*"):
        node = _dig(plan, path[:-2])
        return isinstance(node, Mapping) and any(v == "" for v in node.values())
    if "[]" in path:
        head, tail = path.split("[]", 1)
        rows = _dig(plan, head)
        if not isinstance(rows, list):
            return False
        return any(_blank(_dig(row, tail.lstrip("."))) for row in rows)
    return _blank(_dig(plan, path))


def _blank(value: Any) -> bool:
    """空字符串、缺失，以及**空列表／空字典**都算还没填。

    留空的 `claim_ids` 是 `[]`，只判 `in ("", None)` 会漏掉它——
    那样骨架把编辑决策留空了，todo 却不提，等于没留。
    """
    if value in ("", None):
        return True
    return isinstance(value, (list, dict, tuple)) and not value


def _dig(node: Any, path: str) -> Any:
    if not path:
        return node
    for key in path.split("."):
        if not isinstance(node, Mapping):
            return None
        node = node.get(key)
    return node


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--scaffold", action="store_true",
                        help="生成 ArticlePlan 骨架而不是校验现成的")
    parser.add_argument("--out", help="骨架写到哪里")
    parser.add_argument("--sections", type=int, default=5, help="章节数")
    parser.add_argument("--claims", type=int, help="支撑主张条数；给了 --brief 时默认取 brief 的条数")
    parser.add_argument("--visuals", type=int, default=0,
                        help="要几张配图；不给就是不配图（visual_plan_status=not_applicable）")
    parser.add_argument("--target-total", type=int, help="可见正文目标字数")
    parser.add_argument("--shares", help="各节篇幅占比，逗号分隔，如 10,35,20,25,10")
    parser.add_argument("--length-shape", help=f"篇幅策略，默认 {DEFAULT_SHAPE}")
    parser.add_argument("--generation-mode", default="plan_only",
                        help="plan_only | full_article | revise_article")
    parser.add_argument("--content-kind", default="analysis", choices=sorted(CONTENT_KINDS))
    parser.add_argument("--truth-mode", choices=sorted(TRUTH_MODES))
    parser.add_argument("--article-id", default="article-001")
    parser.add_argument("--force", action="store_true", help="允许覆盖已存在的 --out")


def parse_shares(raw: str | None) -> list[float] | None:
    if not raw:
        return None
    try:
        return [float(part) for part in raw.replace("，", ",").split(",") if part.strip()]
    except ValueError as exc:
        raise ScaffoldError(f"--shares 只能是数字，逗号分隔：{raw}") from exc


if __name__ == "__main__":  # pragma: no cover - 只为挡住「直接跑它」这条错路
    # 这个模块不是命令行入口，骨架生成挂在校验器上。
    #
    # 没有这一段时，`python3 article_plan_scaffold.py …` 会**无声退出、
    # 不建文件、返回 0**——实测中 agent 据此以为是参数写错了，接连 tail 源码、
    # grep def main、翻 import 关系，四五轮之后才找到真正的入口。
    # 静默成功是最贵的一种失败：它连「哪里错了」都不提供。
    import sys as _sys
    _sys.exit(
        """article_plan_scaffold.py 不是命令行入口，直接跑它不会生成任何东西。
骨架生成走校验器，一行写完：
    python3 validate_article_plan.py --scaffold --out <会话根>/20-creative/.meta/article-plan-<article_id>.yaml --brief <ContentBrief 路径> --sections 5 --shares 10,35,20,25,10 --target-total 3800
完整参数见 `validate_article_plan.py --help`。"""
    )
