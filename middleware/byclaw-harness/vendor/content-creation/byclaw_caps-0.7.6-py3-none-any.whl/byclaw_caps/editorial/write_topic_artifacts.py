#!/usr/bin/env python3
"""一次写完选题的三份产物，并把机器能算的都算好。

## 为什么要它

实测一次干净的选题会话（2026-09-11，32 次调用）里，**产物这一段占了 9 次**：

    读 output-templates.md          1
    读 3 份 assets 模板             3
    读 content-brief-contract.md    1
    写 3 份产物                     3
    sed -i 补 generated_at          1

**九次里只有「决定写什么」是人的活，其余全是机器能做的。** 这个脚本把它压到一次。

## 三件机器该做的事

1. **模板由脚本套**，调用方只给决定的内容。不必先读 3 份 assets。
2. **`generated_at` 由脚本填真实时间。** 原先的规矩是「先存 `null`、再读时钟、
   只更新该字段」——那条规矩存在只是因为**模型读不准时间**，而脚本读得准。
   实测里它是用 `sed -i` 补的，白花一次调用。
3. **写完就地跑 `validate_content_brief.py`**，不合格当场报，不用调用方再起一次。

## 一条纪律：缺字段要说清形状

调用方**不预读契约**（见 SKILL《开始前加载：一份都不预读》），所以缺了什么、
该长什么样，全靠这里的报错讲明白。**报错讲不清，调用方就会回去读契约，
那这个脚本就白做了。**
"""

from __future__ import annotations

import copy
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:  # 包内导入
    from .topic_cli_io import read_json, write_json
except ImportError:  # 直接执行
    pass  # 包内使用相对导入，避免污染其他兼容入口
    from .topic_cli_io import read_json, write_json  # type: ignore

ASSETS = Path(__file__).resolve().parent / "assets"

#: 调用方必须给的，缺一个就写不出有意义的产物。
#: 值是「这个字段该长什么样」——**报错要直接能照着填**。
REQUIRED_DECISION = {
    "decision_summary.verdict": "propose | write —— 用户只要选题时是 propose",
    "decision_summary.primary_topic_id": "首选的 topic_id，如 topic-001",
    "decision_summary.reason": "一句话：为什么是它（相对理由，不是自夸）",
}
REQUIRED_BRIEF = {
    "topic.subject": "一个短语，这篇讲什么（不是标题的复述）",
    "topic.core_judgment": "一到三句，这篇要证明的那一个判断",
    "topic.map_nodes": "数组，每项是地图的二级节点，形如 构建·建模方法（⛔ 不带 /内容点）",
}

#: 给每个字段配一个**能照着改的样例值**。
#: 只报字段名不够——实测调用方拿到字段名之后还是回去读了契约和模板（9 次 read）。
SAMPLES: dict[str, Any] = {
    "topic.subject": "本体推理的三层落点",
    "topic.core_judgment": "落地不是「能不能推理」，而是三层递进的应用深度；多数团队停在第一层。",
    "topic.map_nodes": ["应用·推理应用三层"],
    "topic.working_title": "本体推理的三层落点：为什么多数企业只做到了第一层",
    "topic.distribution_title": "为什么上了本体，用起来还是一个更贵的 BI？",
    "topic.content_type": "（取值见报错里的合法集合）",
    "target_account.channel_code": "wechat_mp",
    "target_account.app_id": "wx…（本号 APP_ID，取自会话上下文）",
    "audience.primary": "做过数仓、正在评估本体的数据架构师",
    "audience.current_problem": "本体建完了，业务侧还是只拿它查数",
    "narrative.central_question": "本体到底该用到第几层才算跑通？",
    "narrative.opening_tension": "花了半年建的本体，用起来和原来的 BI 没差别",
    "topic_clarity.plain_language_judgment": "不用术语说清这篇要证明什么",
    "topic_clarity.status": "pass | needs_revision",
    "decision_summary.verdict": "propose",
    "decision_summary.primary_topic_id": "topic-001",
    "decision_summary.reason": "全图唯一落在「成品空 + 素材厚」的格子",
}


def _brief_required() -> list[tuple[str, str]]:
    """必填表从校验器 import，**不在这里抄第二份**。

    这个仓库反复栽的跟头是「文档一份、代码一份，改了一处忘另一处」，
    而**代码赢**。校验器的 `REQUIRED` 是唯一真相，这里只负责把它连同
    样例值一起讲清楚。
    """
    try:
        from .validate_content_brief import REQUIRED  # type: ignore
    except ImportError:  # pragma: no cover - 包内导入
        from .validate_content_brief import REQUIRED  # type: ignore
    return [(path, label) for path, label in REQUIRED]


def describe_fields() -> dict:
    """`--fields`：一次把该填的全列出来，**省掉回头读契约那几轮**。"""
    rows = []
    seen = set()
    for path, shape in REQUIRED_DECISION.items():
        rows.append({"where": "decision", "field": path, "说明": shape,
                     "样例": SAMPLES.get(path)})
        seen.add(path)
    for path, shape in REQUIRED_BRIEF.items():
        rows.append({"where": "brief", "field": path, "说明": shape,
                     "样例": SAMPLES.get(path)})
        seen.add(path)
    for path, label in _brief_required():
        if path in seen:
            continue
        rows.append({"where": "brief", "field": path, "说明": label,
                     "样例": SAMPLES.get(path)})
    return {
        "ok": True,
        "required": rows,
        "markdown": "还要给 markdown —— 《选题决策.md》正文，结构见下面 outline",
        "outline": ["# 选题决策 · <传播标题>", "## 一、推荐选题",
                    "## 二、候选标题（4—10 个）", "## 三、发哪儿"],
        "note": ("这就是全部必填项。**其余字段脚本用 assets 模板补齐**——"
                 "不用读 assets，也不用读 content-brief-contract.md。"
                 "备选只进 decision.intent_result.alternatives（五个字段），"
                 "**不写第二份 ContentBrief**。"),
    }


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _load_asset(name: str) -> Any:
    import yaml

    return yaml.safe_load((ASSETS / name).read_text(encoding="utf-8"))


def _dig(node: Any, dotted: str) -> Any:
    for part in dotted.split("."):
        if not isinstance(node, dict):
            return None
        node = node.get(part)
    return node


def _merge(base: Any, patch: Any) -> Any:
    """把调用方给的内容盖到模板上。

    **只深合并字典**——列表整体替换。模板里的列表多半是**示例块**
    （`article_plan_scaffold` 的注释里记着：模板自带的例子是个陷阱，
    一次贡献了 50 条校验错里的 10 条），逐项合并只会把示例留下来。
    """
    if isinstance(base, dict) and isinstance(patch, dict):
        out = dict(base)
        for key, value in patch.items():
            out[key] = _merge(out.get(key), value) if key in out else value
        return out
    return copy.deepcopy(patch)


def _check_required(payload: dict, spec: dict, label: str) -> list[str]:
    missing = []
    for dotted, shape in spec.items():
        value = _dig(payload, dotted)
        if value is None or value == "" or value == []:
            missing.append(f"{label}.{dotted} —— {shape}")
    return missing


def build(request: dict) -> dict:
    session_root = str(request.get("session_root") or "").strip()
    if not session_root:
        raise ValueError(
            "缺 session_root。产物要落在会话根之下（/by/.sessions/<数字ID>/），"
            "**不能落工作区**——那里会随回收丢失，也无法在数字员工之间交接。")

    decision_patch = request.get("decision") or {}
    brief_patch = request.get("brief") or {}
    markdown = request.get("markdown")

    missing = (_check_required(decision_patch, REQUIRED_DECISION, "decision")
               + _check_required(brief_patch, REQUIRED_BRIEF, "brief"))
    if missing:
        raise ValueError(
            "这几项必须由你决定，脚本算不出来：\n  - " + "\n  - ".join(missing)
            + "\n\n**完整必填清单跑 `--fields` 看**（带样例值），"
              "其余字段脚本会用 assets 模板补齐——**不用读模板，也不用读契约**。")
    if not markdown or not str(markdown).strip():
        raise ValueError(
            "缺 markdown —— 人类可读的那份《选题决策.md》正文。"
            "结构见 assets/选题决策.md：一、推荐选题 / 二、候选标题（4—10 个）/ 三、发哪儿。"
            "**只写在聊天回复里等于没写**，关掉窗口就没了。")

    decision = _merge(_load_asset("topic-decision-result.yaml"), decision_patch)
    brief = _merge(_load_asset("content-brief.yaml"), brief_patch)

    stamp = _now()
    # **时间由脚本填。** 原规矩「先存 null 再读时钟只改该字段」是为了绕开
    # 模型读不准时间，脚本读得准——那一整轮本来就不该存在。
    decision["generated_at"] = stamp
    brief["generated_at"] = stamp
    brief.setdefault("selection_status", "proposed")

    topic_id = _dig(decision_patch, "decision_summary.primary_topic_id")
    brief.setdefault("topic_id", topic_id)
    if not brief.get("brief_id"):
        brief["brief_id"] = str(topic_id).replace("topic-", "brief-", 1)

    # ⚠️ 备选**不写 ContentBrief**，只在 intent_result.alternatives 里留五个字段。
    # ⛔ 这里不能用 `setdefault`：模板里 `content_brief_ids: []` 是**已存在的空值**，
    # setdefault 对它不生效，首选的 id 就永远填不进去——**而且不报错**。
    if not decision.get("content_brief_ids"):
        decision["content_brief_ids"] = [brief["brief_id"]]
    decision.setdefault("content_briefs", [])

    return {"session_root": session_root, "decision": decision,
            "brief": brief, "markdown": str(markdown), "generated_at": stamp}


def emit(built: dict) -> dict:
    import yaml

    out_dir = Path(built["session_root"]) / "10-topic"
    out_dir.mkdir(parents=True, exist_ok=True)

    def dump(name: str, value: Any) -> str:
        path = out_dir / name
        if name.endswith(".md"):
            path.write_text(value if value.endswith("\n") else value + "\n",
                            encoding="utf-8")
        else:
            path.write_text(
                yaml.safe_dump(value, allow_unicode=True, sort_keys=False),
                encoding="utf-8")
        return str(path)

    files = [
        dump("topic-decision-result.yaml", built["decision"]),
        dump("content-brief.yaml", built["brief"]),
        dump("选题决策.md", built["markdown"]),
    ]

    # 就地校验 brief——不合格当场报，不用调用方再起一次。
    try:
        from .validate_content_brief import validate as validate_brief  # type: ignore
    except ImportError:  # pragma: no cover - 包内导入
        from .validate_content_brief import validate as validate_brief  # type: ignore
    errors, warnings = validate_brief(built["brief"])

    return {
        "ok": not errors,
        "generated_at": built["generated_at"],
        "files": files,
        "brief_validation": {"errors": errors, "warnings": warnings},
        "note": ("ok=false 时按 brief_validation.errors 改，**改完重跑本脚本**——"
                 "不要手改产物，格式由这里定。"),
    }


def main() -> int:
    if "--fields" in sys.argv:
        write_json(describe_fields())
        return 0
    try:
        result = emit(build(read_json()))
    except ValueError as exc:
        write_json({"ok": False, "error": str(exc)})
        return 2
    write_json(result)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
