#!/usr/bin/env python3
"""Apply qualification gates and the deterministic EditorialScore formula."""

from __future__ import annotations

from typing import Any

from .topic_cli_io import read_json, write_json

SCORE_LIMITS = {
    "audience_pain": 25,
    "timing_or_evergreen": 20,
    "positioning_alignment": 15,
    "evidence_strength": 15,
    "independent_view": 10,
    "writing_value": 10,
    "meaningful_tension": 5,
}
SCORE_ANCHORS = {
    "audience_pain": {0, 6, 12, 19, 25},
    "timing_or_evergreen": {0, 5, 10, 15, 20},
    "positioning_alignment": {0, 4, 8, 12, 15},
    "evidence_strength": {0, 4, 8, 12, 15},
    "independent_view": {0, 3, 5, 8, 10},
    "writing_value": {0, 3, 5, 8, 10},
    "meaningful_tension": {0, 1, 3, 4, 5},
}
PENALTY_LIMITS = {"history_overlap": 3, "homogeneity": 10}
GATES = {
    "blacklist_hit", "unsourced_product_claims", "unverified_time_claims",
    "irrelevant_to_audience", "exact_history_duplicate",
}
CONFIDENCE_CHECKS = {
    "history_claim_dedup",
    "operations_review",
    "channel_audience_fit",
    "critical_facts_verified",
}
HISTORY_COMPARISON_SCOPES = {"none", "claim_aware", "mixed", "title_only"}
HISTORY_REVIEW_COVERAGE = {"none", "targeted", "sufficient", "full"}
TIEBREAK_SCORE_MARGIN = 8.0
CONFIDENCE_RANK = {"low": 0, "medium": 1, "high": 2}


CAP_SUFFIX = "_capped_"
# 单个候选时「未参与区分」无从谈起，至少两个合格候选才产生告警。
MIN_CANDIDATES_FOR_CAVEAT = 2


def _ranking_caveats(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """找出对**全部**合格候选同时失去区分力的评分维度。

    两个条件缺一不可：

    1. 该维度的证据门对所有候选都未满足——它被证据缺失整体压制；
    2. 该维度在所有候选间取同一值——确实没有参与区分。

    只看条件 1 会误报（候选可以在上限之下正当地拉开差距）；
    只看条件 2 也会误报（证据充分时得分相同是合理结论）。
    """
    eligible = [item for item in results if item.get("eligible")]
    if len(eligible) < MIN_CANDIDATES_FOR_CAVEAT:
        return []
    caveats: list[dict[str, Any]] = []
    for dimension, weight in SCORE_LIMITS.items():
        if not all(
            dimension in (item.get("evidence_gate_unmet") or []) for item in eligible
        ):
            continue
        values = {float((item.get("scores") or {}).get(dimension, 0)) for item in eligible}
        if len(values) != 1:
            continue
        residual = sum(SCORE_LIMITS.values()) - weight
        caveats.append({
            "dimension": dimension,
            "weight": weight,
            "reason": "all_candidates_limited_by_missing_evidence",
            "effect": (
                f"该维度证据门对全部候选均未满足，且取值同为 {values.pop():g}，"
                f"未参与区分；当前排序由其余 {residual} 分权重决定"
            ),
        })
    return caveats



def _bounded(values: dict[str, Any], limits: dict[str, int], name: str) -> dict[str, float]:
    output = {}
    unknown = set(values) - set(limits)
    if unknown:
        raise ValueError(f"{name} 包含未知字段: {', '.join(sorted(unknown))}")
    for key, maximum in limits.items():
        value = float(values.get(key, 0))
        if value < 0 or value > maximum:
            raise ValueError(f"{name}.{key} 必须在 0..{maximum} 之间")
        if name == "scores" and value not in SCORE_ANCHORS[key]:
            allowed = ", ".join(str(item) for item in sorted(SCORE_ANCHORS[key]))
            raise ValueError(f"scores.{key} 必须使用评分锚点: {allowed}")
        output[key] = value
    return output


def _normalize_history_context(params: dict[str, Any]) -> dict[str, Any]:
    context = params.get("history_context")
    if not isinstance(context, dict):
        raise ValueError("history_context 必须来自 check_overlap.py 输出")
    try:
        history_count = int(context.get("history_count"))
        claim_context_count = int(context.get("history_with_claim_context_count"))
    except (TypeError, ValueError) as exc:
        raise ValueError("history_context 计数字段无效") from exc
    if history_count < 0 or claim_context_count < 0 or claim_context_count > history_count:
        raise ValueError("history_context 计数范围无效")
    history_ids = context.get("history_ids")
    if not isinstance(history_ids, list):
        raise ValueError("history_context.history_ids 必须是数组")
    normalized_ids = [str(value).strip() for value in history_ids if str(value).strip()]
    if len(normalized_ids) != history_count or len(set(normalized_ids)) != history_count:
        raise ValueError("history_context.history_ids 必须与 history_count 一一对应")
    if history_count == 0:
        expected_scope = "none"
    elif claim_context_count == history_count:
        expected_scope = "claim_aware"
    elif claim_context_count == 0:
        expected_scope = "title_only"
    else:
        expected_scope = "mixed"
    declared_scope = str(context.get("comparison_scope") or "").strip()
    if declared_scope != expected_scope:
        raise ValueError(
            f"history_context.comparison_scope 应为 {expected_scope}，不能声明为 {declared_scope or '空'}"
        )
    return {
        "history_count": history_count,
        "history_with_claim_context_count": claim_context_count,
        "history_ids": normalized_ids,
        "comparison_scope": expected_scope,
    }


def _history_dedup_verified(
    candidate: dict[str, Any], history_context: dict[str, Any]
) -> tuple[bool, str | None]:
    review = candidate.get("history_review")
    if not isinstance(review, dict):
        return False, "history_review_missing"
    comparison_scope = str(review.get("comparison_scope") or "").strip()
    if comparison_scope not in HISTORY_COMPARISON_SCOPES:
        return False, "history_comparison_scope_missing"
    expected_scope = history_context["comparison_scope"]
    if comparison_scope != expected_scope:
        return False, "history_comparison_scope_mismatch"
    semantic_review_required = review.get("semantic_review_required")
    if not isinstance(semantic_review_required, bool):
        return False, "semantic_review_requirement_missing"
    if not semantic_review_required:
        if comparison_scope in {"none", "claim_aware"}:
            return True, None
        return False, "semantic_review_required_for_incomplete_history"
    reviewed_history_ids = review.get("reviewed_history_ids") or []
    if not isinstance(reviewed_history_ids, list):
        return False, "reviewed_history_ids_invalid"
    if review.get("semantic_review_completed") is not True:
        return False, "candidate_semantic_review_incomplete"
    review_coverage = str(review.get("review_coverage") or "").strip()
    if review_coverage not in HISTORY_REVIEW_COVERAGE:
        return False, "history_review_coverage_missing"
    if review_coverage not in {"sufficient", "full"}:
        return False, "history_review_coverage_insufficient"
    selection_basis = str(review.get("selection_basis") or "").strip()
    if not selection_basis:
        return False, "history_selection_basis_missing"
    selection_method = str(review.get("selection_method") or "").strip()
    if selection_method not in {"lexical", "agent_semantic"}:
        return False, "history_selection_method_invalid"
    if review.get("selection_confidence") != "sufficient":
        return False, "history_selection_confidence_insufficient"
    selection_reason = str(review.get("selection_reason") or "").strip()
    if not selection_reason:
        return False, "history_selection_reason_missing"
    required_history_ids = review.get("required_history_ids") or []
    if not isinstance(required_history_ids, list):
        return False, "required_history_ids_invalid"
    required = {str(value).strip() for value in required_history_ids if str(value).strip()}
    reviewed = {str(value).strip() for value in reviewed_history_ids if str(value).strip()}
    corpus_ids = set(history_context["history_ids"])
    if not required:
        return False, "required_history_ids_missing"
    if not required.issubset(corpus_ids):
        return False, "required_history_ids_outside_corpus"
    if not required.issubset(reviewed):
        return False, "required_history_bodies_incomplete"
    return True, None


def score_candidate(
    candidate: dict[str, Any], history_context: dict[str, Any], index: int = 0
) -> dict[str, Any]:
    gates = candidate.get("gates") or {}
    if not isinstance(gates, dict):
        raise ValueError("gates 必须是对象")
    unknown = set(gates) - GATES
    if unknown:
        raise ValueError(f"gates 包含未知字段: {', '.join(sorted(unknown))}")
    normalized_gates = {key: bool(gates.get(key, False)) for key in sorted(GATES)}
    missing_gate_checks = sorted(GATES - set(gates))
    failed_gates = [key for key, failed in normalized_gates.items() if failed]
    confidence_checks = candidate.get("confidence_checks") or {}
    if not isinstance(confidence_checks, dict):
        raise ValueError("confidence_checks 必须是对象")
    unknown_checks = set(confidence_checks) - CONFIDENCE_CHECKS
    if unknown_checks:
        raise ValueError(
            f"confidence_checks 包含未知字段: {', '.join(sorted(unknown_checks))}"
        )
    effective_confidence_checks = {
        key: confidence_checks.get(key) is True for key in sorted(CONFIDENCE_CHECKS)
    }
    confidence_adjustments: list[str] = []
    if effective_confidence_checks["history_claim_dedup"]:
        verified, reason = _history_dedup_verified(candidate, history_context)
        if not verified:
            effective_confidence_checks["history_claim_dedup"] = False
            confidence_adjustments.append(str(reason))
    completed_checks = sorted(
        key for key, completed in effective_confidence_checks.items() if completed
    )
    missing_confidence_checks = sorted(CONFIDENCE_CHECKS - set(completed_checks))
    if not missing_gate_checks and len(completed_checks) == len(CONFIDENCE_CHECKS):
        ranking_confidence = "high"
    elif not missing_gate_checks and len(completed_checks) >= 3:
        ranking_confidence = "medium"
    else:
        ranking_confidence = "low"
    scores = _bounded(candidate.get("scores") or {}, SCORE_LIMITS, "scores")
    score_adjustments: list[str] = []
    score_evidence = candidate.get("score_evidence") or {}
    if not isinstance(score_evidence, dict):
        raise ValueError("score_evidence 必须是对象")
    audience_basis = str(score_evidence.get("audience_pain") or "").strip()
    audience_refs = score_evidence.get("audience_pain_evidence_refs") or []
    if not isinstance(audience_refs, list):
        raise ValueError("score_evidence.audience_pain_evidence_refs 必须是数组")
    if scores["audience_pain"] == 25 and not (
        audience_basis == "direct" and bool(audience_refs)
    ):
        scores["audience_pain"] = 19.0
        score_adjustments.append("audience_pain_capped_without_direct_evidence")
    if (
        not effective_confidence_checks["critical_facts_verified"]
        and scores["evidence_strength"] > 12
    ):
        scores["evidence_strength"] = 12.0
        score_adjustments.append("evidence_strength_capped_without_verified_critical_facts")
    # 证据门是否满足与「是否申请了满分」无关：Agent 自觉写低分时不会触发封顶，
    # 但该维度同样受证据缺失所限，仍可能对全部候选失去区分力。
    evidence_gate_unmet: list[str] = []
    if not (audience_basis == "direct" and bool(audience_refs)):
        evidence_gate_unmet.append("audience_pain")
    if not effective_confidence_checks["critical_facts_verified"]:
        evidence_gate_unmet.append("evidence_strength")
    penalties = _bounded(candidate.get("penalties") or {}, PENALTY_LIMITS, "penalties")
    total = max(0.0, sum(scores.values()) - sum(penalties.values()))
    return {
        "candidate_id": candidate.get("candidate_id") or candidate.get("topic_id") or f"candidate-{index + 1}",
        "eligible": not failed_gates,
        "failed_gates": failed_gates,
        "missing_gate_checks": missing_gate_checks,
        "editorial_score": round(total, 2) if not failed_gates else None,
        "score_status": "final" if ranking_confidence == "high" else "provisional",
        "ranking_confidence": ranking_confidence,
        "completed_confidence_checks": completed_checks,
        "missing_confidence_checks": missing_confidence_checks,
        "effective_confidence_checks": effective_confidence_checks,
        "confidence_adjustments": confidence_adjustments,
        "score_adjustments": score_adjustments,
        "evidence_gate_unmet": evidence_gate_unmet,
        "scores": scores,
        "penalties": penalties,
    }


def run(params: dict[str, Any]) -> dict[str, Any]:
    candidates = params.get("candidates") or []
    if not isinstance(candidates, list):
        raise ValueError("candidates 必须是数组")
    history_context = _normalize_history_context(params)
    results = [
        score_candidate(candidate, history_context, index)
        for index, candidate in enumerate(candidates)
    ]
    results.sort(key=lambda item: (item["eligible"], item["editorial_score"] or -1), reverse=True)
    eligible_scores = [
        float(item["editorial_score"])
        for item in results
        if item["eligible"] and item["editorial_score"] is not None
    ]
    top_score = max(eligible_scores) if eligible_scores else None
    tiebreak_review_candidate_ids: list[str] = []
    for item in results:
        score = item["editorial_score"]
        close_to_top = (
            top_score is not None
            and item["eligible"]
            and score is not None
            and top_score - float(score) <= TIEBREAK_SCORE_MARGIN
        )
        requires_review = (
            close_to_top
            and not item["effective_confidence_checks"]["history_claim_dedup"]
        )
        item["tiebreak_review_required"] = requires_review
        if requires_review:
            tiebreak_review_candidate_ids.append(str(item["candidate_id"]))
    eligible_results = [item for item in results if item["eligible"]]
    ranking_contenders = []
    if eligible_results and top_score is not None:
        ranking_contenders = [
            item for item in eligible_results
            if top_score - float(item["editorial_score"]) <= TIEBREAK_SCORE_MARGIN
        ]
    if not ranking_contenders:
        decision_ranking_confidence = "low"
        primary_candidate_confidence = "low"
    else:
        primary_candidate_confidence = ranking_contenders[0]["ranking_confidence"]
        minimum_rank = min(
            CONFIDENCE_RANK[item["ranking_confidence"]] for item in ranking_contenders
        )
        decision_ranking_confidence = next(
            name for name, rank in CONFIDENCE_RANK.items() if rank == minimum_rank
        )
    return {
        "ok": True,
        "score_anchor_version": "1.0",
        "history_context": history_context,
        "tiebreak_score_margin": TIEBREAK_SCORE_MARGIN,
        "tiebreak_review_candidate_ids": tiebreak_review_candidate_ids,
        "ranking_contender_ids": [item["candidate_id"] for item in ranking_contenders],
        "primary_candidate_confidence": primary_candidate_confidence,
        "decision_ranking_confidence": decision_ranking_confidence,
        "decision_score_status": "final" if decision_ranking_confidence == "high" else "provisional",
        "ranking_caveats": _ranking_caveats(results),
        "results": results,
    }


if __name__ == "__main__":
    write_json(run(read_json()))
