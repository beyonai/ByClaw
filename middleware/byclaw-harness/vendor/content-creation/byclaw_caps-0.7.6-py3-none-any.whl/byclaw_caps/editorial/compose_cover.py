#!/usr/bin/env python3
"""把封面文案烧进封面底图。

**这一步存在的理由：AI 生图画不出可靠的中文字。**

所以封面不能是一张纯 `ai_image`——那样文案只能留在计划里，永远到不了读者眼前。
实测的一次产出就是如此：底图是抽象发光粒子、零文字，与文章的关系仅止于
"一个点变成很多点"，换成任何一篇 AI 文章都能用。

正确的分层是：

    背景层（ai_image，可以模糊、可以抽象）  ← 模型擅长
    文字层（drawtext，逐像素确定）          ← 代码擅长

文字层走 `byclaw_caps.video build_drawtext` 而不是自己拼滤镜串：那个入口恒带
``expansion=none``，来自一次真实事故——``%`` 在 drawtext 里是展开引导符，
**会被静默吞掉且退出码为 0**。自己拼串迟早漏掉那个开关。

与 `compose_card.py` 同一思路、同一约定：只用标准库 + ffmpeg 子进程，不引第三方图形库。

    python3 compose_cover.py --background bg.png --copy "版本一致，交付才不断" \
        --output cover.png [--channel wechat_public_account] [--font /path/font.ttf]
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

try:
    from byclaw_caps.shared.channel_specs import MEDIUM_ARTICLE_COVER, resolve_channel_size
except ImportError:  # direct script execution
    from byclaw_caps.shared.channel_specs import (  # type: ignore
        MEDIUM_ARTICLE_COVER,
        resolve_channel_size,
    )


class ComposeCoverError(RuntimeError):
    """封面装配失败。"""


# 与 validate_article_plan.py 的 COVER_COPY_MAX_CHARS 是同一条约束的两端：
# 那边在计划期拦住超长，这边在渲染期不做静默截断——截断会让读者看到半句话。
COVER_COPY_MAX_CHARS = 14

# 压暗带：底图亮度不可控，直接压字常常糊在一起。半透明黑带是最低成本的可读性保证，
# 且不遮住底图的整体观感。
SCRIM_OPACITY = 0.45
FONT_COLOR = "white"
# 字号按画幅高度取，而不是写死磅值——换渠道画幅时不必重调。
FONT_SIZE_RATIO = 0.17


# 写死路径只作**兜底**。真正的发现走 fontconfig——见 discover_cjk_fonts()。
# 这份列表存在的理由：容器里可能没有 fontconfig 工具链。
# 顺序即优先级：无衬线优先于衬线（信息流缩略图下无衬线更耐看）。
CJK_FONT_CANDIDATES = (
    # Linux（沙箱）
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJKsc-Regular.otf",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
    "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    "/usr/share/fonts/truetype/arphic/uming.ttc",
    # macOS
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/STHeiti Medium.ttc",
    # Windows（本地开发）
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
    "C:/Windows/Fonts/Deng.ttf",
)


def font_rank(path: str) -> tuple[int, int, str]:
    """封面标题用字的优先级。数值越小越优先。

    无衬线优先：封面在信息流里是缩略显示的，衬线的细笔画先糊。
    其次要 Bold：封面就一句话，压在图上要压得住。
    """
    name = path.rsplit("/", 1)[-1].lower()
    family = 0 if ("sans" in name or "hei" in name or "yahei" in name
                   or "pingfang" in name) else 1
    weight = 0 if ("bold" in name or "hei" in name) else 1
    return (family, weight, path)


def discover_cjk_fonts() -> list[str]:
    """问 fontconfig 要装了哪些中文字体。

    **不能只靠写死的路径列表。** 实测沙箱里装的是 `NotoSerifCJK-Bold.ttc`，
    而列表里只有 `NotoSansCJK-*`——一个字都没命中，脚本会报"找不到中文字体"，
    可系统里明明有一个完全能用的。字体装在哪、叫什么名，是发行版的自由，
    猜文件名迟早猜错；fontconfig 才是那台机器上的事实来源。
    """
    binary = shutil.which("fc-list")
    if not binary:
        return []
    try:
        completed = subprocess.run(
            [binary, ":lang=zh", "--format=%{file}\n"],
            capture_output=True, text=True, timeout=20,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if completed.returncode != 0:
        return []
    seen: dict[str, None] = {}
    for line in (completed.stdout or "").splitlines():
        candidate = line.strip()
        if candidate and Path(candidate).is_file():
            seen.setdefault(candidate, None)
    return sorted(seen, key=font_rank)


def _has_cjk(text: str) -> bool:
    """是否含需要 CJK 字形的字符。范围覆盖常用汉字、扩展 A 与中日韩标点。"""
    for char in text:
        code = ord(char)
        if (0x3000 <= code <= 0x303F or 0x3400 <= code <= 0x4DBF
                or 0x4E00 <= code <= 0x9FFF or 0xFF00 <= code <= 0xFFEF):
            return True
    return False


def resolve_font(explicit: str | None, text: str) -> str | None:
    """给中文文案挑一个真能渲的字体；挑不到就**报错，不出图**。

    出一张豆腐块封面比不出封面更糟：它会带着 exit 0 一路走到发布，
    而没有任何环节会去看那张图长什么样。
    """
    if explicit:
        if not Path(explicit).is_file():
            raise ComposeCoverError("指定的字体文件不存在: %s" % explicit)
        return explicit
    if not _has_cjk(text):
        return None                      # 纯 ASCII，默认字体够用
    discovered = discover_cjk_fonts()
    if discovered:
        return discovered[0]
    for candidate in CJK_FONT_CANDIDATES:   # fontconfig 不可用时的兜底
        if Path(candidate).is_file():
            return candidate
    raise ComposeCoverError(
        "封面文案含中文，但系统里找不到任何中文字体，ffmpeg 会把每个汉字渲成方框且"
        "退出码仍为 0。请用 --font 指定一个中文字体文件，或在环境里安装 "
        "Noto Sans CJK（Debian/Ubuntu: apt install fonts-noto-cjk）。"
    )


def _escape_path(value: str) -> str:
    return value.replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def _drawtext(text: str, *, fontsize: int, fontfile: str | None) -> str:
    """构造文字层滤镜。

    优先复用 `byclaw_caps.video.build_drawtext`；能力不可用时退回本地实现，
    **但同样恒带 expansion=none**——这条不因为走了哪条路径而放松。
    """
    try:
        from byclaw_caps.video import build_drawtext
    except ImportError:
        pass
    else:
        return build_drawtext(
            text, fontfile=fontfile, fontsize=fontsize, fontcolor=FONT_COLOR,
            x="(w-text_w)/2", y="(h-text_h)/2",
        )

    escaped = str(text).replace("\\", r"\\\\").replace("'", r"\'").replace(":", r"\:")
    parts = [
        "text='%s'" % escaped,
        "expansion=none",          # % 会被静默吞掉且退出码为 0，这个开关不可省
        "fontsize=%d" % fontsize,
        "fontcolor=%s" % FONT_COLOR,
        "x=(w-text_w)/2",
        "y=(h-text_h)/2",
    ]
    if fontfile:
        parts.insert(1, "fontfile='%s'" % _escape_path(str(fontfile)))
    return "drawtext=" + ":".join(parts)


def build_filter(copy_text: str, width: int, height: int,
                 *, fontfile: str | None = None) -> str:
    """底图归一到封面画幅 → 压暗带 → 文字层。

    归一用 `increase` + `crop` 而不是 `decrease` + `pad`：封面是满幅视觉，
    留黑边比裁掉背景边缘更难看，且裁掉的是背景不是信息。

    压暗带用 `drawbox` 而不是 `color` 源 + `overlay`。**这不是风格选择**：
    `overlay` 默认落到 yuv420 系，色度二次采样要求偶数边长，会把 383 静默压成 382。
    实测就是这么产出了一张 900×382 的封面——尺寸校验会拒，但报错指向的是画幅表，
    真正的原因藏在滤镜链里。`drawbox` 在原像素格式上就地绘制，不引入这层转换。
    """
    fontsize = max(24, int(height * FONT_SIZE_RATIO))
    return (
        "[0:v]scale=%d:%d:force_original_aspect_ratio=increase,"
        "crop=%d:%d,setsar=1,"
        "drawbox=x=0:y=0:w=iw:h=ih:color=black@%.2f:t=fill,"
        "%s[cover]"
        % (width, height, width, height, SCRIM_OPACITY,
           _drawtext(copy_text, fontsize=fontsize, fontfile=fontfile))
    )


def _resolve_ffmpeg(explicit: str | None = None) -> str:
    candidate = explicit or shutil.which("ffmpeg")
    if not candidate:
        raise ComposeCoverError("未找到 ffmpeg；封面装配依赖 FFmpeg，请先安装或显式传入路径")
    return candidate


def compose(
    background: Path,
    target: Path,
    copy_text: str,
    *,
    channel_ref: str = "wechat_public_account",
    fontfile: str | None = None,
    ffmpeg: str | None = None,
) -> dict[str, object]:
    text = str(copy_text or "").strip()
    if not text:
        raise ComposeCoverError(
            "封面文案为空。没有文案的封面在信息流里等于放弃一次触达——"
            "若确实不要文案，应在 ArticlePlan 里声明 cover_copy_status=not_applicable，"
            "而不是在这里传空串。"
        )
    if len(text) > COVER_COPY_MAX_CHARS:
        # 不静默截断：截断会让读者看到半句话，而作者不会察觉。
        raise ComposeCoverError(
            "封面文案 %d 字，超过 %d 字上限；请先在 ArticlePlan 里改短再渲染"
            % (len(text), COVER_COPY_MAX_CHARS)
        )
    if not background.is_file():
        raise ComposeCoverError("底图不存在: %s" % background)

    width, height = resolve_channel_size(channel_ref, MEDIUM_ARTICLE_COVER)
    font = resolve_font(fontfile, text)
    binary = _resolve_ffmpeg(ffmpeg)
    target.parent.mkdir(parents=True, exist_ok=True)
    command = [
        binary, "-y", "-loglevel", "error",
        "-i", str(background),
        "-filter_complex", build_filter(text, width, height, fontfile=font),
        "-map", "[cover]",
        "-frames:v", "1",
        str(target),
    ]
    try:
        completed = subprocess.run(command, capture_output=True, text=True)
    except OSError as exc:
        raise ComposeCoverError("调用 ffmpeg 失败: %s" % type(exc).__name__) from exc
    if completed.returncode != 0:
        detail = (completed.stderr or "").strip().splitlines()
        raise ComposeCoverError(
            "ffmpeg 封面装配失败（退出码 %d）：%s"
            % (completed.returncode, detail[-1] if detail else "无错误输出")
        )
    if not target.is_file():
        raise ComposeCoverError("ffmpeg 未产出输出文件: %s" % target)
    return {
        "status": "ok",
        "cover": str(target.resolve()),
        "width": width,
        "height": height,
        "cover_copy": text,
        "channel_ref": channel_ref,
        "fontfile": font or "(ffmpeg 默认字体)",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="把封面文案烧进封面底图")
    parser.add_argument("--background", required=True, help="AI 生成或已有的封面底图")
    parser.add_argument("--copy", required=True, help="封面主文案，取自 ArticlePlan.cover_copy")
    parser.add_argument("--output", required=True, help="输出 PNG 路径")
    parser.add_argument("--channel", default="wechat_public_account")
    parser.add_argument("--font", help="中文字体文件；缺省用 ffmpeg 默认字体")
    parser.add_argument("--ffmpeg", help="ffmpeg 可执行文件路径")
    args = parser.parse_args()

    try:
        payload = compose(
            Path(args.background), Path(args.output), args.copy,
            channel_ref=args.channel, fontfile=args.font, ffmpeg=args.ffmpeg,
        )
    except ComposeCoverError as exc:
        print(json.dumps({"status": "failed", "message": str(exc)},
                         ensure_ascii=False, indent=2))
        return 1
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
