#!/usr/bin/env python3
"""认得出「用户给的素材已经是一份大纲」。

## 为什么

平台实测 8/27 那次，用户上传的素材里已经写着：中心论点、目标读者、写作调性、
五段大纲带百分比、篇幅分布表、8 条金句、三份脱敏案例、写作注意事项。
**那就是 ContentBrief 加 ArticlePlan 的全部内容。**

流程照旧跑完了：素材六问 → 候选生成 → 查重 → 编辑打分（82 分）→ ContentBrief
→ TopicDecision → ArticleRequest → ArticlePlan → 渲染。产出的 `文章大纲.md`
21 KB，输入 19 KB——**基本是把作者写好的东西重新排了一次版**。

候选只有一个的时候，「生成候选」和「排序打分」不产生任何决策，是走过场。

## 跳过的是比较，不是门禁

留：素材六问（逐字校验，防的是幻觉）、资格门禁（黑名单、无出处产品断言、
未核验时效断言、跑题、与历史完全重复）、查重。
跳：候选生成、EditorialScore 排序。

## 误判的代价不对称

**漏判只是慢，误判会写出错的文章。** 判据因此保守：中心判断与不少于三节的
章节结构**同时**具备才算数。少一样就走全流程，宁可多花那 20 次调用。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

#: 判成「已是大纲」的最少章节数。两节的东西谈不上结构，
#: 而作者随手写的笔记里出现两个小标题太常见了。
MIN_SECTIONS = 3

#: 各字段的标题同义词。作者不会每次都写「中心论点」四个字。
#:
#: 这是**字面匹配**，和 `video.check_flow` 那次踩的坑不同：那里查的是
#: 「有没有过渡词」（代理指标，换个词照样突兀），这里查的是
#: 「作者有没有为这件事单起一节」——标题本身就是那个动作。
HEADINGS = {
    "core_judgment": ("中心论点", "核心判断", "中心思想", "核心观点",
                      "核心论点", "中心判断"),
    "outline": ("大纲", "文章大纲", "结构", "章节", "内容大纲", "写作大纲"),
    "audience": ("目标读者", "读者", "受众", "目标受众"),
    "tone": ("写作调性", "调性", "语气", "文风", "写作风格"),
    "boundaries": ("写作注意事项", "注意事项", "写作要求", "表达边界", "禁区"),
    "quotes": ("全文金句清单", "金句清单", "金句"),
    "evidence": ("写作素材", "素材", "参考素材", "证据"),
}

#: 「一、最怕的三个字（10%）」→ 序号、标题、占比。
#: 全角与半角括号、百分号前的空格都要认——作者手写的格式不统一。
SECTION_LINE = re.compile(
    r"^#{3,4}\s*"
    r"(?:[一二三四五六七八九十]+|\d+)\s*[、.．)）]\s*"
    r"(?P<heading>.*?)"
    r"(?:\s*[（(]\s*(?P<share>\d+(?:\.\d+)?)\s*%\s*[)）])?\s*$")

#: 没有序号的三级标题也算一节：`### 反差切入（10%）`
BARE_SECTION_LINE = re.compile(
    r"^#{3,4}\s*(?P<heading>.*?)"
    r"(?:\s*[（(]\s*(?P<share>\d+(?:\.\d+)?)\s*%\s*[)）])?\s*$")

#: 快路径**不能**省的。资格门禁在这里是硬性的：
#: 它查的是「这篇能不能写」，和「在几个候选里挑哪个」是两件事。
STILL_REQUIRED = (
    "素材六问 material_first_pass——逐字校验引文，防的是幻觉，与候选多少无关",
    "资格门禁——黑名单、无出处产品断言、未核验时效断言、跑题、与历史完全重复",
    "历史查重——exact_history_duplicate 要靠它才判得出",
)

#: 只有认出「已是大纲」时才可以省。
SKIPPABLE = (
    "候选生成——素材已指定唯一选题，生成备选没有可比的东西",
    "EditorialScore 打分与排序——一个候选的排序不产生决策",
)


def _blocks(text: str) -> list[tuple[int, str, str]]:
    """切成 (层级, 标题, 正文) 三元组，按出现顺序。"""
    found: list[tuple[int, str, list[str]]] = []
    for line in text.splitlines():
        match = re.match(r"^(#{1,6})\s+(.*?)\s*$", line)
        if match:
            found.append((len(match.group(1)), match.group(2), []))
        elif found:
            found[-1][2].append(line)
    return [(level, title, "\n".join(body).strip()) for level, title, body in found]


def _normalise(title: str) -> str:
    """去掉标题里的补充说明：`全文金句清单（可用于标粗）` → `全文金句清单`。"""
    return re.sub(r"[（(].*?[)）]", "", title).strip()


def _find(blocks, key: str):
    """找 `HEADINGS[key]` 命中的那一节，返回 (下标, 正文)。"""
    wanted = HEADINGS[key]
    for index, (level, title, body) in enumerate(blocks):
        if level >= 2 and _normalise(title) in wanted:
            return index, body
    return None, None


def _sections_under(blocks, start: int) -> list[dict[str, Any]]:
    """`## 大纲` 之后、下一个同级标题之前的章节。

    **只认最浅的那一层。** 真实素材里 `### 二、三个真实项目（35%）` 底下还挂着
    `#### 场景一：…` `#### 场景二：…`——把它们也算成章节，5 节就变成 8 节，
    占比只有 5 个而章节有 8 个，接着「占比只标了一部分」按均分处理，
    产出一份分配全错的篇幅计划。**章节是兄弟，子标题是内容。**
    """
    outline_level = blocks[start][0]
    inside = []
    for level, title, _ in blocks[start + 1:]:
        if level <= outline_level:
            break
        inside.append((level, title))
    if not inside:
        return []
    section_level = min(level for level, _ in inside)

    found = []
    for level, title in inside:
        if level != section_level:
            continue
        match = SECTION_LINE.match("#" * level + " " + title) \
            or BARE_SECTION_LINE.match("#" * level + " " + title)
        if not match:
            continue
        share = match.group("share")
        found.append({
            "order": len(found) + 1,
            "heading": match.group("heading").strip(" 　—-"),
            "share": float(share) if share is not None else None,
        })
    return found


def _numbered_items(body: str | None) -> list[str]:
    if not body:
        return []
    return [re.sub(r"^\s*\d+[.、)]\s*", "", line).strip()
            for line in body.splitlines()
            if re.match(r"^\s*\d+[.、)]\s+", line)]


def _sub_headings(blocks, start: int) -> list[str]:
    """`## 写作素材` 下面的 `### 素材一：xxx`。"""
    level = blocks[start][0]
    found = []
    for depth, title, _ in blocks[start + 1:]:
        if depth <= level:
            break
        if depth == level + 1:
            found.append(title.strip())
    return found


def detect_shape(text: str) -> dict[str, Any]:
    """判断这份素材是不是已经写成了大纲。

    返回里 `shape` 只有两种取值：`article_plan` 走快路径，`raw_material`
    走全流程。**没有中间态**——「大概像」在这里等于「不是」，
    因为误判的代价是写出一篇错的文章。
    """
    blocks = _blocks(text)
    title = next((t for level, t, _ in blocks if level == 1), "")

    judgment_index, judgment = _find(blocks, "core_judgment")
    outline_index, _ = _find(blocks, "outline")
    sections = _sections_under(blocks, outline_index) if outline_index is not None else []

    reasons: list[str] = []
    if judgment:
        reasons.append(f"有「{_normalise(blocks[judgment_index][1])}」一节，写着中心判断")
    else:
        reasons.append("没有中心判断——那是选题要产出的东西，不能替作者定")
    if len(sections) >= MIN_SECTIONS:
        with_share = sum(1 for s in sections if s["share"] is not None)
        reasons.append(f"大纲里有 {len(sections)} 节"
                       + (f"，{with_share} 节标了占比" if with_share else "，未标占比"))
    elif sections:
        reasons.append(f"大纲只有 {len(sections)} 节，不足 {MIN_SECTIONS} 节，"
                       "谈不上结构")
    else:
        reasons.append("没有分节的大纲")

    is_plan = bool(judgment) and len(sections) >= MIN_SECTIONS

    # 占比要么全有要么当没有：一半有一半没有时拿去 `--shares` 会算出错的分配，
    # 而那个错很隐蔽——总数仍然对得上，只是某几节被摊薄了。
    shares = [s["share"] for s in sections]
    usable_shares = [float(s) for s in shares] if shares and None not in shares else None
    if is_plan and usable_shares is None and any(s is not None for s in shares):
        reasons.append("占比只标了一部分，按均分处理——半套占比会算出错的分配")

    audience_index, audience = _find(blocks, "audience")
    tone_index, tone = _find(blocks, "tone")
    boundaries_index, boundaries = _find(blocks, "boundaries")
    quotes_index, quotes_body = _find(blocks, "quotes")
    evidence_index, _ = _find(blocks, "evidence")

    found: dict[str, Any] = {
        "shape": "article_plan" if is_plan else "raw_material",
        "reasons": reasons,
        "title": title,
        # `None` 是「素材里没有」，`""` 会被当成「写了但是空的」。
        "core_judgment": judgment or None,
        "audience": audience or None,
        "tone": tone or None,
        "boundaries": boundaries or None,
        "sections": sections,
        "shares": usable_shares,
        "quotes": _numbered_items(quotes_body),
        "evidence": _sub_headings(blocks, evidence_index) if evidence_index is not None else [],
        "still_required": list(STILL_REQUIRED),
        "skippable": list(SKIPPABLE) if is_plan else [],
    }
    found["scaffold_command"] = _scaffold_command(found) if is_plan else ""
    return found


def _scaffold_command(found: dict[str, Any]) -> str:
    """把百分比直接拼成 `--scaffold` 的参数。

    省掉「人再去把 10/35/20/25/10 抄成命令行」那一步——抄错了不会报错，
    只会产出一份分配错了的篇幅计划。
    """
    parts = ["python <write-article根>/scripts/validate_article_plan.py --scaffold",
             "--out <会话根>/20-creative/.meta/article-plan-<article_id>.yaml",
             "--brief <ContentBrief 路径>",
             f"--sections {len(found['sections'])}"]
    if found["shares"]:
        rendered = ",".join(
            str(int(s)) if float(s).is_integer() else str(s) for s in found["shares"])
        parts.append(f"--shares {rendered}")
    return " \\\n  ".join(parts)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="用户上传的素材 Markdown")
    args = parser.parse_args()

    path = Path(args.input)
    if not path.is_file():
        print(f"读不到素材：{path}", file=sys.stderr)
        return 2

    found = detect_shape(path.read_text(encoding="utf-8"))
    print(json.dumps(found, ensure_ascii=False, indent=2))
    # **走全流程是正常结果，不是错误。** 报非零会让 agent 以为出了问题，
    # 转头去查为什么失败——那正是要省掉的一轮。
    return 0


if __name__ == "__main__":
    sys.exit(main())
