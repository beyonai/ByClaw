#!/usr/bin/env python3
"""Validate a clean publishable Markdown article against its manifest and ArticlePlan."""

from __future__ import annotations

import argparse
import hashlib
import math
import json
import re
import sys
from pathlib import Path
from urllib.parse import unquote, urlsplit

import yaml

# 与 `validate_article_plan.py` 同一条保险：直接跑脚本时 Python 会把脚本目录放进
# `sys.path[0]`，但被当模块 import 时不会。显式插一次，两种用法都成立。
pass  # 包内使用相对导入，避免污染其他兼容入口

# 强度词词表两个校验器共用一份，理由与差异见 amplifiers.py。
from .amplifiers import (  # noqa: E402
    CONTEXTUAL_AMPLIFIERS,
    RISKY_AMPLIFIERS,
    is_ordinal_usage,
)
from .story_contract import (  # noqa: E402
    TRUTH_MODES,
    content_kind, is_story, body_format, summary_mode, validate_story_contract,
)


MANIFEST_SCHEMA_VERSION = "1.2"
LEGACY_MANIFEST_SCHEMA_VERSION = "1.1"

#: 超出 `allowed_range.max` 多少以内只告警不阻断。
#: 带宽本身是**计划自己声明的**（`allowed_range`，不是硬编码），
#: 这一档是给「内容确实需要多写一点」留的余地——**只对上限有效**。
OVERFLOW_GRACE = 0.10
#: 逐节篇幅的两档护栏。**宽带是故意的**——`target_length` 是大纲阶段的估算，
#: 正文阶段追它的比例，等于拿估算值去改已经写对的内容（见 `length` 检查里的注释）。
SECTION_RATIO_WARN = (0.6, 1.5)
SECTION_RATIO_FAIL = (0.5, 1.6)
ALLOWED_ARTICLE_STATUSES = {"draft", "revised", "final_candidate"}
ALLOWED_PUBLICATION_STATUSES = {"pending_article", "ready", "blocked"}
FRONT_MATTER_RE = re.compile(r"\A\s*---\s*\n.*?\n---\s*\n", re.DOTALL)
H1_RE = re.compile(r"(?m)^#\s+(.+?)\s*$")
H2_RE = re.compile(r"(?m)^##\s+(.+?)\s*$")
REFERENCE_HEADING_RE = re.compile(r"(?m)^##\s+(参考资料|引用|References?)\s*$", re.IGNORECASE)
INTERNAL_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
SCENE_ANCHOR_RE = re.compile(r"(?m)^[ \t]*<!--[ \t]*scene:[ \t]*(section-[A-Za-z0-9_-]+)[ \t]*-->[ \t]*$")
SCENE_BREAK_RE = re.compile(r"(?m)^[ \t]*<!--[ \t]*scene-break[ \t]*-->[ \t]*$")
VISUAL_SLOT_RE = re.compile(r"(?m)^>\s*\*\*配图占位\s+(\d+)\s*[｜|]\s*(.+?)\*\*\s*$")
#: 「看起来是配图占位」的行——用来把**格式写错**和**压根没写**区分开。
#: 严格式要求 `**` 收尾、独占一行；写成 `> **配图占位 1｜名称** ：说明` 就不匹配，
#: 而那一个偏差会同时引发三个互不相干的报错（见 `visual_slot_format` 检查）。
NEAR_VISUAL_SLOT_RE = re.compile(r"(?m)^>.*配图占位.*$")
IMAGE_RE = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")
BOLD_RE = re.compile(r"\*\*(.+?)\*\*")
DEFENSIVE_QUALIFIERS = ("不等于", "并不意味着", "不意味着", "不能证明", "不能据此", "不代表", "并不是")
PLACEHOLDER_PATTERNS = (
    re.compile(r"\b(?:TODO|TBD)\b", re.IGNORECASE),
    re.compile(r"\{\{[^}]+\}\}"),
    re.compile(r"\[(?:待补充|待填写|占位符)\]"),
    re.compile(r"(?:正文|本节正文)[。.]?\s*$", re.MULTILINE),
)
INTERNAL_LINE_RE = re.compile(
    r"(?m)^(?:schema_version|article_id|brief_id|topic_id|plan_source|generated_at|status|length_unit|target_length)\s*:"
)


def _is_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def load_yaml(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def clean_prose(text: str) -> str:
    """Return visible prose used for deterministic length measurement."""
    text = re.sub(r"```.*?```", "", text, flags=re.DOTALL)
    text = INTERNAL_COMMENT_RE.sub("", text)
    text = VISUAL_SLOT_RE.sub("", text)
    text = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"(?m)^#{1,6}\s*", "", text)
    text = re.sub(r"(?m)^>\s?", "", text)
    # 行内高亮的 `==…==` 只剥**成对的标记**，不剥正文里单独的等号（`x = 1` 要照算）。
    # 不剥的后果实测过：一句话里一个高亮加一个术语，字数虚增 13 字——
    # 篇幅门禁按可见字符判，标记算进去就是拿排版标记去顶正文。
    text = re.sub(r"==([^=\n]+)==", r"\1", text)
    text = re.sub(r"[`*_~|]", "", text)
    return re.sub(r"\s+", "", text)


def bound_local_references(article_path: Path, plan: dict, references: str) -> bool:
    """Accept local citations only for a generic article's current ledger inputs.

    Public-channel URL requirements are unchanged. Each used evidence ID must
    identify an actually linked, registered source with its declared hash.
    """
    if plan.get("profile_id") != "generic.article":
        return False
    root = next((p for p in article_path.resolve().parents
                 if (p / ".runtime/artifacts.yaml").is_file()), None)
    if root is None:
        return False
    try:
        ledger = load_yaml(root / ".runtime/artifacts.yaml")["artifacts"]
        declarations = {}
        for binding in plan.get("source_artifacts", []):
            rel = binding["relative_path"]
            target = (root / rel).resolve()
            if not target.is_relative_to(root) or not target.is_file():
                return False
            digest = hashlib.sha256(target.read_bytes()).hexdigest()
            registered = ledger[binding["artifact_id"]]
            if (digest != binding["sha256"] or digest != registered["sha256"]
                    or target != (root / registered["path"]).resolve()):
                return False
            declarations[rel] = target
        linked = set()
        for destination in re.findall(r"\[[^\]]+\]\(([^)]+)\)", references):
            url = urlsplit(destination)
            if url.scheme or url.netloc or not url.path:
                continue
            target = (article_path.parent / unquote(url.path)).resolve()
            if target.is_relative_to(root):
                linked.add(target)
        pool = {item["evidence_id"]: item for item in plan.get("evidence_pool", [])}
        used = {ref for claim in (plan.get("argument_plan") or {}).get("supporting_claims", [])
                for ref in claim.get("evidence_refs", [])}
        return bool(used) and all(
            pool[ref].get("source") in declarations
            and declarations[pool[ref]["source"]] in linked for ref in used)
    except (OSError, ValueError, KeyError, TypeError, yaml.YAMLError):
        return False


def parse_article(path: Path, *, body_format: str = "headings", summary_mode: str = "visible"):
    content = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    title_matches = list(H1_RE.finditer(content))
    title = title_matches[0].group(1).strip() if len(title_matches) == 1 else ""
    first_section = (SCENE_ANCHOR_RE if body_format == "scenes" else H2_RE).search(content)
    intro_end = first_section.start() if first_section else len(content)
    intro_start = title_matches[0].end() if title_matches else 0
    intro = content[intro_start:intro_end]
    summary_lines = ([item.strip() for item in re.findall(r"(?m)^>\s*(.+?)\s*$", intro)
                      if item.strip()] if summary_mode == "visible" else [])
    summary = " ".join(summary_lines)

    reference_match = REFERENCE_HEADING_RE.search(content)
    article_body = content[:reference_match.start()] if reference_match else content
    references = content[reference_match.end():] if reference_match else ""
    section_matches = list((SCENE_ANCHOR_RE if body_format == "scenes" else H2_RE).finditer(article_body))
    sections = []
    for index, match in enumerate(section_matches):
        end = section_matches[index + 1].start() if index + 1 < len(section_matches) else len(article_body)
        prose = article_body[match.end():end].strip()
        visual_slots = [
            {
                "ordinal": int(slot.group(1)),
                "placeholder_text": slot.group(2).strip(),
                "raw": slot.group(0).strip(),
            }
            for slot in VISUAL_SLOT_RE.finditer(prose)
        ]
        images = [
            {"alt": image.group(1).strip(), "path": image.group(2).strip()}
            for image in IMAGE_RE.finditer(prose)
        ]
        sections.append({
            "heading": match.group(1).strip() if body_format == "headings" else "",
            "section_id": match.group(1).strip() if body_format == "scenes" else "",
            "content": prose,
            "actual_length": len(clean_prose(prose)),
            "visual_slots": visual_slots,
            "images": images,
        })
    return {
        "content": content,
        "title": title,
        "title_count": len(title_matches),
        "summary": summary,
        # 报错要能说出「摘要是几行合并来的」——见 title_summary 检查里的注释。
        "summary_lines": summary_lines,
        "unmapped_intro": ((content[:title_matches[0].start()] if title_matches else "")
                           + (re.sub(r"(?m)^>.*$", "", intro)
                              if summary_mode == "visible" else intro)),
        "sections": sections,
        "references": references,
        "has_reference_heading": reference_match is not None,
    }


#: 读者可见引用的默认形式。**公众号默认不展示**——它的正文外链除白名单外
#: 基本不可点，要求「读者点得到的出处」在这个渠道上根本交付不了。
#: 实测中原门禁逼着人「留一行短来源过门禁」，那是为了让校验器高兴而改内容。
CITATION_DISPLAY_DEFAULT = {
    "wechat_public_account": "omitted",
    "shipinhao": "omitted",
    "wechat_channels": "omitted",
}
CITATION_DISPLAY_FALLBACK = "endnote"


def citation_display(plan):
    """读者侧展示哪种形式：``inline`` / ``endnote`` / ``omitted``。

    **这是声明出来的选择，不是「内部有证据」的隐含义务。** 内部可追溯由
    `evidence_refs` 与 fact check 的 `verification_url`／`verified_at` 保证，
    删掉文末清单不会让审计链断掉——丢的只是读者侧展示。
    """
    declared = str(
        ((plan.get("distribution_plan") or {}).get("citation_display") or "")
    ).strip()
    if declared:
        return declared
    channel = str(plan.get("target_channel") or "").strip()
    return CITATION_DISPLAY_DEFAULT.get(channel, CITATION_DISPLAY_FALLBACK)


def add_check(checks, check_id, status, message, evidence=None):
    checks.append({
        "check_id": check_id,
        "status": status,
        "message": message,
        "evidence": evidence or [],
    })


def prose_paragraphs(sections):
    """Return reader-facing prose paragraphs without visual markers or standalone images."""
    paragraphs = []
    for section in sections:
        text = VISUAL_SLOT_RE.sub("", section["content"])
        text = IMAGE_RE.sub("", text)
        for paragraph in re.split(r"\n\s*\n", text):
            paragraph = paragraph.strip()
            if not paragraph:
                continue
            visible = clean_prose(paragraph)
            if visible:
                paragraphs.append({
                    "heading": section["heading"],
                    "text": paragraph,
                    "visible_length": len(visible),
                })
    return paragraphs


def describe_text_diff(actual: str, expected: str, *, limit: int = 24) -> str:
    """指出两段文本第一处不同：位置 + 两侧字符 + 上下文。

    严格相等本身是对的（标题必须逐字一致），但只报"不一致"会让调用方无从下手——
    实测一次会话为定位半角/全角标点差异反复试探近十轮，中途还写坏了参考资料的
    Markdown 链接。把差异直接说清楚，这类问题就是一轮的事。
    """
    if actual == expected:
        return ""
    common = 0
    for left, right in zip(actual, expected):
        if left != right:
            break
        common += 1
    if common == len(actual) or common == len(expected):
        longer, who = (actual, "发布稿") if len(actual) > len(expected) else (expected, "契约")
        return "前 {0} 字相同，{1}多出「{2}」".format(common, who, longer[common:common + limit])
    a, b = actual[common], expected[common]
    context = actual[max(0, common - 8):common]
    return (
        "第 {0} 字起不同：发布稿是「{1}」(U+{2:04X})，契约是「{3}」(U+{4:04X})；"
        "上文「…{5}」"
    ).format(common + 1, a, ord(a), b, ord(b), context)


#: 表格行与列表项。**它们不是句子**，不参与长句与长段判定。
TABLE_ROW_RE = re.compile(r"^\|.*\|$")
LIST_ITEM_RE = re.compile(r"^(?:[-*+]|\d+[.)])\s+")


def split_measurable_units(paragraph):
    """把一段拆成「可以谈长度」的单位，返回 [(可见长度, 文本)]。

    **表格行整块排除，列表项各自成一个单位。** 二者都没有句末标点，
    原来直接丢给 `split_sentences` 的后果是整块粘成一句：
    一张五行三列的表格是"一句 216 字"，文末参考资料列表是"一句 240 字"，
    全都超 120 的护栏。实测一次会话为这 4 条假长句查了两轮才判断出是表格——
    `script-io-contract.md` 里早写着「表格数据行常被误判」，**但没人修**。

    表格排除、不是"宽容"：把表格拆成短句是错的修法，
    真要治的是单元格里塞太多字，那属于信息密度，不是阅读负荷。
    """
    units = []
    prose_lines = []

    def flush():
        if prose_lines:
            units.extend(split_sentences("\n".join(prose_lines)))
            prose_lines.clear()

    for line in paragraph.split("\n"):
        stripped = line.strip()
        if not stripped:
            continue
        if TABLE_ROW_RE.match(stripped):
            flush()
            continue
        item = LIST_ITEM_RE.match(stripped)
        if item:
            flush()
            units.extend(split_sentences(stripped[item.end():]))
            continue
        prose_lines.append(stripped)
    flush()
    return units


def prose_only(paragraph: str) -> str:
    """去掉表格行**与列表项**后的可见正文——长段判定用它，篇幅统计**不用**。

    表格和列表都是真内容，`actual_length` 必须照数；但「这一段读起来太长」说的是
    **连续散文**，一张宽表、一串列表都不是长段。

    ⛔ **列表这一条是补的。** 上一版只剔了表格行，于是连续的有序列表被当成一整段：
    5 条 Action（每条 40 余字）合起来 375 字 → 报「过长段落」。
    实测的后果是把 5 条列表**改写成「短标题 + 短段落」**，同一篇里改了两次——
    校验器又一次改了交付结构。而列表项各自的长度**长句检查已经在管**
    （`split_measurable_units` 逐项计算），这里重复算一遍只会制造假阳性。
    """
    kept = [
        line for line in paragraph.split("\n")
        if not TABLE_ROW_RE.match(line.strip())
        and not LIST_ITEM_RE.match(line.strip())
    ]
    return clean_prose("\n".join(kept))


def split_sentences(paragraph):
    """切句，返回 [(可见长度, 原句)]。

    **返回原句而不只是长度。** 原来只回长度，报错于是只能拿章节标题当定位——
    实测一次会话为「section-04 存在过长句（单句 137 个可见字符）」翻了四轮：
    先猜是 H2 标题被算进去了，再猜是第二段，最后靠重写整段绕过。
    同一个文件里加粗那条已经改成"直接点名该砍哪几处"了，这条漏了。
    """
    sentences = [item.strip() for item in re.split(r"(?<=[。！？!?；;])", paragraph) if item.strip()]
    result = []
    for item in sentences:
        visible = clean_prose(item)
        if visible:
            result.append((len(visible), visible))
    return result


def locate(text: str, *, head: int = 22) -> str:
    """把一段过长文本压成可搜索的定位串：开头 + 结尾。

    给开头就能 grep，给结尾才知道到哪儿为止（长句往往是两三个判断挤在一起，
    断点在后半段）。
    """
    text = text.strip()
    if len(text) <= head * 2:
        return "「{0}」".format(text)
    return "「{0}…{1}」".format(text[:head], text[-8:])


def describe_length_gap(*, total, allowed_min, allowed_max, section_metrics,
                        tolerance=SECTION_RATIO_WARN):
    """篇幅不达标时，说清**差多少、去哪一节改**。

    原来只有一句「正文实际篇幅 3419 不在允许区间 3420—4180」。它说了不合格，
    没说差多少（要自己减），也没说哪一节欠（要自己比对逐节 target）。
    线上那次的结果是：助理为了过一个字的门槛，往正文里塞了一句话。

    **门禁不该松**——那是计划自己的契约，松了只是把悬崖挪个位置。
    该改的是它给不给得出下一步。

    逐节容差是 ``SECTION_RATIO_WARN`` 的宽带，所以**每节都合格、总量仍差一点**是可能的。
    那种情况下点名某一节是误导（那一节没问题），要明说可以只微调收尾。
    """
    low, high = tolerance
    short = total < allowed_min
    gap = (allowed_min - total) if short else (total - allowed_max)
    direction = "少" if short else "超"
    head = ("正文实际篇幅 {0} 不在允许区间 {1}—{2}，{3} {4} 字。"
            .format(total, allowed_min, allowed_max, direction, gap))

    # 只看与偏差同向、且已经跌出（或涨出）逐节容差的那些节——
    # 反向的节改了会让总量更远。
    offenders = []
    for item in section_metrics or []:
        target = item.get("target_length") or 0
        actual = item.get("actual_length") or 0
        if not target:
            continue
        ratio = actual / float(target)
        if short and ratio < low:
            offenders.append((target - actual, item.get("section_id"), "扩写"))
        elif not short and ratio > high:
            offenders.append((actual - target, item.get("section_id"), "压缩"))
    offenders.sort(reverse=True)

    # 两个方向的出路不一样，分开说。
    # **方向用函数内已经算好的 `short`，不再让调用方传。**
    # 原先加过一个 `under=` 参数，结果兵底那条分支忘了传——
    # **不足下限的场景走成了超上限的文案**，
    # “不要凑字数”那句直接丢了。**同一个判断别存两份。**
    escape = ("⛔ **不许灌水凑数。** 只有两条路：**补实质内容**，"
              "或者**下调 length_plan.target_total 与 allowed_range 并写明理由**——"
              "篇幅不够说明论证没展开，**不要硬塞一句无关的话**："
              "读者读到的是那句话，不是篇幅数字。"
              if short else
              "两条路：**删水分**（一次删够，别贴着线停），"
              "或者**上调 length_plan.target_total 与 allowed_range 并写明理由**——"
              "内容确实需要这个长度时，改计划比砍内容诚实。")

    if offenders:
        verb = offenders[0][2]
        named = "；".join("{0} {1} {2} 字".format(verb, sid, delta)
                         for delta, sid, verb in offenders[:3])
        return (head + "先{0}偏离最大的那几节：{1}。{2}"
                .format(verb, named, escape))

    # 各节都在容差内：总量的缺口是均摊出来的，没有哪一节该背这个锅。
    move = "补" if short else "收"
    return (head + "各节篇幅都在容差内，说明缺口是均摊的——"
            "可以只微调收尾或过渡句{0}上这 {1} 字。{2}"
            .format(move, gap, escape))


def _resolve_under(base: Path, reference: str) -> Path | None:
    """把一个相对引用按给定基准解析成绝对路径；绝对路径与空值原样处理。

    图片路径有**三个不同的基准**：正文（`20-creative/`）、manifest（`20-creative/.meta/`）、
    编译出的 HTML（`40-package/`）。同一张图从三处看过去写法本就不同，
    比字符串必然把正确的写法判成错。
    """
    text = str(reference or "").strip()
    if not text:
        return None
    candidate = Path(text)
    try:
        return (candidate if candidate.is_absolute() else base / candidate).resolve()
    except (OSError, ValueError):
        return None


#: 术语在全文出现多少次就不该再划线。
#:
#: **划线标的是「这里是定义点」。** 一个词出现几十次，它已经是文章的主题词，
#: 读者读两段就熟了，再划就是噪音。线上实测那篇：`方法论` 40 次、`Action` 34 次、
#: `Ontology` 20 次全被划了线，而真正需要提示的专业术语通常只出现 2–6 次。
#:
#: 用绝对次数而不是密度：可解释，作者一眼能核对。**给 warning 不给 error**——
#: 作者可能有理由，这里只负责让他看见。
TERM_FREQUENCY_WARN = 10

CJK = re.compile(r"[一-鿿]")

#: 紧跟在术语后面、但**不构成更长词**的高频虚词与常用动词。
#:
#: 实测 `方法论` 后面跟的是「是、有、就、这、太、可、跟」这类字——那是正常语法，
#: 不是「方法论X」这个词。不滤掉的话 40 次出现里有 33 次要报，
#: **报太多假警报，真警报（`本体工程` 之于 `本体`）就没人看了**。
FUNCTION_CHARS = set(
    "的是在和与不也就都会要能把被让从对有没这那之等中上下里后前并而但则却又再还很更最"
    "个们为以及或即则若因所由于向往到过着了吗呢吧啊如同比当其此该它他她我你们"
    "可太跟才只每各多少大小新老好真做说看想用需应必另更"
)


#: 块级强调的护栏。阈值出自 `typeset-article/references/layout-selection.md`，
#: **这里是那份文档的可执行版本**。
#:
#: 在此之前它只是文档里的一张表，没有任何校验器测量它——两篇线上实测
#: 分别排出 8 张和 6 张结论卡片（各 6 节，护栏是每节 1 张），**两次都超，两次都没人拦**。
#: 仓库里加粗超限是有真检查的，块级强调漏了。**文档里的数字没有校验器背书，等于没有。**
#:
#: 全部是 warning：作者可能有理由，这里只负责让他看见。
EMPHASIS_QUOTA = {
    # 键 → (每节配额, 每篇上限)；None 表示该维度不限
    "conclusion_card": (1, None),   # 独占一段的粗体 → 结论卡片
    "highlight": (1, None),         # ==核心判断==
    "quote": (None, 3),             # 引用卡片
    "ordinal": (None, 3),           # 并列论点段
}

#: 连续多少张列表卡片算「卡片墙」。中间该有普通段落喘口气。
MAX_CONSECUTIVE_LISTS = 2

#: 单个代码块的行数上限。手机上超过一屏的代码没人读。
MAX_CODE_LINES = 30


def _emphasis_blocks(article_body: str) -> dict:
    """按**编译器的分块方式**数出各类强调块。

    **这里的数必须与渲染出来的一致。** 校验器说 6 张、实际渲染 8 张的话，
    警告本身就是错的，作者照着改反而改坏——`test_compile_emphasis_density`
    用同一份 markdown 两边对数，就是守这件事。
    """
    text = VISUAL_SLOT_RE.sub("", article_body)

    code_blocks = [b for b in re.findall(r"```.*?```", text, flags=re.DOTALL)]
    text = re.sub(r"```.*?```", "\n\n", text, flags=re.DOTALL)

    counts = {"conclusion_card": [], "quote": 0, "ordinal": [], "list": 0,
              "highlight": [], "max_consecutive_lists": 0,
              "long_code_blocks": [len(b.splitlines()) for b in code_blocks
                                   if len(b.splitlines()) > MAX_CODE_LINES]}

    consecutive = 0
    for raw in re.split(r"\n\s*\n", text):
        block = raw.strip()
        if not block:
            continue
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if not lines:
            continue
        is_list = all(re.match(r"^([-*+]|\d+\.)\s+", l) for l in lines)
        if is_list:
            counts["list"] += 1
            consecutive += 1
            counts["max_consecutive_lists"] = max(
                counts["max_consecutive_lists"], consecutive)
            continue
        consecutive = 0
        if all(l.startswith(">") for l in lines):
            counts["quote"] += 1
            continue
        if lines[0].startswith("#"):
            continue
        joined = " ".join(lines)
        # 编译器判「结论卡片」用的就是 fullmatch：`**这句**后面还有字` 不算。
        card = re.fullmatch(r"\*\*([^*]+)\*\*", joined)
        if card:
            counts["conclusion_card"].append(card.group(1))
            continue
        counts["ordinal"].extend(
            re.findall(r"^(第[一二三四五六七八九十]+|\d{1,2})\s*[，、：:.]", joined))
        counts["highlight"].extend(re.findall(r"==([^=\n]+)==", joined))
    return counts


def _check_emphasis_density(article_body: str, section_count: int,
                            checks, warnings) -> None:
    """块级强调密度。**强调用多了等于没有强调。**"""
    found = _emphasis_blocks(article_body)
    issues = []

    for key, label in (("conclusion_card", "结论卡片（独占一段的粗体）"),
                       ("highlight", "行内高亮（==…==）")):
        per_section, _ = EMPHASIS_QUOTA[key]
        items = found[key]
        quota = per_section * section_count if section_count else per_section
        if len(items) > quota:
            excess = len(items) - quota
            longest = sorted(items, key=len, reverse=True)[:min(excess, 3)]
            issues.append(
                "{0}共 {1} 处，护栏 {2} 处（每节 {3} 处 × {4} 节），"
                "**去掉 {5} 处即可达标**。先看最长的那几处——"
                "整段叙述被写成了卡片，而卡片该放的是一句结论：{6}".format(
                    label, len(items), quota, per_section, section_count, excess,
                    "；".join("「{0}」({1} 字)".format(
                        p[:20] + ("…" if len(p) > 20 else ""), len(p))
                        for p in longest)))

    for key, label in (("quote", "引用卡片"), ("ordinal", "并列论点段")):
        _, per_article = EMPHASIS_QUOTA[key]
        value = found[key] if isinstance(found[key], int) else len(found[key])
        if value > per_article:
            issues.append(
                f"{label}共 {value} 处，护栏每篇 {per_article} 处。"
                "超出的部分改成普通段落——引用是佐证不是叙述，"
                "并列论点超过三组读者就记不住在数第几件事"
            )

    if found["max_consecutive_lists"] > MAX_CONSECUTIVE_LISTS:
        issues.append(
            f"有 {found['max_consecutive_lists']} 个列表卡片连续出现，"
            f"护栏 {MAX_CONSECUTIVE_LISTS} 个。**连着三张卡片，页面就成了卡片墙**——"
            "中间插一段普通段落喘口气"
        )

    for lines in found["long_code_blocks"]:
        issues.append(
            f"有代码块 {lines} 行，护栏 {MAX_CODE_LINES} 行。"
            "手机上超过一屏的代码没人读，拆开或只留关键几行"
        )

    if issues:
        warnings.extend(issues)
        add_check(checks, "emphasis_density", "warning", "；".join(issues))
    else:
        add_check(
            checks, "emphasis_density", "pass",
            "块级强调密度处于护栏内（结论卡片 {0}、高亮 {1}、引用 {2}、"
            "并列论点段 {3}）。".format(
                len(found["conclusion_card"]), len(found["highlight"]),
                found["quote"], len(found["ordinal"])))


def _check_term_glossary(content: str, plan: dict, checks, warnings) -> None:
    """术语表对着正文查两件事：划得太频，和可能切开更长的词。

    这两件事都**要有正文才查得了**，所以放在这里而不是 plan 校验器里。
    """
    glossary = ((plan.get("production_plan") or {}).get("term_glossary")) or []
    glossary = [t for t in glossary if isinstance(t, str) and t.strip()]
    if not glossary:
        add_check(checks, "term_glossary", "pass", "未声明术语表，排版不加下划线。")
        return

    issues = []
    for term in glossary:
        term = term.strip()
        count = content.count(term)
        if count == 0:
            issues.append(
                f"术语「{term}」在正文中一次都没出现，排版时不会有任何效果——"
                "是不是写法不一致（大小写、中英文括号）？"
            )
            continue
        if count > TERM_FREQUENCY_WARN:
            issues.append(
                f"术语「{term}」在正文出现 {count} 次，已是主题词而非待定义术语。"
                f"超过 {TERM_FREQUENCY_WARN} 次的词建议移出 term_glossary——"
                "划线标的是定义点，主题词划线只会变成噪音"
            )
            # 频次已经超标，结论就是「移出去」。再报一条切词提示是同一个词报两次，
            # **一个术语一条可执行的话**，多了作者只会整段略过。
            continue
        # 中文没有词边界，编译器判不出 `本体` 是不是 `本体论` 的一部分。
        # 这里有正文，**把真实的字串列出来**交给作者判断——不要编例子：
        # 实测 `方法论` 后面跟的多是「是/有/就」这类虚词，编一个「方法论论」
        # 只会让人以为校验器在胡说。
        if CJK.search(term):
            glued = sorted({
                m.group(0) for m in
                re.finditer(re.escape(term) + r"[一-鿿]{1,2}", content)
                if m.group(0)[len(term)] not in FUNCTION_CHARS
            })
            if glued:
                sample = "、".join(f"「{s}」" for s in glued[:4])
                issues.append(
                    f"术语「{term}」在正文里出现于这些更长的串中：{sample}。"
                    "**中文没有词边界，排版会从更长的词中间切开划线**——"
                    f"若其中有真正的术语（如「本体工程」之于「本体」），"
                    f"请把更长的那个填进 term_glossary 代替「{term}」"
                )
    if issues:
        warnings.extend(issues)
        add_check(checks, "term_glossary", "warn", "；".join(issues))
    else:
        add_check(checks, "term_glossary", "pass",
                  f"术语表 {len(glossary)} 项，出现频次与边界均正常。")


def validate(article_path: Path, plan_path: Path, manifest_path: Path):
    plan = load_yaml(plan_path) or {}
    manifest = load_yaml(manifest_path) or {}
    kind = content_kind(plan)
    story = is_story(plan)
    format_mode = body_format(plan)
    summary_display = summary_mode(plan)
    article = parse_article(article_path, body_format=format_mode, summary_mode=summary_display)
    checks = []
    failures = []
    warnings = []
    content = article["content"]

    mode_issues = validate_story_contract(plan)
    if mode_issues:
        failures.extend(mode_issues)
        add_check(checks, "content_contract", "fail", "；".join(mode_issues))
    else:
        add_check(checks, "content_contract", "pass", "文体、真实性和故事契约有效。")

    cleanliness_issues = []
    if FRONT_MATTER_RE.search(content):
        cleanliness_issues.append("发布稿包含 YAML front matter")
    comment_scan = content
    if story:
        comment_scan = SCENE_BREAK_RE.sub("", comment_scan)
        if format_mode == "scenes":
            comment_scan = SCENE_ANCHOR_RE.sub("", comment_scan)
    if INTERNAL_COMMENT_RE.search(comment_scan):
        cleanliness_issues.append("发布稿包含 HTML 工作注释")
    if INTERNAL_LINE_RE.search(content):
        cleanliness_issues.append("发布稿包含机器元数据字段")
    if re.search(r"(?m)^##\s+配图说明\s*$", content):
        cleanliness_issues.append("无关的生产说明“配图说明”出现在发布稿")
    if cleanliness_issues:
        failures.extend(cleanliness_issues)
        add_check(checks, "publish_cleanliness", "fail", "；".join(cleanliness_issues))
    else:
        add_check(checks, "publish_cleanliness", "pass", "发布稿不含机器标签、工作注释或生产说明。")

    _check_term_glossary(content, plan, checks, warnings)

    required_manifest = (
        "schema_version", "article_id", "brief_id", "topic_id", "article_path",
        "plan_path", "title", "summary", "length_unit", "target_length",
        "generated_at", "section_map", "visual_asset_status",
    )
    manifest_schema = str(manifest.get("schema_version"))
    if manifest_schema == MANIFEST_SCHEMA_VERSION:
        required_manifest += ("revision", "content_status", "publication_status", "planned_title")
    elif manifest_schema == LEGACY_MANIFEST_SCHEMA_VERSION:
        required_manifest += ("status",)
    missing = [key for key in required_manifest if manifest.get(key) in (None, "", [])
               and not (key == "summary" and summary_display == "hidden" and key in manifest)]
    if "visual_slot_map" not in manifest:
        missing.append("visual_slot_map")
    if missing:
        message = "ArticleManifest 缺少字段：{0}".format(", ".join(missing))
        failures.append(message)
        add_check(checks, "manifest", "fail", message)
    elif manifest_schema not in {MANIFEST_SCHEMA_VERSION, LEGACY_MANIFEST_SCHEMA_VERSION}:
        message = "ArticleManifest.schema_version 必须为 {0}。".format(MANIFEST_SCHEMA_VERSION)
        failures.append(message)
        add_check(checks, "manifest", "fail", message)
    elif manifest_schema == LEGACY_MANIFEST_SCHEMA_VERSION:
        message = "ArticleManifest 1.1 可兼容读取，但新产物应升级到 1.2 的内容/发布双状态。"
        warnings.append(message)
        add_check(checks, "manifest", "warning", message)
    else:
        revision = manifest.get("revision")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            message = "ArticleManifest.revision 必须为正整数。"
            failures.append(message)
            add_check(checks, "manifest", "fail", message)
        elif revision > 1 and not str(manifest.get("supersedes_manifest_path") or "").strip():
            message = "ArticleManifest.revision>1 时 supersedes_manifest_path 不能为空。"
            failures.append(message)
            add_check(checks, "manifest", "fail", message)
        else:
            add_check(checks, "manifest", "pass", "ArticleManifest 元数据完整。")

    if story:
        digest = manifest.get("digest")
        digest_issues = []
        if not isinstance(digest, str) or not clean_prose(digest):
            digest_issues.append("故事 ArticleManifest.digest 必须为非空字符串；分享摘要应单独编写，不能从正文来信引用块自动提取")
        elif len(clean_prose(digest)) > 120:
            digest_issues.append("故事 ArticleManifest.digest 超过 120 个可见字符，请压缩分享摘要，保留正文不变")
        planned_digest = (plan.get("distribution_plan") or {}).get("digest")
        if planned_digest not in (None, "") and digest != planned_digest:
            digest_issues.append("ArticleManifest.digest 必须逐字等于 ArticlePlan.distribution_plan.digest")
        if digest_issues:
            failures.extend(digest_issues)
            add_check(checks, "story_digest", "fail", "；".join(digest_issues))
        else:
            add_check(checks, "story_digest", "pass", "故事分享摘要已独立填写，长度与计划一致；不从正文引用块取值。")

    mismatches = []
    if content_kind(manifest) != kind:
        mismatches.append("content_kind 与 ArticlePlan 不一致")
    if str(manifest.get("truth_mode") or "") != str(plan.get("truth_mode") or ""):
        mismatches.append("truth_mode 与 ArticlePlan 不一致")
    if story and manifest.get("truth_mode") not in TRUTH_MODES:
        mismatches.append("故事 ArticleManifest.truth_mode 必须为 real_case|adapted_case|fictional_scenario")
    for key in ("article_id", "brief_id", "topic_id"):
        if str(manifest.get(key, "")) != str(plan.get(key, "")):
            mismatches.append("{0}: manifest={1}, plan={2}".format(key, manifest.get(key), plan.get(key)))
    plan_title = str((plan.get("distribution_plan") or {}).get("final_title") or "").strip()
    if manifest_schema == MANIFEST_SCHEMA_VERSION:
        if manifest.get("publication_status") != (plan.get("readiness") or {}).get("publication_status"):
            mismatches.append("publication_status 与 ArticlePlan 不一致")
        if str(manifest.get("planned_title") or "").strip() != plan_title:
            mismatches.append("planned_title 与 ArticlePlan.distribution_plan.final_title 不一致")
    if Path(str(manifest.get("article_path") or "")).name != article_path.name:
        mismatches.append("article_path 与实际文件名不一致")
    if Path(str(manifest.get("plan_path") or "")).name != plan_path.name:
        mismatches.append("plan_path 与实际文件名不一致")
    if mismatches:
        message = "ArticleManifest 与 ArticlePlan/文件不一致：{0}。".format("；".join(mismatches))
        failures.append(message)
        add_check(checks, "identity", "fail", message)
    else:
        add_check(checks, "identity", "pass", "ArticleManifest 的 ID 与文件指向均正确。")

    status = manifest.get("content_status") if manifest_schema == MANIFEST_SCHEMA_VERSION else manifest.get("status")
    if status not in ALLOWED_ARTICLE_STATUSES:
        message = "ArticleManifest.content_status 必须为 draft|revised|final_candidate。"
        failures.append(message)
        add_check(checks, "article_status", "fail", message)
    elif manifest_schema == MANIFEST_SCHEMA_VERSION and manifest.get("publication_status") not in ALLOWED_PUBLICATION_STATUSES:
        message = "ArticleManifest.publication_status 必须为 pending_article|ready|blocked。"
        failures.append(message)
        add_check(checks, "article_status", "fail", message)
    else:
        add_check(checks, "article_status", "pass", "文章状态有效：{0}。".format(status))

    title_summary_issues = []
    if article["title_count"] != 1:
        title_summary_issues.append("发布稿必须且只能有一个一级标题")
    if summary_display == "visible" and not article["summary"]:
        title_summary_issues.append("一级标题后、第一节前必须提供引用格式摘要")
    manifest_title = str(manifest.get("title") or "").strip()
    if article["title"] != manifest_title:
        title_summary_issues.append(
            "发布稿标题与 ArticleManifest.title 不一致（{0}）".format(
                describe_text_diff(article["title"], manifest_title)))
    if article["title"] != plan_title:
        title_summary_issues.append(
            "发布稿标题必须等于 ArticlePlan 中已完成主旨与传播审计的 final_title（{0}）".format(
                describe_text_diff(article["title"], plan_title)))
    planned_title = str(manifest.get("planned_title") or "").strip()
    if manifest_schema == MANIFEST_SCHEMA_VERSION and article["title"] != planned_title:
        title_summary_issues.append(
            "发布稿标题与 ArticleManifest.planned_title 不一致（{0}）".format(
                describe_text_diff(article["title"], planned_title)))
    manifest_summary = str(manifest.get("summary") or "").strip()
    if summary_display == "visible" and article["summary"] != manifest_summary:
        # ⛔ **报错必须说清「摘要是从哪儿取的」。**
        #
        # 摘要不是某一行，而是**导语区（H1 之后、第一个 `##` 之前）所有 `>` 行的合并**
        # （`parse_article` 的 `summary_lines`）。这条规则原先一个字都没写进契约，
        # 于是在导语里多放一个引用块（比如 `> **导语摘要｜30 秒读懂**`，那是**大纲**
        # 的约定、不是正文的）就会被静默并进摘要，manifest 永远对不上。
        # 实测的后果：调用方读了两段校验器源码，然后**手数了两遍 42 个汉字**去定位差异。
        line_count = len(article.get("summary_lines") or [])
        source_hint = (
            "摘要取自**导语区（H1 之后、第一个 `##` 之前）的所有 `>` 行合并**，"
            "本篇取到 {0} 行。⚠️ 导语区**只应有一个引用块**——"
            "多放一块（例如「30 秒读懂」，那是**大纲**的约定不是正文的）会被并进摘要。"
        ).format(line_count)
        if line_count > 1:
            source_hint += "**本篇取到 {0} 行，先确认是不是多了一个引用块。**".format(line_count)
        title_summary_issues.append(
            "发布稿摘要与 ArticleManifest.summary 不一致（{0}）。{1}".format(
                describe_text_diff(article["summary"], manifest_summary), source_hint))
    if title_summary_issues:
        failures.extend(title_summary_issues)
        add_check(checks, "title_summary", "fail", "；".join(title_summary_issues))
    else:
        add_check(checks, "title_summary", "pass", "纯净发布稿的标题和摘要与 ArticleManifest 一致。")

    plan_contract = (plan.get("contract_validation") or {}).get("status")
    outline_status = (plan.get("readiness") or {}).get("outline_status")
    if plan_contract != "pass" or outline_status != "ready":
        message = "ArticlePlan 未通过正文前置门禁：contract={0}, outline={1}。".format(plan_contract, outline_status)
        failures.append(message)
        add_check(checks, "plan_gate", "fail", message)
    else:
        add_check(checks, "plan_gate", "pass", "ArticlePlan 契约和大纲状态已通过。")

    fact_checks = ((plan.get("production_plan") or {}).get("fact_checks") or [])
    unresolved_drafting = []
    unresolved_publication = []
    for item in fact_checks:
        if item.get("status") in {"verified", "not_applicable"}:
            continue
        check_id = item.get("check_id") or "unknown"
        if item.get("required_stage") == "required_before_drafting":
            unresolved_drafting.append(check_id)
        else:
            unresolved_publication.append(check_id)
    # **「不能发布」不等于「初稿不合格」，这两件事原来共用一个 fail。**
    # 原实现只要有任何 unresolved 就 fail，`required_before_publication` 也算。
    # 但 SKILL.md 明写「发布前事实未解决时 publication_status 保持 blocked」——
    # 初稿照写。于是一篇完全合规的初稿必然 fail，再经两道传导锁死：
    #   validate_article_acceptance「deterministic_validation.status 必须等于真实校验结果」
    #     → ArticleAcceptanceReport 只能 fail
    #   validate_article_plan「acceptance == fail → publication_status = blocked」
    #     → 回到起点
    # 实测的结果是助理在回执里自己加一句「fail 是合规状态，不是质量问题」来免责——
    # 门禁失去了区分能力，读回执的人也没法一眼看出到底能不能发。
    #
    # 现在分开：正文前未解决 → fail（确实不该开写）；
    #           只有发布前未解决 → warning（能不能发由 publication_status 承载）。
    if unresolved_drafting:
        message = (
            "仍有正文前事实未核验：{0}。".format("、".join(unresolved_drafting))
            + ("同时发布前待核验：{0}。".format("、".join(unresolved_publication))
               if unresolved_publication else "")
            + "正文前事实全部 verified|not_applicable 才能开写——"
              "先去查云盘（素材 / 实体 / 成品，**云盘随时可查，不算联网**）；"
              "查了确实没有就标 unresolved 并把正文那句降级或删掉。"
        )
        failures.append(message)
        add_check(checks, "fact_gate", "fail", message, unresolved_drafting + unresolved_publication)
    elif unresolved_publication:
        message = (
            "发布前事实待核验：{0}。正文前事实已全部核验，**初稿本身合格**——"
            "这一条只对应 publication_status=blocked，不是稿子的缺陷，"
            "**不要为它改稿或在回执里写免责说明**。补采完成后重跑本校验即转 pass。"
        ).format("、".join(unresolved_publication))
        warnings.append(message)
        add_check(checks, "fact_gate", "warning", message, unresolved_publication)
    else:
        add_check(checks, "fact_gate", "pass", "所有正文前和发布前事实均已核验或明确不适用。")

    expected_sections = ((plan.get("narrative_plan") or {}).get("sections") or [])
    section_map = manifest.get("section_map") or []
    expected_ids = [str(item.get("section_id", "")) for item in expected_sections]
    mapped_ids = [str(item.get("section_id", "")) for item in section_map]
    actual_sections = article["sections"]
    structure_issues = []
    if mapped_ids != expected_ids:
        structure_issues.append("ArticleManifest.section_map 的 ID 或顺序与 ArticlePlan 不一致")
    if len(actual_sections) != len(expected_sections):
        structure_issues.append("发布稿正文{0}数量与 ArticlePlan 不一致".format(
            "场景锚点" if format_mode == "scenes" else "二级标题"))
    if format_mode == "scenes":
        actual_ids = [item["section_id"] for item in actual_sections]
        if actual_ids != expected_ids:
            structure_issues.append("场景锚点必须完整、唯一并按 ArticlePlan.sections 的 section_id 顺序出现")
        if len(actual_ids) != len(set(actual_ids)):
            structure_issues.append("正文出现重复 scene 场景锚点")
        if clean_prose(article["unmapped_intro"]):
            structure_issues.append("首个 scene 场景锚点之前存在未映射正文；把锚点放到故事第一段之前")
        first_anchor = SCENE_ANCHOR_RE.search(content)
        first_title = H1_RE.search(content)
        if first_anchor and first_title and first_anchor.start() < first_title.end():
            structure_issues.append("scene 场景锚点必须位于一级标题之后")
        if H2_RE.search("\n\n".join(item["content"] for item in actual_sections)):
            structure_issues.append("scenes 正文不使用可见二级标题；需要标题分节时选择 body_format=headings")
        if any(SCENE_ANCHOR_RE.search(block) for block in re.findall(r"```.*?(?:```|\Z)", content, flags=re.DOTALL)):
            structure_issues.append("scene 场景锚点不能位于代码块中；锚点必须对应实际正文")
    for index, expected in enumerate(expected_sections):
        if index >= len(section_map) or index >= len(actual_sections):
            continue
        mapping = section_map[index]
        actual = actual_sections[index]
        if mapping.get("ordinal") != index + 1:
            structure_issues.append("section_map[{0}].ordinal 应为 {1}".format(index, index + 1))
        if format_mode == "scenes":
            if str(mapping.get("article_heading") or "").strip():
                structure_issues.append("{0}.article_heading 应为空：scenes 以锚点映射，不生成可见小标题".format(expected_ids[index]))
            continue
        # **两条都带上差异定位。** `describe_text_diff` 早就写好了，却只服务标题与摘要——
        # 章节标题这两条仍然只说"不一致"。实测撞过：正文用 `## 一、…` 带序号前缀，
        # manifest 登记的是不带序号的标题，报错看不出差在哪，白跑两轮。
        plan_heading = str(mapping.get("plan_heading") or "").strip()
        expected_heading = str(expected.get("heading") or "").strip()
        if plan_heading != expected_heading:
            structure_issues.append("{0}.plan_heading 与 ArticlePlan 不一致：{1}".format(
                expected_ids[index], describe_text_diff(plan_heading, expected_heading)))
        article_heading = str(mapping.get("article_heading") or "").strip()
        if article_heading != actual["heading"]:
            structure_issues.append(
                "{0}.article_heading 与发布稿标题不一致：{1}"
                "（`article_heading` 要**逐字等于**正文里 `## ` 后面的整行，"
                "序号前缀如「一、」也算在内）".format(
                    expected_ids[index], describe_text_diff(article_heading, actual["heading"])))
    if structure_issues:
        failures.extend(structure_issues)
        add_check(checks, "section_structure", "fail", "；".join(structure_issues))
    else:
        add_check(checks, "section_structure", "pass",
                  "场景锚点与 ArticlePlan、ArticleManifest 完整对应。" if format_mode == "scenes"
                  else "章节由 ArticleManifest 映射到 ArticlePlan，正文无需隐藏标签。", expected_ids)

    empty_sections = []
    for index, actual in enumerate(actual_sections):
        section_id = mapped_ids[index] if index < len(mapped_ids) else "section-{0}".format(index + 1)
        if (format_mode == "headings" and not actual["heading"]) or not clean_prose(actual["content"]):
            empty_sections.append(section_id)
    if empty_sections:
        message = "以下章节缺少{0}：{1}。".format(
            "正文" if format_mode == "scenes" else "标题或正文", ", ".join(empty_sections))
        failures.append(message)
        add_check(checks, "section_content", "fail", message, empty_sections)
    else:
        add_check(checks, "section_content", "pass", "所有已规划章节均有正文。" if story else "所有已规划章节均有标题和正文。")

    plan_visuals = [
        item for item in (plan.get("visual_plan") or [])
        if isinstance(item, dict) and item.get("status") == "defined"
    ]
    # **封面不是正文配图。** 下面的逐项检查原来不认 `asset_role`，于是
    # `asset_role=cover` 也被算进「每个已定义视觉项必须有且只有一个正文位置映射」，
    # 封面图被要求在正文里占一个「配图占位 N」。公众号的封面是独立头图，不进正文流。
    # 实测的后果是助理为了让校验器通过，把 visual-cover 从 plan.visual_plan 删掉、
    # 从 pending_asset_ids 删掉、再把 cover_copy_status 从 defined 改成 not_applicable——
    # **校验器逼着它抹掉一个已经做完的封面决策**，方向是反的。
    #
    # 现在：封面仍留在 visual_slot_map 里（`pending_asset_ids` 照样盯着它，
    # ArticlePlan 侧的联合校验一个字都不用改），但它 `ordinal=0`、`section_id=""`，
    # **不占正文占位编号**。正文里的「配图占位 1..N」只数非封面项。
    # **按 visual_id 索引，不按下标。** 下标对齐只在两边完全一致时成立；
    # 一旦 slot_map 少了封面，下标就整体前移，后面每一条都会指错 ID
    # （封面缺失时把 visual-001 报成「封面项 ordinal 应为 0」，一条真错误变成五条假错误）。
    plan_visual_by_id = {
        str(item.get("visual_id") or ""): item for item in plan_visuals
    }
    cover_ids = {
        str(item.get("visual_id") or "")
        for item in plan_visuals if item.get("asset_role") == "cover"
    }
    body_visual_count = len(plan_visuals) - len(cover_ids)
    visual_plan_status = plan.get("visual_plan_status")
    visual_slot_map = manifest.get("visual_slot_map") or []
    actual_visual_slots = []
    actual_images = []
    for index, section in enumerate(actual_sections):
        section_id = mapped_ids[index] if index < len(mapped_ids) else ""
        for slot in section["visual_slots"]:
            actual_visual_slots.append(dict(slot, section_id=section_id))
        for article_image in section["images"]:
            actual_images.append(dict(article_image, section_id=section_id))

    # ⛔ **先把「格式写错」和「压根没写」分开报。**
    #
    # 占位是严格式：`> **配图占位 N｜名称**`，`**` 收尾、独占一行
    # （`article-acceptance.md` 第 8 条原话是「单行标准格式」）。
    # 写成 `> **配图占位 1｜名称** ：说明` 只差一个尾巴，但会同时炸出**三个**
    # 互不相干的报错，而原先没有一条指向真正的原因：
    #   ① 占位正则不匹配 → 「配图占位 N 未在指定章节按 manifest 文案出现」
    #   ② 占位行没被 `clean_prose` / 加粗统计剥掉 → `**配图占位 N｜…**` **计入加粗数**
    #   ③ 同理，占位行那几十个字**计入正文篇幅**
    # 实测为定位这一个偏差花了 3 次读校验器源码 + 自己在 Python 里试正则。
    malformed_slots = []
    for section_index, section in enumerate(actual_sections):
        good = {item["raw"] for item in section["visual_slots"]}
        for line in NEAR_VISUAL_SLOT_RE.findall(section["content"]):
            if line.strip() not in good:
                malformed_slots.append((
                    mapped_ids[section_index] if section_index < len(mapped_ids) else "?",
                    line.strip()))
    if malformed_slots:
        detail = "；".join(
            "{0} 的「{1}」".format(sid, locate(line, head=30)) for sid, line in malformed_slots[:3])
        message = (
            "有 {0} 行像配图占位但**格式不合规**：{1}。"
            "标准格式是 `> **配图占位 N｜名称**`——**`**` 必须收尾、占位独占一行**，"
            "说明文字另起一段，不要接在同一行（`…**｜名称** ：说明` 就不匹配）。"
            "⚠️ 这一个偏差会同时引发三处报错：占位「未出现」、"
            "占位标题**被计入加粗数**、占位那几十字**被计入正文篇幅**——"
            "**先修格式，再看其余报错**，不要逐条去追。"
        ).format(len(malformed_slots), detail)
        failures.append(message)
        add_check(checks, "visual_slot_format", "fail", message,
                  [line for _, line in malformed_slots[:5]])
    else:
        add_check(checks, "visual_slot_format", "pass", "配图占位格式合规。")

    visual_issues = []
    visual_warnings = []
    allowed_slot_statuses = {"placeholder", "embedded"}
    if visual_plan_status == "defined":
        expected_visual_ids = [str(item.get("visual_id") or "") for item in plan_visuals]
        mapped_visual_ids = [str(item.get("visual_id") or "") for item in visual_slot_map]
        if mapped_visual_ids != expected_visual_ids:
            hint = ""
            # ⛔ **slot_map 里有 plan 里不存在的 ID —— 这一类要单独说清。**
            #
            # 实测撞过：plan 的 visual_plan 里**没有** `asset_role=cover` 的项，
            # 调用方却在 manifest 里加了一个 `visual-cover`。于是 `cover_ids` 是空集，
            # 那条 `ordinal: 0` 被当成正文第 0 张图，报出来是
            # 「visual_slot_map[0].ordinal 应为 1」——**完全指不到真正的原因**。
            # 调用方靠读源码才想明白「visual-cover 是个不存在的 ID」。
            unknown = [v for v in mapped_visual_ids if v and v not in set(expected_visual_ids)]
            if unknown:
                hint += (
                    "⛔ **{0} 不在 ArticlePlan.visual_plan 里**——manifest 不能凭空发明视觉项。"
                    "需要封面就先在 `visual_plan` 里加一项 `asset_role: cover`（"
                    "`placement` 留空即可），再在 slot_map 登记；"
                    "不需要它就从 slot_map 删掉。"
                    "⚠️ 这个 ID 不被认成封面时，它的 `ordinal: 0` 会被当作**正文第 0 张图**，"
                    "于是报「ordinal 应为 1」——那条报错是这个原因的**下游症状**。"
                ).format("、".join(unknown))
            missing_covers = [value for value in sorted(cover_ids) if value and value not in mapped_visual_ids]
            if missing_covers:
                # **别让调用方以为解法是把封面从 plan 里删掉。** 实测它就是这么"修"的。
                hint = (
                    "缺的是封面项 {0}——**封面要留在 slot_map 里**，"
                    "写 `ordinal: 0`、`section_id: \"\"`、`slot_status: placeholder`，"
                    "它不占正文「配图占位 N」的编号。"
                    "⛔ 不要从 ArticlePlan.visual_plan 删封面，也不要改 cover_copy_status。"
                ).format("、".join(missing_covers))
            visual_issues.append(
                "ArticleManifest.visual_slot_map 与 ArticlePlan.visual_plan 的 ID 或顺序不一致。" + hint)
        if len(visual_slot_map) != len(plan_visuals):
            visual_issues.append(
                "每个已定义视觉项必须有且只有一个 visual_slot_map 条目"
                "（封面也要登记，只是 ordinal=0、不占正文占位）")
        body_ordinals = []
        for index, item in enumerate(visual_slot_map):
            ordinal = item.get("ordinal")
            status = item.get("slot_status")
            section_id = str(item.get("section_id") or "")
            visual_id = str(item.get("visual_id") or "")
            is_cover = visual_id in cover_ids
            if status not in allowed_slot_statuses:
                visual_issues.append("visual_slot_map[{0}].slot_status 必须为 placeholder|embedded".format(index))
            if is_cover:
                # 封面：不占正文编号、不绑章节、不需要正文占位文案。
                #
                # **报错要说清「封面与正文配图是两项资产」。** 原来只说
                # 「封面项 visual-001.ordinal 应为 0」，实测被读成了
                # 「校验器强制要求封面就是 visual-001」，接着为了迁就这套机制
                # **删掉了 section-01 的正文配图占位**——校验器又一次改了交付内容。
                COVER_HINT = (
                    "封面是独立头图，与正文配图是**两项资产**。"
                    "该章节还需要一张正文配图时，在 ArticlePlan.visual_plan 里**另开一项** "
                    "`asset_role: body`，**不要让封面兼任**。"
                )
                if ordinal != 0:
                    visual_issues.append(
                        "封面项 {0}.ordinal 应为 0——它不占正文「配图占位」编号，"
                        "正文占位仍从 1 连续数起。{1}".format(visual_id, COVER_HINT))
                if section_id:
                    visual_issues.append(
                        "封面项 {0}.section_id 应为空字符串（当前是「{1}」）——封面不出现在正文流里。"
                        "ArticlePlan 里它的 `placement` 也建议留空，填了不生效。{2}".format(
                            visual_id, section_id, COVER_HINT))
                if status == "embedded" and not str(item.get("asset_path") or "").strip():
                    visual_issues.append("已嵌入封面 {0} 缺少 asset_path".format(visual_id))
                continue
            body_ordinals.append(ordinal)
            expected_ordinal = len(body_ordinals)
            if ordinal != expected_ordinal:
                visual_issues.append("visual_slot_map[{0}].ordinal 应为 {1}".format(index, expected_ordinal))
            if section_id not in expected_ids:
                visual_issues.append("visual_slot_map[{0}].section_id 必须引用实际章节".format(index))
            if visual_id in plan_visual_by_id:
                placement = str(plan_visual_by_id[visual_id].get("placement") or "")
                referenced_sections = re.findall(r"[A-Za-z][A-Za-z0-9_-]*|section-\d+", placement)
                referenced_sections = [value for value in referenced_sections if value in expected_ids]
                if referenced_sections and section_id not in referenced_sections:
                    visual_issues.append("{0} 的正文位置不符合 ArticlePlan.placement".format(visual_id))
            if status == "placeholder":
                label = str(item.get("placeholder_text") or "").strip()
                matched = any(
                    slot["ordinal"] == ordinal
                    and slot["placeholder_text"] == label
                    and slot["section_id"] == section_id
                    for slot in actual_visual_slots
                )
                if not label or not matched:
                    visual_issues.append("配图占位 {0} 未在指定章节按 manifest 文案出现".format(ordinal))
            elif status == "embedded":
                asset_path = str(item.get("asset_path") or "").strip()
                # **各自解析到同一个文件后再比，不比字符串。**
                #
                # 正文在 `20-creative/`，manifest 在 `20-creative/.meta/`——
                # 同一张图从这两处看过去，相对路径本来就不一样。原先这里直接
                # `image["path"] == asset_path`，等于要求两个基准写出同一个字符串，
                # 而 `validate_article_plan.py` 又按 manifest 目录解析 `asset_path`
                # 去找文件。**在文档化的布局里这两条无法同时满足**：
                # `../../30-assets/x.png` 从 `.meta/` 解析正确，但把它原样写进正文，
                # 图就显示不出来。2026-09-11 那次没炸，只因为 manifest 恰好与正文同级。
                target = _resolve_under(manifest_path.parent, asset_path)
                matched = any(
                    _resolve_under(article_path.parent, image["path"]) == target
                    and image["section_id"] == section_id
                    for image in actual_images
                ) if target else False
                if not asset_path or not matched:
                    visual_issues.append(
                        "已嵌入视觉项 {0} 缺少指定图片资产"
                        "（asset_path 相对 manifest 解析为 {1}；"
                        "正文里的引用相对正文解析后没有一条指向它）".format(
                            visual_id, target or asset_path))
        if body_ordinals != list(range(1, body_visual_count + 1)):
            visual_issues.append("正文配图序号必须从 1 连续递增（封面不计入）")
        placeholder_entries = [item for item in visual_slot_map if item.get("slot_status") == "placeholder"]
        body_placeholder_entries = [
            item for item in visual_slot_map
            if item.get("slot_status") == "placeholder"
            and str(item.get("visual_id") or "") not in cover_ids
        ]
        if len(actual_visual_slots) != len(body_placeholder_entries):
            visual_issues.append(
                "正文标准配图占位数量 {0} 与 manifest 的正文占位数 {1} 不一致（封面不算正文占位）".format(
                    len(actual_visual_slots), len(body_placeholder_entries)))
        all_assets_embedded = (
            bool(plan_visuals)
            and len(visual_slot_map) == len(plan_visuals)
            and all(item.get("slot_status") == "embedded" for item in visual_slot_map)
        )
        expected_asset_status = "complete" if all_assets_embedded else "pending"
        if manifest.get("visual_asset_status") != expected_asset_status:
            visual_issues.append("visual_asset_status 应为 {0}".format(expected_asset_status))
        if placeholder_entries:
            cover_pending = len(placeholder_entries) - len(body_placeholder_entries)
            visual_warnings.append(
                "正文保留 {0} 个配图占位{1}，替换为图片或明确删除后才可直接发布。".format(
                    len(body_placeholder_entries),
                    "，另有 {0} 张封面待出图".format(cover_pending) if cover_pending else ""))
    else:
        if visual_slot_map or actual_visual_slots:
            visual_issues.append("ArticlePlan 未定义视觉项，正文和 manifest 不应保留配图占位")
        if manifest.get("visual_asset_status") != "not_applicable":
            visual_issues.append("无视觉计划时 visual_asset_status 应为 not_applicable")
    if visual_issues:
        failures.extend(visual_issues)
        add_check(checks, "visual_placement", "fail", "；".join(visual_issues))
    elif visual_warnings:
        warnings.extend(visual_warnings)
        add_check(checks, "visual_placement", "warning", "；".join(visual_warnings), [item.get("visual_id") for item in visual_slot_map])
    else:
        add_check(checks, "visual_placement", "pass", "配图位置、正文标记与机器映射一致。")

    placeholder_hits = []
    for pattern in PLACEHOLDER_PATTERNS:
        placeholder_hits.extend(match.group(0) for match in pattern.finditer(content))
    if placeholder_hits:
        message = "正文仍含占位内容：{0}。".format(", ".join(sorted(set(placeholder_hits))))
        failures.append(message)
        add_check(checks, "placeholders", "fail", message)
    else:
        add_check(checks, "placeholders", "pass", "未发现模板占位内容。")

    article_body = "\n\n".join(item["content"] for item in actual_sections)
    # Do not require disclosure text in fiction. Semantic acceptance evaluates
    # misleading case/testimonial framing and any explicit user requirements.
    if kind == "story_marketing":
        product_ids = set((plan.get("marketing_plan") or {}).get("product_claim_ids") or [])
        product_fact_ids = {
            str(fact_id)
            for claim in ((plan.get("argument_plan") or {}).get("supporting_claims") or [])
            if claim.get("claim_id") in product_ids
            for fact_id in (claim.get("fact_check_ids") or [])
        }
        exempt_products = [str(item.get("check_id")) for item in fact_checks
                           if str(item.get("check_id")) in product_fact_ids
                           and item.get("status") == "not_applicable"]
        if exempt_products:
            message = "营销产品主张对应的事实核验不得为 not_applicable：{0}。".format("、".join(exempt_products))
            failures.append(message)
            add_check(checks, "product_fact_gate", "fail", message, exempt_products)
        else:
            add_check(checks, "product_fact_gate", "pass", "产品主张保留事实核验，未核验项继续按起草/发布阶段门禁处理。")
    supported_amplifiers = {
        str(item.get("term") or "").strip()
        for item in ((plan.get("truth_strength_review") or {}).get("supported_amplifiers") or [])
        if isinstance(item, dict)
    }
    # **已核验事实的原文措辞自动豁免。** 强度词门禁防的是「作者自己加码」，
    # 不是「官方文档原话里带了这个词」。实测出过一次：正文写「每 10 分钟自动 rebase」，
    # 出处是 ev-003 官方文档的 auto-rebase 原句，却照样报「自动」需要复核——
    # 助理只能在回执里写一段免责说明，等于每篇都要交一次同样的作业。
    verified_statements = "".join(
        clean_prose(str(item.get("statement") or "") + str(item.get("original_statement") or ""))
        for item in (((plan.get("production_plan") or {}).get("fact_checks")) or [])
        if isinstance(item, dict) and item.get("status") == "verified"
    )
    HATCH = (
        "词确实由证据逐字支持时，在 ArticlePlan.truth_strength_review.supported_amplifiers "
        "登记 `term` + 证据（或把它写进对应 fact check 的 statement），本检查即放行——"
        "**不要靠回执里的免责说明过关**。"
    )

    truth_sections = actual_sections
    declared_claims = []
    if story:
        # 人物对白不是产品能力证据。故事中的实际产品主张仍须登记 claim，
        # 由产品验收检查正文是否扩大承诺；词法门禁用于说明段与登记的真实主张。
        truth_sections = [actual for index, actual in enumerate(actual_sections)
                          if index < len(expected_sections)
                          and expected_sections[index].get("section_kind", "scene") == "explanation"]
        declared_claims = [str(item.get("statement") or "")
                           for item in ((plan.get("argument_plan") or {}).get("supporting_claims") or [])]
    truth_text = "\n\n".join([item["content"] for item in truth_sections] + declared_claims)
    visible_article = clean_prose(truth_text)
    # `首次` / `第一次` 的序数豁免按**段**判，不按整篇——整篇里随便哪儿有个「第二次」
    # 就放行等于没有门禁。逐段拿原文（不是 clean_prose 后的整串）去判。
    amplifier_paragraphs = [item["text"] for item in prose_paragraphs(truth_sections)] + declared_claims
    risky_hits = []
    ordinal_hits = []
    for term in RISKY_AMPLIFIERS:
        if term in supported_amplifiers or term in verified_statements:
            continue
        if term not in visible_article:
            continue
        if term in {"首次", "第一次"}:
            # 出现处所在的那些段里，**每一处**都是序数叙述才豁免；
            # 只要有一段是优先性主张，照旧 failure。
            hosting = [para for para in amplifier_paragraphs if term in clean_prose(para)]
            if hosting and all(is_ordinal_usage(para) for para in hosting):
                ordinal_hits.append(term)
                continue
        risky_hits.append(term)
    if risky_hits:
        message = ("正文出现未在 ArticlePlan 绑定证据的高风险强度词：{0}。{1}"
                   .format("、".join(risky_hits), HATCH))
        if set(risky_hits) & {"首次", "第一次"}:
            message += (
                "⚠️ 若它其实是**序数叙述**（「第一次问它…」「第一次接入之后，第二次…」），"
                "本检查会自动豁免——没豁免说明本段读起来是**优先性主张**。"
                "**先确认它到底是哪一种，不要直接改措辞去绕过**："
                "实测有两篇为此把「第一次」改成「头一回」，交付稿的用词是校验器改的。")
        failures.append(message)
        add_check(checks, "truth_strength_language", "fail", message, risky_hits)
    elif ordinal_hits:
        message = (
            "「{0}」按**序数叙述**放行（同段有序数兄弟或紧跟经历类动词），未计入强度词。"
            "⚠️ 若其中某处其实是优先性主张，登记 supported_amplifiers 并补证据。"
        ).format("、".join(ordinal_hits))
        warnings.append(message)
        add_check(checks, "truth_strength_language", "warning", message, ordinal_hits)
    else:
        add_check(checks, "truth_strength_language", "pass", "未发现无证据新增的高风险强度词。")

    contextual_hits = [
        term for term in CONTEXTUAL_AMPLIFIERS
        if term not in supported_amplifiers
        and term not in verified_statements
        and term in visible_article
    ]
    if contextual_hits:
        message = ("正文出现需要结合语境复核范围或机制证据的强度词：{0}。{1}"
                   .format("、".join(contextual_hits), HATCH))
        warnings.append(message)
        add_check(checks, "contextual_strength_language", "warning", message, contextual_hits)
    else:
        add_check(checks, "contextual_strength_language", "pass", "未发现需要额外语境复核的范围或机制强度词。")

    paragraphs = prose_paragraphs(actual_sections)
    # **报错要能直接 grep 到。** 原来这两条只给 `item["heading"]`（章节 H2 标题），
    # 不给句子——调用方拿到「section-04 存在过长句（单句 137 字）」之后只能自己
    # 在正文里逐句数。实测为这一件事翻了四轮，中途还误判成「校验器把 H2 也算进去了」。
    # 现在给首尾定位串，`grep` 一次就能定位。
    #（不给行号：正文进 `prose_paragraphs` 前做过两次 `sub("")`，偏移已经不可靠，
    #  报一个错行号比不报更糟。）
    long_paragraphs = []
    long_sentences = []
    for item in paragraphs:
        prose = prose_only(item["text"])
        if len(prose) > 350:
            long_paragraphs.append("{0} {1}（{2} 个可见字符，拆段）".format(
                item["heading"], locate(prose), len(prose)))
        for length, sentence in split_measurable_units(item["text"]):
            if length > 120:
                long_sentences.append("{0} {1}（单句 {2} 个可见字符，拆成两句）".format(
                    item["heading"], locate(sentence), length))
    readability_messages = []
    if long_paragraphs:
        readability_messages.append("存在过长段落：{0}".format("；".join(long_paragraphs[:5])))
    if long_sentences:
        readability_messages.append("存在过长句：{0}".format("；".join(long_sentences[:5])))
    if readability_messages:
        warnings.extend(readability_messages)
        add_check(checks, "readability_signals", "warning", "；".join(readability_messages))
    else:
        add_check(checks, "readability_signals", "pass", "未发现超过护栏的长段落或长句。")

    hygiene_hits = sorted(set(re.findall(r"(?:，，|。。|；；|：：|！！|？？|的的|了了)", article_body)))
    if hygiene_hits:
        message = "正文存在疑似重复标点或叠词错误：{0}。".format("、".join(hygiene_hits))
        failures.append(message)
        add_check(checks, "language_hygiene", "fail", message, hygiene_hits)
    else:
        add_check(checks, "language_hygiene", "pass", "未发现常见重复标点或叠词错误。")

    defensive_hits = []
    visible_body = clean_prose(article_body)
    for phrase in DEFENSIVE_QUALIFIERS:
        defensive_hits.extend([phrase] * visible_body.count(phrase))
    defensive_threshold = max(6, len(actual_sections) + 2)
    if len(defensive_hits) > defensive_threshold:
        message = (
            "边界限定句式共 {0} 处，超过当前护栏 {1} 处；"
            "检查是否因反复使用“不等于/不意味着/不能据此”等表达削弱叙事推进。"
        ).format(len(defensive_hits), defensive_threshold)
        warnings.append(message)
        add_check(checks, "defensive_repetition", "warning", message, defensive_hits[:12])
    else:
        add_check(
            checks,
            "defensive_repetition",
            "pass",
            "边界限定句式数量处于护栏内。",
            defensive_hits[:12],
        )

    target_by_id = {str(item.get("section_id", "")): int(item.get("target_length") or 0) for item in expected_sections}
    actual_by_id = {}
    for index, item in enumerate(actual_sections):
        if format_mode == "scenes":
            actual_by_id[item["section_id"]] = item["actual_length"]
        elif index < len(mapped_ids):
            actual_by_id[mapped_ids[index]] = item["actual_length"]
    unmapped_length = len(clean_prose(article["unmapped_intro"])) if format_mode == "scenes" else 0
    total_actual = (sum(item["actual_length"] for item in actual_sections) + unmapped_length
                    if format_mode == "scenes" else sum(actual_by_id.values()))
    length_plan = plan.get("length_plan") or {}
    allowed = length_plan.get("allowed_range") or {}
    allowed_min = int(allowed.get("min") or 0)
    allowed_max = int(allowed.get("max") or 0)
    plan_target_total = length_plan.get("target_total")
    length_failures = []
    length_warnings = []
    section_metrics = []
    # **上限与下限不对称，不该都是 hard fail。**
    #   超上限 = 内容多了。硬砍砍掉的是**内容**。
    #   不足下限 = 内容没写够。补足的办法只有一个坏答案：**灌水**。
    # 实测两头都出过事：一次为 121 字（2.9%）砍了 8 轮，中途还砍反过一次；
    # 另一次「为了过一个字的门槛，往正文里塞了一句话」。
    #
    # 所以：上限超 OVERFLOW_GRACE 以内降为 warning（要在回执里说明为什么留），
    # 超更多才 fail；下限一律 fail，并写死**不许灌水**。
    over = total_actual - allowed_max if allowed_max and total_actual > allowed_max else 0
    under = allowed_min - total_actual if allowed_min and total_actual < allowed_min else 0
    grace = int(allowed_max * OVERFLOW_GRACE) if allowed_max else 0
    total_overflow_tolerated = bool(over) and over <= grace
    total_out_of_range = bool(under) or (bool(over) and not total_overflow_tolerated)
    for section_id in expected_ids:
        target = target_by_id.get(section_id, 0)
        actual = actual_by_id.get(section_id, 0)
        ratio = round(actual / float(target), 3) if target else None
        article_heading = ""
        if section_id in mapped_ids and mapped_ids.index(section_id) < len(actual_sections):
            article_heading = actual_sections[mapped_ids.index(section_id)]["heading"]
        section_metrics.append({
            "section_id": section_id,
            "article_heading": article_heading,
            "target_length": target,
            "actual_length": actual,
            "target_ratio": ratio,
        })
        # **逐节 `target_length` 是大纲阶段的估算，不是契约。**
        # 原来的 warning 带是 0.75—1.3。实测一次 5 节文章**5 节全部落在 warning 区**
        # （0.76 / 1.28 / 1.33 / 1.46 / 1.48），于是助理扩 section-02、压 section-05、
        # 再扩、再压，绕着比例改了十几轮稿——而总篇幅一直在 allowed_range 里。
        # 大纲阶段预估不出「第三层机制最陌生所以要给足篇幅」这种事，
        # 追它的比例就是拿估算值去改已经写对的内容。
        #
        # 所以放宽到 0.6—1.5，并且**明说不要为对齐比例改稿**——
        # 真正该硬拦的只有「这一节基本没写」和「这一节吃掉了别节的篇幅」。
        if target and (ratio < SECTION_RATIO_FAIL[0] or ratio > SECTION_RATIO_FAIL[1]):
            length_failures.append(
                "{0} 实际篇幅 {1} 与目标 {2} 偏差过大（{3:.2f}x，护栏 {4:.1f}—{5:.1f}x）。"
                "这一档说明这一节要么基本没写、要么吃掉了别节的篇幅，**要改结构**。".format(
                    section_id, actual, target, ratio, *SECTION_RATIO_FAIL))
        elif target and (ratio < SECTION_RATIO_WARN[0] or ratio > SECTION_RATIO_WARN[1]):
            length_warnings.append(
                "{0} 实际篇幅 {1} 与目标 {2}（{3:.2f}x）。"
                "`target_length` 是大纲阶段的估算，**不要为对齐比例改稿**——"
                "在回执里写一句为什么这一节是这个长度就行。".format(
                    section_id, actual, target, ratio))
    # 总量那条放在逐节指标算完之后——它要拿 section_metrics 才说得出去哪儿改。
    if total_out_of_range:
        length_failures.insert(0, describe_length_gap(
            total=total_actual, allowed_min=allowed_min, allowed_max=allowed_max,
            section_metrics=section_metrics))
    elif total_overflow_tolerated:
        length_warnings.insert(0, (
            "正文 {0} 字，超上限 {1} 字（{2:.1%}），在 {3:.0%} 宽限内**放行**。"
            "⛔ **不要为这点字数删内容**——实测出过一次：为 121 字砍了 8 轮，"
            "后面几轮砍的已经是实质内容。"
            "**在回执里写一句为什么留**（哪一节的论证需要这个长度）；"
            "真觉得是水分，就一次删够、别贴着线停。"
        ).format(total_actual, over, over / float(allowed_max), OVERFLOW_GRACE))
    # ⛔ **反向拟合检测：写完再把靶子挪到箭上。**
    #
    # 这道逐节检查原本是「计划 vs 产出」的对照，但计划是可写的，而校验器只校内部自洽
    # （`sum(target_length) == target_total`、`target_total ∈ allowed_range`）。
    # 于是有一条捷径：正文压不下来时，把 `target_total` 改成实测总量、
    # 再把每节 `target_length` 改成该节实测值——两个校验器全过，逐节比例全是 1.00x。
    #
    # 实测就这么发生过一次：正文 6142 字压了五轮到 4330，仍超上限，
    # 于是改计划 `target_total = 4330`、各节目标写成 588/708/800/1463/771（全是实测值），
    # 回执里写着「**5 节全在 1.0 ratio**」。**一个满分，等于什么都没校。**
    #
    # 判据：≥3 节、每节都贴着目标（±2%）、总量又几乎正好等于 `target_total`。
    # 真实写作里这个巧合的概率约等于零——`length_shape` 分出来的是整齐比例，
    # 不会是 588/708/800/1463/771 这种数。
    measured = [item for item in section_metrics if item.get("target_length")]
    if (len(section_metrics) >= 3 and len(measured) == len(section_metrics)
            and _is_number(plan_target_total) and plan_target_total > 0
            and abs(total_actual - plan_target_total) <= max(2, plan_target_total * 0.005)
            and all(abs(item["actual_length"] - item["target_length"])
                    <= max(1, item["target_length"] * 0.02) for item in measured)):
        message = (
            "疑似把 `target_length` 按实测值回填：{0} 节全部贴着目标（±2% 内），"
            "总量 {1} 又几乎正好等于 target_total {2}。**这样逐节篇幅这道检查就是自证的**——"
            "靶子挪到了箭上，1.00x 不代表篇幅规划成立。"
            "把各节 `target_length` 恢复成**大纲阶段定的那组值**再跑；"
            "内容确实需要别的长度，就让它落在 {3:.1f}—{4:.1f}x 的护栏里"
            "（超出逐节护栏才是真信号），总量确实需要调整就改 `target_total` 并在回执里说明，"
            "**但不要把逐节目标也一起改成实测值**。"
        ).format(len(section_metrics), total_actual, plan_target_total, *SECTION_RATIO_WARN)
        length_failures.append(message)

    if length_failures:
        failures.extend(length_failures)
        add_check(checks, "length", "fail", "；".join(length_failures))
    elif length_warnings:
        warnings.extend(length_warnings)
        add_check(checks, "length", "warning", "；".join(length_warnings))
    else:
        add_check(checks, "length", "pass", "总篇幅和各章节篇幅处于计划容差内。")

    article_without_slots = VISUAL_SLOT_RE.sub("", article_body)
    bold_phrases = [match.group(1).strip() for match in BOLD_RE.finditer(article_without_slots) if match.group(1).strip()]
    emphasis_warnings = []
    if not story and total_actual >= 1500 and not bold_phrases:
        emphasis_warnings.append("长文没有重点句加粗，读者难以快速抓住中心判断或关键转折。")
    maximum_bold = max(len(actual_sections) * 2, int(math.ceil(total_actual / 250.0))) if total_actual else 0
    if len(bold_phrases) > maximum_bold:
        # **说清「超几处、按什么留、先砍哪几个」。**
        # 原来只说「共 19 处，超过护栏 10 处」——调用方于是自己 grep 一遍、
        # 自己判断每一处该不该留，实测为这一件事烧掉四轮。
        # 判据是可算的：**长的、整句的先砍**（产品名与术语通常短，是该留的那批）。
        # **给下限，不然会砍穿。** 原来只说"要去掉 N 处"，加上按长度只列前 5 条，
        # 超限 23 处时调用方看见 5 条就大砍——实测一次从 48 处一刀砍到 5 处
        # （护栏是 25），再往回补到 7 处。砍到护栏内就停，那才是目标。
        excess = len(bold_phrases) - maximum_bold
        by_length = sorted(bold_phrases, key=len, reverse=True)
        floor = max(len(actual_sections), maximum_bold // 2)
        emphasis_message = (
            "重点加粗共 {0} 处，护栏 {1} 处，**去掉 {2} 处即可达标**——"
            "目标是落到 {1} 处以内，**不是越少越好**（{3} 处上下是合理区间，"
            "每节至少留住中心判断那一处）。"
            "留短的、去长的——产品名与术语通常短，整句加粗才是噪声。"
            "按长度排在最前的几处：{4}。".format(
                len(bold_phrases), maximum_bold, excess, floor,
                "；".join("「{0}」({1} 字)".format(
                    p[:18] + ("…" if len(p) > 18 else ""), len(p))
                    for p in by_length[:excess if excess <= 5 else 5])))
        if story:
            emphasis_message = (
                "重点加粗共 {0} 处，超过护栏 {1} 处；减少 {2} 处即可。"
                "故事不要求每节保留加粗，也不要高亮未揭晓的结局。"
            ).format(len(bold_phrases), maximum_bold, excess)
        emphasis_warnings.append(emphasis_message)
    if emphasis_warnings:
        warnings.extend(emphasis_warnings)
        # **超限时把 19 处全给出来，不要截成 10 处。** 实测出过一次：
        # 调用方看不见剩下 9 处，就自己编了个解释——「`**配图占位 N｜**` 也被算进去了，
        # 占 3 处」——而 `article_without_slots` 上面刚把占位整行剔掉。
        # 它按这个错判去砍加粗，砍的是别的地方。
        add_check(checks, "emphasis_signals", "warning", "；".join(emphasis_warnings), bold_phrases)
    else:
        add_check(checks, "emphasis_signals", "pass", "重点加粗数量处于护栏内。", bold_phrases[:10])

    # 块级强调：结论卡片、高亮、引用、并列论点段、卡片墙、超长代码块。
    # 加粗那条管的是**行内**，这条管的是**块级**，两者互不覆盖。
    _check_emphasis_density(article_body, len(actual_sections), checks, warnings)

    link_count = len(re.findall(r"\[[^\]]+\]\(https?://[^)]+\)", article["references"]))
    evidence_expected = any(
        item.get("evidence_refs")
        for item in ((plan.get("argument_plan") or {}).get("supporting_claims") or [])
    )
    display = citation_display(plan)
    local_shown = article["has_reference_heading"] and bound_local_references(
        article_path, plan, article["references"])
    shown = article["has_reference_heading"] and (link_count > 0 or local_shown)

    if not evidence_expected:
        add_check(checks, "references", "pass", "本文未登记证据引用。")
    elif display == "omitted":
        # 读者拿不到出处时，作者这边一点都不能含糊。原门禁方向是反的——
        # 只要文末贴了链接，内部核验是不是 unresolved 它根本不看。
        # ⚠️ `fact_checks` 挂在 `production_plan` 下，不在顶层。
        # 原来这里写的是 `plan.get("fact_checks")`——**永远取到空列表**，
        # 于是这道「不展示来源就必须全核验」的门禁从落地起就是死代码。
        # **按 stage 分档，和 `fact_gate` 保持一致。** 这道门禁在上一行被从死代码救活，
        # 如果对两个 stage 一视同仁地 fail，就会从另一条路把 `fact_gate` 的分档
        # 重新压成 fail——公众号默认 `citation_display=omitted`，等于所有公众号初稿又全 fail。
        omitted_unresolved = [
            item for item in (((plan.get("production_plan") or {}).get("fact_checks")) or [])
            if str(item.get("status") or "") not in {"verified", "not_applicable"}
        ]
        blocking = [
            str(item.get("check_id") or "?") for item in omitted_unresolved
            if item.get("required_stage") == "required_before_drafting"
        ]
        deferred = [
            str(item.get("check_id") or "?") for item in omitted_unresolved
            if item.get("required_stage") != "required_before_drafting"
        ]
        if blocking:
            message = (
                "声明 citation_display=omitted（读者侧不展示来源）时，"
                "正文前事实必须已核验，否则读者既看不到出处、内部也没核过："
                "未核验 {0}".format("、".join(blocking))
            )
            failures.append(message)
            add_check(checks, "references", "fail", message, blocking)
        elif deferred:
            message = (
                "按 citation_display=omitted 不展示来源，读者无法自行核对；"
                "发布前事实 {0} 仍待补采。**初稿本身合格**，"
                "但发布前必须补齐——读者看不到出处时，内部核验是唯一的兜底。".format("、".join(deferred))
            )
            warnings.append(message)
            add_check(checks, "references", "warning", message, deferred)
        else:
            add_check(
                checks, "references", "warning",
                "按 citation_display=omitted 不展示来源；事实出处仅存于内部核验档，"
                "读者无法自行核对。内部 fact check 已全部核验。",
            )
    elif shown:
        add_check(
            checks, "references", "pass",
            ("本地参考资料与任务账本、证据池及文件哈希一致。" if local_shown else
             "已登记参考资料 URL 数量：{0}；该检查不代表链接已在本轮实际打开。".format(link_count)),
        )
    else:
        message = (
            "citation_display={0} 声明要展示来源，但发布稿“参考资料”未提供来源 URL。"
            "确实不想展示时把它改成 omitted。".format(display)
        )
        failures.append(message)
        add_check(checks, "references", "fail", message)

    return {
        "schema_version": "1.2",
        "article_id": manifest.get("article_id", ""),
        "brief_id": manifest.get("brief_id", ""),
        "topic_id": manifest.get("topic_id", ""),
        "content_kind": kind,
        "truth_mode": str(plan.get("truth_mode") or ""),
        "status": "fail" if failures else ("pass_with_warnings" if warnings else "pass"),
        "checks": checks,
        "metrics": {
            "length_unit": length_plan.get("length_unit", manifest.get("length_unit", "")),
            "measurement_method": "visible_characters" if length_plan.get("length_unit") == "chinese_characters" else "words",
            "measurement_label": "可见正文字符" if length_plan.get("length_unit") == "chinese_characters" else "英文单词",
            "target_total": int(length_plan.get("target_total") or 0),
            "allowed_range": {"min": allowed_min, "max": allowed_max},
            "actual_total": total_actual,
            "unmapped_body_length": unmapped_length,
            "sections": section_metrics,
            "reference_url_count": link_count,
            "paragraph_count": len(paragraphs),
            "long_paragraph_count": len(long_paragraphs),
            "long_sentence_count": len(long_sentences),
            "bold_phrase_count": len(bold_phrases),
            "visual_placeholder_count": len(actual_visual_slots),
            "embedded_image_count": len(actual_images),
            "defensive_qualification_count": len(defensive_hits),
        },
        "failures": failures,
        "warnings": warnings,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--article", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        result = validate(args.article, args.plan, args.manifest)
    except (OSError, yaml.YAMLError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0 if result["status"] in {"pass", "pass_with_warnings"} else 1


if __name__ == "__main__":
    sys.exit(main())
