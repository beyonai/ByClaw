#!/usr/bin/env python3
"""Compute reproducible lexical overlap between candidate and historical topics."""

from __future__ import annotations

import re
from typing import Any

from .topic_cli_io import read_json, write_json


def _tokens(value: str) -> set[str]:
    normalized = re.sub(r"[^\w\u4e00-\u9fff]+", "", value.lower())
    latin = set(re.findall(r"[a-z0-9_]+", normalized))
    chinese = "".join(re.findall(r"[\u4e00-\u9fff]", normalized))
    grams = {chinese[index:index + 2] for index in range(max(0, len(chinese) - 1))}
    if len(chinese) == 1:
        grams.add(chinese)
    return latin | grams


def _text(item: dict[str, Any]) -> str:
    return " ".join(str(item.get(key) or "") for key in (
        "title", "working_title", "core_judgment", "reader_problem", "reader_question",
        "summary", "abstract", "body", "content",
    ))


def _has_claim_context(item: dict[str, Any]) -> bool:
    return any(item.get(key) for key in (
        "core_judgment", "reader_problem", "reader_question", "summary", "abstract", "body", "content"
    ))


def similarity(left: dict[str, Any], right: dict[str, Any]) -> float:
    left_tokens, right_tokens = _tokens(_text(left)), _tokens(_text(right))
    if not left_tokens or not right_tokens:
        return 0.0
    return round(len(left_tokens & right_tokens) / len(left_tokens | right_tokens), 4)


def analyze(params: dict[str, Any]) -> dict[str, Any]:
    candidates = params.get("candidates") or []
    history = params.get("history") or []
    threshold = float(params.get("threshold", 0.55))
    review_threshold = float(params.get("review_threshold", 0.15))
    if not isinstance(candidates, list) or not isinstance(history, list):
        raise ValueError("candidates 和 history 必须是数组")
    valid_history = [item for item in history if isinstance(item, dict)]
    claim_context_count = sum(1 for item in valid_history if _has_claim_context(item))
    if not valid_history:
        comparison_scope = "none"
    elif claim_context_count == len(valid_history):
        comparison_scope = "claim_aware"
    elif claim_context_count == 0:
        comparison_scope = "title_only"
    else:
        comparison_scope = "mixed"
    results = []
    for index, candidate in enumerate(candidates):
        if not isinstance(candidate, dict):
            raise ValueError("candidate 必须是对象")
        comparisons = []
        for historical in history:
            if not isinstance(historical, dict):
                continue
            score = similarity(candidate, historical)
            comparisons.append({
                "history_id": historical.get("topic_id") or historical.get("instance_id") or historical.get("id"),
                "title": historical.get("title") or historical.get("working_title"),
                "score": score,
            })
        comparisons.sort(key=lambda item: item["score"], reverse=True)
        maximum = comparisons[0]["score"] if comparisons else 0.0
        results.append({
            "candidate_id": candidate.get("candidate_id") or candidate.get("topic_id") or f"candidate-{index + 1}",
            "max_overlap": maximum,
            "duplicate_risk": maximum >= threshold,
            "semantic_review_required": bool(valid_history) and (
                comparison_scope != "claim_aware" or maximum >= review_threshold
            ),
            "top_matches": comparisons[:3],
        })
    return {
        "ok": True,
        "threshold": threshold,
        "review_threshold": review_threshold,
        "history_count": len(valid_history),
        "history_with_claim_context_count": claim_context_count,
        "history_ids": [
            item.get("topic_id") or item.get("instance_id") or item.get("id")
            for item in valid_history
        ],
        "comparison_scope": comparison_scope,
        "results": results,
    }


if __name__ == "__main__":
    write_json(analyze(read_json()))
