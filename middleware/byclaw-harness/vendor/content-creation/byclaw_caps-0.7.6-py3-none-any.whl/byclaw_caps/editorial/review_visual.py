#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""语义复核记录：要有证据，不能只有字段。

方案《配图语义规划方案.md》§3.7、§4.3。

**字段不等于证据。** 早先的做法是"复核结论写进 `validation.semantic_review`"——
那和 1301 那轮 `text_legibility: pass` 全是伪证是同一个形状：
一个可以直接写上去的字段，没有任何东西约束它对应过什么。

所以按 `inspect` 检查记录的同一套办法做：绑输入包各件的哈希、逐项结论、
问题位置、失效规则、缺失/失败/过期不登记。

**两个维度，不是一个。**

- `method`：谁验的（`deterministic` / `reviewed` / `declared` / `n/a`）
- `result`：验出什么（`pass` / `fail` / `inconclusive`）

`reviewed` 只说明"是模型验的"，**不代表通过**。把它和 `pass` 并列成
"三种通过"，等于让一个来源标记冒充结论。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Mapping

pass  # 包内使用相对导入，避免污染其他兼容入口

from byclaw_caps.shared.visual_semantics import sha256_text  # noqa: E402
from byclaw_caps.shared.render_contract import (  # noqa: E402  构建期与 visual_semantics 同路注入
    DigestFormatError, digests_match,
)

METHOD_DETERMINISTIC = "deterministic"
METHOD_REVIEWED = "reviewed"
METHOD_DECLARED = "declared"
METHOD_NA = "n/a"
METHODS = (METHOD_DETERMINISTIC, METHOD_REVIEWED, METHOD_DECLARED, METHOD_NA)

RESULT_PASS = "pass"
RESULT_FAIL = "fail"
RESULT_INCONCLUSIVE = "inconclusive"
RESULTS = (RESULT_PASS, RESULT_FAIL, RESULT_INCONCLUSIVE)

#: 复核清单。每一条都要有 `method` + `result`。
CHECKS = (
    ("relation_direction", "每条事实关系的方向与正文一致"),
    ("derivation_holds", "derived 关系的推导站得住"),
    ("no_meaning_drift", "excerpt/abbrev/summary 没有丢掉否定、条件、适用范围"),
    ("coverage_claims", "覆盖/程度类判断有依据，不是凑格子"),
    ("must_cover_complete", "must_cover 逐条都在画面上"),
    ("must_avoid_absent", "must_avoid 一条都没出现"),
    ("no_undeclared_claims", "画面上没有未声明的新断言"),
)

REVIEW_STALE = "REVIEW_STALE"


class ReviewError(ValueError):
    def __init__(self, code: str, message: str, **detail: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.detail = detail


def build_review_input(
    *,
    visual_id: str,
    sources: Mapping[str, Any],
    plan_item: Mapping[str, Any],
    design: Mapping[str, Any],
) -> dict:
    """复核输入包：**屏蔽理由，不屏蔽待核查的内容**。

    只给来源和图，复核者做不了上面那张清单——它不知道哪些是 `must_cover`、
    哪些是 `must_avoid`、画面上哪个断言是设计里声明过的、`derived` 声称的
    推导是什么。「未声明的新断言」这一项，没有声明清单就无从谈起。

    屏蔽 `rationale` 是为了防止复核者顺着设计者的论证走；
    屏蔽断言清单则是直接取消了复核能力。**这是两件事。**
    """
    assertions = []
    for node in (design.get("nodes") or []):
        if isinstance(node, Mapping):
            assertions.append({"where": "node", "id": node.get("id"),
                               "text": node.get("label") or node.get("text"),
                               "anchor": node.get("anchor"),
                               "relation": node.get("relation")})
    for relation in (design.get("relations") or []):
        if isinstance(relation, Mapping):
            assertions.append({"where": "relation", "kind": relation.get("kind"),
                               "text": relation.get("label"),
                               "support": relation.get("support"),
                               "visual_convention": relation.get("visual_convention")})
    return {
        "visual_id": visual_id,
        "section_excerpt": sources.get("section_excerpt") or "",
        "evidence": sources.get("evidence") or [],
        "assertions": assertions,
        "must_cover": list(plan_item.get("must_cover") or []),
        "must_avoid": list(plan_item.get("must_avoid") or []),
        "structure": plan_item.get("structure") or {},
        # `rationale` 故意不在这里。
    }


def review_input_sha256(review_input: Mapping[str, Any]) -> str:
    return sha256_text(json.dumps(review_input, sort_keys=True,
                                  ensure_ascii=False, separators=(",", ":")))


def validate_record(record: Mapping[str, Any]) -> list[str]:
    """记录本身合不合规。"""
    errors: list[str] = []
    checks = record.get("checks") or {}
    for key, description in CHECKS:
        entry = checks.get(key)
        if not isinstance(entry, Mapping):
            errors.append(f"缺检查项 {key}（{description}）")
            continue
        method = entry.get("method")
        result = entry.get("result")
        if method not in METHODS:
            errors.append(f"{key} 的 method 未知：{method}")
        if result not in RESULTS:
            errors.append(f"{key} 的 result 必须是 pass / fail / inconclusive，"
                          f"实际：{result}")
        if result in (RESULT_FAIL, RESULT_INCONCLUSIVE) and \
                not str(entry.get("detail") or "").strip():
            errors.append(f"{key} 是 {result} 但没写问题位置")
    if str(record.get("reviewer") or "").strip() == \
            str(record.get("designer") or "").strip() and record.get("designer"):
        errors.append("复核者不能是产出 VisualDesign 的那个助理——那是自证")
    return errors


def is_stale(record: Mapping[str, Any], *, review_input_hash: str,
             output_sha256: str) -> bool:
    """来源、设计或图片任一变化 → 该复核结论失效。

    **按归一化后的摘要比。** 这个仓库里 `file_sha256` 出大写、
    `sha256_file` 出小写，裸比字符串会把"同一个文件"判成"图换过了"。
    格式不合法时按失效处理，并由 `gate()` 报成"记录写坏了"而不是"内容变了"。
    """
    bound = record.get("bound") or {}
    try:
        return not (digests_match(bound.get("review_input_sha256"),
                                  review_input_hash)
                    and digests_match(bound.get("output_sha256"), output_sha256))
    except DigestFormatError:
        return True


def malformed_digest(record: Mapping[str, Any], *, review_input_hash: str,
                     output_sha256: str) -> str:
    """摘要格式有没有写坏——写坏了要单独说，别混进"内容变了"。"""
    bound = record.get("bound") or {}
    for field, left, right in (
            ("review_input_sha256", bound.get("review_input_sha256"),
             review_input_hash),
            ("output_sha256", bound.get("output_sha256"), output_sha256)):
        try:
            digests_match(left, right, field=field)
        except DigestFormatError as failure:
            return str(failure)
    return ""


def gate(record: Mapping[str, Any] | None, *, review_input_hash: str,
         output_sha256: str) -> dict:
    """能不能登记完成。

    **缺失、`fail`、`inconclusive` 或过期，一律不能。**
    `inconclusive` 不是通过：它和 `fail` 一样挡住登记，
    区别只在于前者要补材料、后者要改图。
    """
    if record is None:
        return {"ok": False, "code": "REVIEW_MISSING",
                "message": "没有语义复核记录——必需检查缺失不是通过"}
    errors = validate_record(record)
    if errors:
        return {"ok": False, "code": "REVIEW_INVALID",
                "message": "复核记录不合规", "errors": errors}
    broken = malformed_digest(record, review_input_hash=review_input_hash,
                              output_sha256=output_sha256)
    if broken:
        return {"ok": False, "code": "REVIEW_MALFORMED",
                "message": "复核记录里的摘要格式不对：%s。"
                           "**这不是「内容变了」**，是记录写坏了；"
                           "摘要要由工具读文件算出来，不要手填。" % broken}
    if is_stale(record, review_input_hash=review_input_hash,
                output_sha256=output_sha256):
        return {"ok": False, "code": REVIEW_STALE,
                "message": "复核记录绑定的是旧输入：来源、设计或图片已经变过"}
    failed = [key for key, _ in CHECKS
              if (record["checks"][key]["result"]) != RESULT_PASS]
    if failed:
        return {"ok": False, "code": "REVIEW_NOT_PASSED",
                "message": "复核未全部通过：%s" % failed, "failed": failed}
    return {"ok": True, "code": "", "message": "复核通过"}


def main() -> None:
    parser = argparse.ArgumentParser(description="语义复核记录：生成输入包 / 判门禁")
    sub = parser.add_subparsers(dest="command", required=True)

    prepare = sub.add_parser("prepare", help="生成复核输入包（不含 rationale）")
    prepare.add_argument("plan", help="最终 VisualPlan")
    prepare.add_argument("design", help="VisualDesign")
    prepare.add_argument("visual_id")
    prepare.add_argument("output")

    check = sub.add_parser("gate", help="判这张图能不能登记完成")
    check.add_argument("record", help="复核记录 JSON")
    check.add_argument("review_input", help="复核输入包 JSON")
    check.add_argument("--output-sha256", required=True, help="当前 PNG 的哈希")

    args = parser.parse_args()

    if args.command == "prepare":
        plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
        design_doc = json.loads(Path(args.design).read_text(encoding="utf-8"))
        item = next((a for a in plan.get("items") or []
                     if str(a.get("asset_id")) == args.visual_id), None)
        design = next((d for d in design_doc.get("visuals") or []
                       if str(d.get("visual_id")) == args.visual_id), None)
        if item is None or design is None:
            print(json.dumps({"ok": False, "message": "找不到 %s" % args.visual_id},
                             ensure_ascii=False))
            raise SystemExit(1)
        payload = build_review_input(
            visual_id=args.visual_id, sources=item.get("sources") or {},
            plan_item=item, design=design)
        Path(args.output).write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8")
        print(json.dumps({"ok": True, "output": args.output,
                          "review_input_sha256": review_input_sha256(payload),
                          "note": "rationale 不在包里：不读设计理由，"
                                  "不等于不读待核查的设计内容"},
                         ensure_ascii=False, indent=2))
        return

    record = json.loads(Path(args.record).read_text(encoding="utf-8"))
    review_input = json.loads(Path(args.review_input).read_text(encoding="utf-8"))
    verdict = gate(record, review_input_hash=review_input_sha256(review_input),
                   output_sha256=args.output_sha256)
    print(json.dumps(verdict, ensure_ascii=False, indent=2))
    raise SystemExit(0 if verdict["ok"] else 1)


if __name__ == "__main__":
    main()
