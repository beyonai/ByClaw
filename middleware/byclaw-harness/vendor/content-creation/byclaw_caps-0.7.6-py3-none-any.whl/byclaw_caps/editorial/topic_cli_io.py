"""Small JSON CLI helpers shared by deterministic topic scripts."""

from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Any

try:
    from byclaw_caps.space import (
        SessionPathError,
        assert_within_session,
        resolve_session_root,
    )
except ImportError:  # direct script execution
    from byclaw_caps.space import (  # type: ignore
        SessionPathError,
        assert_within_session,
        resolve_session_root,
    )


def _argv_value(flag: str) -> str | None:
    """从 argv 取一个开关的值；这些脚本走位置参数 + 少量开关，不用 argparse。"""
    if flag not in sys.argv:
        return None
    index = sys.argv.index(flag)
    if index + 1 >= len(sys.argv):
        raise ValueError(f"{flag} 缺少值")
    return sys.argv[index + 1]


def read_json() -> Any:
    if len(sys.argv) > 2 and sys.argv[1] == "--input":
        return json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
    if len(sys.argv) > 1:
        raw = sys.argv[1]
    else:
        # **stdin 也要强成 UTF-8。** Windows 下子进程按系统编码
        # （GBK）解 stdin，中文 JSON 会被解成**游离代理字符**，
        # 后面一写文件就炸 `surrogates not allowed`——
        # 而报错里只有一串编码名，**看不出是输入坏了**。
        # 此前只修了 stdout（`_force_utf8_stdout`），漏了这一半。
        reconfigure = getattr(sys.stdin, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8")
            except (ValueError, OSError):
                pass
        raw = sys.stdin.read().strip()
    if not raw:
        raise ValueError("缺少 JSON 输入")
    return json.loads(raw)


def _force_utf8_stdout() -> None:
    """把 stdout 强制成 UTF-8。

    回执里有 `⚠` 这类字符，而 Windows 控制台默认 GBK——
    `print` 会抛 `UnicodeEncodeError`，**脚本以退出码 1 死掉且 stdout 为空**。
    调用方看到的是「脚本失败」，而校验本身其实跑完了、结果也是对的。
    """
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8")
            except (ValueError, OSError):
                pass


def write_json(value: Any) -> None:
    rendered = json.dumps(value, ensure_ascii=False, indent=2)
    if "--result-file" in sys.argv:
        index = sys.argv.index("--result-file")
        if index + 1 >= len(sys.argv):
            raise ValueError("--result-file 缺少路径")
        # 结果文件不经工作流分配，因此必须在此自行约束：
        # 相对文件名会落到当前工作目录（即工作区），所以 Session Root 必填。
        try:
            session_root = resolve_session_root(_argv_value("--session-root"))
            resolved = assert_within_session(
                str(sys.argv[index + 1]).replace("\\", "/"), session_root
            )
        except SessionPathError as exc:
            # 守卫失败也要输出稳定 JSON，调用方需要能解析。
            print(json.dumps({
                "ok": False,
                "error_code": "session_path_rejected",
                "message": str(exc),
            }, ensure_ascii=False))
            raise SystemExit(2) from None
        output_path = Path(str(resolved))
        output_path.parent.mkdir(parents=True, exist_ok=True)
        temporary_path = output_path.with_suffix(output_path.suffix + ".tmp")
        temporary_path.write_text(rendered + "\n", encoding="utf-8")
        temporary_path.replace(output_path)
        print(json.dumps({
            "ok": bool(value.get("ok", True)) if isinstance(value, dict) else True,
            "result_file": str(output_path.resolve()),
        }, ensure_ascii=False))
        return
    _force_utf8_stdout()
    print(rendered)
