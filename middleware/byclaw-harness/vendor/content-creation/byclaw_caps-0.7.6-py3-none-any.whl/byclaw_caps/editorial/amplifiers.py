#!/usr/bin/env python3
"""强度词词表 —— **两个校验器共用这一份，不要各自手写。**

原来 `validate_article.py` 与 `validate_article_plan.py` 各存一份，于是：

- 两份都**漏了 `首发` 与 `重磅`**，而 9 份写法模板的《模板让路》段明写着
  「`首次 / 唯一 / 全部 / 必然 / 彻底 / 首发 / 重磅` 这类词一律需要素材逐字或等价支持」。
  `写法资产/hook/业界首发稀缺钩子` 的 `表达内容` 就是「业界首发」，而选题侧 hook 管道
  已经通了、hook 又正是标题公式——**数据侧尽责写了 `注意事项`，门禁不看**。
- 两份还不一致（大纲侧多 `全部`、`完全自动`），同一个词在两个阶段结论不同。

**差异保留一处，但要写明理由**（见 `PLAN_ONLY_AMPLIFIERS`）：两个阶段扫的**面**不同。
"""

from __future__ import annotations

import re

#: 任何阶段都需要证据的高风险强度词 —— 优先性、排他性、确定性断言。
#:
#: ⚠️ **改这里就是改两个阶段的红线**，加词前先想清楚它在正文散文里会不会大面积误命中。
#: 逃生口是 `ArticlePlan.truth_strength_review.supported_amplifiers`（登记 `term` + 证据），
#: 以及已 `verified` 的 fact check 的 `statement`——**不要靠回执里的免责说明过关**。
RISKY_AMPLIFIERS: tuple[str, ...] = (
    "首次", "第一次", "唯一", "必然", "彻底", "显著", "消灭",
    # 1.16 新增。模板文档一直要求管这两个，两个校验器一直都没管。
    "首发", "重磅",
)

#: 大纲阶段**额外**收紧的两个词。
#:
#: **为什么只在大纲阶段收紧**：大纲侧扫的是标题、摘要、中心判断、claim 这类
#: **短而高风险的字符串**，那里的 `全部` 是范围断言，fail 是对的。
#: 正文侧扫的是**整篇散文**，那里的 `全部` 多半是描述性的
#: （「指标、维度、计算逻辑全部建模到 ontology 上」），所以在正文侧它归
#: `CONTEXTUAL_AMPLIFIERS`（warning 档）。
#:
#: ⛔ **这不是疏漏，是扫描面不同。** 想把两边统一成一样之前，先确认你要的是
#: 「正文里每个『全部』都 fail」——那会把描述性表述也拦下来。
PLAN_ONLY_AMPLIFIERS: tuple[str, ...] = ("全部", "完全自动")

#: 正文阶段需要结合语境复核的范围／机制词 —— warning 档，不阻断。
CONTEXTUAL_AMPLIFIERS: tuple[str, ...] = ("全部", "任何", "自动")


#: `首次` / `第一次` 的**序数叙述**用法 —— 降为 warning，不算 failure。
#:
#: 门禁要防的是**优先性主张**（「业界首次实现」「首次公开」），
#: 而「第一次问它业务问题就会撞墙」说的是**读者自己的第一次**，没有任何优先性断言。
#:
#: **实测连续两次因为这个改措辞去迁就校验器**：
#:   1524 那篇把「第一次接入」改掉；1914 那篇把「第一次问它业务问题」改成「头一回」——
#: 交付稿里现在留着「头一回」这个更口语的词，**是校验器改的，不是作者选的**。
#: 而这两处都没有证据可登记（序数用法本来就不需要证据），`supported_amplifiers`
#: 这个逃生口在这里不成立。
#:
#: 判据只看**紧跟其后的动词**，不看主语：
#:   「第一次**问**／**用**／**试**」= 个人经历 → 序数
#:   「首次**实现**／**公开**／**发布**」= 优先性主张 → 照旧 failure
#: ⛔ **不要改成看主语**（「我们首次实现」里「我们」是人称，却是实打实的优先性主张）。
ORDINAL_EXPERIENCE_VERBS: tuple[str, ...] = (
    "问", "用", "试", "接触", "打开", "登录", "见", "听", "看", "上手",
    "点开", "体验", "装", "跑", "读", "碰",
)

#: `(首次|第一次)` + 可选的一两个虚词 + 经历类动词。
ORDINAL_EXPERIENCE_RE = re.compile(
    r"(?:首次|第一次)\s*(?:地|去|来)?\s*(?:" + "|".join(ORDINAL_EXPERIENCE_VERBS) + r")"
)


#: 序数「兄弟」——同段出现它们，说明 `第一次` 在数次数，不在宣示优先性。
#: 这是第二条**独立**信号：「第一次接入之后，第二次就顺了」里 `接入` 不在经历动词表内
#: （而且「首次接入某能力」确实可能是优先性主张，不该靠扩动词表放行），
#: 但同段的「第二次」把它钉死成序数。
ORDINAL_SIBLING_RE = re.compile(r"第[二三四五六七八九十]次|第[2-9]次|下一次|上一次|又一次")


def is_ordinal_usage(window: str) -> bool:
    """`首次` / `第一次` 在这段文字里是不是**序数叙述**（而非优先性主张）。

    两条信号任一成立即算序数：
      ① 紧跟经历类动词（`第一次问`／`用`／`试`…）
      ② 同段出现序数兄弟（`第二次`／`下一次`…）

    ⚠️ **两条都只看局部**，所以传进来的 `window` 应该是**出现处所在的那一段**，
    不是整篇正文——整篇里随便哪儿有个「第二次」就放行，等于没有门禁。
    """
    if ORDINAL_EXPERIENCE_RE.search(window):
        return True
    return bool(ORDINAL_SIBLING_RE.search(window))


#: 大纲阶段实际使用的完整词表。
PLAN_AMPLIFIERS: tuple[str, ...] = RISKY_AMPLIFIERS + PLAN_ONLY_AMPLIFIERS


__all__ = [
    "ORDINAL_EXPERIENCE_RE",
    "ORDINAL_SIBLING_RE",
    "is_ordinal_usage",
    "ORDINAL_EXPERIENCE_VERBS",
    "RISKY_AMPLIFIERS",
    "PLAN_ONLY_AMPLIFIERS",
    "PLAN_AMPLIFIERS",
    "CONTEXTUAL_AMPLIFIERS",
]
