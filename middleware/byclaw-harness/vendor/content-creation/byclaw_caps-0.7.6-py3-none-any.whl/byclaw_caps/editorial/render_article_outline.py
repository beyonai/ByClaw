#!/usr/bin/env python3
"""Render the human ArticleOutline deterministically from an ArticlePlan YAML."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
from typing import Any

try:
    import yaml
except ImportError as exc:  # pragma: no cover - environment failure
    raise SystemExit("PyYAML is required to render ArticlePlan YAML") from exc


UNIT_LABELS = {
    "chinese_characters": "可见正文字符",
    "words": "英文单词",
}

LABELS = {
    "ready": "大纲已就绪", "needs_revision": "需要修订",
    "needs_fact_verification": "需要事实核验", "blocked": "已阻断",
    "pending_article": "等待正文或发布资产", "not_started": "尚未开始", "not_run": "尚未校验",
    "pass": "通过", "fail": "未通过", "defined": "已确定",
    "not_applicable": "不适用", "unresolved": "待补充",
    "qualitative": "定性指标", "official_fact": "官方事实",
    "source_synthesis": "来源综合", "author_inference": "作者分析",
    "communication_metaphor": "传播隐喻", "roadmap": "路线图",
    "required_before_drafting": "正文前必须核验",
    "required_before_publication": "发布前必须核验",
    "front_light_core_heavy_end_light": "轻开头、重核心、轻结尾",
    "case_led": "案例驱动", "progressive_tutorial": "递进教程",
    "argument_counterargument": "正反论证", "narrative_arc": "叙事弧",
    "comparison": "对比评测", "list_based": "清单结构", "custom": "自定义结构",
    "opening": "开头", "core_proof": "核心证明",
    "counterargument": "反方与边界", "conclusion": "结尾",
}


COVER_HOOK_LABELS = {
    "cost_reveal": "亮代价",
    "contrast": "前后对撞",
    "question": "读者原话",
    "counter_intuition": "反直觉",
}


def scalar(value: Any, empty: str = "未定义") -> str:
    if value is None or value == "":
        return empty
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        return "；".join(scalar(item, "") for item in value if item not in (None, "")) or empty
    if isinstance(value, dict):
        return "；".join(f"{key}：{scalar(item, '')}" for key, item in value.items()) or empty
    return str(value).strip() or empty


def human_label(value: Any, empty: str = "未定义") -> str:
    raw = scalar(value, empty)
    return LABELS.get(raw, raw)


def cell(value: Any) -> str:
    return scalar(value).replace("|", "\\|").replace("\r", " ").replace("\n", " ")


def compact_cell(value: Any, limit: int = 56) -> str:
    """Keep summary tables scannable while full text remains in section cards."""
    text = cell(value)
    if len(text) <= limit:
        return text
    for punctuation in ("。", "；"):
        position = text.find(punctuation, 18, limit + 1)
        if position != -1:
            return text[: position + 1]
    soft_break = max(text.rfind(mark, 24, limit) for mark in ("，", "、", " "))
    if soft_break != -1:
        return text[:soft_break].rstrip("，、；。 ") + "…"
    return text[: limit - 1].rstrip("，、；。 ") + "…"


def percent(value: Any) -> str:
    try:
        return f"{float(value):.1%}"
    except (TypeError, ValueError):
        return "未计算"


def bullets(items: Any, empty: str = "- 无") -> str:
    if not items:
        return empty
    if not isinstance(items, list):
        items = [items]
    return "\n".join(f"- {scalar(item)}" for item in items)


def append_labeled_list(lines: list[str], title: str, items: Any, empty: str = "无") -> None:
    """Append a readable label followed by one item per line.

    **前面必须留一个空行。** 上一块常是表格，Markdown 里表格与紧随其后的列表
    之间没有空行时，列表会被当成表格的一部分渲染——看到的是一行乱码似的管道符。
    """
    if lines and lines[-1].strip():
        lines.append("")
    # 四级标题：它属于上一个章节，做成标题才看得出归属，也才进得了目录。
    lines.append(f"#### {title}")
    lines.append("")
    if not items:
        lines.append(f"- {empty}")
        return
    if not isinstance(items, list):
        items = [items]
    lines.extend(f"- {scalar(item)}" for item in items)


def numbered(items: Any, empty: str = "1. 无") -> str:
    if not items:
        return empty
    if not isinstance(items, list):
        items = [items]
    return "\n".join(f"{index}. {scalar(item)}" for index, item in enumerate(items, 1))


def material_line(label: str, item: dict[str, Any]) -> str:
    items = item.get("items")
    item_text = scalar(items) if items else "无"
    handling = scalar(item.get("handling"), "未说明")
    return f"- **{label}（{human_label(item.get('status'))}）：** {item_text}；处理方式：{handling}"


def renumber(text: str) -> str:
    """给所有二到四级标题打上层级序号：`## 1.` / `### 1.1` / `#### 1.1.1`。

    **序号由这里算，不由写的人手填。** 手填的号在删掉一节之后永远不会有人
    回来重排，而读的人看到 1、2、4 会以为漏发了一段。

    放在最后统一走一遍，还有一个好处：**以后新加的标题自动带号**，
    不用记得去改编号逻辑。H1 是文档标题，不参与编号。
    """
    counters = [0, 0, 0]
    out = []
    for line in text.split("\n"):
        marks = len(line) - len(line.lstrip("#"))
        if 2 <= marks <= 4 and line[marks:marks + 1] == " ":
            level = marks - 1
            counters[level - 1] += 1
            for deeper in range(level, len(counters)):
                counters[deeper] = 0
            number = ".".join(str(n) for n in counters[:level])
            # 一级补尾点：`## 1.` 与 `### 1.1` 并排时才像同一套编号。
            # 二级以下不补——`1.1.` 末尾那个点会被读成「还有一层」。
            if level == 1:
                number += "."
            out.append(f"{'#' * marks} {number} {line[marks + 1:].strip()}")
        else:
            out.append(line)
    return "\n".join(out)


def render_story(plan: dict[str, Any], source_name: str) -> str:
    """Render scene decisions rather than asking stories to prove a thesis."""
    story = plan.get("story_plan") or {}
    narrative = plan.get("narrative_plan") or {}
    distribution = plan.get("distribution_plan") or {}
    length = plan.get("length_plan") or {}
    unit = UNIT_LABELS.get(length.get("length_unit"), scalar(length.get("length_unit")))
    readiness = plan.get("readiness") or {}
    contract = plan.get("contract_validation") or {}
    truth_labels = {"real_case": "真实案例", "adapted_case": "改编案例", "fictional_scenario": "虚构情境"}
    kind = "故事型营销" if plan.get("content_kind") == "story_marketing" else "短篇小说"
    lines = [f"# {scalar(distribution.get('final_title'), scalar(plan.get('topic_id')))}", "",
             f"**{kind} · {truth_labels.get(plan.get('truth_mode'), '真实性待明确')}**", "",
             "| 审稿状态 | 结果 |", "|---|---|",
             f"| 契约校验 | {human_label(contract.get('status'), '尚未校验')} |",
             f"| 大纲 | {human_label(readiness.get('outline_status'))} |",
             f"| 正文起草 | {human_label(readiness.get('drafting_status'))} |",
             f"| 发布 | {human_label(readiness.get('publication_status'))} |", ""]
    if contract.get("status") == "fail" or contract.get("failures"):
        lines += ["**校验未通过，以下问题修复前不可进入正文：**", "",
                  bullets(contract.get("failures"), "- 未提供具体失败原因，请重新运行计划校验。"), ""]
    if readiness.get("summary"):
        lines += [scalar(readiness["summary"]), ""]
    lines += ["## 故事方向", "", "| 项目 | 设计 |", "|---|---|"]
    for label, field in (("写法", "style"), ("视角", "viewpoint"), ("人物目标", "protagonist_goal"),
                         ("主要冲突", "central_conflict"), ("结尾意图", "ending_intent")):
        lines.append(f"| {label} | {cell(story.get(field))} |")
    if story.get("disclosure"):
        lines.append(f"| 真实性说明安排（按需） | {cell(story['disclosure'])} |")
    lines += ["", f"目标篇幅：{scalar(length.get('target_total'))} {unit}；场景标题可以只供内部规划使用。", "",
              "## 场景安排", ""]
    for index, section in enumerate(narrative.get("sections") or [], 1):
        lines += [f"### {scalar(section.get('heading'), '场景 ' + str(index))}", "",
                  f"预计 {scalar(section.get('target_length'))} {unit}。", ""]
        if section.get("section_kind", "scene") == "scene":
            scene = section.get("scene") or {}
            for label, field in (("目标", "goal"), ("阻力", "obstacle"), ("行动", "action"), ("变化", "change")):
                lines.append(f"- **{label}：** {scalar(scene.get(field))}")
        else:
            lines += [f"- **说明任务：** {scalar(section.get('section_judgment'))}",
                      f"- **依据：** {scalar(section.get('evidence_summary'))}"]
        if section.get("transition_to_next"):
            lines.append(f"- **衔接：** {scalar(section.get('transition_to_next'))}")
        lines.append("")
    marketing = plan.get("marketing_plan") or {}
    if plan.get("content_kind") == "story_marketing":
        lines += ["## 产品与转化", ""]
        for label, field in (("读者问题", "reader_problem"), ("产品作用", "product_role"),
                             ("出场契机", "introduction_trigger"), ("转化目标", "conversion_goal"),
                             ("行动入口", "cta"), ("优惠与条件", "offer_terms")):
            lines.append(f"- **{label}：** {scalar(marketing.get(field))}")
        lines += ["", "### 需要证据支持的主张", ""]
        evidence = {item.get("evidence_id"): item for item in plan.get("evidence_pool") or []
                    if isinstance(item, dict)}
        for claim in (plan.get("argument_plan") or {}).get("supporting_claims") or []:
            sources = []
            for ref in claim.get("evidence_refs") or []:
                item = evidence.get(ref) or {}
                sources.append(item.get("source") or item.get("claim") or f"待补资料出处（{ref}）")
            lines.append(f"- {scalar(claim.get('statement'))}（依据：{scalar(sources, '待补资料出处')}）")
    lines += ["", "## 分享与呈现", "",
              f"- **分享摘要：** {scalar(distribution.get('digest'))}",
              f"- **呈现理由：** {scalar((distribution.get('presentation') or {}).get('rationale'))}"]
    completeness = plan.get("completeness_review") or {}
    pending = list(completeness.get("unresolved_items") or []) + list(completeness.get("blockers") or [])
    pending += list(plan.get("data_gaps") or [])
    if pending or contract.get("warnings"):
        lines += ["", "## 待处理事项", ""]
        if pending:
            lines += [bullets(pending), ""]
        if contract.get("warnings"):
            lines += ["**校验提醒：**", "", bullets(contract["warnings"]), ""]
    lines += ["", f"结构化源：`{source_name}`", ""]
    return renumber("\n".join(lines))


def render(plan: dict[str, Any], source_name: str) -> str:
    if plan.get("content_kind") in {"story_marketing", "short_fiction"}:
        return render_story(plan, source_name)
    editorial = plan.get("editorial_core") or {}
    reader_value = editorial.get("reader_value") or {}
    audience = plan.get("audience_plan") or {}
    argument = plan.get("argument_plan") or {}
    narrative = plan.get("narrative_plan") or {}
    sections = narrative.get("sections") or []
    readiness = plan.get("readiness") or {}
    contract = plan.get("contract_validation") or {}
    length = plan.get("length_plan") or {}
    calculated = length.get("calculated") or {}
    length_validation = length.get("validation") or {}
    production = plan.get("production_plan") or {}
    distribution = plan.get("distribution_plan") or {}
    title_review = distribution.get("title_review") or {}
    cover_hook = distribution.get("cover_hook") or {}
    logic = plan.get("logic_review") or {}
    truth = plan.get("truth_strength_review") or {}
    completeness = plan.get("completeness_review") or {}
    hook = (plan.get("hook_payoff_map") or {}).get("core_hook") or {}
    unit = UNIT_LABELS.get(length.get("length_unit"), scalar(length.get("length_unit")))
    title = scalar(distribution.get("final_title"), scalar(plan.get("topic_id")))

    lines: list[str] = [
        f"# {title}",
        "",
        "| | |",
        "|---|---|",
        f"| 大纲状态 | {human_label(readiness.get('outline_status'))} |",
        f"| 正文起草 | {human_label(readiness.get('drafting_status'))} |",
        f"| 发布状态 | {human_label(readiness.get('publication_status'))}；资产 {human_label(readiness.get('publication_asset_status'))}，待处理 {scalar(readiness.get('pending_asset_ids'), '无')} |",
        f"| 目标篇幅 | {scalar(length.get('target_total'))} {unit}，建议 {scalar((length.get('allowed_range') or {}).get('min'))}—{scalar((length.get('allowed_range') or {}).get('max'))} {unit} |",
        f"| 篇幅策略 | {human_label(length.get('length_shape'))}——{cell(length.get('selection_reason'))} |",
        "",
        "## 30秒读懂",
        "",
        "| | |",
        "|---|---|",
        f"| 一句话中心观点 | {cell(editorial.get('reader_facing_thesis'))} |",
        f"| 读完能判断 | {cell(reader_value.get('decision_enabled'))} |",
        f"| 读完能行动 | {cell(reader_value.get('action_enabled'))} |",
        f"| 30秒摘要 | {cell(editorial.get('thirty_second_summary'))} |",
        "",
        "### 章节编辑摘要",
        "",
        "| 章节 | 本节判断 | 证据落点 | 篇幅 |",
        "|---|---|---|---:|",
    ]
    for index, section in enumerate(sections, 1):
        lines.append(
            f"| {index}. {cell(section.get('heading'))} | {cell(section.get('section_judgment'))} | "
            f"{compact_cell(section.get('evidence_summary'))} | "
            f"{scalar(section.get('target_length'))} {unit}（{percent(section.get('length_share'))}） |"
        )

    lines.extend(["", "### 中心因果链", ""])
    for item in editorial.get("causal_chain") or []:
        lines.append(f"{scalar(item.get('order'))}. **{scalar(item.get('role'))}：** {scalar(item.get('statement'))}")

    lines.extend([
        "",
        "## 选题与读者",
        "",
        "| | |",
        "|---|---|",
        f"| 目标读者 | {cell(audience.get('primary'))} |",
        f"| 次级读者 | {cell(audience.get('secondary'))} |",
        f"| 读者已经知道 | {cell(audience.get('prior_knowledge'))} |",
        f"| 当前问题 | {cell(audience.get('current_problem'))} |",
        f"| 为什么现在写 | {cell(audience.get('why_now'))} |",
        f"| 认知变化 | {cell(audience.get('cognitive_change'))} |",
        f"| 行动变化 | {cell(audience.get('action_change'))} |",
        "",
        "## 观点与论证",
        "",
        f"**唯一中心判断**：{scalar(argument.get('central_thesis'))}",
        "",
        "### 二级判断",
        "",
    ])
    for claim in argument.get("supporting_claims") or []:
        lines.append(
            f"- **{human_label(claim.get('claim_type'))}：** {scalar(claim.get('statement'))}"
        )
    lines.extend([
        "",
        "### 反方观点",
        "",
        bullets(argument.get("counterpoints")),
        "",
        f"> 为什么需要处理：{scalar(argument.get('counterpoints_reason'))}",
        "",
        "### 本文不解决",
        "",
        bullets(argument.get("non_goals")),
        "",
        "## 叙事与章节",
        "",
        "| | |",
        "|---|---|",
        f"| 写法模板 | {human_label(narrative.get('template_selection'))}"
        f"·{human_label(narrative.get('template_adoption'))}"
        f"——{cell((narrative.get('structure_template') or {}).get('remote_path'))} |",
        f"| 采用说明 | {cell(narrative.get('adoption_notes'))} |",
        f"| 开头策略 | {human_label((narrative.get('opening_strategy') or {}).get('opening_source'))}"
        f"·{human_label((narrative.get('opening_strategy') or {}).get('type'))}"
        f"——{cell((narrative.get('opening_strategy') or {}).get('content'))} |",
        f"| 全文核心问题 | {cell(narrative.get('central_question'))} |",
        f"| 标题兑现 | {cell(narrative.get('title_payoff'))} |",
        f"| 结尾记忆点 | {cell(narrative.get('closing_takeaway'))} |",
        f"| 唯一核心悬念 | {cell(hook.get('question'))} |",
        f"| 悬念 提出→兑现 | {scalar(hook.get('introduced_at'))} → {scalar(hook.get('payoff_at'))} |",
    ])
    for index, section in enumerate(sections, 1):
        rationale = section.get("length_rationale") or {}
        # **每节前一条分隔线。** 五节紧挨着排时扫不出边界。
        # 用 `---` 而不是空行：很多渲染器会把连续空行折成一个。
        lines.extend([
            "",
            "---",
            "",
            f"### {scalar(section.get('heading'))}",
            "",
            f"**{scalar(section.get('target_length'))} {unit}，占 {percent(section.get('length_share'))}**",
            "",
            "| | |",
            "|---|---|",
            f"| 本节判断 | {cell(section.get('section_judgment'))} |",
            f"| 本节任务 | {cell(section.get('purpose'))} |",
            f"| 回答问题 | {cell(section.get('reader_question'))} |",
            f"| 事实与证据 | {cell(section.get('evidence_summary'))} |",
            f"| 如何过渡 | {cell(section.get('transition_to_next'))} |",
            f"| 为什么这个篇幅 | {cell(rationale.get('explanation'))} |",
        ])
        append_labeled_list(lines, "论证展开", section.get("key_points"))
        append_labeled_list(lines, "事实与分析边界", section.get("fact_analysis_boundary"))

    role_shares = calculated.get("role_shares") or {}
    role_share_text = "；".join(f"{human_label(key)} {percent(value)}" for key, value in role_shares.items()) or "未计算"
    exception = length.get("shape_exception") or {}
    material = production.get("material_plan") or {}
    lines.extend([
        "",
        "## 内容生产",
        "",
        "### 篇幅安排",
        "",
        f"- **角色占比：** {role_share_text}",
        f"- **篇幅合计：** 章节 {scalar(calculated.get('section_total'))} + 前置 {scalar(length.get('front_matter_length'), '0')} + 后置 {scalar(length.get('back_matter_length'), '0')} = {scalar(calculated.get('total_with_matter'))} {unit}",
        f"- **最大/最小章节比：** {scalar(calculated.get('section_max_min_ratio'))}",
        f"- **策略例外：** {human_label(exception.get('status'))}；{scalar(exception.get('reason'), '无')}",
        f"- **篇幅校验：** {human_label(length_validation.get('status'))}；违规：{scalar(length_validation.get('violations'), '无')}；警告：{scalar(length_validation.get('warnings'), '无')}",
        "",
        "### 材料计划",
        "",
        material_line("官方资料", material.get("official_sources") or {}),
        material_line("案例", material.get("cases") or {}),
        material_line("数据", material.get("data") or {}),
        material_line("直接引用", material.get("quotes") or {}),
        "",
        "### 配图计划",
        "",
    ])
    for visual in plan.get("visual_plan") or []:
        lines.extend([
            f"- **{scalar(visual.get('visual_goal') or visual.get('type'))}｜{scalar(visual.get('placement'))}**",
            f"  - 理解任务：{scalar(visual.get('understanding_task'))}",
            f"  - 核心信息：{scalar(visual.get('key_message') or visual.get('understanding_task'))}",
            f"  - 依据：{scalar(visual.get('basis'))}",
            f"  - 信息收益：{scalar(visual.get('information_gain'))}",
        ])
    if not plan.get("visual_plan"):
        lines.append(f"- {scalar(plan.get('visual_plan_reason'), '无配图计划')}")

    lines.extend(["", "### 写作前事实核验", ""])
    for check in production.get("fact_checks") or []:
        lines.append(
            f"- **{human_label(check.get('required_stage'))}｜{human_label(check.get('status'))}：** "
            f"{scalar(check.get('statement'))}（来源：{scalar(check.get('verification_source'))}）"
        )
    tone = production.get("tone") or {}
    lines.extend([
        "",
        "### 语气、术语与边界",
        "",
        f"- **语气：** {scalar(tone.get('style'))}",
        f"- **技术密度：** {scalar(tone.get('technical_density'))}",
    ])
    append_labeled_list(lines, "避免", tone.get("avoid"))
    append_labeled_list(lines, "术语", production.get("terminology"))
    append_labeled_list(lines, "表达边界", production.get("expression_boundaries"))
    lines.extend([
        "",
        "## 传播与转化",
        "",
        f"- **标题：** {title}",
        f"- **标题与主旨：** {human_label(title_review.get('thesis_alignment_status'))}——{scalar(title_review.get('thesis_connection'))}",
        f"- **标题传播判断：** {human_label(title_review.get('distribution_strength_status'))}——{scalar(title_review.get('propagation_hook'))}",
        f"- **标题点击价值：** {scalar(title_review.get('reader_value'))}",
        f"- **标题转发理由：** {scalar(title_review.get('sharing_reason'))}",
        f"- **封面文案：** {scalar(distribution.get('cover_copy'))}"
        f"（{COVER_HOOK_LABELS.get(cover_hook.get('hook_type'), '钩子类型未定')}）",
        f"- **封面钩子来源：** {scalar(cover_hook.get('copy_source'))}",
        f"- **封面读者带走：** {scalar(cover_hook.get('reader_takeaway'))}",
        f"- **公众号摘要：** {scalar(distribution.get('summary'))}",
        f"- **首屏钩子：** {scalar(distribution.get('first_screen_hook'))}",
    ])
    lines.extend([
        "",
        "### 留存与转化",
        "",
        f"- **转发理由：** {scalar(distribution.get('sharing_reason'))}",
        f"- **文末行动：** {scalar(distribution.get('closing_action'))}",
    ])
    append_labeled_list(lines, "中段留存点", distribution.get("retention_points"))
    lines.extend([
        "",
        "### 成功指标",
        "",
    ])
    for criterion in distribution.get("success_criteria") or []:
        lines.extend([
            f"- **{human_label(criterion.get('metric_status'))}：** {scalar(criterion.get('criterion'))}",
            f"  - 依据：{scalar(criterion.get('reason'))}",
        ])

    # **未解析项、阻断项、逻辑/事实/契约校验、验收标准都不进这份文档。**
    # 它们是自检回执，已经在 ArticlePlan 里；写进给人读的大纲，
    # 只会把人真正要读的内容往下挤——线上那份 10610 字，
    # 末尾整整一节全是「无」「通过」。
    lines.extend([
        "",
        "---",
        "",
        f"结构化源：`{source_name}`",
        "本文档由结构化 ArticlePlan 确定性渲染；如有冲突以结构化源为准。",
        "未解析项、阻断项、契约校验与验收标准只在 YAML。",
        "",
    ])
    return renumber("\n".join(lines))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="ArticlePlan YAML path")
    parser.add_argument("--output", required=True, help="ArticleOutline Markdown path")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    plan = yaml.safe_load(input_path.read_text(encoding="utf-8"))
    if not isinstance(plan, dict):
        print("ArticlePlan YAML root must be an object", file=sys.stderr)
        return 1
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(render(plan, input_path.name), encoding="utf-8")
    print(str(output_path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
