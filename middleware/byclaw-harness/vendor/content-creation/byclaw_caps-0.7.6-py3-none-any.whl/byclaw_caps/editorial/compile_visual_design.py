#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""二编：把 VisualDesign 编成最终 VisualPlan。

方案《配图语义规划方案.md》§二、§四、§5.4。

**为什么要有这一步。** 一编产出的计划里，形式（骨架、画幅）是按
`visual_goal` + `diagram_subtype` 查表定死的——**在任何人读懂这一节之前**。
出图助理读了正文也改不了，因为渲染只认已编译的那份规格。
于是"理解语义再决定怎么画"这句话在流程里没有落点。

加这一步之后：

    一编（形式留空/给默认） → VisualDesign（助理读正文，选编码、写依据）
    → 二编（校验并编译） → 最终 VisualPlan → 渲染

关键在**二编真的消费 VisualDesign**。只让助理写一份"设计说明"落盘、
渲染仍走一编那份规格，那份文件就是旁路文档：写得再好也不影响产出，
写错了也没人发现。

这里只做**确定性校验**：事实关系有没有依据、`must_cover` 有没有被减、
编码在不在词汇表里、`none_fit` 有没有被当成完成。
"图画得对不对"是语义复核那一步的事（`review_visual.py`），机器判不了。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Mapping

pass  # 包内使用相对导入，避免污染其他兼容入口

from byclaw_caps.shared.visual_semantics import (  # noqa: E402
    build_review_input, review_input_sha256, sha256_text,
)

# 骨架与画幅是**派生**的，不是另一份可以各写一遍的表。
# 从一编那份取——两处各存一张，换编码时必有一处忘了改，
# 而症状是"骨架说 matrix、画幅说 body_std、图却按 composite 画"。
from .compile_article_visual_plan import (  # noqa: E402
    LAYOUT_SIZE_TIER, LAYOUT_SKELETON, resolve_body_size,
)

#: 论证形状 → 视觉编码。**一期不新增骨架**——先验证"把形式选择放到理解之后"
#: 值多少。二期补哪些，由 `none_fit` 的实际分布决定，不是现在拍。
ENCODINGS = {
    "layered": "递进 / 依赖：层 + 方向",
    "comparison": "对立 / 权衡：同构双栏",
    "matrix": "覆盖 / 缺口：行 × 列",
    "nested": "归属 / 包含：真包含",
    "composite": "一节的完整论证：复合面板",
}

#: 现有编码都不合适。**这是待修订，不是失败**，更不是"随便挑一个最近的"。
NONE_FIT = "none_fit"

#: 事实关系：画反了就是事实错误，不是表达效率问题。必须有依据。
FACTUAL_RELATIONS = frozenset({
    "dependency", "causal", "contains", "coverage", "sequence", "negation",
})

#: 排版关系：左右摆放、上下顺序、分组、对齐。不需要依据。
LAYOUT_RELATIONS = frozenset({"beside", "above", "group", "align"})

#: 依据只有两种。`convention` **不是第三种**——「箭头指向被依赖方」解释的是
#: 视觉约定，它不能证明 A 依赖 B。记录有用，所以它独立成 `visual_convention`
#: 字段，但不充当事实依据。
SUPPORT_TYPES = frozenset({"quote", "derived"})

#: 锚点与标签的关系。**三档都不豁免语义复核**——
#: `"支持场景推演" in "不支持场景推演"` 是 True，子串判定放行意思相反的 label。
#: 它的价值是告诉复核者该查什么，不是替复核者放行。
RELATIONS = frozenset({"excerpt", "abbrev", "summary"})


#: 编码名 → 编译器内部的 layout 名。
#:
#: **两套名字是历史遗留，不是设计。** 编码词汇表对外叫 `comparison`
#: （"对立/权衡"读起来就是这个词），而编译器的画幅表沿用早期的 `paired`。
#: 上一轮我直接拿编码名去查那两张表，`LAYOUT_SIZE_TIER.get("comparison", "")`
#: 取到空串、画幅整条分支被跳过——**`layered`/`matrix`/`nested`/`composite`
#: 四个恰好同名所以能换，只有 `comparison` 换不了**，而我验证时偏偏挑的是
#: `matrix → composite`。同名掩盖了不同名，这就是不能用 `.get(x, 默认)` 的理由：
#: 查不到时它给一个看起来合理的值，而不是喊出来。
ENCODING_TO_LAYOUT = {
    "layered": "layered",
    "comparison": "paired",
    "matrix": "matrix",
    "nested": "nested",
    "composite": "composite",
}


def _layout_name(encoding: str) -> str:
    """编码名翻成 layout 名。**查不到就抛**，不给默认值。"""
    try:
        return ENCODING_TO_LAYOUT[encoding]
    except KeyError:
        raise DesignError(
            "UNMAPPED_ENCODING",
            f"编码 {encoding!r} 没有对应的 layout 名。"
            "新增编码时 ENCODING_TO_LAYOUT、LAYOUT_SKELETON、LAYOUT_SIZE_TIER "
            "三张表要一起加——漏一张的症状是画幅悄悄不换，没有任何报错。"
        ) from None


class DesignError(ValueError):
    def __init__(self, code: str, message: str, **detail: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.detail = detail


def _fail(code: str, message: str, **detail: Any) -> None:
    raise DesignError(code, message, **detail)


def _check_support(visual_id: str, relation: Mapping[str, Any],
                   errors: list[str]) -> None:
    """事实关系必须有依据，且依据只有 quote / derived 两种。"""
    kind = str(relation.get("kind") or "").strip()
    label = str(relation.get("label") or "")
    if kind in LAYOUT_RELATIONS:
        return
    if kind not in FACTUAL_RELATIONS:
        errors.append(f"{visual_id} 关系 kind 未知：{kind}")
        return
    support = relation.get("support")
    if not isinstance(support, Mapping):
        errors.append(
            f"{visual_id} 的事实关系「{label or kind}」没有 support。"
            "两个节点名都真实，依赖方向仍可能画反——方向画反是事实错误，"
            "不是表达效率问题")
        return
    support_type = str(support.get("type") or "").strip()
    if support_type == "convention":
        errors.append(
            f"{visual_id} 的「{label or kind}」把 convention 当依据了。"
            "视觉约定解释的是怎么画，证明不了 A 依赖 B；"
            "它应写进 visual_convention 字段")
        return
    if support_type not in SUPPORT_TYPES:
        errors.append(f"{visual_id} 的 support.type 只能是 quote / derived，"
                      f"实际：{support_type or '（空）'}")
        return
    if not str(support.get("text") or "").strip():
        errors.append(f"{visual_id} 的 support 缺 text（要能逐字定位）")
    if support_type == "derived" and not str(support.get("derivation") or "").strip():
        errors.append(
            f"{visual_id} 的 derived 关系没写 derivation。"
            "机器只能验证引用的那几句在，验证不了推得对——"
            "推导写出来才能进语义复核")


def _check_anchors(visual_id: str, node: Mapping[str, Any],
                   excerpt: str, errors: list[str], warnings: list[str]) -> None:
    """锚点只证明引用存在，不证明表达正确。

    定位不到就报 `ANCHOR_NOT_FOUND`——**它只表示引用定位失败**，
    可能正文改过、也可能复制串了字。错误码不该越权做"编造事实"的分类。
    """
    anchor = str(node.get("anchor") or "").strip()
    if not anchor:
        return
    if excerpt and anchor not in excerpt:
        errors.append(
            f"{visual_id} 节点 {node.get('id')} 的 anchor 在本节正文里定位不到："
            f"「{anchor[:24]}」")
        return
    relation = str(node.get("relation") or "").strip()
    if relation and relation not in RELATIONS:
        errors.append(f"{visual_id} 节点 {node.get('id')} 的 relation 未知：{relation}")


def _check_must_cover(visual_id: str, design: Mapping[str, Any],
                      must_cover: list[str], errors: list[str]) -> None:
    """`must_cover` 逐条都要在设计里认领。

    **不得放宽成"证明大意即可"**。这是 `must_include` 拆分时最大的风险：
    自动拆会把"必须呈现这些事实"悄悄改成"只要大意"。
    """
    claimed = {str(item).strip() for item in (design.get("covers") or [])}
    missing = [item for item in must_cover if item not in claimed]
    if missing:
        errors.append(
            f"{visual_id} 的 must_cover 有 {len(missing)} 条没在设计里认领："
            f"{missing[0][:24]}…。这些是必须呈现的事实，不能减")


#: 封面：不论证任何东西，编码词汇表对它不适用。
COVER_ROLES = frozenset({"cover"})
COVER_METHODS = frozenset({"cover_composite"})


def _is_cover(item: Mapping[str, Any]) -> bool:
    return (str(item.get("asset_role") or "") in COVER_ROLES
            or str(item.get("generation_method") or "") in COVER_METHODS)


def _visual_record(design: Mapping[str, Any], item: Mapping[str, Any],
                   merged: Mapping[str, Any]) -> dict:
    """这张图的按图粒度记录：设计哈希、依赖、复核输入哈希。

    **封面与正文图用同一份**——豁免的是编码，不是留痕与复核。
    """
    sources = item.get("sources") or {}
    payload = json.dumps(design, sort_keys=True, ensure_ascii=False,
                         separators=(",", ":"))
    return {
        "design_sha256": sha256_text(payload),
        "depends_on": (sources.get("depends_on") or {}),
        "review_input_sha256": review_input_sha256(build_review_input(
            visual_id=str(item.get("asset_id") or ""), sources=sources,
            plan_item=merged, design=design)),
    }


def compile_design(
    stage_one: Mapping[str, Any],
    design_doc: Mapping[str, Any],
) -> dict[str, Any]:
    """一编产物 + VisualDesign → 最终 VisualPlan。

    返回 `{"plan": …, "pending": [...], "warnings": [...]}`。
    `pending` 是 `none_fit` 等待修订的图：**它们不进可交付规格、不登记完成，
    而其他图照常推进**——一张画不出来不该把整批卡住。
    """
    designs = {str(item.get("visual_id") or ""): item
               for item in (design_doc.get("visuals") or [])
               if isinstance(item, Mapping)}
    # **键名是 `items`。** 下游 `init-assets` / `inspect` / `finalize-assets`
    # 全都读 `plan["items"]`——写成别的名字，二编的产物下游一个都读不了，
    # 而它自己的单测照样全绿（只测了本函数，没把输出喂进图片链路）。
    items = [item for item in (stage_one.get("items") or [])
             if isinstance(item, Mapping)]
    if not items:
        _fail("EMPTY_STAGE_ONE", "一编产物里没有资产")

    compiled: list[dict] = []
    pending: list[dict] = []
    warnings: list[str] = []
    errors: list[str] = []
    visuals_record: dict[str, dict] = {}

    for item in items:
        visual_id = str(item.get("asset_id") or item.get("visual_id") or "")
        design = designs.get(visual_id)
        if design is None:
            # **规划不是可选的。** "不给就用默认"是一条 opt-out，
            # 分不清"默认编码是判断出来的"还是"根本没规划"。
            errors.append(
                f"{visual_id} 没有 VisualDesign。新任务必须有显式计划"
                "（选默认编码也要写为什么合适）；存量走兼容路径时"
                "产物须显式标 semantic_planned: false")
            continue

        if _is_cover(item):
            # **封面不走图表编码词汇表。**
            #
            # 那五个编码说的是"这一节的论证是什么形状"；封面不论证任何东西，
            # 它是一句承诺加一张背景，文字层由 `compose_cover.py` 合成。
            #
            # 早先这里对每一项一视同仁，于是封面只有两条路：挑一个无意义的
            # 编码，或者诚实写 `none_fit` 然后**被挂起、永不交付**。
            # 0913 那轮封面拿到 `comparison`，就是被这条规则逼的——
            # 而"挑一个最近的凑上去"正是整套设计要避免的那件事。
            #
            # 封面仍要有设计条目：`covers` 与 `rationale` 照样要留痕，
            # 语义复核也照跑。**豁免的只是编码，不是交代。**
            merged = dict(item)
            merged["semantic_planned"] = True
            merged["rationale"] = str(design.get("rationale") or "")
            if not merged["rationale"]:
                errors.append(f"{visual_id} 是封面，仍要写 rationale（凭什么这么画）")
            _check_must_cover(visual_id, design,
                              [str(x) for x in (item.get("must_cover") or [])],
                              errors)
            compiled.append(merged)
            visuals_record[visual_id] = _visual_record(design, item, merged)
            continue

        encoding = str(design.get("encoding") or "").strip()
        if encoding == NONE_FIT:
            pending.append({
                "visual_id": visual_id,
                "reason": str(design.get("rationale") or "").strip(),
                "missing_encoding": str(design.get("missing_encoding") or "").strip(),
            })
            continue
        if encoding not in ENCODINGS:
            errors.append(
                f"{visual_id} 的 encoding 不在词汇表里：{encoding or '（空）'}。"
                f"可选 {sorted(ENCODINGS)}，都不合适就写 {NONE_FIT}——"
                "**挑一个最近的凑上去**才是要避免的那件事")
            continue
        if not str(design.get("rationale") or "").strip():
            errors.append(f"{visual_id} 选了 {encoding} 但没写 rationale")

        sources = item.get("sources") or {}
        excerpt = str(sources.get("section_excerpt") or "")
        for node in (design.get("nodes") or []):
            if isinstance(node, Mapping):
                _check_anchors(visual_id, node, excerpt, errors, warnings)
        for relation in (design.get("relations") or []):
            if isinstance(relation, Mapping):
                _check_support(visual_id, relation, errors)
        _check_must_cover(visual_id, design,
                          [str(x) for x in (item.get("must_cover") or [])], errors)

        form_hint = [str(x) for x in (item.get("form_hint") or [])]
        if form_hint and encoding not in " ".join(form_hint):
            # 形式建议可换，**换了要写为什么**——这条不是硬失败。
            warnings.append(
                f"{visual_id} 的 form_hint 是「{form_hint[0][:16]}」而选了 {encoding}；"
                "rationale 里要说明为什么换")

        merged = dict(item)
        structure = dict(merged.get("structure") or {})
        structure["layout"] = encoding
        # **换编码必须连带重算骨架与画幅。** 只改 layout 的话，
        # matrix → composite 之后骨架仍指向 matrix、画幅仍是 1280×800，
        # 于是"VisualDesign 控制产出"只控制了一个字段名——
        # 照骨架填的人第一件事还是手改宽高，正是这套改动要消灭的那个动作。
        structure["skeleton"] = LAYOUT_SKELETON[_layout_name(encoding)]
        # **按"给没给"判，不按"给的是不是空"判。**
        # 写成 `if design.get("relations"):` 的话，空列表是假值，
        # 于是"这张图我确认不画任何关系"被当成"这一项我没提"，旧关系原样留着——
        # 而"删掉一条画错的关系"恰恰是二编最常见的用法。
        if "nodes" in design:
            structure["nodes"] = list(design.get("nodes") or [])
        if "relations" in design:
            structure["relations"] = list(design.get("relations") or [])
        merged["structure"] = structure

        if str(merged.get("asset_role") or "body") == "body":
            size_tier = LAYOUT_SIZE_TIER[_layout_name(encoding)]
            merged["body_size_tier"] = size_tier
            width, height = resolve_body_size(size_tier)
            merged["width"], merged["height"] = int(width), int(height)

        # 期望文字随节点走。**不重算的话 inspect 仍按旧节点查**——
        # 画面上写的是新标签，检查却在找一批已经不存在的字，
        # 两边都"通过"而彼此说的不是同一张图。
        labels = [str(node.get("label") or "").strip()
                  for node in (structure.get("nodes") or [])
                  if isinstance(node, Mapping) and str(node.get("label") or "").strip()]
        if labels:
            merged["text"] = labels
        # 数值约束随设计走进最终规格：`inspect` 靠它查"标的倍数与画的长度"。
        # **不声明就不查**——不能凭 DOM 猜哪根线是量尺。
        if "numeric" in design:
            merged["numeric"] = design.get("numeric")
        merged["semantic_planned"] = True
        merged["encoding"] = encoding
        merged["argument_shape"] = str(design.get("argument_shape") or "")
        merged["rationale"] = str(design.get("rationale") or "")
        compiled.append(merged)

        design_payload = json.dumps(design, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":"))
        # 复核输入包的哈希在这里就算好，**门禁不必再去找 VisualDesign**——
        # 也就不会出现"报告绑的是旧设计，而门禁只比了 PNG 哈希"那种放行。
        visuals_record[visual_id] = _visual_record(design, item, merged)

    if errors:
        _fail("DESIGN_REJECTED", "VisualDesign 有 %d 处不合规" % len(errors),
              errors=errors)

    plan = dict(stage_one)
    plan["items"] = compiled
    plan["stage"] = "compiled"
    # 全文指纹保留用于追溯，**不参与失效判定**（§3.2）。
    plan["visuals"] = visuals_record
    plan["document"] = {
        "content_sha256": str(((items[0].get("sources") or {}).get("document") or {})
                              .get("content_sha256") or ""),
        "article_path": str(stage_one.get("article_path") or ""),
        "article_plan_path": str(stage_one.get("article_plan_path") or ""),
    }
    return {"plan": plan, "pending": pending, "warnings": warnings}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="二编：VisualDesign → 最终 VisualPlan")
    parser.add_argument("stage_one", help="一编产出的 visual-plan JSON")
    parser.add_argument("design", help="VisualDesign JSON（30-assets/.meta/visual-design.json）")
    parser.add_argument("output", help="最终 VisualPlan 输出路径")
    args = parser.parse_args()

    stage_one = json.loads(Path(args.stage_one).read_text(encoding="utf-8"))
    design = json.loads(Path(args.design).read_text(encoding="utf-8"))
    try:
        result = compile_design(stage_one, design)
    except DesignError as failure:
        print(json.dumps({"ok": False, "code": failure.code,
                          "message": failure.message, **failure.detail},
                         ensure_ascii=False, indent=2))
        raise SystemExit(1)

    Path(args.output).write_text(
        json.dumps(result["plan"], ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8")
    report = {"ok": True, "output": args.output,
              "compiled": len(result["plan"]["items"]),
              "pending": result["pending"], "warnings": result["warnings"]}
    if result["pending"]:
        report["note"] = (
            "有 %d 张图 encoding=none_fit：保留待办、**不登记完成**，"
            "其余照常推进。它们是二期补哪些骨架的唯一证据来源"
            % len(result["pending"]))
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
