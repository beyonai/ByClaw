#!/usr/bin/env python3
"""Decide which account-level heuristics are supported by the sample size."""

from __future__ import annotations

from typing import Any

from .topic_cli_io import read_json, write_json


def analyze(params: dict[str, Any]) -> dict[str, Any]:
    outputs = params.get("writing_outputs") or []
    if not isinstance(outputs, list):
        raise ValueError("writing_outputs 必须是数组")
    article_count = len(outputs)
    account_min = int(params.get("account_state_min_articles", 5))
    performance_min = int(params.get("performance_feedback_min_articles", 10))
    reviews = params.get("writing_reviews") or []
    if not isinstance(reviews, list):
        raise ValueError("writing_reviews 必须是数组")
    return {
        "ok": True,
        "article_count": article_count,
        "review_count": len(reviews),
        "account_state_enabled": article_count >= account_min,
        "performance_feedback_enabled": article_count >= performance_min,
        "qualitative_review_enabled": bool(reviews),
        "warnings": [] if article_count >= performance_min else [
            f"历史样本仅 {article_count} 篇，低于 {performance_min} 篇；不启用统计性效果反馈"
        ],
    }


if __name__ == "__main__":
    write_json(analyze(read_json()))
