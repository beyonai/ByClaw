from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

import yaml


if sys.version_info < (3, 11):
    raise RuntimeError("write-image-text-post requires Python 3.11 or newer")

try:
    from byclaw_caps.shared.channel_specs import (
        MEDIUM_IMAGE_TEXT_POST,
        ChannelSpecError,
        resolve_channel_size,
    )
except ImportError:  # direct script execution
    from byclaw_caps.shared.channel_specs import (  # type: ignore
        MEDIUM_IMAGE_TEXT_POST,
        ChannelSpecError,
        resolve_channel_size,
    )


PNG_SIGNATURE = bytes([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])


def read_png_size(path: Path) -> tuple[int, int]:
    """从 PNG 的 IHDR 读取宽高；纯标准库，不引入 Pillow。"""
    data = path.read_bytes()[:33]
    if not data.startswith(PNG_SIGNATURE) or data[12:16] != b"IHDR":
        raise ValueError(f"不是合法 PNG，无法读取尺寸：{path.name}")
    width = int.from_bytes(data[16:20], "big")
    height = int.from_bytes(data[20:24], "big")
    if width <= 0 or height <= 0:
        raise ValueError(f"PNG 尺寸非法：{path.name}")
    return width, height


def check_card_sizes(cards: list[Path], channel_ref: Any) -> list[str]:
    """校验每张卡片的画幅等于渠道规范，且全套一致。

    原缺陷是画幅完全没人校验：横版图当竖版贴图，一路走到发布都没被拦。
    """
    errors: list[str] = []
    try:
        # 贴图是独立作品，一律竖版；不得沿用正文配图的横版画幅。
        expected = resolve_channel_size(channel_ref, MEDIUM_IMAGE_TEXT_POST)
    except ChannelSpecError as exc:
        return [str(exc)]

    observed: set[tuple[int, int]] = set()
    for card in cards:
        try:
            size = read_png_size(Path(card))
        except (OSError, ValueError) as exc:
            errors.append(str(exc))
            continue
        observed.add(size)
        if size != expected:
            errors.append(
                f"卡片画幅不符：{Path(card).name} 为 {size[0]}×{size[1]}，"
                f"渠道 {channel_ref} 要求 {expected[0]}×{expected[1]}"
            )
    if len(observed) > 1:
        rendered = "、".join(f"{w}×{h}" for w, h in sorted(observed))
        errors.append(f"同一作品内混用了多种画幅：{rendered}；全套卡片必须一致")
    return errors


def load_document(path: Path) -> dict[str, Any]:
    value = (
        json.loads(path.read_text(encoding="utf-8"))
        if path.suffix.lower() == ".json"
        else yaml.safe_load(path.read_text(encoding="utf-8"))
    )
    if not isinstance(value, dict):
        raise ValueError(f"结构化文件顶层必须是对象：{path}")
    return value


def channel_code(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("code") or value.get("channel_code") or "").strip()
    return str(value or "").strip()


def ordered_pages(post: dict[str, Any]) -> list[dict[str, Any]]:
    cover = post.get("cover")
    cards = post.get("cards")
    result: list[dict[str, Any]] = []
    if isinstance(cover, dict):
        result.append(cover)
    if isinstance(cards, list):
        result.extend(item for item in cards if isinstance(item, dict))
    return result


def _asset_path(asset_manifest: dict[str, Any], asset: dict[str, Any]) -> Path:
    directory = Path(str(asset_manifest.get("asset_directory") or "")).resolve()
    raw = str(asset.get("file_path") or "").strip()
    candidate = Path(raw)
    resolved = candidate.resolve() if candidate.is_absolute() else (directory / candidate).resolve()
    try:
        resolved.relative_to(directory)
    except ValueError as exc:
        raise ValueError(f"图片路径越出 asset_directory：{raw}") from exc
    return resolved


def validate_image_text_post(
    post: dict[str, Any],
    *,
    manifest: dict[str, Any] | None = None,
    image_manifest: dict[str, Any] | None = None,
    root: Path | None = None,
) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    card_paths: list[Path] = []
    if post.get("schema_version") != "1.1":
        errors.append("ImageTextPost.schema_version 必须为 1.1")
    for field in ("post_id", "brief_id", "topic_id", "title"):
        if not str(post.get(field) or "").strip():
            errors.append(f"ImageTextPost.{field} 不能为空")
    revision = post.get("revision")
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
        errors.append("ImageTextPost.revision 必须为正整数")
    if post.get("status") not in {"draft", "final_candidate", "ready"}:
        errors.append("ImageTextPost.status 非法")
    if channel_code(post.get("channel_ref")) == "wechat_public_account" and len(str(post.get("title") or "")) > 32:
        errors.append("微信公众号贴图标题不得超过 32 个字")
    publishing_copy = post.get("publishing_copy")
    if not isinstance(publishing_copy, dict) or not str(
        publishing_copy.get("body") or publishing_copy.get("lead") or ""
    ).strip():
        errors.append("ImageTextPost.publishing_copy 必须包含非空发布配文")

    pages = ordered_pages(post)
    if not 1 <= len(pages) <= 20:
        errors.append("ImageTextPost 图片总数必须为 1—20")
    actual_orders: list[int] = []
    asset_ids: list[str] = []
    page_ids: list[str] = []
    for index, page in enumerate(pages, 1):
        prefix = f"pages[{index}]"
        order = page.get("order")
        if not isinstance(order, int) or isinstance(order, bool):
            errors.append(f"{prefix}.order 必须为整数")
        else:
            actual_orders.append(order)
        for field in ("page_id", "asset_id", "narrative_role", "main_message", "alt_text"):
            if not str(page.get(field) or "").strip():
                errors.append(f"{prefix}.{field} 不能为空")
        asset_ids.append(str(page.get("asset_id") or ""))
        page_ids.append(str(page.get("page_id") or ""))
    if actual_orders != list(range(1, len(pages) + 1)):
        errors.append("ImageTextPost 图片顺序必须从 1 开始连续递增")
    if len(asset_ids) != len(set(asset_ids)):
        errors.append("ImageTextPost.asset_id 不得重复")
    if len(page_ids) != len(set(page_ids)):
        errors.append("ImageTextPost.page_id 不得重复")

    if manifest is not None:
        if manifest.get("schema_version") != "1.0":
            errors.append("ImageTextPostManifest.schema_version 必须为 1.0")
        if manifest.get("post_id") != post.get("post_id"):
            errors.append("ImageTextPostManifest.post_id 与成品不一致")
        if manifest.get("revision") != post.get("revision"):
            errors.append("ImageTextPostManifest.revision 与成品不一致")
        if manifest.get("publication_status") != "ready":
            errors.append("ImageTextPostManifest.publication_status 必须为 ready")
        if manifest.get("visual_asset_status") != "complete":
            errors.append("ImageTextPostManifest.visual_asset_status 必须为 complete")
        if manifest.get("title") != post.get("title"):
            errors.append("ImageTextPostManifest.title 与成品不一致")

    if image_manifest is not None:
        if image_manifest.get("status") != "validated":
            errors.append("ImageAssetManifest.status 必须为 validated")
        assets = [item for item in image_manifest.get("assets", []) if isinstance(item, dict)]
        manifest_ids = [str(item.get("asset_id") or "") for item in assets]
        if manifest_ids != asset_ids:
            errors.append("ImageAssetManifest.assets 必须按贴图顺序精确覆盖全部 asset_id")
        for asset in assets:
            asset_id = str(asset.get("asset_id") or "")
            if asset.get("status") != "validated":
                errors.append(f"图片资产未验证：{asset_id}")
                continue
            try:
                resolved = _asset_path(image_manifest, asset)
            except ValueError as exc:
                errors.append(str(exc))
                continue
            if root is not None:
                try:
                    resolved.relative_to(root.resolve())
                except ValueError:
                    errors.append(f"图片资产不在工作区内：{asset_id}")
                    continue
            if not resolved.is_file() or resolved.stat().st_size <= 0:
                errors.append(f"图片资产不存在或为空：{asset_id}")
            if not re.search(r"\.(?:png|jpe?g|gif|bmp)$", resolved.name, re.IGNORECASE):
                errors.append(f"图片格式不受公众号永久素材支持：{resolved.name}")
            elif resolved.suffix.lower() == ".png":
                card_paths.append(resolved)
    elif manifest is not None and manifest.get("visual_asset_status") == "complete":
        errors.append("visual_asset_status=complete 时必须提供 ImageAssetManifest")

    # 画幅门禁：贴图是竖版独立作品，不能沿用正文配图的横版画幅。
    if card_paths:
        errors.extend(check_card_sizes(card_paths, channel_code(post.get("channel_ref"))))

    return {
        "status": "pass" if not errors else "fail",
        "post_id": post.get("post_id"),
        "revision": post.get("revision"),
        "image_count": len(pages),
        "errors": errors,
        "warnings": warnings,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--post", required=True)
    parser.add_argument("--manifest")
    parser.add_argument("--image-manifest")
    parser.add_argument("--root", default=".")
    parser.add_argument("--output")
    args = parser.parse_args()
    try:
        result = validate_image_text_post(
            load_document(Path(args.post)),
            manifest=load_document(Path(args.manifest)) if args.manifest else None,
            image_manifest=load_document(Path(args.image_manifest)) if args.image_manifest else None,
            root=Path(args.root).resolve(),
        )
    except (OSError, ValueError, yaml.YAMLError, json.JSONDecodeError) as exc:
        result = {"status": "fail", "errors": [str(exc)], "warnings": []}
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8", newline="\n")
    print(text, end="")
    return 0 if result["status"] == "pass" else 2


if __name__ == "__main__":
    sys.exit(main())
