#!/usr/bin/env python3
"""Compile a write-article VisualIntent into a deterministic VisualPlan."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError as exc:  # pragma: no cover - environment failure
    raise SystemExit("PyYAML is required to read ArticlePlan YAML") from exc

try:
    from byclaw_caps.shared.channel_specs import (
        BODY_SIZE_TIERS,
        DEFAULT_BODY_TIER,
        MEDIUM_ARTICLE_BODY,
        MEDIUM_ARTICLE_COVER,
        ChannelSpecError,
        resolve_body_size,
        resolve_channel_size,
    )
    from byclaw_caps.shared.diagram_tokens import (
        delivery_scale_for as _delivery_scale_for,
        global_style as _global_style,
    )
except ImportError:  # direct script execution
    try:
        from byclaw_caps.shared.channel_specs import (  # type: ignore
            BODY_SIZE_TIERS,
            DEFAULT_BODY_TIER,
            MEDIUM_ARTICLE_BODY,
            MEDIUM_ARTICLE_COVER,
            ChannelSpecError,
            resolve_body_size,
            resolve_channel_size,
        )
        from byclaw_caps.shared.diagram_tokens import (  # type: ignore
            delivery_scale_for as _delivery_scale_for,
            global_style as _global_style,
        )
    except ImportError as exc:
        # **这条报错是给部署的人看的，不是给读代码的人看的。**
        #
        # `channel_specs.py` 与 `diagram_tokens.py` 由 `build_skill_zips.py` 在
        # 构建期注入，源码目录 `skills/illustrate-article/` 里**本来就没有**——
        # 它只有 SKILL.md 和两个脚本。所以裸的 ImportError 在这里几乎只有一个含义：
        # 装进运行环境的不是 `dist/skills/illustrate-article.zip`，
        # 而是源码目录，或者是一份新旧混装的包。
        #
        # 2026-09-11 实测：助理拿到裸 ImportError 后花了约 14 次工具调用才摸清
        # 缺了什么，最后放弃编译器、手拼计划、再 grep 源码反推 schema。
        # 报错里说不出"你部署错了东西"，它就只能自己猜。
        raise SystemExit(
            "\n".join([
                f"缺少共享库：{exc.name or exc}",
                "",
                "`channel_specs.py` 与 `diagram_tokens.py` 由 build_skill_zips.py 在构建期",
                "注入 scripts/，源码目录里本来就没有这两个文件。",
                "",
                "**几乎可以肯定是部署内容不对**，按这个顺序查：",
                "  1. 运行环境里 scripts/ 下是否同时有 channel_specs.py 与 diagram_tokens.py",
                "  2. references/article-visual/ 下是否有 diagram-design-system.md 与 skeletons/",
                "  3. 以上缺任意一项：部署的不是完整包。",
                "     正确做法是部署 dist/skills/illustrate-article.zip，",
                "     **不要直接拷 skills/illustrate-article/ 源码目录**。",
                "",
                "本地可用 `python3 build_skill_zips.py --check --skill illustrate-article` 确认构建产物是否最新。",
                "在这之前不要手写 VisualPlan 绕过去——手拼的计划没有画幅推导、",
                "没有 context_digest、也不会被任何校验器认领。",
            ])
        ) from exc


LEGACY_TYPE_MAP = {
    "relationship_diagram": ("relationship", "network"),
    "flow_diagram": ("process", "flowchart"),
    "comparison": ("comparison", "comparison"),
    "data_chart": ("trend", ""),
    "information_graphic": ("structure", "hierarchy"),
    "screenshot": ("evidence_capture", ""),
}
GOAL_OUTPUT_MAP = {
    "relationship": ("diagram", "html_svg"),
    "process": ("diagram", "html_svg"),
    "comparison": ("diagram", "html_svg"),
    "trend": ("chart", "html_svg"),
    "structure": ("diagram", "html_svg"),
    "instruction": ("card", "html_svg"),
    "concept": ("illustration", "ai_image"),
    "scene": ("illustration", "ai_image"),
    "evidence_capture": ("screenshot_reference", "source_asset"),
}
PREFERENCE_METHOD = {
    "deterministic": "html_svg",
    "infographic": "infographic",
    "svg": "svg_file",
    "ai": "ai_image",
    "source": "source_asset",
}
# AntV Infographic、手写 HTML/SVG、独立 .svg 源文件同属确定性渲染：数值只来自输入，
# 由代码绘制，不存在模型编造数字的可能，因此对事实类 visual_goal 三者都放行。
DETERMINISTIC_METHODS = frozenset({"html_svg", "infographic", "svg_file"})
FACTUAL_GOALS = {"relationship", "process", "comparison", "trend", "structure", "instruction"}


from byclaw_caps.shared.visual_semantics import (  # noqa: E402  构建期与源码树同目录
    build_sources, content_sha256 as _content_sha256, evidence_index,
    split_must_include,
)


def _section_excerpt_for(plan: dict[str, Any], article_sections: dict[str, str],
                         section_id: str) -> str:
    """这一节的正文原文。

    与 `_context_digest` 取的是同一段，但**不截断**：截断版给的是"看个大概"，
    而来源快照要给的是"据以判断的那一版"——哈希绑在截断版上，
    正文改在被截掉的那一半里时，依赖判定会说没变。
    """
    section = _section_of(plan, section_id)
    heading = str(section.get("heading") or section.get("title") or "").strip()
    if not heading:
        return ""
    return article_sections.get(_normalise_heading(heading), "")


def _section_heading_for(plan: dict[str, Any], section_id: str) -> str:
    section = _section_of(plan, section_id)
    return str(section.get("heading") or section.get("title") or "").strip()


def _read_yaml(path: Path) -> dict[str, Any]:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"YAML 顶层必须是对象: {path}")
    return value


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _workflow_root(path: Path) -> Path | None:
    for candidate in (path.parent, *path.parents):
        if (candidate / ".workflow-state.yaml").is_file():
            return candidate
    return None


def _source_reference(root: Path, path: Path, artifact_id: str, revision: int) -> dict[str, Any]:
    relative = path.resolve().relative_to(root.resolve()).as_posix()
    return {
        "artifact_id": artifact_id,
        "revision": revision,
        "relative_path": relative,
        "sha256": _sha256(path),
    }


def _article_suffix(article_path: Path) -> str:
    """从文件名取 topic_id。**只在需要自动定位 plan/manifest 时才调用。**

    命名约定 `article-<topic_id>.md` 存在的唯一理由，是在只给了 `--article`
    时能推出同目录的 `article-plan-<topic_id>.yaml` 与 `article-manifest-…`。
    显式传了那两个参数，这个约定就没有任何用处。

    **原先它是无条件的**，于是 SKILL.md 第一步写的
    `--article <会话根>/20-creative/正文.md` 被脚本自己拒了——
    技能的示例命令跑不通。2026-09-11 实测里助理只好把正文与 manifest
    各拷一份到 /tmp 改名，每次配图都要做这两步。
    """
    name = article_path.name
    if not name.startswith("article-") or article_path.suffix.lower() != ".md":
        raise ValueError(
            f"要自动定位 ArticlePlan 与 ArticleManifest，文章文件名得是 "
            f"article-<topic_id>.md，而当前是 {name}。\n"
            "两条路：把文件改成那个名字，或者**显式传 --article-plan 与 "
            "--article-manifest**——显式传了就不需要这个命名约定，"
            "topic_id 直接从 ArticlePlan 里取。")
    suffix = name[len("article-") : -len(".md")]
    if not suffix:
        raise ValueError("文章文件名缺少 topic_id")
    return suffix


#: 章节正文摘录的上限。够画图的人看懂这一节在证明什么，又不至于把整篇文章
#: 塞进 VisualPlan——那会让计划文件本身变得没法读。
SECTION_EXCERPT_LIMIT = 900

_HEADING = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
#: 标题里的装饰与编号：比对时一律剥掉。大纲里写「三个真实项目」，
#: 正文里可能是「## 二、三个真实项目」——按原样比对一个都对不上。
_HEADING_NOISE = re.compile(r"[\s0-9０-９一二三四五六七八九十、．.。\-—－:：|｜*_`#]+")


def _normalise_heading(text: str) -> str:
    return _HEADING_NOISE.sub("", str(text or ""))


def _article_sections(article_path: Path) -> dict[str, str]:
    """正文 Markdown → {归一化标题: 该节正文}。

    **这是「上下文吻合」的唯一来源。** 在此之前，画图的人对文章的全部认知
    就是 `purpose` + `key_message` + `must_include` 三行——它没读过论证链，
    也拿不到正文里那些必须逐字照抄的代码标识与术语，
    于是只能照着两句摘要现编，编出来的图与上下文对不上。
    """
    try:
        lines = article_path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return {}
    sections: dict[str, str] = {}
    current: str | None = None
    buffer: list[str] = []
    in_fence = False
    for line in lines:
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
        match = None if in_fence else _HEADING.match(line)
        if match:
            if current:
                sections[current] = "\n".join(buffer).strip()
            current = _normalise_heading(match.group(2))
            buffer = []
            continue
        if current:
            buffer.append(line)
    if current:
        sections[current] = "\n".join(buffer).strip()
    return sections


def _section_of(plan: dict[str, Any], section_id: str) -> dict[str, Any]:
    for section in ((plan.get("narrative_plan") or {}).get("sections") or []):
        if isinstance(section, dict) and str(section.get("section_id") or "") == section_id:
            return section
    return {}


def _context_digest(
    plan: dict[str, Any],
    article_sections: dict[str, str],
    section_id: str,
    glossary: list[str],
) -> dict[str, Any]:
    """把这张图所在章节的上下文随资产下发。

    **不新增决策权**：这里只搬运已经存在的东西（章节标题、目的、要点、证据说明、
    正文原文），不替调用方判断该画什么。「计划不是画图的人定的」那条边界不受影响。
    """
    section = _section_of(plan, section_id)
    heading = str(section.get("heading") or section.get("title") or "").strip()
    excerpt = article_sections.get(_normalise_heading(heading), "") if heading else ""
    if len(excerpt) > SECTION_EXCERPT_LIMIT:
        excerpt = excerpt[:SECTION_EXCERPT_LIMIT].rstrip() + "……"
    return {
        "section_id": section_id,
        "section_heading": heading,
        "section_purpose": str(section.get("purpose") or "").strip(),
        "reader_question": str(section.get("reader_question") or "").strip(),
        "key_points": _normalize_strings(section.get("key_points"), "key_points", 0),
        "evidence_summary": str(section.get("evidence_summary") or "").strip(),
        "section_excerpt": excerpt,
        #: 图上出现的术语必须逐字取自这里。写「编排层」而正文写「调度层」，
        #: 读者会以为那是两个东西，而没有任何环节会发现。
        "glossary": glossary,
    }


def _glossary(plan: dict[str, Any]) -> list[str]:
    """全篇锁定术语：核心概念 + 各图 must_include 里出现的实体名。"""
    terms: list[str] = []
    for value in (plan.get("key_terms") or plan.get("glossary") or []):
        if isinstance(value, str) and value.strip() and value.strip() not in terms:
            terms.append(value.strip())
    return terms


def _derive_evidence_refs(plan: dict[str, Any], visual_id: str) -> list[str]:
    refs: list[str] = []
    sections = ((plan.get("narrative_plan") or {}).get("sections") or [])
    for section in sections:
        if visual_id not in (section.get("visual_refs") or []):
            continue
        for ref in section.get("evidence_refs") or []:
            if isinstance(ref, str) and ref and ref not in refs:
                refs.append(ref)
    return refs


def _validate_manifest(plan: dict[str, Any], manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    for field in ("article_id", "brief_id", "topic_id"):
        if str(manifest.get(field) or "") != str(plan.get(field) or ""):
            raise ValueError(f"ArticleManifest.{field} 与 ArticlePlan 不一致")
    visuals = [item for item in (plan.get("visual_plan") or []) if isinstance(item, dict)]
    slots = [item for item in (manifest.get("visual_slot_map") or []) if isinstance(item, dict)]
    visual_ids = [str(item.get("visual_id") or "") for item in visuals]
    slot_ids = [str(item.get("visual_id") or "") for item in slots]
    if slot_ids != visual_ids:
        raise ValueError("ArticleManifest.visual_slot_map 必须按顺序覆盖 ArticlePlan.visual_plan")
    return {str(item["visual_id"]): item for item in slots}


def _normalize_strings(value: Any, field: str, index: int) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise ValueError(f"visual_plan[{index}].{field} 必须为字符串数组")
    return [item.strip() for item in value if item.strip()]


def _resolve_goal(item: dict[str, Any], index: int, warnings: list[str]) -> tuple[str, str]:
    goal = str(item.get("visual_goal") or "").strip()
    subtype = str(item.get("diagram_subtype") or "").strip()
    if goal:
        if goal not in GOAL_OUTPUT_MAP:
            raise ValueError(f"visual_plan[{index}].visual_goal 非法: {goal}")
        return goal, subtype
    legacy_type = str(item.get("type") or "").strip()
    mapped = LEGACY_TYPE_MAP.get(legacy_type)
    if not mapped:
        raise ValueError(
            f"visual_plan[{index}] 的旧 type={legacy_type or '<empty>'} 无法安全转换，"
            "请明确 visual_goal"
        )
    warnings.append(f"{item.get('visual_id')} 从旧 type={legacy_type} 推导 visual_goal={mapped[0]}")
    return mapped


#: `structure.layout` 的合法取值。**扁平字符串数组画不出机制**——
#: `must_include` 是 `list[str]`，只能表达「图里要有这几个东西」，
#: 表达不了「它们之间是什么关系」。于是可画的上限就是 N 个方块连上箭头，
#: 而「框套框」「成对反向边」「把不存在的连接画出来」在契约里根本无处声明。
LAYOUTS = frozenset({"layered", "nested", "paired", "radial", "matrix", "composite"})
#: 边的线型即语义：实线 = 实体调用，虚线 = 引用/工具化，negated = 不存在的连接。
EDGE_STYLES = frozenset({"solid", "dashed", "negated"})
ANNOTATION_TYPES = frozenset({"callout", "tip", "highlight_chip"})
#: layout → 骨架。骨架在 references/article-visual/skeletons/ 下。
#:
#: **`paired` 与 `matrix` 原先都指向 `layered`，那是错的**：`layered.html` 是一套
#: 自上而下的层级拓扑加成对箭头，拿它做左右对照表南辕北辙。
#: 2026-09-11 那篇文章要的正是 3 张对照 + 1 张矩阵——**一张都套不上**，
#: 于是助理只能从零手写 HTML，产出的就是没有图标、没有层级色、
#: 卡片下半截空掉的那四张。
LAYOUT_SKELETON = {
    "layered": "layered",
    "paired": "comparison",
    "matrix": "matrix",
    "nested": "nested",
    "radial": "composite",
    "composite": "composite",
}
#: layout → 画幅档。**必须与骨架写死的画布一致**，否则照骨架填的人
#: 第一件事就是手改 body 的宽高——2026-09-11 实测里正是如此：
#: 骨架是 1280×800，而编译器给的是 body_wide 1280×720。
#:
#: `tests/test_diagram_tokens.py` 把这张表与骨架的 `width:..px;height:..px`
#: 绑在一起校验，**不是靠人记得两边一起改**。
#:
#: 没有 `structure`（因而没有 layout）时回落 `DEFAULT_BODY_TIER`，
#: 存量文章的画幅不变。
LAYOUT_SIZE_TIER = {
    "layered": "body_std",
    "paired": "body_std",
    "matrix": "body_std",
    "nested": "body_std",
    "radial": "body_tall",
    "composite": "body_tall",
}
#: `visual_goal` → 默认 layout。**只在 plan 没给 `structure` 时用**，
#: 而且**只派 layout，不伪造 nodes**——图里画什么必须来自计划，编译器不编内容。
#:
#: 它解决的是"该用哪套骨架"这个纯派生的问题。2026-09-11 实测里，
#: `visual_goal=comparison` 的一项因为 plan 没填 `structure`，编译器只给了句告警，
#: 助理反查了四遍源码才确认"编译器不派生 layout"，然后手写 10 个节点回填。
#: **告警说得出"缺什么"，说不出"那该用哪套"——后者是可以算出来的。**
GOAL_DEFAULT_LAYOUT = {
    "comparison": "paired",
    "relationship": "layered",
    "structure": "layered",
    "process": "layered",
    "instruction": "layered",
    "trend": "matrix",
}
#: `diagram_subtype` → layout。**比 `visual_goal` 更具体，所以先查这张表。**
#:
#: subtype 是自由文本（仓库里出现过 `capability_matrix`、`matrix`、`comparison`、
#: `chatgpt_answer_vs_analyst_thinking`、`timeline`…），没法穷举，所以按关键词匹配，
#: **顺序即优先级**：`comparison_matrix` 该是矩阵，所以 matrix 排在 comparison 前面。
#:
#: 2026-09-11 实测：计划里写了 `diagram_subtype=matrix`，而编译器只看
#: `visual_goal=comparison`，推出 `paired` → comparison.html。
#: **计划已经把"这是个矩阵"说清楚了，编译器却没听。** 助理自己换成 matrix.html——
#: 判断是对的，但那是它替编译器补的课。
SUBTYPE_LAYOUT_KEYWORDS = (
    ("matrix", "matrix"),
    ("quadrant", "matrix"),
    ("nest", "nested"),
    ("contain", "nested"),
    ("as_tool", "nested"),
    ("compare", "paired"),
    ("comparison", "paired"),
    ("_vs_", "paired"),
    ("versus", "paired"),
    ("composite", "composite"),
    ("radial", "composite"),
    ("hub", "composite"),
    ("layer", "layered"),
    ("tier", "layered"),
    ("hierarchy", "layered"),
    ("network", "layered"),
    ("flow", "layered"),
    ("process", "layered"),
    ("timeline", "layered"),
    ("sequence", "layered"),
)


def _layout_from(goal: str, subtype: str) -> tuple[str, str]:
    """派生 layout，返回 `(layout, 依据)`。**subtype 优先于 goal。**"""
    key = str(subtype or "").strip().lower()
    if key:
        for keyword, layout in SUBTYPE_LAYOUT_KEYWORDS:
            if keyword in key:
                return layout, f"diagram_subtype={subtype}"
    layout = GOAL_DEFAULT_LAYOUT.get(goal, "")
    return layout, (f"visual_goal={goal}" if layout else "")


def _normalize_structure(source: dict[str, Any], index: int, goal: str, subtype: str,
                         warnings: list[str]) -> dict[str, Any]:
    """校验并归一 `structure`。事实类图缺它只告警不拒绝——存量文章还没有这个字段。"""
    raw = source.get("structure")
    asset_id = source.get("visual_id")
    if raw is None:
        if goal in FACTUAL_GOALS:
            # **派 layout，不派 nodes。** 该用哪套骨架是能从 visual_goal 算出来的，
            # 图里画什么不能——那必须来自计划。告警照旧保留。
            suggested, basis = _layout_from(goal, subtype)
            hint = (f"；按 {basis} 默认用 "
                    f"layout={suggested}（骨架 {LAYOUT_SKELETON[suggested]}.html，"
                    f"画幅 {LAYOUT_SIZE_TIER[suggested]}）" if suggested else "")
            warnings.append(
                f"{asset_id} 没有 structure，只能按 must_include 画成扁平方块；"
                f"要画出机制（嵌套、成对反向边、反事实标注）就得补这个字段{hint}")
            if suggested:
                return {"layout": suggested, "nodes": [], "edges": [],
                        "skeleton": LAYOUT_SKELETON[suggested], "derived": True}
        return {}
    if not isinstance(raw, dict):
        raise ValueError(f"visual_plan[{index}].structure 必须是对象")
    layout = str(raw.get("layout") or "").strip()
    if layout not in LAYOUTS:
        raise ValueError(
            f"visual_plan[{index}].structure.layout 非法：{layout or '<empty>'}。"
            f"必须是 {'、'.join(sorted(LAYOUTS))} 之一")
    nodes: list[dict[str, Any]] = []
    ids: set[str] = set()
    for position, node in enumerate(raw.get("nodes") or [], 1):
        if not isinstance(node, dict):
            raise ValueError(f"visual_plan[{index}].structure.nodes[{position}] 必须是对象")
        node_id = str(node.get("id") or "").strip()
        label = str(node.get("label") or "").strip()
        if not node_id or not label:
            raise ValueError(
                f"visual_plan[{index}].structure.nodes[{position}] 缺少 id 或 label")
        if node_id in ids:
            raise ValueError(f"visual_plan[{index}].structure.nodes[{position}] id 重复：{node_id}")
        ids.add(node_id)
        nodes.append({
            "id": node_id,
            "label": label,
            # 寄存器 2：代码标识／API／英文术语。**深度主要来自这一项**——
            # 读者同时拿到抽象角色和它的实现。必须逐字取自正文或证据原文。
            "identifier": str(node.get("identifier") or "").strip(),
            "tags": _normalize_strings(node.get("tags"), "structure.nodes[].tags", index),
            "tier": int(node.get("tier") or 0) or None,
            # 包含关系：图例 2 的「框套框」靠它，不靠连线
            "contains": _normalize_strings(node.get("contains"), "structure.nodes[].contains", index),
        })
    if not nodes:
        raise ValueError(f"visual_plan[{index}].structure.nodes 不能为空")
    edges: list[dict[str, Any]] = []
    for position, edge in enumerate(raw.get("edges") or [], 1):
        if not isinstance(edge, dict):
            raise ValueError(f"visual_plan[{index}].structure.edges[{position}] 必须是对象")
        style = str(edge.get("style") or "solid").strip()
        if style not in EDGE_STYLES:
            raise ValueError(
                f"visual_plan[{index}].structure.edges[{position}].style 非法：{style}。"
                f"必须是 {'、'.join(sorted(EDGE_STYLES))} 之一")
        for end in ("from", "to"):
            ref = str(edge.get(end) or "").strip()
            if ref not in ids:
                raise ValueError(
                    f"visual_plan[{index}].structure.edges[{position}].{end}={ref or '<empty>'} "
                    "不在 nodes 里。**连到不存在的节点，渲染时那条边会静默消失。**")
        edges.append({
            "from": str(edge["from"]).strip(), "to": str(edge["to"]).strip(),
            "label": str(edge.get("label") or "").strip(), "style": style,
            "paired_with": str(edge.get("paired_with") or "").strip(),
        })
    for node in nodes:
        for child in node["contains"]:
            if child not in ids:
                raise ValueError(
                    f"visual_plan[{index}].structure：{node['id']}.contains 指向不存在的节点 {child}")
    return {"layout": layout, "nodes": nodes, "edges": edges,
            "skeleton": LAYOUT_SKELETON[layout]}


def _normalize_annotations(source: dict[str, Any], index: int,
                           node_ids: set[str]) -> list[dict[str, Any]]:
    """批注层：气泡、提示条、内嵌高亮词条。主结构之外的说明挂这里，不塞进节点。"""
    result: list[dict[str, Any]] = []
    for position, item in enumerate(source.get("annotations") or [], 1):
        if not isinstance(item, dict):
            raise ValueError(f"visual_plan[{index}].annotations[{position}] 必须是对象")
        kind = str(item.get("type") or "").strip()
        if kind not in ANNOTATION_TYPES:
            raise ValueError(
                f"visual_plan[{index}].annotations[{position}].type 非法：{kind or '<empty>'}。"
                f"必须是 {'、'.join(sorted(ANNOTATION_TYPES))} 之一")
        anchor = str(item.get("anchor") or "").strip()
        if anchor and node_ids and anchor not in node_ids:
            raise ValueError(
                f"visual_plan[{index}].annotations[{position}].anchor={anchor} 不在 structure.nodes 里")
        lines = _normalize_strings(item.get("lines"), "annotations[].lines", index)
        if not lines:
            raise ValueError(f"visual_plan[{index}].annotations[{position}].lines 不能为空")
        result.append({"type": kind, "anchor": anchor, "lines": lines})
    return result


def _resolve_method(goal: str, preference: str, index: int) -> str:
    default_method = GOAL_OUTPUT_MAP[goal][1]
    if preference in {"", "auto"}:
        return default_method
    method = PREFERENCE_METHOD.get(preference)
    if not method:
        raise ValueError(f"visual_plan[{index}].render_preference 非法: {preference}")
    if goal in FACTUAL_GOALS and method not in DETERMINISTIC_METHODS:
        raise ValueError(
            f"visual_plan[{index}] 的事实结构图必须使用确定性渲染"
            "（deterministic/html_svg、infographic 或 svg）"
        )
    if goal in {"concept", "scene"} and method != "ai_image":
        raise ValueError(f"visual_plan[{index}] 的概念或场景图必须使用 ai/ai_image")
    if goal == "evidence_capture" and method != "source_asset":
        raise ValueError(f"visual_plan[{index}] 的界面证据必须使用 source/source_asset")
    return method


#: 两张图内容重合到这个比例就告警。取 0.6 是因为对照图与总览图天然会共享
#: 两三个实体名，那是正常的；共享到六成以上就该问"为什么要两张"。
VISUAL_OVERLAP_THRESHOLD = 0.6
#: 少于三项时比例没有意义（两项里重合一项就是 50%），不参与比较。
VISUAL_OVERLAP_MIN_ITEMS = 3


def _content_tokens(item: dict[str, Any]) -> set[str]:
    """一张图"画了哪些东西"的粗略指纹：节点主名 + must_keep。"""
    tokens = {
        str(node.get("label") or "").strip()
        for node in ((item.get("structure") or {}).get("nodes") or [])
    }
    tokens |= {str(value).strip() for value in (item.get("must_keep") or [])}
    return {token for token in tokens if token}


def _warn_overlapping_visuals(items: list[dict[str, Any]], warnings: list[str]) -> None:
    """两张正文图内容高度重合时告警。

    **没有任何环节比较过两张图之间的重叠。** `information_gain` 是逐图填的，
    每一张单看都说得出"我比文字多给了什么"，合起来却可能是一张的真子集。

    2026-09-11 实测：visual-001（三层阶梯）的三个主名与副标，
    在 visual-002（对照表）的行头与"这一层在做什么"列里全都有——
    **前者是后者的真子集**，只多了两个"依赖"箭头。
    两张图各自的 `information_gain` 都填得很像样，没人看出重复。

    只告警，不拒绝：要不要两张是**上游的判断**，这里只负责让它被看见。
    """
    body = [item for item in items if item.get("asset_role") == "body"]
    for left, right in ((a, b) for i, a in enumerate(body) for b in body[i + 1:]):
        a_tokens, b_tokens = _content_tokens(left), _content_tokens(right)
        smaller = min(len(a_tokens), len(b_tokens))
        if smaller < VISUAL_OVERLAP_MIN_ITEMS:
            continue
        shared = a_tokens & b_tokens
        ratio = len(shared) / smaller
        if ratio < VISUAL_OVERLAP_THRESHOLD:
            continue
        subset = "；前者的内容是后者的子集" if a_tokens <= b_tokens else (
            "；后者的内容是前者的子集" if b_tokens <= a_tokens else "")
        warnings.append(
            f"{left['asset_id']} 与 {right['asset_id']} 内容重合 {ratio:.0%}"
            f"（{'、'.join(sorted(shared)[:5])}）{subset}——"
            "回去确认两张图的 information_gain 是不是同一件事，"
            "**能合成一张就不要出两张**")


def compile_plan(
    article_plan: dict[str, Any],
    *,
    article_manifest: dict[str, Any],
    article_path: Path,
    channel_ref: str,
    asset_directory: Path,
    style_id: str = "editorial",
    workflow: dict[str, Any] | None = None,
    source_artifacts: list[dict[str, Any]] | None = None,
    article_plan_path: Path | None = None,
) -> dict[str, Any]:
    if article_plan.get("visual_plan_status") != "defined":
        raise ValueError("ArticlePlan.visual_plan_status 必须为 defined")
    visuals = article_plan.get("visual_plan") or []
    if not isinstance(visuals, list) or not visuals:
        raise ValueError("ArticlePlan.visual_plan 必须是非空数组")
    topic_id = str(article_plan.get("topic_id") or "").strip()
    brief_id = str(article_plan.get("brief_id") or "").strip()
    article_id = str(article_plan.get("article_id") or "").strip()
    if not all((topic_id, brief_id, article_id)):
        raise ValueError("ArticlePlan 缺少 article_id、brief_id 或 topic_id")

    slot_by_id = _validate_manifest(article_plan, article_manifest)
    # 证据原文与语义内容哈希：两者都要在进循环前备好，
    # 每张图各取自己那一份（按图粒度，不按全文）。
    evidence_lookup = evidence_index(article_plan)
    try:
        article_content_sha256 = _content_sha256(
            article_path.read_text(encoding="utf-8"))
    except OSError:
        article_content_sha256 = ""
    # 画幅来自单一事实来源；未登记渠道硬失败，不再静默回落到正文配图横版。
    # 贴图走 write-image-text-post，画幅不同，不由本编译器负责。
    #
    # **按 asset_role 逐项解析，不能在循环外定一个给所有图用。** 封面是信息流首图，
    # 2.35:1；正文配图嵌在文中，16:9。原先所有资产共用 article_body 一档，
    # 封面拿到 16:9 后上下各被裁掉约 15%，而封面文案正压在这两条带上。
    role_sizes = {
        "cover": resolve_channel_size(channel_ref, MEDIUM_ARTICLE_COVER),
        "body": resolve_channel_size(channel_ref, MEDIUM_ARTICLE_BODY),
    }
    # 正文正文与术语表只读一次，供所有资产共用。
    article_sections = _article_sections(article_path)
    glossary = _glossary(article_plan)
    distribution = article_plan.get("distribution_plan") or {}
    cover_copy = str(distribution.get("cover_copy") or "").strip()
    cover_hook = distribution.get("cover_hook") or {}
    has_cover = any(
        isinstance(item, dict) and item.get("asset_role") == "cover" for item in visuals
    )
    if has_cover and distribution.get("cover_copy_status") == "defined" and not cover_copy:
        raise ValueError(
            "visual_plan 有封面且 cover_copy_status=defined，但 cover_copy 为空——"
            "封面文案要印在图上，空文案等于放弃信息流里的一次触达"
        )

    warnings: list[str] = []
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, source in enumerate(visuals, 1):
        if not isinstance(source, dict):
            raise ValueError(f"visual_plan[{index}] 必须是对象")
        asset_id = str(source.get("visual_id") or "").strip()
        if not asset_id or asset_id in seen:
            raise ValueError(f"visual_plan[{index}].visual_id 缺失或重复")
        seen.add(asset_id)
        goal, subtype = _resolve_goal(source, index, warnings)
        content_type, _ = GOAL_OUTPUT_MAP[goal]
        preference = str(source.get("render_preference") or "auto").strip()
        method = _resolve_method(goal, preference, index)
        purpose = str(source.get("understanding_task") or "").strip()
        key_message = str(source.get("key_message") or purpose).strip()
        if not purpose or not key_message:
            raise ValueError(f"visual_plan[{index}] 缺少 understanding_task 或 key_message")
        evidence_refs = _normalize_strings(source.get("evidence_refs"), "evidence_refs", index)
        if not evidence_refs:
            evidence_refs = _derive_evidence_refs(article_plan, asset_id)
            if evidence_refs:
                warnings.append(f"{asset_id} 从引用章节继承 evidence_refs")
        if goal == "trend" and not evidence_refs:
            raise ValueError(f"visual_plan[{index}] 是数据趋势图但没有 evidence_refs")
        source_ref = str(source.get("source_ref") or "").strip()
        if goal == "evidence_capture" and not source_ref:
            raise ValueError(f"visual_plan[{index}] 是界面证据图但没有 source_ref")
        must_include = _normalize_strings(source.get("must_include"), "must_include", index)
        # `must_include` 拆两半：**事实要求**必须全部呈现，**形式建议**可换。
        # 不拆的话，「三行 × 四个维度」这种条目会把矩阵钉死在计划里——
        # 就算把它解释成"至少包含这些"，助理选流程图仍与原要求冲突。
        split = split_must_include(must_include)
        form_hint = _normalize_strings(source.get("form_hint"), "form_hint", index)
        if split["form_hint_candidate"]:
            warnings.append(
                f"{asset_id} 的 must_cover 有 {len(split['form_hint_candidate'])} 条像是在说形式"
                f"（{split['form_hint_candidate'][0][:18]}…）；**不自动搬**，"
                "请人工确认是否移到 form_hint")
        must_avoid = _normalize_strings(source.get("must_avoid"), "must_avoid", index)
        basis = str(source.get("basis") or "").strip()
        if goal in FACTUAL_GOALS and not must_include:
            warnings.append(f"{asset_id} 来自旧 VisualIntent，must_include 为空；生成前应补充关键实体或阶段")
        text = _normalize_strings(source.get("text"), "text", index)
        if not text:
            text = list(must_include)

        structure = _normalize_structure(source, index, goal, subtype, warnings)
        annotations = _normalize_annotations(
            source, index, {node["id"] for node in structure.get("nodes") or []})

        asset_role = str(source.get("asset_role") or "body")
        # social/storyboard 尚未登记自己的画幅，暂随正文；登记后在 role_sizes 里加一条即可。
        width, height = role_sizes.get(asset_role, role_sizes["body"])
        # 正文配图按档位取画幅。**16:9 不再是唯一档**——三层结构加批注层塞不进
        # 720px 高，模型只能砍掉第二个信息寄存器，产出「一排方块加箭头」。
        size_tier = ""
        if asset_role == "body":
            size_tier = str(source.get("body_size_tier") or "").strip()
            layout = structure.get("layout") or ""
            if layout == "composite" and size_tier not in ("", "body_tall"):
                raise ValueError(
                    f"visual_plan[{index}] 是复合版式（layout=composite），"
                    f"画幅必须用 body_tall，不能是 {size_tier}")
            if not size_tier:
                # 有 layout 就按 layout 定档（与骨架画布一致）；没有就回落缺省档。
                size_tier = LAYOUT_SIZE_TIER.get(layout, DEFAULT_BODY_TIER)
            width, height = resolve_body_size(size_tier)
            tiers = {node.get("tier") for node in (structure.get("nodes") or [])
                     if node.get("tier")}
            if len(tiers) >= 3 and size_tier == "body_wide":
                warnings.append(
                    f"{asset_id} 有 {len(tiers)} 层而画幅是 body_wide(16:9)："
                    "塞得下但会贴边，标注无处可放；建议 body_std")

        item = {
            "asset_id": asset_id,
            "order": index,
            "asset_role": asset_role,
            "visual_goal": goal,
            "diagram_subtype": subtype,
            "purpose": purpose,
            "key_message": key_message,
            "source_basis": basis,
            "content_type": content_type,
            "width": int(source.get("width") or width),
            "height": int(source.get("height") or height),
            "placement": source.get("placement"),
            "article_slot": {
                "ordinal": slot_by_id[asset_id].get("ordinal", index),
                "section_id": slot_by_id[asset_id].get("section_id"),
                "slot_status": slot_by_id[asset_id].get("slot_status"),
                "placeholder_text": slot_by_id[asset_id].get("placeholder_text") or "",
            },
            "text": text,
            "evidence_refs": evidence_refs,
            "alt_text": str(source.get("alt_text") or key_message),
            "generation_method": method,
            "style": str(source.get("style") or style_id),
            "must_keep": must_include or ([basis] if basis else []),
            # 必须全部呈现，**不得放宽成"证明大意即可"**。
            "must_cover": split["must_cover"],
            # 可换，换了要在 rationale 里写为什么。
            "form_hint": form_hint,
            "form_hint_candidate": split["form_hint_candidate"],
            "must_avoid": must_avoid,
            # 上游一直在填，编译器一直没下发——而它是唯一一个直接指向「这张图凭什么
            # 值得存在」的字段。丢了它，画图的人就只能按 must_include 摆方块。
            "information_gain": str(source.get("information_gain") or "").strip(),
            "structure": structure,
            "annotations": annotations,
            # 来源快照：把 evidence_refs 解成原文，并按**这一张图**记依赖。
            # 不记的话，`['ev-001']` 只是一串裸 ID，复核者读不到它说了什么，
            # 也就无从判断图上那句话是不是它支持的。
            "sources": build_sources(
                section_id=str(slot_by_id[asset_id].get("section_id")
                               or source.get("placement") or ""),
                section_excerpt=_section_excerpt_for(
                    article_plan, article_sections,
                    str(slot_by_id[asset_id].get("section_id")
                        or source.get("placement") or "")),
                # 标题要一并记：失效判定只能按标题在正文里查得到这一节，
                # `section_id` 是 ArticlePlan 的编号，正文里没有它。
                section_heading=_section_heading_for(
                    article_plan,
                    str(slot_by_id[asset_id].get("section_id")
                        or source.get("placement") or "")),
                evidence_refs=evidence_refs,
                evidence_lookup=evidence_lookup,
                content_sha256=article_content_sha256),
            "context_digest": _context_digest(
                article_plan, article_sections,
                str(slot_by_id[asset_id].get("section_id") or source.get("placement") or ""),
                glossary),
        }
        if size_tier:
            item["body_size_tier"] = size_tier
        # 交付倍率随资产下发，**不让渲染环节自己决定**。
        # `width`/`height` 是 layout（HTML 的 CSS 画布），交付像素 = layout × scale。
        # 三个量各有名字之前，"尺寸"一个词同时指这三件事，于是 `raster` 默认 2 倍
        # 与 `verify`/`finalize` 要求严格相等必然打架。
        item["delivery_scale"] = _delivery_scale_for(item["generation_method"])
        if source_ref:
            item["source_ref"] = source_ref
        if asset_role == "cover":
            # 封面文案必须随资产下发，否则渲染环节拿不到它，文案就只能停在计划里
            # ——那正是此前的实际状态：产出的封面零文字，与内容无关。
            # AI 生图画不出可靠中文，所以背景归模型、文字归代码，分两层。
            item["text_layer"] = {
                "copy": cover_copy,
                "hook_type": str(cover_hook.get("hook_type") or ""),
                "reader_takeaway": str(cover_hook.get("reader_takeaway") or ""),
                "compositor": "scripts/compose_cover.py",
            }
            item["generation_method"] = "cover_composite"
            item["background_method"] = method
        items.append(item)

    _warn_overlapping_visuals(items, warnings)

    return {
        "schema_version": "1.1",
        # **语义契约标记由编译器盖，不由调用方给。**
        # 新旧任务要由工具链判定：带这个标记的计划出自新编译器，
        # 它的每一项都必须显式说明走没走语义规划；没有标记的是存量，整体豁免。
        # 判据若换成"字段在不在"，调用方只要省掉字段就能豁免——
        # 而"新任务必须有规划"恰恰是要拦这个。
        "semantic_contract": "1.0",
        "workflow": dict(workflow or {}),
        "producer": {"skill": "write-article", "version": "1.2.0"},
        "source_artifacts": list(source_artifacts or []),
        "plan_id": f"visual-plan-{topic_id}",
        "brief_id": brief_id,
        "topic_id": topic_id,
        "work_id": article_id,
        "modality": "article",
        "channel_ref": channel_ref,
        "article_path": str(article_path.resolve()),
        # **证据也要能重新读一遍。** 登记时要判「依据变没变」，
        # 而证据原文只存在 ArticlePlan 里；不记路径的话，
        # 当前证据表永远是空的——凡是声明了证据依赖的图都会被判失配。
        "article_plan_path": str(article_plan_path.resolve()) if article_plan_path else "",
        "asset_directory": str(asset_directory.resolve()),
        # 令牌从 diagram_tokens 下发，**不再是空数组**。空 palette 的后果不是
        # 「没有风格」，是每张图现场发明一套配色——同一篇里第一层在图 1 是紫的、
        # 到图 3 变成绿的，而这种不一致机器查不出来，人也要把五张图并排才看得见。
        "global_style": _global_style(style_id),
        "items": items,
        "warnings": warnings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Compile ArticlePlan VisualIntent into VisualPlan")
    parser.add_argument("--article", required=True, help=(
        "正文 Markdown。显式给了 --article-plan 与 --article-manifest 时文件名随意；"
        "只给本参数时要靠文件名自动定位那两份，需命名为 article-<topic_id>.md"))
    parser.add_argument("--article-plan", help="ArticlePlan YAML；默认自动定位同目录同 topic_id 文件")
    parser.add_argument("--article-manifest", help="ArticleManifest YAML；默认自动定位同目录同 topic_id 文件")
    parser.add_argument("--channel", default="wechat-official-account")
    parser.add_argument("--style", default="editorial")
    parser.add_argument("--asset-directory", help="图片资产目录；版本化工作区内必须显式传入")
    parser.add_argument("--output", help="输出 JSON；默认写入 asset-directory")
    args = parser.parse_args()

    article_path = Path(args.article).expanduser().resolve()
    if not article_path.is_file():
        raise FileNotFoundError(f"文章不存在: {article_path}")
    # **两个都显式给了就不看文件名。** 命名约定只为自动定位服务；
    # 强求它会把 SKILL.md 自己的示例（`20-creative/正文.md`）挡在门外。
    autolocating = not (args.article_plan and args.article_manifest)
    suffix = _article_suffix(article_path) if autolocating else ""
    plan_path = (
        Path(args.article_plan).expanduser().resolve()
        if args.article_plan
        else article_path.parent / f"article-plan-{suffix}.yaml"
    )
    if not plan_path.is_file():
        raise FileNotFoundError(f"ArticlePlan 不存在: {plan_path}")
    manifest_path = (
        Path(args.article_manifest).expanduser().resolve()
        if args.article_manifest
        else article_path.parent / f"article-manifest-{suffix}.yaml"
    )
    if not manifest_path.is_file():
        raise FileNotFoundError(f"ArticleManifest 不存在: {manifest_path}")
    article_plan = _read_yaml(plan_path)
    article_manifest = _read_yaml(manifest_path)
    topic_id = str(article_plan.get("topic_id") or "").strip()
    # 只有靠文件名找到的那两份才需要这条一致性校验：显式传参时
    # ArticlePlan 与 ArticleManifest 的 ID 一致性已由 `_validate_manifest` 保证。
    if suffix and topic_id != suffix:
        raise ValueError(f"文章文件 topic_id={suffix} 与 ArticlePlan.topic_id={topic_id} 不一致")
    workspace_root = _workflow_root(article_path)
    if workspace_root is not None and not args.asset_directory:
        try:
            article_relative = article_path.relative_to(workspace_root).as_posix()
        except ValueError:
            article_relative = ""
        if article_relative.startswith("deliverables/"):
            raise ValueError("版本化工作区必须显式传入 --asset-directory，禁止写入已提交文章修订")
    asset_directory = (
        Path(args.asset_directory).expanduser().resolve()
        if args.asset_directory
        else article_path.parent / "article-assets" / topic_id
    )
    asset_relative = None
    if workspace_root is not None:
        try:
            asset_relative = asset_directory.relative_to(workspace_root).as_posix()
        except ValueError as exc:
            raise ValueError("asset-directory 必须位于工作区内") from exc
    output_path = (
        Path(args.output).expanduser().resolve()
        if args.output
        else asset_directory / f"visual-plan-{topic_id}.json"
    )
    article_workflow = dict(article_manifest.get("workflow") or {})
    workflow = {
        "workflow_id": article_workflow.get("workflow_id"),
        "content_family_id": article_workflow.get("content_family_id"),
        "content_id": str(article_manifest.get("article_id") or ""),
        "article_revision": int(article_manifest.get("revision") or 1),
        "article_allocation_path": article_workflow.get("allocation_path"),
        "asset_allocation_path": asset_relative,
    }
    result = compile_plan(
        article_plan,
        article_manifest=article_manifest,
        article_path=article_path,
        channel_ref=args.channel,
        asset_directory=asset_directory,
        style_id=args.style,
        workflow=workflow,
        article_plan_path=plan_path,
        source_artifacts=(
            [
                _source_reference(
                    workspace_root,
                    article_path,
                    f"{article_manifest.get('article_id')}-r{int(article_manifest.get('revision') or 1):04d}",
                    int(article_manifest.get("revision") or 1),
                ),
                _source_reference(
                    workspace_root,
                    manifest_path,
                    f"{article_manifest.get('article_id')}-manifest-r{int(article_manifest.get('revision') or 1):04d}",
                    int(article_manifest.get("revision") or 1),
                ),
            ]
            if workspace_root is not None
            else []
        ),
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"ok": True, "visual_plan_path": str(output_path), "plan": result}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
