#!/usr/bin/env python3
"""按当前文件重算验收报告里 artifact_bindings 的 sha256。

为什么需要这个：验收报告用哈希绑定被验收的产物，这是对的——但它会级联失效。
改一次 ArticleManifest（哪怕只是把 publication_status 改成 ready），manifest 哈希就变，
验收报告里绑定它的那条就成了旧值，提交时被 ACCEPTANCE_HASH_MISMATCH 拒绝。

实测的一次配图流程里，这个级联触发了两次，每次都要手工：改文件 → 找出哪条绑定过期 →
翻出新哈希 → 手改验收报告 → 重跑验收校验 → 重跑联合校验 → 再提交。合计十余轮。
这些步骤全是确定性的，不该由模型手工做。

    # 只看哪些绑定过期，不改文件
    python3 refresh_acceptance_bindings.py --report <验收报告.yaml> --check

    # 重算并写回
    python3 refresh_acceptance_bindings.py --report <验收报告.yaml> --apply

重算只改 sha256，不动 role / artifact_id / relative_path / revision——
绑定关系仍由人决定，本脚本只负责让哈希与磁盘一致。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError as exc:  # pragma: no cover
    raise SystemExit("PyYAML is required") from exc

SHA256_PATTERN = re.compile(r"[0-9a-f]{64}")
# 会话根的标志物，新旧结构都要认：新结构状态在 .runtime/ 下且没有 deliverables/ 层。
WORKFLOW_MARKERS = (
    ".runtime/workflow-state.yaml",
    ".workflow-state.yaml",
    "deliverables",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def workflow_root(report_path: Path) -> Path | None:
    """绑定里的 relative_path 以会话根为基准，向上找到带任一标志物的目录。"""
    for parent in [report_path, *report_path.parents]:
        for marker in WORKFLOW_MARKERS:
            target = parent / marker
            if target.is_file() or target.is_dir():
                return parent
    return None


def scan(report: dict[str, Any], root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, binding in enumerate(report.get("artifact_bindings") or [], 1):
        if not isinstance(binding, dict):
            rows.append({"index": index, "state": "invalid", "reason": "绑定项不是对象"})
            continue
        relative = str(binding.get("relative_path") or "").strip()
        recorded = str(binding.get("sha256") or "").lower()
        row = {
            "index": index,
            "role": str(binding.get("role") or ""),
            "artifact_id": str(binding.get("artifact_id") or ""),
            "relative_path": relative,
            "recorded_sha256": recorded,
            "actual_sha256": "",
            "state": "",
        }
        if not relative:
            row["state"] = "invalid"
            row["reason"] = "relative_path 为空"
            rows.append(row)
            continue
        target = root / Path(*relative.split("/"))
        if not target.is_file():
            row["state"] = "missing"
            row["reason"] = "引用文件不存在"
            rows.append(row)
            continue
        actual = sha256_file(target)
        row["actual_sha256"] = actual
        if not recorded or not SHA256_PATTERN.fullmatch(recorded):
            row["state"] = "unset"
        elif recorded == actual:
            row["state"] = "ok"
        else:
            row["state"] = "stale"
        rows.append(row)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="按当前文件重算验收报告的绑定哈希")
    parser.add_argument("--report", required=True, help="验收报告 YAML 路径")
    parser.add_argument("--root", help="工作区根目录；缺省从报告路径向上探测 deliverables/")
    parser.add_argument("--check", action="store_true", help="只报告，不写回（缺省行为）")
    parser.add_argument("--apply", action="store_true", help="把过期绑定的 sha256 写回报告")
    parser.add_argument("--result-file", help="结果 JSON 输出路径")
    args = parser.parse_args()

    report_path = Path(args.report).expanduser().resolve()
    if not report_path.is_file():
        payload = {"status": "failed", "error_code": "REPORT_NOT_FOUND",
                   "message": "验收报告不存在：%s" % report_path}
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 2

    report = yaml.safe_load(report_path.read_text(encoding="utf-8"))
    if not isinstance(report, dict):
        print(json.dumps({"status": "failed", "error_code": "INVALID_REPORT",
                          "message": "验收报告根节点必须是对象"}, ensure_ascii=False, indent=2))
        return 2

    root = Path(args.root).expanduser().resolve() if args.root else workflow_root(report_path)
    if root is None:
        print(json.dumps({"status": "failed", "error_code": "WORKFLOW_ROOT_NOT_FOUND",
                          "message": "无法定位工作区根目录，请显式传 --root"},
                         ensure_ascii=False, indent=2))
        return 2

    rows = scan(report, root)
    stale = [r for r in rows if r["state"] in {"stale", "unset"}]
    broken = [r for r in rows if r["state"] in {"missing", "invalid"}]

    if args.apply and stale and not broken:
        bindings = report["artifact_bindings"]
        for row in stale:
            bindings[row["index"] - 1]["sha256"] = row["actual_sha256"]
        report_path.write_text(
            # width 给足：默认 80 列会把长中文串折成多行，之后按字面匹配
            # 的编辑就都失效了（同 validate_article_plan.dump_yaml_compatible）。
            yaml.safe_dump(report, allow_unicode=True, sort_keys=False,
                           width=10 ** 9),
            encoding="utf-8",
        )
        status, code = "refreshed", 0
    elif broken:
        status, code = "broken", 2
    elif stale:
        status, code = "stale", 2
    else:
        status, code = "clean", 0

    payload = {
        "status": status,
        "report": str(report_path),
        "workflow_root": str(root),
        "stale": [r["role"] for r in stale],
        "broken": [{"role": r["role"], "reason": r.get("reason")} for r in broken],
        "bindings": rows,
        "next_step": {
            "clean": "全部绑定与磁盘一致，可以直接提交。",
            "stale": "加 --apply 重算，然后重跑验收校验与联合校验，再提交。",
            "refreshed": "已重算。重跑 validate_article_acceptance.py 与联合校验后即可提交。",
            "broken": "存在缺失或非法绑定，需人工修正 relative_path 后再重算。",
        }[status],
    }
    text = json.dumps(payload, ensure_ascii=False, indent=2) + chr(10)
    if args.result_file:
        out = Path(args.result_file)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8", newline=chr(10))
    print(text, end="")
    return code


if __name__ == "__main__":
    sys.exit(main())
