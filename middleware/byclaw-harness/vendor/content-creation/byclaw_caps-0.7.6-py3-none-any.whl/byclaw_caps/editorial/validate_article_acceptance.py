#!/usr/bin/env python3
"""Validate an ArticleAcceptanceReport and prevent false-pass reports."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

import yaml

pass  # 包内使用相对导入，避免污染其他兼容入口
from .story_contract import CONTENT_KINDS, TRUTH_MODES, content_kind, is_story  # noqa: E402


REPORT_SCHEMA_VERSION = "1.4"
LEGACY_REPORT_SCHEMA_VERSIONS = {"1.2", "1.3"}
SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
BASE_REQUIRED_CHECK_IDS = {
    "identity_and_structure",
    "fact_verification",
    "claim_coverage",
    "fact_analysis_boundary",
    "hook_payoff",
    "title_payoff",
    "length_and_density",
    "readability_and_fluency",
    "logical_coherence",
    "language_quality",
    "emphasis_design",
    "channel_expression",
    "citations",
    "visual_consistency",
    "placeholders",
}
REQUIRED_CHECK_IDS = BASE_REQUIRED_CHECK_IDS | {"title_distribution"}
# Keep the historical ID for report compatibility. truth_mode_disclosure is a
# semantic check for misleading case/testimonial framing, not a required notice.
STORY_REQUIRED_CHECK_IDS = {"story_consistency", "truth_mode_disclosure", "spoiler_control"}
MARKETING_REQUIRED_CHECK_IDS = {"marketing_bridge", "product_claim_verification", "conversion_action"}
ALLOWED_CHECK_STATUSES = {"pass", "pass_with_warnings", "fail", "not_applicable"}


def load_yaml(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


# 会话根的标志物。新结构把状态收进 .runtime/，旧结构放在根下；两者都要认，
# 否则在新布局里探测失败，调用方只能建软链接绕过——实测确实发生过。
WORKFLOW_ROOT_MARKERS = (
    Path(".runtime") / "artifacts.yaml",    # article task ledger
    Path(".runtime") / "workflow-state.yaml",   # 当前结构
    Path(".workflow-state.yaml"),               # 旧结构
    Path("deliverables"),                       # 更旧的结构
)


#: 找候选路径时最多看多少个同名文件——会话目录不大，这个上限只是防病态输入。
_SUGGEST_SCAN_LIMIT = 200


def _suggest_relative_path(root: Path, basename: str, digest: str) -> str:
    """在会话根下按「同名 + 同哈希」找出正确的 `relative_path`。

    **`relative_path` 的基准是会话根**（`.runtime/workflow-state.yaml` 所在目录），
    不是验收报告自己所在的 `.meta/`。这条契约以前只写在实现里，报错也只说
    「引用文件不存在」——实测调用方只能去 `grep` 校验器源码才解开，
    而 SKILL.md 恰好明令「不要读脚本源码推断入参」。同名同哈希命中时直接给出正确写法。
    """
    if not digest:
        return ""
    seen = 0
    for candidate in root.rglob(basename):
        seen += 1
        if seen > _SUGGEST_SCAN_LIMIT:
            break
        if not candidate.is_file():
            continue
        try:
            if _sha256(candidate) != digest:
                continue
            return "——同名同哈希的文件在 `{0}`，基准是会话根，改成这个。".format(
                candidate.resolve().relative_to(root).as_posix())
        except (OSError, ValueError):
            continue
    return ""


def _workflow_root(report_path: Path) -> Path:
    for candidate in (report_path.parent, *report_path.parents):
        for marker in WORKFLOW_ROOT_MARKERS:
            target = candidate / marker
            if target.is_file() or target.is_dir():
                return candidate
    return report_path.parent


def validate(report, article_validation, *, report_path: Path | None = None):
    failures = []
    warnings = []
    kind = content_kind(article_validation)
    story = is_story(article_validation)
    if kind not in CONTENT_KINDS:
        failures.append("正文校验结果 content_kind 非法。")
    if content_kind(report) != kind:
        failures.append("content_kind 与正文校验结果不一致。")
    if str(report.get("truth_mode") or "") != str(article_validation.get("truth_mode") or ""):
        failures.append("truth_mode 与正文校验结果不一致。")
    if story and article_validation.get("truth_mode") not in TRUTH_MODES:
        failures.append("故事正文校验结果必须声明有效 truth_mode。")

    report_schema = str(report.get("schema_version"))
    if report_schema not in {REPORT_SCHEMA_VERSION, *LEGACY_REPORT_SCHEMA_VERSIONS}:
        failures.append("ArticleAcceptanceReport.schema_version 必须为 {0}。".format(REPORT_SCHEMA_VERSION))
    elif report_schema in LEGACY_REPORT_SCHEMA_VERSIONS:
        warnings.append("旧 ArticleAcceptanceReport 可兼容读取；新产物必须使用 1.4 的产物哈希绑定契约。")

    for key in ("article_id", "brief_id", "topic_id", "article_path", "manifest_path", "plan_path", "validation_path"):
        if report.get(key) in (None, ""):
            failures.append("{0} 不能为空。".format(key))

    for key in ("article_id", "brief_id", "topic_id"):
        if str(report.get(key, "")) != str(article_validation.get(key, "")):
            failures.append("{0} 与正文校验结果不一致。".format(key))

    if report_schema == REPORT_SCHEMA_VERSION:
        bindings = report.get("artifact_bindings") or []
        if not isinstance(bindings, list):
            failures.append("artifact_bindings 必须是数组。")
            bindings = []
        roles = set()
        root = _workflow_root(report_path.resolve()) if report_path else None
        for index, binding in enumerate(bindings, 1):
            if not isinstance(binding, dict):
                failures.append("artifact_bindings[{0}] 必须是对象。".format(index))
                continue
            role = str(binding.get("role") or "").strip()
            roles.add(role)
            for field in ("role", "artifact_id", "relative_path", "sha256"):
                if not str(binding.get(field) or "").strip():
                    failures.append("artifact_bindings[{0}].{1} 不能为空。".format(index, field))
            digest = str(binding.get("sha256") or "").lower()
            if digest and not SHA256_PATTERN.fullmatch(digest):
                failures.append("artifact_bindings[{0}].sha256 必须为 SHA-256。".format(index))
            if root is not None and str(binding.get("relative_path") or "").strip():
                target = (root / Path(*str(binding["relative_path"]).split("/"))).resolve()
                try:
                    target.relative_to(root)
                except ValueError:
                    failures.append("artifact_bindings[{0}] 路径逃逸工作区。".format(index))
                    continue
                if not target.is_file():
                    # **说清基准目录在哪。** `relative_path` 是相对**会话根**
                    # （`.runtime/workflow-state.yaml` 所在目录），不是相对本报告所在的
                    # `.meta/`。原来只报「引用文件不存在」，调用方无从判断是路径写错
                    # 还是基准搞错——实测它只能去 grep 校验器源码才解开，
                    # 而 SKILL.md 恰好明令「不要读脚本源码推断入参」。
                    # 按 basename + 声明的哈希在会话根下找一遍。命中就是同一份文件，
                    # 唯一的问题就是基准写错了——直接把正确的 relative_path 报出去。
                    hint = _suggest_relative_path(root, target.name, digest)
                    failures.append(
                        "artifact_bindings[{0}] 引用文件不存在：`relative_path` 相对**会话根** "
                        "{1}（即 .runtime/workflow-state.yaml 所在目录，不是本报告所在的 .meta/），"
                        "解析到 {2}{3}".format(index, root.as_posix(), target.as_posix(), hint))
                elif digest and _sha256(target) != digest:
                    failures.append(
                        "artifact_bindings[{0}] 文件哈希不一致：{1} 的实际 sha256 是 {2}，"
                        "报告里写的是 {3}。文件在登记后又改过——重算哈希、不要改文件。".format(
                            index, target.as_posix(), _sha256(target), digest))
        for required_role in ("article", "article_manifest"):
            if required_role not in roles:
                failures.append("artifact_bindings 缺少 {0}。".format(required_role))
        embedded_images = int((article_validation.get("metrics") or {}).get("embedded_image_count") or 0)
        if embedded_images and "image_asset_manifest" not in roles:
            failures.append("正文已嵌入图片时 artifact_bindings 必须绑定 image_asset_manifest。")

    deterministic = report.get("deterministic_validation") or {}
    deterministic_status = deterministic.get("status")
    actual_validation_status = article_validation.get("status")
    if deterministic_status != actual_validation_status:
        failures.append(
            "deterministic_validation.status={0}，但正文校验结果为 {1}。".format(
                deterministic_status, actual_validation_status
            )
        )
    if deterministic_status not in {"pass", "pass_with_warnings", "fail"}:
        failures.append("deterministic_validation.status 必须记录真实校验结果。")
    if deterministic.get("report_path") in (None, ""):
        failures.append("deterministic_validation.report_path 不能为空。")

    checks = report.get("checks") or []
    check_ids = [item.get("check_id") for item in checks if isinstance(item, dict)]
    required_check_ids = set(REQUIRED_CHECK_IDS if report_schema == REPORT_SCHEMA_VERSION else BASE_REQUIRED_CHECK_IDS)
    non_optional_checks = set()
    if story:
        required_check_ids.update(STORY_REQUIRED_CHECK_IDS)
        non_optional_checks.update(STORY_REQUIRED_CHECK_IDS)
    if kind == "story_marketing":
        required_check_ids.update(MARKETING_REQUIRED_CHECK_IDS)
        non_optional_checks.update(MARKETING_REQUIRED_CHECK_IDS)
        non_optional_checks.update({"fact_verification", "claim_coverage", "fact_analysis_boundary"})
    missing = sorted(required_check_ids - set(check_ids))
    duplicate = sorted({item for item in check_ids if item and check_ids.count(item) > 1})
    if missing:
        failures.append("验收项缺失：{0}。".format(", ".join(missing)))
    if duplicate:
        failures.append("验收项重复：{0}。".format(", ".join(duplicate)))

    semantic_failures = []
    semantic_warnings = []
    checks_by_id = {}
    for item in checks:
        if not isinstance(item, dict):
            failures.append("checks 中的每一项必须是对象。")
            continue
        check_id = item.get("check_id") or "unknown"
        checks_by_id[check_id] = item
        status = item.get("status")
        if status not in ALLOWED_CHECK_STATUSES:
            failures.append("{0}.status 非法。".format(check_id))
            continue
        if status in {"pass", "pass_with_warnings"} and not (item.get("evidence") or []):
            failures.append("{0} 通过时必须提供可复核 evidence。".format(check_id))
        if check_id in {"readability_and_fluency", "logical_coherence", "language_quality", "emphasis_design"}:
            if status in {"pass", "pass_with_warnings"} and len(item.get("evidence") or []) < 2:
                failures.append("{0} 通过时至少提供两项正文定位或原句证据，不能只写笼统结论。".format(check_id))
        if check_id == "title_distribution" and status in {"pass", "pass_with_warnings"}:
            if len(item.get("evidence") or []) < 3:
                failures.append("title_distribution 通过时至少提供主旨连接、读者价值和传播钩子/转发理由三项证据。")
        if status == "not_applicable" and not str(item.get("reason") or "").strip():
            failures.append("{0} 为 not_applicable 时必须说明 reason。".format(check_id))
        if status == "not_applicable" and check_id in non_optional_checks:
            failures.append("{0} 在 {1} 中不得为 not_applicable；必须实际检查并提供证据。".format(check_id, kind))
        if status == "fail":
            semantic_failures.append(check_id)
            if not str(item.get("issue") or "").strip():
                failures.append("{0} 失败时必须填写 issue。".format(check_id))
            if not str(item.get("revision_action") or "").strip():
                failures.append("{0} 失败时必须填写 revision_action。".format(check_id))
        elif status == "pass_with_warnings":
            semantic_warnings.append(check_id)

    metrics = article_validation.get("metrics") or {}
    visual_placeholders = int(metrics.get("visual_placeholder_count") or 0)
    embedded_images = int(metrics.get("embedded_image_count") or 0)
    visual_check = checks_by_id.get("visual_consistency") or {}
    visual_status = visual_check.get("status")
    if visual_placeholders and visual_status not in {"pass_with_warnings", "fail"}:
        failures.append("正文仍有配图占位时 visual_consistency 必须为 pass_with_warnings|fail。")
    if embedded_images and visual_status == "not_applicable":
        failures.append("正文已嵌入图片时 visual_consistency 不得为 not_applicable。")

    if report_schema == REPORT_SCHEMA_VERSION:
        citation_verification = report.get("citation_verification") or {}
        citation_status = citation_verification.get("status")
        checked_urls = citation_verification.get("checked_urls") or []
        unverified_urls = citation_verification.get("unverified_urls") or []
        if citation_status not in {"verified", "partial", "not_checked", "failed"}:
            failures.append("citation_verification.status 必须为 verified|partial|not_checked|failed。")
        if not isinstance(checked_urls, list) or not isinstance(unverified_urls, list):
            failures.append("citation_verification.checked_urls 与 unverified_urls 必须为数组。")
        if citation_status == "verified" and not checked_urls:
            failures.append("citation_verification.status=verified 时 checked_urls 不能为空。")
        if citation_status == "not_checked" and checked_urls:
            failures.append("citation_verification.status=not_checked 时 checked_urls 必须为空。")
        if citation_status in {"partial", "failed", "not_checked"} and not str(citation_verification.get("note") or "").strip():
            failures.append("引用未全部核验可访问性时 citation_verification.note 不能为空。")
        citations_check = checks_by_id.get("citations") or {}
        citation_claim_text = " ".join(
            [str(citations_check.get("reason") or "")]
            + [str(item) for item in (citations_check.get("evidence") or [])]
        )
        if "可访问" in citation_claim_text and citation_status not in {"verified", "partial"}:
            failures.append("未实际核验链接时，citations 不得声称来源 URL“可访问”。")

    defensive_warning = any(
        isinstance(item, dict)
        and item.get("check_id") == "defensive_repetition"
        and item.get("status") == "warning"
        for item in (article_validation.get("checks") or [])
    )
    language_status = (checks_by_id.get("language_quality") or {}).get("status")
    if defensive_warning and language_status not in {"pass_with_warnings", "fail"}:
        failures.append("正文存在边界限定句式重复 warning 时，language_quality 不得直接标记为 pass。")

    blockers = report.get("blocking_issues") or []
    report_warnings = report.get("warnings") or []
    revision_actions = report.get("revision_actions") or []
    expected_status = "pass"
    if actual_validation_status == "fail" or semantic_failures:
        expected_status = "fail"
    elif actual_validation_status == "pass_with_warnings" or semantic_warnings or report_warnings:
        expected_status = "pass_with_warnings"

    if report.get("status") != expected_status:
        failures.append(
            "报告 status 应为 {0}，实际为 {1}。".format(expected_status, report.get("status"))
        )
    if expected_status == "fail" and not blockers:
        failures.append("fail 报告必须列出 blocking_issues。")
    if expected_status == "fail" and not revision_actions:
        failures.append("fail 报告必须列出 revision_actions。")
    if expected_status != "fail" and blockers:
        failures.append("非 fail 报告不得保留 blocking_issues。")
    if not str(report.get("verified_at") or "").strip():
        failures.append("verified_at 不能为空。")

    if actual_validation_status == "pass_with_warnings" and not report_warnings:
        warnings.append("正文校验含 warning，建议在报告 warnings 中逐项承接。")

    return {
        "schema_version": "1.0",
        "status": "fail" if failures else ("pass_with_warnings" if warnings else "pass"),
        "expected_report_status": expected_status,
        "failures": failures,
        "warnings": warnings,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--article-validation", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        result = validate(
            load_yaml(args.report),
            load_json(args.article_validation),
            report_path=args.report,
        )
    except (OSError, yaml.YAMLError, ValueError, TypeError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0 if result["status"] in {"pass", "pass_with_warnings"} else 1


if __name__ == "__main__":
    sys.exit(main())
