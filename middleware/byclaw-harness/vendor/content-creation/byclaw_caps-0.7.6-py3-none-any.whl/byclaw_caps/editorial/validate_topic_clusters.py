#!/usr/bin/env python3
"""Validate that topic clusters represent claims, not title variants."""

from __future__ import annotations

from typing import Any

from .topic_cli_io import read_json, write_json

ROLES = {"primary", "section", "follow_up", "title_variant"}


def validate(params: dict[str, Any]) -> dict[str, Any]:
    clusters = params.get("clusters") or []
    if not isinstance(clusters, list):
        raise ValueError("clusters 必须是数组")
    errors, warnings = [], []
    seen_ids: set[str] = set()
    for index, cluster in enumerate(clusters):
        path = f"clusters[{index}]"
        if not isinstance(cluster, dict):
            errors.append({"path": path, "message": "必须是对象"})
            continue
        cluster_id = str(cluster.get("cluster_id") or "")
        if not cluster_id:
            errors.append({"path": path, "message": "缺少 cluster_id"})
        elif cluster_id in seen_ids:
            errors.append({"path": path, "message": "cluster_id 重复"})
        seen_ids.add(cluster_id)
        if not str(cluster.get("core_judgment") or "").strip():
            errors.append({"path": path, "message": "缺少 core_judgment"})
        members = cluster.get("members") or []
        if not isinstance(members, list) or not members:
            errors.append({"path": path, "message": "members 必须是非空数组"})
            continue
        primary_count = 0
        for member_index, member in enumerate(members):
            role = member.get("role") if isinstance(member, dict) else None
            if role not in ROLES:
                errors.append({"path": f"{path}.members[{member_index}]", "message": f"未知 role: {role}"})
            if role == "primary":
                primary_count += 1
        if primary_count != 1:
            errors.append({"path": path, "message": "每个簇必须且只能有一个 primary"})
        if len(members) > 5:
            warnings.append({"path": path, "message": "簇成员过多，请检查是否混入不同核心判断"})
    return {"ok": not errors, "cluster_count": len(clusters), "errors": errors, "warnings": warnings}


if __name__ == "__main__":
    write_json(validate(read_json()))
