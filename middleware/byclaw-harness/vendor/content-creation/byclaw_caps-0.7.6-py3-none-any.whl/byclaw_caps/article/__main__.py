from __future__ import annotations
import argparse
import json
from pathlib import Path
import yaml
from byclaw_caps.article import (ArticleError, init, register, verify, record_check,
                                 technical_check, deliver, load, INTENTS)
from byclaw_caps.article.catalog import load_catalog
from byclaw_caps.article.runtime import (bind_call, check_delivery, check_stage,
                                          record_step, validate_plan)


def build():
    p = argparse.ArgumentParser(description="按意图运行；不补跑历史阶段，不自动验收语义")
    sub = p.add_subparsers(dest="command", required=True)
    for command in ["init", "register", "verify", "check", "review", "deliver", "show", "intents",
                    "catalog", "plan", "bind", "stage-check", "record-step", "delivery-check"]:
        one = sub.add_parser(command)
        one.add_argument("--root", type=Path)
        one.add_argument("--request", type=Path)
        one.add_argument("--id")
        one.add_argument("--kind")
        one.add_argument("--path")
        one.add_argument("--input", action="append", default=[])
        one.add_argument("--producer", default="agent")
        one.add_argument("--report", type=Path)
        one.add_argument("--artifact", action="append", default=[])
        one.add_argument("--delivery-id")
        one.add_argument("--catalog-root", type=Path)
        one.add_argument("--include-development", action="store_true",
                         help="仅开发/校验时加载 status=development 的定义")
        one.add_argument("--plan-file", type=Path)
        one.add_argument("--instance")
        one.add_argument("--stage")
        one.add_argument("--mode")
        one.add_argument("--phase", choices=["before", "after"])
        one.add_argument("--result", type=Path)
    return p


def main():
    a = build().parse_args()
    try:
        if a.command == "intents":
            result = sorted(INTENTS)
        elif a.command == "catalog":
            if not a.catalog_root or not a.catalog_root.is_absolute():
                raise ArticleError("--catalog-root 必须是 Skill 的绝对目录")
            catalog = load_catalog(a.catalog_root, include_development=a.include_development)
            result = {kind: sorted(items) for kind, items in catalog.items()}
        else:
            if not a.root or not a.root.is_absolute():
                raise ArticleError("--root 必须是当前任务的绝对目录")
            if a.command == "init":
                if not a.request: raise ArticleError("缺少 --request")
                result = init(a.root, yaml.safe_load(a.request.read_text(encoding="utf-8")))
            elif a.command == "register":
                if not all([a.id, a.kind, a.path]): raise ArticleError("缺少 --id/--kind/--path")
                result = register(a.root, a.id, a.kind, a.path, a.input, a.producer)
            elif a.command in {"verify", "check", "review"}:
                if not a.id: raise ArticleError("缺少 --id")
                if a.command == "verify": result = verify(a.root, a.id)
                elif a.command == "check": result = technical_check(a.root, a.id)
                else:
                    if not a.report: raise ArticleError("缺少 --report")
                    result = record_check(a.root, a.id, yaml.safe_load(a.report.read_text(encoding="utf-8")))
            elif a.command == "deliver": result = deliver(a.root, a.artifact, a.delivery_id)
            elif a.command in {"plan", "bind"}:
                if not a.catalog_root or not a.catalog_root.is_absolute():
                    raise ArticleError("缺少绝对路径 --catalog-root")
                catalog = load_catalog(a.catalog_root, include_development=a.include_development)
                if a.command == "plan":
                    if not a.plan_file: raise ArticleError("缺少 --plan-file")
                    result = validate_plan(a.root, yaml.safe_load(a.plan_file.read_text(encoding="utf-8")), catalog)
                else:
                    if not a.instance: raise ArticleError("缺少 --instance")
                    result = bind_call(a.root, a.instance, catalog)
            elif a.command == "stage-check":
                if not all([a.stage, a.mode, a.phase]): raise ArticleError("缺少 --stage/--mode/--phase")
                result = check_stage(a.root, a.stage, a.mode, a.phase)
            elif a.command == "record-step":
                if not a.instance or not a.result: raise ArticleError("缺少 --instance/--result")
                result = record_step(a.root, a.instance, yaml.safe_load(a.result.read_text(encoding="utf-8")))
            elif a.command == "delivery-check": result = check_delivery(a.root, a.artifact)
            else: result = load(a.root)
        print(json.dumps({"ok": True, "result": result}, ensure_ascii=False, indent=2, default=str))
        return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(json.dumps({"ok": False, "code": "ARTICLE_CONTRACT_ERROR", "message": str(exc)}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
