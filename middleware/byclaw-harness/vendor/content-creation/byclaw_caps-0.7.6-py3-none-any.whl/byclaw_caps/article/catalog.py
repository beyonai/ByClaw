"""Load explicitly indexed process, stage, and component definitions.

Definitions use Markdown with a YAML frontmatter block. Index files are YAML
and are the only discovery mechanism; this module never scans for executable
code or imports a path declared by a definition.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any, Iterable

import yaml

from byclaw_caps.article import ArticleError

INDEXES = {
    "process": ("workflows/processes/index.yaml", "processes"),
    "stage": ("workflows/stages/index.yaml", "stages"),
    "component": ("references/components/index.yaml", "components"),
}
_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")


def _read_yaml(path: Path) -> Any:
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8-sig"))
    except (OSError, yaml.YAMLError) as exc:
        raise ArticleError(f"无法读取 YAML 定义：{path.name}: {exc}") from exc


def _root(value: str | Path) -> Path:
    path = Path(value).resolve()
    if not path.is_dir():
        raise ArticleError(f"定义源目录不存在：{value}")
    return path


def _within(root: Path, value: str) -> Path:
    if not isinstance(value, str) or not value or Path(value).is_absolute():
        raise ArticleError("定义路径必须是非空相对路径")
    path = (root / value).resolve()
    if not path.is_relative_to(root):
        raise ArticleError("定义路径越出 Skill 根目录")
    return path


def _frontmatter(path: Path) -> tuple[dict, str]:
    text = path.read_text(encoding="utf-8-sig")
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ArticleError(f"定义缺少 YAML frontmatter：{path.name}")
    try:
        end = next(i for i in range(1, len(lines)) if lines[i].strip() == "---")
    except StopIteration as exc:
        raise ArticleError(f"定义 frontmatter 未闭合：{path.name}") from exc
    try:
        metadata = yaml.safe_load("\n".join(lines[1:end]))
    except yaml.YAMLError as exc:
        raise ArticleError(f"定义 frontmatter 无效：{path.name}: {exc}") from exc
    if not isinstance(metadata, dict):
        raise ArticleError(f"定义 frontmatter 必须是对象：{path.name}")
    return metadata, "\n".join(lines[end + 1:]).strip()


def _validate_definition(kind: str, definition_id: str, data: dict) -> None:
    if kind not in INDEXES:
        raise ArticleError(f"不支持的定义类型：{kind}")
    if not _ID.fullmatch(definition_id):
        raise ArticleError("定义 ID 格式无效")
    if data.get("id") != definition_id:
        raise ArticleError(f"定义 ID 与索引不一致：{definition_id}")
    if data.get("version") is None:
        raise ArticleError(f"定义缺少 version：{definition_id}")
    expected = {"process": "process", "stage": "stage", "component": "component"}[kind]
    if data.get("template_type", expected) != expected:
        raise ArticleError(f"定义类型不匹配：{definition_id}")
    for field in ("profiles", "inputs", "optional_inputs", "outputs", "actions", "acceptance"):
        value = data.get(field, [])
        if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
            raise ArticleError(f"{definition_id}.{field} 必须是字符串列表")
    if kind == "process" and "modes" in data:
        modes = data["modes"]
        if not isinstance(modes, dict) or not modes:
            raise ArticleError("流程 modes 必须是非空对象")
        for name, mode in modes.items():
            if not isinstance(name, str) or not isinstance(mode, dict):
                raise ArticleError("流程模式必须是命名对象")
            allowed = {"components", "required_components", "deliverable_slots", "output_slots",
                       "reviewed_components", "stop_after", "coverage", "required_inputs", "unique_inputs"}
            if set(mode) - allowed:
                raise ArticleError(f"未知流程模式字段：{name}")
            for field in ("components", "output_slots", "required_inputs", "unique_inputs"):
                mapping = mode.get(field, {})
                if not isinstance(mapping, dict) or any(
                        not isinstance(k, str) or not isinstance(v, list) or not v
                        or any(not isinstance(x, str) for x in v) for k, v in mapping.items()):
                    raise ArticleError(f"流程模式 {field} 必须是字符串列表映射")
            if not mode.get("components") or not isinstance(mode.get("stop_after"), str):
                raise ArticleError("流程模式缺少 components 或 stop_after")
            for field in ("required_components", "deliverable_slots", "reviewed_components"):
                value = mode.get(field, [])
                if not isinstance(value, list) or any(not isinstance(x, str) for x in value):
                    raise ArticleError(f"流程模式 {field} 必须是字符串列表")
            if any(x not in mode["components"] for field in (
                    "required_components", "reviewed_components", "output_slots", "required_inputs", "unique_inputs") for x in mode.get(field, [])):
                raise ArticleError("流程模式约束引用了未允许的组件")
            coverage = mode.get("coverage", [])
            if not isinstance(coverage, list) or any(
                    not isinstance(pair, list) or len(pair) not in (2, 3)
                    or any(not isinstance(x, str) or x not in mode["components"] for x in pair[:2])
                    or (len(pair) == 3 and (not isinstance(pair[2], str) or not pair[2]))
                    for pair in coverage):
                raise ArticleError("流程 coverage 必须是已允许组件的来源/目标对，可附目标输入槽位")


def load_definition(kind: str, definition_id: str,
                    sources: str | Path | Iterable[str | Path], *,
                    include_development: bool = False) -> dict:
    """Resolve one verified definition from an explicit index, validating hash and identity."""
    if isinstance(sources, (str, Path)):
        roots = [_root(sources)]
    else:
        roots = [_root(source) for source in sources]
    if kind not in INDEXES:
        raise ArticleError(f"不支持的定义类型：{kind}")
    index_rel, collection = INDEXES[kind]
    found: list[tuple[Path, dict]] = []
    for root in roots:
        index_path = root / index_rel
        if not index_path.is_file():
            continue
        index = _read_yaml(index_path)
        entries = index.get(collection) if isinstance(index, dict) else None
        if not isinstance(entries, list):
            raise ArticleError(f"索引缺少 {collection} 列表：{index_path}")
        seen: set[str] = set()
        for entry in entries:
            if not isinstance(entry, dict) or not isinstance(entry.get("id"), str):
                raise ArticleError(f"索引项必须包含 id：{index_path}")
            item_id = entry["id"]
            if item_id in seen:
                raise ArticleError(f"索引重复 ID：{item_id}")
            seen.add(item_id)
            if item_id == definition_id:
                found.append((root, entry))
    if not found:
        raise ArticleError(f"未在显式索引中找到 {kind}：{definition_id}")
    if len(found) > 1:
        raise ArticleError(f"多个来源重复注册 {kind}：{definition_id}")

    root, entry = found[0]
    allowed_statuses = {"verified"} | ({"development"} if include_development else set())
    if entry.get("status") not in allowed_statuses:
        raise ArticleError(f"定义尚未通过验证或已停用：{definition_id}")
    path = _within(root, entry.get("path"))
    if not path.is_file():
        raise ArticleError(f"定义文件不存在：{entry.get('path')}")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    expected_digest = entry.get("sha256")
    if expected_digest and expected_digest != digest:
        raise ArticleError(f"定义文件哈希与索引不一致：{definition_id}")
    metadata, body = _frontmatter(path)
    _validate_definition(kind, definition_id, metadata)
    implementation_hashes: dict[str, str] = {}
    knowledge_hashes: dict[str, str] = {}
    program_hashes = {}
    script_hashes = {}
    if kind == "component":
        implementation = metadata.get("implementation")
        if not isinstance(implementation, dict):
            raise ArticleError(f"组件缺少受控实现：{definition_id}")
        implementation_type = implementation.get("type")
        if implementation_type == "skill_script":
            entries = implementation.get("entries")
            actions = metadata.get("actions", [])
            if not isinstance(entries, dict) or any(action not in entries for action in actions):
                raise ArticleError(f"组件 action 缺少程序入口：{definition_id}")
            for action, program_entry in entries.items():
                program = _within(root, program_entry)
                if not program.is_file() or program.suffix.lower() != ".py":
                    raise ArticleError(f"组件程序入口不存在或不是 Python 文件：{program_entry}")
                implementation_hashes[action] = hashlib.sha256(program.read_bytes()).hexdigest()
        elif implementation_type == "agent":
            if implementation.get("entry") != "host_agent":
                raise ArticleError(f"agent 组件必须绑定 host_agent：{definition_id}")
            from .agent import program_hashes as resolve_programs
            program_hashes = resolve_programs(implementation.get("supporting_programs", []))
            scripts = implementation.get("supporting_scripts", [])
            if not isinstance(scripts, list):
                raise ArticleError("supporting_scripts 必须是相对 Python 路径列表")
            for rel in scripts:
                script = _within(root, rel)
                if not script.is_file() or script.suffix != ".py":
                    raise ArticleError("supporting_scripts 不是实际 Python 文件")
                script_hashes[rel] = hashlib.sha256(script.read_bytes()).hexdigest()
            external = implementation.get("external_skills", [])
            if not isinstance(external, list) or any(
                    skill not in {"bycli", "knowledge-collection"}
                    for skill in external):
                raise ArticleError(f"agent 外部 Skill 不在白名单：{definition_id}")
            implementation_hashes["agent"] = hashlib.sha256(
                yaml.safe_dump(implementation, sort_keys=True, allow_unicode=True).encode("utf-8")
            ).hexdigest()
        else:
            raise ArticleError(f"组件实现类型不受支持：{definition_id}")
        knowledge = metadata.get("knowledge", [])
        if not isinstance(knowledge, list):
            raise ArticleError(f"组件 knowledge 必须是列表：{definition_id}")
        for reference in knowledge:
            knowledge_path = _within(root, reference)
            if not knowledge_path.is_file():
                raise ArticleError(f"组件知识文件不存在：{reference}")
            knowledge_hashes[reference] = hashlib.sha256(knowledge_path.read_bytes()).hexdigest()
        resources = metadata.get("resources", [])
        if not isinstance(resources, list):
            raise ArticleError(f"组件 resources 必须是列表：{definition_id}")
        resource_hashes = {}
        for reference in resources:
            resource_path = _within(root, reference)
            if not resource_path.is_file():
                raise ArticleError(f"组件资源文件不存在：{reference}")
            resource_hashes[reference] = hashlib.sha256(resource_path.read_bytes()).hexdigest()
    else:
        resource_hashes = {}
    return {**metadata, "body": body, "definition_path": path,
            "definition_sha256": digest, "source_root": root,
            "implementation_sha256": implementation_hashes,
            "knowledge_sha256": knowledge_hashes,
            "resource_sha256": resource_hashes,
            "supporting_program_sha256": program_hashes,
            "supporting_script_sha256": script_hashes,
            "status": entry["status"]}


def load_catalog(sources: str | Path | Iterable[str | Path], *,
                 include_development: bool = False) -> dict:
    """Load all entries in the three indexes and expose them by ID."""
    if isinstance(sources, (str, Path)):
        roots = [_root(sources)]
    else:
        roots = [_root(source) for source in sources]
    catalog: dict[str, dict] = {key: {} for key in ("processes", "stages", "components")}
    kind_map = {"process": "processes", "stage": "stages", "component": "components"}
    for kind, (index_rel, collection) in INDEXES.items():
        for root in roots:
            index_path = root / index_rel
            if not index_path.is_file():
                continue
            index = _read_yaml(index_path)
            entries = index.get(collection) if isinstance(index, dict) else None
            if not isinstance(entries, list):
                raise ArticleError(f"索引缺少 {collection} 列表：{index_path}")
            for entry in entries:
                if not isinstance(entry, dict) or not isinstance(entry.get("id"), str):
                    raise ArticleError(f"索引项必须包含 id：{index_path}")
                definition_id = entry["id"]
                if definition_id in catalog[kind_map[kind]]:
                    raise ArticleError(f"多个来源重复注册 {kind}：{definition_id}")
                if entry.get("status") != "verified" and not (
                        include_development and entry.get("status") == "development"):
                    continue
                catalog[kind_map[kind]][definition_id] = load_definition(
                    kind, definition_id, root, include_development=include_development)
    return catalog
