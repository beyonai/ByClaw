"""Deterministic plan validation and execution records for article workflows."""
from __future__ import annotations

import copy
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from byclaw_caps.article import ArticleError, _inside, _save, load, verify, _id
from . import agent


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read(path: Path) -> dict:
    try:
        value = yaml.safe_load(path.read_text(encoding="utf-8-sig"))
    except (OSError, yaml.YAMLError) as exc:
        raise ArticleError(f"运行文件无效：{path.name}: {exc}") from exc
    if not isinstance(value, dict):
        raise ArticleError(f"运行文件必须是对象：{path.name}")
    return value


def _instances(plan: dict) -> list[dict]:
    value = plan.get("instances")
    if not isinstance(value, list) or not value:
        raise ArticleError("plan.instances 必须是非空列表")
    return value


def _acyclic(items: list[dict]) -> None:
    deps = {item["instance_id"]: set(item.get("needs", [])) for item in items}
    for name, needs in deps.items():
        missing = needs - deps.keys()
        if missing:
            raise ArticleError(f"实例依赖不存在：{name} <- {', '.join(sorted(missing))}")
    remaining = {name: set(needs) for name, needs in deps.items()}
    while remaining:
        ready = {name for name, needs in remaining.items() if not needs}
        if not ready:
            raise ArticleError("组件实例依赖形成循环")
        remaining = {name: needs - ready for name, needs in remaining.items() if name not in ready}


def _output_dir(root: Path, item: dict) -> tuple[Path, str]:
    relative = agent.output_dir(root, item)
    return _inside(root, relative), relative


def _validate_process(root: Path, plan: dict, process: dict, items: list[dict]) -> None:
    """Apply the selected recipe's limits, using actual artifact edges for review/coverage."""
    modes = process.get("modes")
    if not modes:  # Existing custom recipes remain compatible.
        return
    selected = plan.get("mode")
    mode = modes.get(selected) if isinstance(selected, str) else None
    if mode is None:
        raise ArticleError("流程必须选择已声明的 mode")
    if plan.get("stop_after") != mode["stop_after"]:
        raise ArticleError("流程 stop_after 与模式停止条件不符")
    used = {item["component_id"] for item in items}
    if set(mode.get("required_components", [])) - used:
        raise ArticleError("流程缺少模式必需组件")
    producers = {aid: item for item in items for aid in item["outputs"].values()}
    deliverables = set(plan["deliverables"])
    delivered = [item for item in items if deliverables & set(item["outputs"].values())]
    slots = {slot for item in delivered for slot, aid in item["outputs"].items() if aid in deliverables}
    if set(mode.get("deliverable_slots", [])) - slots:
        raise ArticleError("流程缺少模式必需交付槽位")
    for item in items:
        cid = item["component_id"]
        if item["action"] not in mode["components"].get(cid, []):
            raise ArticleError(f"流程模式不允许组件或动作：{cid}/{item['action']}")
        allowed_outputs = mode.get("output_slots", {}).get(cid)
        if allowed_outputs is not None and set(item["outputs"]) - set(allowed_outputs):
            raise ArticleError("流程模式不允许该输出槽位")
        if set(mode.get("required_inputs", {}).get(cid, [])) - set(item["inputs"]):
            raise ArticleError("流程模式缺少必需输入绑定")
        for slot in mode.get("unique_inputs", {}).get(cid, []):
            values = [other["inputs"].get(slot) for other in items if other["component_id"] == cid]
            if None in values or len(values) != len(set(values)):
                raise ArticleError("流程模式不允许重复来源实例")
        if cid in mode.get("reviewed_components", []):
            for slot in ("article", "revised_article"):
                aid = item["outputs"].get(slot)
                if aid not in deliverables:
                    continue
                if not any(review["component_id"] == "writing.review"
                           and review["inputs"].get("article") == aid
                           and review["outputs"].get("review_report") in deliverables
                           for review in items):
                    raise ArticleError("实际交付稿必须绑定审校并交付对应报告")

    artifacts = load(root)["artifacts"]
    def artifact_ancestors(item, input_slot=None):
        result = set()
        pending = ([item["inputs"][input_slot]] if input_slot in item["inputs"] else []) if input_slot else list(item["inputs"].values())
        seen = set()
        while pending:
            aid = pending.pop()
            if aid in seen:
                continue
            seen.add(aid)
            if aid in producers:
                parent = producers[aid]
                result.add(parent["instance_id"])
                pending.extend(parent["inputs"].values())
            else:
                pending.extend(artifacts.get(aid, {}).get("inputs", {}))
        return result

    for edge in mode.get("coverage", []):
        source, target = edge[:2]
        input_slot = edge[2] if len(edge) == 3 else None
        targets = [item for item in delivered if item["component_id"] == target]
        for item in items:
            if item["component_id"] == source and not any(
                    item["instance_id"] in artifact_ancestors(dst, input_slot) for dst in targets):
                raise ArticleError(f"流程产物未接入实际交付依赖：{source} -> {target}")


def validate_plan(root: str | Path, plan: dict, catalog: dict) -> dict:
    """Validate and persist the single active plan for a task."""
    root = Path(root).resolve()
    load(root)  # Require an initialized article task.
    if not isinstance(plan, dict):
        raise ArticleError("plan 必须是对象")
    process_id = plan.get("process_id")
    profile_id = plan.get("profile_id")
    processes = catalog.get("processes", {})
    stages = catalog.get("stages", {})
    components = catalog.get("components", {})
    if process_id not in processes:
        raise ArticleError(f"流程未注册：{process_id}")
    if profile_id not in processes[process_id].get("profiles", []):
        raise ArticleError(f"流程不支持 profile：{profile_id}")
    if not isinstance(plan.get("deliverables"), list) or not plan["deliverables"] or any(
            not isinstance(aid, str) or not aid for aid in plan["deliverables"]):
        raise ArticleError("plan.deliverables 必须是非空产物 ID 列表")

    seen: set[str] = set()
    outputs: dict[str, str] = {}
    normalized = []
    for raw in _instances(plan):
        if not isinstance(raw, dict):
            raise ArticleError("每个实例必须是对象")
        item = copy.deepcopy(raw)
        instance_id = item.get("instance_id")
        if not isinstance(instance_id, str) or not instance_id or instance_id in seen:
            raise ArticleError("instance_id 缺失或重复")
        _id(instance_id)
        seen.add(instance_id)
        stage_id, component_id = item.get("stage_id"), item.get("component_id")
        if stage_id not in stages:
            raise ArticleError(f"阶段未注册：{stage_id}")
        if component_id not in components:
            raise ArticleError(f"组件未注册：{component_id}")
        stage, component = stages[stage_id], components[component_id]
        if component.get("stage_id") != stage_id or component_id not in stage.get("components", []):
            raise ArticleError(f"阶段未允许组件：{stage_id} -> {component_id}")
        if profile_id not in stage.get("profiles", []) or profile_id not in component.get("profiles", []):
            raise ArticleError(f"阶段或组件不支持 profile：{profile_id}")
        action = item.get("action")
        if action not in component.get("actions", []):
            raise ArticleError(f"组件不支持 action：{component_id}/{action}")
        if not isinstance(item.get("options", {}), dict):
            raise ArticleError("实例 options 必须是对象")
        if not isinstance(item.get("needs", []), list) or any(
                not isinstance(dep, str) for dep in item.get("needs", [])):
            raise ArticleError("实例 needs 必须是 ID 列表")
        if component["implementation"]["type"] == "agent":
            _output_dir(root, item)
        inputs = item.get("inputs", {})
        item_outputs = item.get("outputs", {})
        if not isinstance(inputs, dict) or not isinstance(item_outputs, dict) or not item_outputs:
            raise ArticleError(f"实例输入输出格式无效：{instance_id}")
        allowed_inputs = set(component.get("inputs", [])) | set(component.get("optional_inputs", []))
        required_inputs = set(component.get("inputs", []))
        if not isinstance(allowed_inputs, set) or any(slot not in allowed_inputs for slot in inputs):
            raise ArticleError(f"实例输入槽位未在组件声明：{instance_id}")
        missing_inputs = required_inputs - set(inputs)
        if missing_inputs:
            raise ArticleError(f"实例缺少必需输入：{instance_id} <- {', '.join(sorted(missing_inputs))}")
        if any(not isinstance(slot, str) or not isinstance(value, str) or not value
               for slot, value in inputs.items()):
            raise ArticleError(f"实例输入格式无效：{instance_id}")
        allowed_outputs = set(component.get("outputs", []))
        if isinstance(component.get("output_slots"), list):
            allowed_outputs |= set(component["output_slots"])
        if any(slot not in allowed_outputs for slot in item_outputs):
            raise ArticleError(f"实例输出槽位未在组件声明：{instance_id}")
        for name, artifact_id in item_outputs.items():
            if not isinstance(name, str) or not isinstance(artifact_id, str) or not artifact_id:
                raise ArticleError(f"实例输出格式无效：{instance_id}")
            if artifact_id in outputs:
                raise ArticleError(f"多个实例写入同一产物：{artifact_id}")
            _id(artifact_id)
            outputs[artifact_id] = instance_id
        normalized.append(item)
    _acyclic(normalized)
    by_id = {item["instance_id"]: item for item in normalized}
    def ancestors(item):
        result = set(item.get("needs", []))
        for dependency in item.get("needs", []):
            result |= ancestors(by_id[dependency])
        return result
    artifacts = load(root)["artifacts"]
    for item in normalized:
        pending = list(item.get("inputs", {}).values())
        inspected = set()
        while pending:
            aid = pending.pop()
            if aid in inspected:
                continue
            inspected.add(aid)
            if aid in outputs and outputs[aid] not in ancestors(item):
                raise ArticleError("产物生产者必须在直接或传递前置依赖中")
            if aid not in outputs:
                verify(root, aid, require_checks=False)
                pending.extend(artifacts[aid].get("inputs", {}))
    if process_id == "single-stage" and len({i["stage_id"] for i in normalized}) != 1:
        raise ArticleError("single-stage 只允许一个阶段")
    _validate_process(root, plan, processes[process_id], normalized)
    if any(aid not in outputs and aid not in load(root)["artifacts"]
           for aid in plan.get("deliverables", [])):
        raise ArticleError("交付产物未登记也未被计划生产")
    used_stages = sorted({item["stage_id"] for item in normalized})
    used_components = sorted({item["component_id"] for item in normalized})
    bindings = {
        "process": {process_id: processes[process_id]["definition_sha256"]},
        "stages": {name: stages[name]["definition_sha256"] for name in used_stages},
        "components": {name: agent.definition_snapshot(components[name]) for name in used_components},
    }
    normalized_plan = {**plan, "schema_version": "1.0", "instances": normalized,
                       "definition_bindings": bindings,
                       "validated_at": _now()}
    previous_state = None
    previous_plan = None
    try:
        previous_plan, previous_state = _plan_state(root)
    except ArticleError:
        pass
    old_instances = (previous_state or {}).get("instances", {})
    old_plan_items = {item.get("instance_id"): item for item in (previous_plan or {}).get("instances", [])}
    instance_states = {}
    for item in normalized:
        prior = old_instances.get(item["instance_id"], {})
        prior_item = old_plan_items.get(item["instance_id"])
        unchanged = prior_item == item and prior.get("status") == "completed"
        old_bindings = (previous_plan or {}).get("definition_bindings", {})
        unchanged = unchanged and (
            old_bindings.get("process") == bindings["process"]
            and old_bindings.get("stages", {}).get(item["stage_id"]) == bindings["stages"][item["stage_id"]]
            and old_bindings.get("components", {}).get(item["component_id"]) == bindings["components"][item["component_id"]])
        if unchanged:
            try:
                agent.verify_completed(root, item, prior)
            except ArticleError:
                unchanged = False
        instance_states[item["instance_id"]] = copy.deepcopy(prior) if unchanged else {
            "status": "pending", "attempts": int(prior.get("attempts", 0)),
            "updated_at": normalized_plan["validated_at"]}
    # Invalidate dependent instances even when a changed producer has not yet written new bytes.
    for _ in normalized:
        for item in normalized:
            if any(instance_states[dep]["status"] != "completed" for dep in item.get("needs", [])):
                instance_states[item["instance_id"]]["status"] = "pending"
    state = {"schema_version": "1.0", "process_id": process_id,
             "profile_id": profile_id, "plan_revision": int((previous_state or {}).get("plan_revision", 0)) + 1,
             "status": "completed" if instance_states and all(
                 value["status"] == "completed" for value in instance_states.values()) else "ready",
             "instances": instance_states}
    _save(root / ".runtime/plan.yaml", normalized_plan)
    _save(root / ".runtime/state.yaml", state)
    return {"ok": True, "process_id": process_id, "profile_id": profile_id,
            "instance_count": len(normalized), "plan": ".runtime/plan.yaml",
            "state": ".runtime/state.yaml"}


def _plan_state(root: Path) -> tuple[dict, dict]:
    plan_path, state_path = root / ".runtime/plan.yaml", root / ".runtime/state.yaml"
    if not plan_path.is_file() or not state_path.is_file():
        raise ArticleError("任务缺少已校验的 plan.yaml 或 state.yaml")
    return _read(plan_path), _read(state_path)


def _instance(plan: dict, instance_id: str) -> dict:
    for item in _instances(plan):
        if item.get("instance_id") == instance_id:
            return item
    raise ArticleError(f"实例不存在：{instance_id}")


def bind_call(root: str | Path, instance_id: str, catalog: dict) -> dict:
    """Bind logical artifacts to current paths and return a controlled implementation entry."""
    root = Path(root).resolve()
    plan, state = _plan_state(root)
    item = _instance(plan, instance_id)
    current = state.get("instances", {}).get(instance_id)
    if not current:
        raise ArticleError(f"实例状态不存在：{instance_id}")
    blocked = [name for name in item.get("needs", [])
               if state["instances"].get(name, {}).get("status") != "completed"]
    if blocked:
        raise ArticleError("前置实例尚未完成：" + ", ".join(blocked))
    for name in item.get("needs", []):
        dependency = _instance(plan, name)
        if state["instances"][name].get("binding_id"):
            agent.verify_completed(root, dependency, state["instances"][name])
    component = catalog.get("components", {}).get(item["component_id"])
    if not component:
        raise ArticleError(f"组件未注册：{item['component_id']}")
    skill_root = Path(component.get("source_root")).resolve()
    implementation = component.get("implementation")
    if not isinstance(implementation, dict):
        raise ArticleError("组件缺少受控实现")
    implementation_type = implementation.get("type")
    script = None
    entry = None
    if implementation_type == "skill_script":
        entries = implementation.get("entries", {})
        entry = entries.get(item["action"])
        script = _inside(skill_root, entry) if entry else None
        if not script or not script.is_file() or script.suffix.lower() != ".py":
            raise ArticleError(f"组件入口不存在或不受支持：{entry}")
    elif implementation_type == "agent":
        if implementation.get("entry") != "host_agent":
            raise ArticleError("agent 组件入口必须是 host_agent")
    else:
        raise ArticleError("组件实现类型不受支持")
    bindings = plan.get("definition_bindings", {})
    expected_process = bindings.get("process", {}).get(plan.get("process_id"))
    process = catalog.get("processes", {}).get(plan.get("process_id"))
    stage = catalog.get("stages", {}).get(item["stage_id"])
    expected_stage = bindings.get("stages", {}).get(item["stage_id"])
    expected_component = bindings.get("components", {}).get(item["component_id"], {})
    from .catalog import load_definition
    for kind, definition in (("process", process), ("stage", stage), ("component", component)):
        if not definition:
            raise ArticleError("绑定定义不存在")
        fresh = load_definition(kind, definition["id"], definition["source_root"],
                                include_development=definition["status"] == "development")
        if fresh["definition_sha256"] != definition["definition_sha256"]:
            raise ArticleError("定义目录已变化；请重新校验计划")
    current_definition = hashlib.sha256(Path(component["definition_path"]).read_bytes()).hexdigest()
    current_program = (hashlib.sha256(script.read_bytes()).hexdigest() if script else
                       hashlib.sha256(yaml.safe_dump(implementation, sort_keys=True,
                                                     allow_unicode=True).encode("utf-8")).hexdigest())
    current_knowledge = {reference: hashlib.sha256(_inside(skill_root, reference).read_bytes()).hexdigest()
                         for reference in component.get("knowledge", [])}
    implementation_binding = expected_component.get("implementation", {})
    implementation_matches = (implementation_binding.get(item["action"]) == current_program
                               if implementation_type == "skill_script"
                               else implementation_binding.get("agent") == current_program)
    if (not process or not stage
            or expected_process != hashlib.sha256(Path(process["definition_path"]).read_bytes()).hexdigest()
            or expected_stage != hashlib.sha256(Path(stage["definition_path"]).read_bytes()).hexdigest()
            or expected_component.get("definition") != current_definition
            or not implementation_matches
            or expected_component.get("knowledge", {}) != current_knowledge
            or expected_component.get("resources", {}) != {
                reference: hashlib.sha256(_inside(skill_root, reference).read_bytes()).hexdigest()
                for reference in component.get("resources", [])}
            or (implementation_type == "agent" and expected_component.get("programs", {}) !=
                agent.program_hashes(implementation.get("supporting_programs", [])))
            or expected_component.get("scripts", {}) != {
                reference: hashlib.sha256(_inside(skill_root, reference).read_bytes()).hexdigest()
                for reference in implementation.get("supporting_scripts", [])}):
        raise ArticleError("流程、阶段、组件实现或知识已变化；请重新校验计划")
    artifacts = load(root)["artifacts"]
    bound_inputs = {}
    for slot, artifact_id in item.get("inputs", {}).items():
        verify(root, artifact_id, require_checks=False)
        bound_inputs[slot] = {"artifact_id": artifact_id,
                              "path": artifacts[artifact_id]["path"],
                              "sha256": artifacts[artifact_id]["sha256"]}
    if implementation_type == "agent":
        output_path, output_relative = _output_dir(root, item)
    else:
        # Existing script components choose their own task-local package layout.
        output_relative = item.get("options", {}).get("output_dir", f"{item['stage_id']}/{instance_id}/v1")
        output_path = _inside(root, output_relative)
    output_path.mkdir(parents=True, exist_ok=True)
    package = {"ok": True, "instance_id": instance_id, "action": item["action"],
               "implementation_type": implementation_type,
               "entry": str(script) if script else "host_agent",
               "entry_sha256": current_program, "inputs": bound_inputs,
               "outputs": item["outputs"], "allowed_output_slots": list(item["outputs"]),
               "output_dir": output_relative, "profile_id": plan.get("profile_id"),
               "options": item.get("options", {})}
    if implementation_type == "agent":
        package["supporting_programs"] = list(implementation.get("supporting_programs", []))
        package["external_skills"] = list(implementation.get("external_skills", []))
        package["knowledge"] = component.get("knowledge_sha256", {})
        package["resources"] = component.get("resource_sha256", {})
        package["definition_sha256"] = current_definition
        package["component_id"] = item["component_id"]
        package["component_version"] = component["version"]
        package["required_checks"] = list(component.get("acceptance", []))
        package["supporting_program_sha256"] = component.get("supporting_program_sha256", {})
        package["supporting_scripts"] = component.get("supporting_script_sha256", {})
        package["catalog_entries"] = [{"kind": kind, "id": definition["id"],
            "root": str(definition["source_root"]), "status": definition["status"],
            "sha256": definition["definition_sha256"]} for kind, definition in (
                ("process", process), ("stage", stage), ("component", component))]
        package = agent.issue_receipt(root, item, package,
                                      agent.file_bindings([process, stage, component]))
    return package


def check_stage(root: str | Path, stage_id: str, mode: str, phase: str) -> dict:
    root = Path(root).resolve()
    plan, state = _plan_state(root)
    items = [item for item in _instances(plan) if item.get("stage_id") == stage_id]
    if not items:
        raise ArticleError(f"计划中没有阶段：{stage_id}")
    if phase == "before":
        issues = [item["instance_id"] for item in items if any(
            state["instances"].get(dep, {}).get("status") != "completed"
            for dep in item.get("needs", []))]
    elif phase == "after":
        issues = [item["instance_id"] for item in items
                  if state["instances"].get(item["instance_id"], {}).get("status") != "completed"]
        for item in items:
            current = state["instances"][item["instance_id"]]
            if current.get("status") == "completed" and current.get("binding_id"):
                try:
                    agent.verify_completed(root, item, current)
                except ArticleError:
                    issues.append(item["instance_id"])
    else:
        raise ArticleError("phase 仅支持 before|after")
    return {"ok": not issues, "stage_id": stage_id, "mode": mode,
            "phase": phase, "issues": issues}


def record_step(root: str | Path, instance_id: str, result: dict) -> dict:
    root = Path(root).resolve()
    plan, state = _plan_state(root)
    item = _instance(plan, instance_id)
    if not isinstance(result, dict) or result.get("status") not in {"completed", "failed", "pending_review"}:
        raise ArticleError("步骤结果须包含 completed|failed|pending_review 状态")
    current = state["instances"][instance_id]
    expected_outputs = item.get("outputs", {})
    actual_outputs = result.get("outputs", {})
    if result["status"] == "completed" and (
            not isinstance(actual_outputs, dict) or actual_outputs != expected_outputs):
        raise ArticleError(f"步骤输出必须与计划一致：{instance_id}")
    if not isinstance(actual_outputs, dict):
        actual_outputs = {}
    binding_type = (plan.get("definition_bindings", {}).get("components", {})
                    .get(item.get("component_id"), {}).get("implementation_type"))
    if result["status"] == "completed" and binding_type == "agent":
        for dep in item.get("needs", []):
            if state["instances"][dep]["status"] != "completed":
                raise ArticleError("前置实例尚未完成")
            if state["instances"][dep].get("binding_id"):
                agent.verify_completed(root, _instance(plan, dep), state["instances"][dep])
        current.update(agent.complete(root, item, result))
    elif result["status"] == "completed":
        current["input_snapshot"] = agent.input_snapshot(root, item)
    current["attempts"] = int(current.get("attempts", 0)) + 1
    current.update({"status": result["status"], "updated_at": _now(),
                    "outputs": actual_outputs, "checks": result.get("checks", []),
                    "error": result.get("error"), "resume_from": result.get("resume_from")})
    if result.get("input_snapshot") is not None:
        current["input_snapshot"] = result["input_snapshot"]
    statuses = {item["status"] for item in state["instances"].values()}
    state["status"] = "completed" if statuses == {"completed"} else (
        "failed" if "failed" in statuses else "in_progress")
    _save(root / ".runtime/state.yaml", state)
    return {"ok": True, "instance_id": instance_id, **current}


def check_delivery(root: str | Path, artifact_ids: list[str]) -> dict:
    root = Path(root).resolve()
    request = _read(root / ".runtime/request.yaml")
    plan, state = _plan_state(root)
    if not artifact_ids:
        raise ArticleError("交付产物不能为空")
    for artifact_id in artifact_ids:
        verify(root, artifact_id)
    expected = set(plan.get("deliverables", []))
    missing = expected - set(artifact_ids)
    if missing:
        raise ArticleError("交付缺少计划产物：" + ", ".join(sorted(missing)))
    if state.get("status") != "completed":
        raise ArticleError("流程实例尚未全部完成")
    for item in _instances(plan):
        current = state["instances"][item["instance_id"]]
        if current.get("binding_id"):
            agent.verify_completed(root, item, current)
    return {"ok": True, "goal": request.get("goal"), "artifacts": artifact_ids,
            "stop_after": plan.get("stop_after")}
