"""Host-agent call receipts. This module never imports a definition's entry."""
from __future__ import annotations

from pathlib import Path
from uuid import uuid4
import hashlib

import yaml

from . import ArticleError, _inside, _save, load, sha, verify

# Executable capabilities are maintained here, never inferred from a prefix.
PROGRAMS = {
    "byclaw_caps.article": "article/__init__.py",
    "byclaw_caps.article.register": "article/__init__.py",
    "byclaw_caps.article.technical_check": "article/__init__.py",
    "byclaw_caps.article.materials": "article/materials.py",
    **{f"byclaw_caps.editorial.{name}": f"editorial/{name}.py" for name in (
        "detect_material_shape", "validate_material_pass", "check_overlap",
        "score_editorial", "rank_candidates", "validate_topic_clusters",
        "write_topic_artifacts", "validate_content_brief", "article_plan_scaffold",
        "validate_article_plan", "render_article_outline", "validate_article",
        "validate_article_acceptance", "refresh_acceptance_bindings")},
}
EXTERNAL_SKILLS = {"bycli", "knowledge-collection"}
PROGRAM_DEPENDENCIES = {
    "byclaw_caps.article": ["article/__main__.py", "article/runtime.py", "article/catalog.py", "article/agent.py"],
    "byclaw_caps.article.materials": ["article/__init__.py"],
    "byclaw_caps.editorial.rank_candidates": ["editorial/check_overlap.py", "editorial/score_editorial.py", "editorial/topic_cli_io.py"],
    "byclaw_caps.editorial.validate_content_brief": ["editorial/local_sources.py"],
    "byclaw_caps.editorial.validate_article_plan": ["editorial/local_sources.py", "editorial/amplifiers.py", "editorial/story_contract.py"],
    "byclaw_caps.editorial.validate_article": ["editorial/amplifiers.py", "editorial/story_contract.py"],
    "byclaw_caps.editorial.article_plan_scaffold": ["editorial/validate_article_plan.py", "editorial/local_sources.py", "editorial/story_contract.py"],
}


def program_files(name: str) -> list[Path]:
    package = Path(__file__).resolve().parent.parent
    return [package / rel for rel in [PROGRAMS[name], *PROGRAM_DEPENDENCIES.get(name, [])]]


def program_hashes(programs: list[str]) -> dict:
    if not isinstance(programs, list) or not programs or any(
            not isinstance(name, str) or name not in PROGRAMS for name in programs):
        raise ArticleError("agent 支持程序不在受控白名单")
    hashes = {}
    for name in programs:
        files = program_files(name)
        digests = [sha(path) for path in files]
        hashes[name] = digests[0] if len(digests) == 1 else hashlib.sha256(
            "\n".join(digests).encode("ascii")).hexdigest()
    return hashes


def definition_snapshot(component: dict) -> dict:
    return {"definition": component["definition_sha256"],
            "implementation_type": component["implementation"]["type"],
            "implementation": component.get("implementation_sha256", {}),
            "knowledge": component.get("knowledge_sha256", {}),
            "resources": component.get("resource_sha256", {}),
            "scripts": component.get("supporting_script_sha256", {}),
            "programs": component.get("supporting_program_sha256", {})}


def input_snapshot(root: Path, item: dict) -> dict:
    artifacts = load(root)["artifacts"]
    result = {}
    for slot, aid in item.get("inputs", {}).items():
        verify(root, aid, require_checks=False)
        result[slot] = {"artifact_id": aid, "path": artifacts[aid]["path"],
                        "sha256": artifacts[aid]["sha256"]}
    return result


def output_dir(root: Path, item: dict) -> str:
    stage_dirs = {"research": "10-research", "writing": "20-creative",
                  "illustration": "30-assets", "typesetting": "40-package"}
    base = f"{stage_dirs.get(item['stage_id'], item['stage_id'])}/{item['instance_id']}"
    raw = item.get("options", {}).get("output_dir", f"{base}/v1")
    if not isinstance(raw, str) or Path(raw).is_absolute():
        raise ArticleError("实例 output_dir 必须是相对路径")
    target = _inside(root, raw)
    if not target.is_relative_to(_inside(root, base)) or target == _inside(root, base):
        raise ArticleError("输出目录必须在分配的阶段和实例目录内")
    return target.relative_to(root).as_posix()


def file_bindings(definitions: list[dict]) -> dict:
    files = {}
    for definition in definitions:
        files[str(definition["definition_path"])] = definition["definition_sha256"]
        root = Path(definition["source_root"])
        for key in ("knowledge_sha256", "resource_sha256", "supporting_script_sha256"):
            files.update({str(root / rel): digest for rel, digest in definition.get(key, {}).items()})
        for name in definition.get("supporting_program_sha256", {}):
            files.update({str(path): sha(path) for path in program_files(name)})
    return files


def issue_receipt(root: Path, item: dict, package: dict, files: dict) -> dict:
    package = {**package, "binding_id": uuid4().hex, "files": files}
    _save(root / ".runtime/bindings" / f"{item['instance_id']}.yaml", package)
    return package


def validate_receipt(root: Path, item: dict, receipt: dict) -> None:
    validate_catalog_entries(receipt.get("catalog_entries", []))
    for path, digest in receipt.get("files", {}).items():
        if not Path(path).is_file() or sha(Path(path)) != digest:
            raise ArticleError("调用绑定的定义、知识、资源或支持程序已变化；请重新绑定")
    if receipt.get("inputs") != input_snapshot(root, item):
        raise ArticleError("调用绑定的输入版本失效；请重新绑定")
    if receipt.get("outputs") != item["outputs"] or receipt.get("output_dir") != output_dir(root, item):
        raise ArticleError("调用绑定与当前实例输出不符")


def validate_catalog_entries(entries: list) -> None:
    from .catalog import load_definition
    for entry in entries:
        definition = load_definition(entry["kind"], entry["id"], entry["root"],
                                     include_development=entry["status"] == "development")
        if definition["definition_sha256"] != entry["sha256"] or definition["status"] != entry["status"]:
            raise ArticleError("调用绑定的定义索引已变化")


def complete(root: Path, item: dict, result: dict) -> dict:
    receipt_path = root / ".runtime/bindings" / f"{item['instance_id']}.yaml"
    if not receipt_path.is_file():
        raise ArticleError("agent 完成前必须先 bind 并取得 binding_id")
    receipt = yaml.safe_load(receipt_path.read_text(encoding="utf-8"))
    if result.get("binding_id") != receipt.get("binding_id"):
        raise ArticleError("agent 完成回执的 binding_id 无效或已过期")
    validate_receipt(root, item, receipt)
    if result.get("input_snapshot") != receipt["inputs"]:
        raise ArticleError("agent 完成回执缺少当前输入快照")
    artifacts = load(root)["artifacts"]
    expected_inputs = {v["artifact_id"]: v["sha256"] for v in receipt["inputs"].values()}
    output_root = _inside(root, receipt["output_dir"])
    snapshots = {}
    for aid in item["outputs"].values():
        verify(root, aid, required_checks=set(receipt.get("required_checks", [])))
        artifact = artifacts[aid]
        if not _inside(root, artifact["path"]).is_relative_to(output_root):
            raise ArticleError("agent 输出产物越出分配目录")
        if any(artifact["inputs"].get(key) != value for key, value in expected_inputs.items()):
            raise ArticleError("agent 输出必须登记全部绑定输入依赖")
        snapshots[aid] = {"path": artifact["path"], "sha256": artifact["sha256"]}
    return {"input_snapshot": receipt["inputs"], "output_snapshot": snapshots,
            "binding_id": receipt["binding_id"], "binding_files": receipt["files"],
            "required_checks": receipt.get("required_checks", []),
            "catalog_entries": receipt.get("catalog_entries", [])}


def verify_completed(root: Path, item: dict, current: dict) -> None:
    validate_catalog_entries(current.get("catalog_entries", []))
    if current.get("input_snapshot") != input_snapshot(root, item):
        raise ArticleError("已完成实例输入版本失效")
    for path, digest in current.get("binding_files", {}).items():
        if not Path(path).is_file() or sha(Path(path)) != digest:
            raise ArticleError("已完成实例的定义或知识版本失效")
    artifacts = load(root)["artifacts"]
    for aid, snapshot in current.get("output_snapshot", {}).items():
        verify(root, aid, required_checks=set(current.get("required_checks", [])))
        if snapshot != {"path": artifacts[aid]["path"], "sha256": artifacts[aid]["sha256"]}:
            raise ArticleError("已完成实例输出版本失效")
