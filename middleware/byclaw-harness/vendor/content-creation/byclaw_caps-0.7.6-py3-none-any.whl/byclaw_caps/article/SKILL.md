---
name: article-artifacts
description: 当文章任务需要从现有输入直接进入、登记文件依赖、记录真实验收或导出成品快照时，使用公共产物契约能力。创作意图与语义判断由业务Skill组织。
---

# 文章任务与产物

业务请求与字段说明位于 self-media-article 的 references/contracts/direct-task.md。这里只提供稳定程序接口，不新增创作员工或外部工作流引擎。

```text
python3 -m byclaw_caps.article init --root <任务绝对目录> --request <请求.yaml>
python3 -m byclaw_caps.article register --root <任务根> --id article-1 --kind article --path 20-creative/article.md --input source-1
python3 -m byclaw_caps.article check --root <任务根> --id article-1
python3 -m byclaw_caps.article review --root <任务根> --id article-1 --report <实际检查.yaml>
python3 -m byclaw_caps.article verify --root <任务根> --id article-1
python3 -m byclaw_caps.article deliver --root <任务根> --artifact article-1 --delivery-id v1
python3 -m byclaw_caps.article show --root <任务根>
python3 -m byclaw_caps.article intents
```

显式工作流定义和本次计划使用以下入口；`--catalog-root` 指向活动 Skill 根目录，程序只从三个索引加载 `verified` 定义：

```text
python3 -m byclaw_caps.article catalog --catalog-root <Skill绝对目录>
python3 -m byclaw_caps.article plan --root <任务根> --catalog-root <Skill根> --plan-file <计划.yaml>
python3 -m byclaw_caps.article bind --root <任务根> --catalog-root <Skill根> --instance <实例ID>
python3 -m byclaw_caps.article stage-check --root <任务根> --stage <阶段ID> --mode <动作> --phase before|after
python3 -m byclaw_caps.article record-step --root <任务根> --instance <实例ID> --result <结果.yaml>
python3 -m byclaw_caps.article delivery-check --root <任务根> --artifact <产物ID>
```

`check` 只生成技术检查，不能证明语义、事实、翻译或画面。`review` 接收真实检查并绑定文件哈希；状态区分通过、失败、待验证和警告。更改原文或重登记输入后，依赖它的检查失效；修复后复验，不覆盖历史交付。导出前核对文件与资源完整性，必需图片也要加入 --artifact。交付不调用发布接口。

退出码：0 成功；1 文件、业务契约或验收不满足；2 参数用法错误。结果为 JSON，错误不应通过伪造历史审批或补全旧串行状态解决。
