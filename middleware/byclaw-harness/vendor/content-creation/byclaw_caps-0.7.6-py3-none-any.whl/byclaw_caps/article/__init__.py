"""按意图执行的文章任务与产物契约；与旧串行 workflow 并存。"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import time
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

import yaml

from byclaw_caps.credentials import reject_plaintext_secrets

INTENTS = {
    "research", "topics", "source_analysis", "outline", "write", "continue",
    "title_summary", "translate", "synthesize", "revise", "review", "humanize",
    "cover", "illustrate", "visual_plan", "image_text", "typeset", "html",
    "upload", "draft", "update_draft", "publish", "broadcast", "query",
}
KINDS = {
    "source", "research", "topics", "outline", "article", "title_summary",
    "translation", "review", "visual_plan", "image", "image_text_plan",
    "image_text", "html", "preview", "receipt", "resource", "plan",
}
REQUIRED = {
    "source": {"coverage"}, "research": {"sources", "relevance"},
    "topics": {"sources", "relevance"}, "outline": {"scope", "meaning"},
    "article": {"meaning", "facts", "scope"},
    "translation": {"fidelity", "terminology", "coverage"},
    "title_summary": {"meaning", "scope"}, "review": {"scope", "facts"},
    "visual_plan": {"relevance"}, "image": {"visual", "relevance"},
    "image_text_plan": {"meaning", "scope"},
    "image_text": {"visual", "meaning", "order"},
    "html": {"content_fidelity", "render"}, "preview": {"render"},
    "receipt": {"business_status"}, "resource": set(), "plan": {"scope"},
}
STAGES = {"research": "10-research", "topics": "10-research",
          "source_analysis": "10-research", "cover": "30-assets",
          "illustrate": "30-assets", "visual_plan": "30-assets",
          "image_text": "30-assets", "typeset": "40-package", "html": "40-package",
          **{k: "50-publish" for k in ("upload", "draft", "update_draft", "publish", "broadcast", "query")}}


class ArticleError(ValueError):
    pass


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _inside(root: Path, value: str) -> Path:
    path = (root / value).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ArticleError("路径越出任务根目录")
    return path


def _id(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", value):
        raise ArticleError("标识只接受字母数字、点、下划线与连字符，最长80字符")
    return value


def _save(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(yaml.safe_dump(value, allow_unicode=True, sort_keys=False), encoding="utf-8")
    # Windows readers can briefly hold the ledger without delete sharing.
    # Keep the old file intact and retry only the atomic replacement, with a
    # bounded delay; persistent access failures must still reach the caller.
    for attempt in range(6):
        try:
            temp.replace(path)
            return
        except OSError as exc:
            if getattr(exc, "winerror", None) not in {5, 32, 33} or attempt == 5:
                raise
            time.sleep(0.025 * 2 ** attempt)


def load(root: str | Path) -> dict:
    path = Path(root) / ".runtime/artifacts.yaml"
    if not path.is_file():
        raise ArticleError("任务未初始化；先运行 article init")
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def validate_request(request: dict) -> dict:
    if not isinstance(request, dict):
        raise ArticleError("任务请求必须是对象")
    reject_plaintext_secrets(request)
    intents = request.get("intents")
    if not isinstance(intents, list) or not intents or any(not isinstance(i, str) or i not in INTENTS for i in intents):
        raise ArticleError("intents 必须是支持意图的非空列表")
    if not isinstance(request.get("goal"), str) or not request["goal"].strip():
        raise ArticleError("goal 必须记录本次用户目标")
    if (not isinstance(request.get("deliverables"), list) or not request["deliverables"]
            or any(not isinstance(d, str) or not d.strip() for d in request["deliverables"])):
        raise ArticleError("deliverables 必须明确本次交付")
    language = request.get("target_language")
    if "translate" in intents and not language:
        raise ArticleError("翻译须明确 target_language")
    if "translate" in intents and request.get("translation_scope") not in {"full", "excerpt"}:
        raise ArticleError("翻译须明确 translation_scope: full|excerpt")
    return {**request, "schema_version": "1.0", "intents": list(dict.fromkeys(intents))}


def init(root: str | Path, request: dict) -> dict:
    root = Path(root).resolve()
    request = validate_request(request)
    marker = root / ".runtime/artifacts.yaml"
    if marker.exists():
        raise ArticleError("任务已存在；读取原索引恢复，不能覆盖初始化")
    for part in {"inputs", ".runtime", *(STAGES.get(i, "20-creative") for i in request["intents"])}:
        (root / part).mkdir(parents=True, exist_ok=True)
    state = {"schema_version": "1.0", "task_id": uuid4().hex, "revision": 1,
             "artifacts": {}, "deliveries": []}
    _save(root / ".runtime/request.yaml", request)
    _save(marker, state)
    return state


def register(root: str | Path, artifact_id: str, kind: str, path: str,
             inputs: list[str] | None = None, producer: str = "agent") -> dict:
    root = Path(root).resolve()
    state = load(root)
    _id(artifact_id)
    if kind not in KINDS:
        raise ArticleError("不支持的产物类型")
    target = _inside(root, path)
    if not target.is_file() or not target.stat().st_size:
        raise ArticleError("产物不存在或为空")
    relative = target.relative_to(root).as_posix()
    if relative.startswith((".runtime/", "delivery/")):
        raise ArticleError("索引与交付快照不能作为工作产物")
    refs = {}
    for name in inputs or []:
        if name == artifact_id:
            raise ArticleError("产物不能依赖自己")
        if name not in state["artifacts"]:
            raise ArticleError(f"未知输入 {name}")
        verify(root, name, require_checks=False, state=state)
        refs[name] = state["artifacts"][name]["sha256"]
    # 拒绝循环引用，即使文件哈希暂时相同。
    def reaches(name, seen):
        if name == artifact_id:
            return True
        if name in seen:
            return False
        return any(reaches(n, seen | {name}) for n in state["artifacts"][name]["inputs"])
    if any(reaches(n, set()) for n in refs):
        raise ArticleError("产物依赖形成循环")
    previous = state["artifacts"].get(artifact_id, {})
    item = {"artifact_id": artifact_id, "kind": kind, "path": relative,
            "sha256": sha(target), "revision": previous.get("revision", 0) + 1,
            "inputs": refs, "producer": producer, "checks": []}
    state["artifacts"][artifact_id] = item
    state["revision"] += 1
    _save(root / ".runtime/artifacts.yaml", state)
    return item


def verify(root: str | Path, artifact_id: str, *, require_checks: bool = True,
           state: dict | None = None, seen: set | None = None,
           required_checks: set[str] | None = None) -> dict:
    root = Path(root).resolve()
    state = state or load(root)
    if artifact_id not in state["artifacts"]:
        raise ArticleError(f"未知产物 {artifact_id}")
    seen = set() if seen is None else seen
    if artifact_id in seen:
        raise ArticleError("循环依赖")
    item = state["artifacts"][artifact_id]
    path = _inside(root, item["path"])
    if not path.is_file() or sha(path) != item["sha256"]:
        raise ArticleError(f"产物已变化或缺失：{artifact_id}")
    for name, digest in item["inputs"].items():
        verify(root, name, require_checks=False, state=state, seen=seen | {artifact_id})
        if state["artifacts"][name]["sha256"] != digest:
            raise ArticleError(f"输入版本失效：{artifact_id} <- {name}")
    if require_checks:
        latest = {}
        for ref in item["checks"]:
            report = _inside(root, ref["path"])
            if not report.is_file() or sha(report) != ref["sha256"]:
                raise ArticleError("检查报告已变化")
            data = yaml.safe_load(report.read_text(encoding="utf-8"))
            if data.get("subject_sha256") != item["sha256"]:
                raise ArticleError("检查未绑定当前产物")
            for check in data["checks"]:
                latest[check["name"]] = check
        for check in latest.values():
            if check["status"] == "fail":
                raise ArticleError(f"检查失败：{check['name']}")
        passed = {name for name, check in latest.items() if check["status"] == "pass"}
        missing = (REQUIRED[item["kind"]] | {"technical"} | (required_checks or set())) - passed
        if missing:
            raise ArticleError("尚缺通过的检查：" + ", ".join(sorted(missing)))
    return {"ok": True, "artifact_id": artifact_id, "sha256": item["sha256"]}


def record_check(root: str | Path, artifact_id: str, report: dict) -> dict:
    root = Path(root).resolve()
    state = load(root)
    verify(root, artifact_id, require_checks=False, state=state)
    item = state["artifacts"][artifact_id]
    if not isinstance(report, dict):
        raise ArticleError("检查报告必须是对象")
    reject_plaintext_secrets(report)
    if report.get("subject_sha256") != item["sha256"]:
        raise ArticleError("报告的 subject_sha256 与当前文件不符")
    if not report.get("reviewer") or not isinstance(report.get("checks"), list) or not report["checks"]:
        raise ArticleError("报告须包含 reviewer 及非空 checks")
    for check in report["checks"]:
        if (not isinstance(check, dict) or not isinstance(check.get("name"), str)
                or not check["name"].strip() or check.get("status") not in {"pass", "fail", "pending", "warning"}):
            raise ArticleError("检查需 name 及 pass|fail|pending|warning 状态")
        if check.get("method") not in {"program", "model", "human", "target_environment"} or not check.get("evidence"):
            raise ArticleError("检查需声明 method 与具体 evidence，不自动生成语义通过结论")
    path = root / ".runtime/checks" / f"{artifact_id}-{uuid4().hex[:12]}.yaml"
    _save(path, report)
    # 最新同名检查生效，其他已检查维度保留；历史报告不可覆写。
    item["checks"].append({"path": path.relative_to(root).as_posix(), "sha256": sha(path)})
    _save(root / ".runtime/artifacts.yaml", state)
    return {"report": path.relative_to(root).as_posix(), "checks": report["checks"]}


def technical_check(root: str | Path, artifact_id: str) -> dict:
    root = Path(root).resolve()
    state = load(root)
    verify(root, artifact_id, require_checks=False, state=state)
    item = state["artifacts"][artifact_id]
    path = _inside(root, item["path"])
    findings = []
    if item["kind"] == "image" or path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
        from byclaw_caps.image import read_dimensions, read_format
        width, height = read_dimensions(path)
        fmt = read_format(path)
        if width <= 0 or height <= 0 or fmt not in {"png", "jpeg", "webp", "PNG", "JPEG", "WEBP"}:
            raise ArticleError("实际图片格式或尺寸无效")
        findings.append(f"decoded_header={fmt}; pixels={width}x{height}; 需另做画面复核")
    elif item["kind"] == "html":
        from byclaw_caps.compile import validate_channel_html
        result = validate_channel_html(path.read_text(encoding="utf-8"))
        if not result.get("ok", result.get("status") == "pass"):
            raise ArticleError("渠道 HTML 校验失败：" + json.dumps(result, ensure_ascii=False))
        findings.append("公共编译器渠道红线检查通过；不代表目标编辑器粘贴通过")
    elif item["kind"] == "source" and path.suffix.lower() in {".pdf", ".docx", ".pptx"}:
        from byclaw_caps.article.materials import extract
        result = extract(path)
        findings.append(f"原件哈希已登记；提取{len(result['units'])}个文本单元；coverage={result['coverage']}；需另核对读取范围")
    elif item["kind"] == "resource" and path.suffix.lower() not in {".md", ".txt", ".json", ".yaml", ".yml", ".csv", ".html", ".css", ".svg"}:
        findings.append("二进制资源非空且哈希一致；不代表格式或内容验收")
    else:
        text = path.read_text(encoding="utf-8")
        if re.search(r"\[\[visual:|\{\{(?:TODO|PLACEHOLDER)", text):
            raise ArticleError("存在未解析占位符")
        findings.append("文件非空，UTF-8可读，无未解析视觉占位符；需另做语义检查")
    report = {"subject_sha256": item["sha256"], "reviewer": "byclaw_caps.article",
              "checks": [{"name": "technical", "status": "pass", "method": "program", "evidence": "; ".join(findings)}]}
    return record_check(root, artifact_id, report)


def local_resources(root: Path, path: Path) -> set[Path]:
    """核对本地引用，保留相对目录结构；不联网验证远程URL。"""
    values = []
    if path.suffix.lower() in {".html", ".htm"}:
        class References(HTMLParser):
            def handle_starttag(self, tag, attrs):
                for name, value in attrs:
                    if value and (name == "src" or (tag == "link" and name == "href")):
                        values.append(value)
        References().feed(path.read_text(encoding="utf-8"))
    elif path.suffix.lower() == ".md":
        values = re.findall(r'!\[[^\]]*\]\(([^)]+)\)', path.read_text(encoding="utf-8"))
    found = set()
    for value in values:
        url = urlsplit(value.strip().strip('<>'))
        if url.scheme in {"http", "https", "data"} or value.startswith("#"):
            continue
        if url.scheme or url.netloc or Path(unquote(url.path)).is_absolute() or url.path.startswith("/"):
            raise ArticleError("交付不接受本机绝对资源URL：" + value)
        target = (path.parent / unquote(url.path)).resolve()
        if not target.is_relative_to(root) or not target.is_file():
            raise ArticleError("本地引用不存在或越界：" + value)
        found.add(target)
    return found


def deliver(root: str | Path, artifact_ids: list[str], delivery_id: str | None = None) -> dict:
    root = Path(root).resolve()
    state = load(root)
    delivery_id = _id(delivery_id or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid4().hex[:6])
    target = _inside(root, "delivery/" + delivery_id)
    if target.exists():
        raise ArticleError("交付编号已存在；不覆盖历史快照")
    entries = []
    for name in artifact_ids:
        verify(root, name, state=state)
        item = state["artifacts"][name]
        if not any(c for c in item["checks"]):
            raise ArticleError("交付需要检查记录")
        entries.append({k: item[k] for k in ("artifact_id", "kind", "path", "sha256", "inputs", "checks")})
    if not entries:
        raise ArticleError("交付列表不能为空")
    included = {_inside(root, item["path"]) for item in entries}
    for item in entries:
        missing = local_resources(root, _inside(root, item["path"])) - included
        if missing:
            raise ArticleError("交付缺少被引用资源，请登记并加入 --artifact：" + ", ".join(p.relative_to(root).as_posix() for p in missing))
    target.mkdir(parents=True)
    for item in entries:
        dest = target / item["path"]
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_inside(root, item["path"]), dest)
        if sha(dest) != item["sha256"]:
            raise ArticleError("导出期间文件变化；快照未完成")
    manifest = {"schema_version": "1.0", "task_id": state["task_id"], "delivery_id": delivery_id,
                "artifacts": entries}
    _save(target / "manifest.yaml", manifest)
    state["deliveries"].append({"delivery_id": delivery_id, "manifest": f"delivery/{delivery_id}/manifest.yaml"})
    _save(root / ".runtime/artifacts.yaml", state)
    return manifest
