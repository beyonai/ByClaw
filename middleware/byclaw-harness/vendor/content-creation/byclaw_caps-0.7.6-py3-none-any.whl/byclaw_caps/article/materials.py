"""本地素材文本提取；原件独立保留，不把文本提取当作完整视觉读取。"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
from xml.etree import ElementTree as ET
from zipfile import BadZipFile, ZipFile
from byclaw_caps.article import sha, ArticleError


def extract(path: str | Path) -> dict:
    try:
        return _extract(path)
    except (BadZipFile, ET.ParseError, KeyError) as exc:
        raise ArticleError(f'Office原件结构不可读取：{type(exc).__name__}；未声明已读取内容') from exc


def _extract(path: str | Path) -> dict:
    source = Path(path).resolve()
    suffix = source.suffix.lower()
    units = []
    limitations = []
    if suffix in {'.md', '.txt', '.csv', '.json', '.yaml', '.yml'}:
        units = [{'unit': 'document', 'text': source.read_bytes().decode('utf-8-sig')}]
    elif suffix in {'.docx', '.pptx'}:
        with ZipFile(source) as archive:
            if suffix == '.docx':
                names = ['word/document.xml']
                namespace = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
            else:
                names = sorted((n for n in archive.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml', n)),
                               key=lambda n: int(re.search(r'slide(\d+)\.xml', n).group(1)))
                namespace = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
            for name in names:
                tree = ET.fromstring(archive.read(name))
                paragraphs = [''.join(p.itertext()) for p in tree.iter(namespace + 't')]
                units.append({'unit': name, 'text': '\n'.join(paragraphs)})
        limitations.append('仅提取正文/幻灯片文本；图片、图表、批注、页眉页脚、版面与讲者备注未读取，表格单元格按文本顺序提取')
    elif suffix == '.pdf':
        try:
            from pypdf import PdfReader
            from pypdf.errors import PyPdfError
        except ImportError as exc:
            raise ArticleError('PDF文本提取需部署安装 byclaw-caps[documents]；未配置OCR') from exc
        try:
            reader = PdfReader(source)
            if reader.is_encrypted:
                raise ArticleError('加密PDF须提供可读取版本，不猜密码')
            units = [{'unit': f'page-{n}', 'text': page.extract_text() or ''} for n, page in enumerate(reader.pages, 1)]
        except PyPdfError as exc:
            raise ArticleError(f'PDF原件不可读取：{type(exc).__name__}；需提供可读版本') from exc
        limitations.append('仅PDF文本层；扫描件、图片、复杂表格和阅读顺序未做OCR/视觉核验')
    else:
        raise ArticleError('未支持的本地格式；PPT旧二进制文件请用宿主文档能力转为PPTX或PDF后读取')
    if not units or not any(u['text'].strip() for u in units):
        raise ArticleError('未提取到文本；不能声明已阅读全文，需要OCR/视觉读取或可读原文')
    empty = [u['unit'] for u in units if not u['text'].strip()]
    if empty: limitations.append('无可读文本的页/单元：' + ', '.join(empty))
    return {'schema_version': '1.0', 'source': str(source), 'source_sha256': sha(source),
            'coverage': 'text_layer_only' if limitations else 'full_text',
            'limitations': limitations, 'units': units}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input', required=True)
    p.add_argument('--output', required=True)
    a = p.parse_args()
    try:
        result = extract(a.input)
        output = Path(a.output)
        if output.resolve() == Path(a.input).resolve(): raise ArticleError('不得覆盖原件')
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps({'ok': True, 'output': str(output), 'coverage': result['coverage'], 'limitations': result['limitations']}, ensure_ascii=False))
        return 0
    except (ValueError, OSError) as e:
        print(json.dumps({'ok': False, 'error': str(e)}, ensure_ascii=False))
        return 1


if __name__ == '__main__': raise SystemExit(main())
