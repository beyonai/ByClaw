#!/usr/bin/env python3
"""Infographic 图层拆分：把一张信息图拆成底板 + 逐条目的透明图层。

为什么要拆：用户说动画「毫无逻辑」，根因是**整张图第一帧就全给了**，
旁白还在讲第一点。要做到「讲到哪个、哪个才出现」，图必须能分层。

## 这是模板适配器，不是通用 SVG 拆分

第一版方案打算按 `<g>` 顺序拆，判据是「层数等于 DSL 条目数」。
**那只证明没少拆，不证明对应正确**——完全可能「第一个月」那一层叠上的是标题或箭头。

而且中文全在 ``<foreignObject>`` 里：实测一份产出，``foreignObject`` 16 次、
``<text>`` **0 次**。第一版做过一次结构验证，当时文本读出来是空的，
我判断是 symbol/use 所致、不影响结论——**那个判断是错的**。

所以收窄成：

1. 只支持验证过的 ``sequence-*`` / ``list-*``
2. **锁定引擎版本**——结构变了而适配器不知道，会静默拆错
3. 拿**已知的 DSL label** 去找 ``foreignObject``，再向上找共同语义容器
4. label、索引、层数三重一致
5. 未支持的模板**退回静态图，不自动猜**

第 3 条是关键：label 是我们自己写进 DSL 的，这是「拿已知答案去核对」，
不是「从 DOM 里猜语义」。
"""

from __future__ import annotations

import copy
import re
import xml.etree.ElementTree as ET

VERSION = "1.0.0"

#: 已验证过结构的引擎版本。**升版必须重跑适配器测试**——
#: 版式一变，向上找容器的层数就可能不同，而拆错了画面上看不出来。
VERIFIED_ENGINE_VERSION = "0.2.20"

#: 支持拆层的模板族。**逐族真跑一遍定的，不是按名字猜的。**
#:
#: | 族 | 渲染 | 拆层 | 结论 |
#: |---|---|---|---|
#: | `sequence-*` | ✓ | 不串味 | 支持 |
#: | `list-*` | ✓ | 不串味 | 支持 |
#: | `hierarchy-*` | ✓ | 不串味 | 支持 |
#: | `chart-*` | ✓ | 不串味 | **刻意不支持**，见 REFUSED_FAMILIES |
#: | `compare-*` | ✓ | — | 不可用：硬编码英文 PROS/CONS 并丢弃中文标签 |
#: | `relation-*` | ✓ | — | 不可用：根本不画 relations |
SUPPORTED_FAMILIES: frozenset[str] = frozenset({"sequence", "list", "hierarchy"})

#: 拆得出来、但**不该拆**的族，附带理由。
#:
#: 只说「不支持」的话，人会以为是没做完，然后想办法绕过去——
#: 所以拒绝必须带上原因。
REFUSED_FAMILIES: dict[str, str] = {
    "chart": ("图表能拆得干净，但**柱子的高度就是数据本身**。"
              "逐根出现时观众看到的是一个不完整的分布，很容易读成「就这么多」——"
              "误读比看不见更坏。图表要么整幅出现，要么不出现。"),
    "compare": ("对比族连静态图都不可用：模板硬编码英文 PROS/CONS，"
                "丢弃中文标签，箭头语义还是反的。"),
    "relation": "关系族根本不画 relations，只把节点摆成一圈，看不出方向。",
}

_SVG_NS = "http://www.w3.org/2000/svg"


class LayerError(RuntimeError):
    """模板不支持、引擎版本不符，或 label 定位不到唯一容器。"""


def supports_template(template: str) -> bool:
    return str(template or "").split("-", 1)[0] in SUPPORTED_FAMILIES


def _tag(element) -> str:
    return element.tag.split("}")[-1]


def _texts(element) -> list[str]:
    """收集元素内的全部可见文字。**必须走 foreignObject 里的 HTML**。"""
    out = []
    for node in element.iter():
        for chunk in node.itertext():
            value = chunk.strip()
            if value:
                out.append(value)
    return out


def split_layers(svg: str, *, labels, template: str,
                 engine_version: str = VERIFIED_ENGINE_VERSION) -> dict:
    """拆成 ``{"base": svg, "layers": [{"label", "index", "svg"}]}``。

    Raises:
        LayerError: 模板不支持、版本不符、label 找不到或不唯一。
    """
    family = str(template or "").split("-", 1)[0]
    if family in REFUSED_FAMILIES:
        raise LayerError(
            f"模板族 {family}-* 不做分步：{REFUSED_FAMILIES[family]}"
            "  改用整幅静态图。")
    if not supports_template(template):
        raise LayerError(
            f"模板 {template!r} 不在支持列表内（{'、'.join(sorted(SUPPORTED_FAMILIES))}-*）"
            "——退回静态图，不自动猜语义")
    if str(engine_version) != VERIFIED_ENGINE_VERSION:
        raise LayerError(
            f"引擎版本 {engine_version} 与已验证的 {VERIFIED_ENGINE_VERSION} 不符——"
            "版式一变，向上找容器的层数就可能不同，而拆错了画面上看不出来")

    wanted = [str(x) for x in (labels or [])]
    if not wanted:
        raise LayerError("labels 为空——没有条目就没有分步可言")
    if len(set(wanted)) != len(wanted):
        raise LayerError("labels 里有重名条目，无法唯一定位")

    ET.register_namespace("", _SVG_NS)
    root = ET.fromstring(svg)
    parents = {child: parent for parent in root.iter() for child in parent}

    owners = []
    for label in wanted:
        holders = [n for n in root.iter()
                   if _tag(n) == "foreignObject" and label in _texts(n)]
        if not holders:
            raise LayerError(
                f"SVG 里找不到 label {label!r}——DSL 写了而图上没有。"
                "少一层就是画面上少一个元素，而 ffmpeg 退出码照样是 0")
        if len(holders) > 1:
            raise LayerError(f"label {label!r} 出现 {len(holders)} 次，无法唯一定位")
        node = holders[0]
        others = [x for x in wanted if x != label]
        owner = node
        while True:
            parent = parents.get(owner)
            if parent is None or parent is root:
                break
            texts = _texts(parent)
            if any(other in texts for other in others):
                break          # 再往上就会圈进别的条目，当前这层才是语义容器
            owner = parent
        owners.append((label, owner))

    # 三重一致：数量对得上、label 对得上、文档顺序对得上。
    if len(owners) != len(wanted):
        raise LayerError(f"拆出 {len(owners)} 层，labels 有 {len(wanted)} 个")
    order = [list(root.iter()).index(owner) for _, owner in owners]
    if order != sorted(order):
        raise LayerError(
            "label 顺序与文档顺序不一致——说明找错了容器，"
            "叠上去会出现「讲第一点、亮第三个」")

    owner_set = {id(owner) for _, owner in owners}

    def clone_without(drop_ids: set[int], *, keep_background: bool) -> str:
        tree = copy.deepcopy(root)
        # 深拷贝后 id 全变，靠「文档中的序号」重新定位。
        originals = list(root.iter())
        copies = list(tree.iter())
        index_map = {id(o): i for i, o in enumerate(originals)}
        drop_indexes = {index_map[i] for i in drop_ids if i in index_map}
        cparents = {c: p for p in tree.iter() for c in p}
        for idx in sorted(drop_indexes, reverse=True):
            node = copies[idx]
            parent = cparents.get(node)
            if parent is not None:
                parent.remove(node)
        if not keep_background:
            for node in list(tree):
                if _tag(node) == "rect":
                    tree.remove(node)      # 透明叠加：白底会把下层整块盖住
        return ET.tostring(tree, encoding="unicode")

    base = clone_without(owner_set, keep_background=True)
    layers = []
    for index, (label, owner) in enumerate(owners):
        others = {id(o) for _, o in owners} - {id(owner)}
        layers.append({"label": label, "index": index,
                       "svg": clone_without(others, keep_background=False)})
    return {"base": base, "layers": layers, "template": template,
            "engine_version": engine_version}


__all__ = ["VERSION", "VERIFIED_ENGINE_VERSION", "SUPPORTED_FAMILIES",
           "REFUSED_FAMILIES",
           "LayerError", "supports_template", "split_layers"]
