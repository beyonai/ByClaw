#!/usr/bin/env python3
"""Finalize generated PNG assets and write synchronized JSON/YAML manifests."""

from __future__ import annotations

import argparse
from datetime import datetime
import json
from pathlib import Path
from typing import Any

from byclaw_caps.image.inspect_visual import read_inspection
from byclaw_caps.image.manifest import (
    SCHEMA_VERSION,
    file_sha256,
    png_dimensions,
    read_json,
    resolve_asset_path,
    validate_manifest,
    write_manifest_pair,
)
from byclaw_caps.shared.diagram_tokens import delivered_size, delivery_scale_for
from byclaw_caps.shared.render_contract import (
    INPUT_FINGERPRINT_MISMATCH, PLAN_FINGERPRINT_MISMATCH,
)
from byclaw_caps.image import semantic_review


def parse_asset_mapping(values: list[str]) -> dict[str, str]:
    mappings: dict[str, str] = {}
    for value in values:
        asset_id, separator, file_path = value.partition("=")
        asset_id, file_path = asset_id.strip(), file_path.strip()
        if not separator or not asset_id or not file_path or asset_id in mappings:
            raise ValueError(f"非法或重复 --asset，必须为 asset_id=file.png: {value}")
        mappings[asset_id] = file_path
    return mappings


#: 确定性渲染出来的图**必须**有机器检查记录。其余生成方式（AI 生图、封面合成、
#: 既有截图）没有 HTML 可探，只能由人确认——那就如实写 `declared`，不写 `pass`。
INSPECTABLE_METHODS = frozenset({"html_svg", "infographic", "svg_file"})


def _validation_block(
    asset_id: str,
    item: dict[str, Any],
    *,
    asset_directory: Path,
    plan: dict[str, Any],
    image_path: Path,
    sha: str,
    reviewed: bool,
) -> dict[str, Any]:
    """按**真实证据**填 validation，不写字面量。

    原先这里是一段无条件的 `{"crop": "pass", "text_legibility": "pass", …}`，
    而 `--reviewed-all` 连这几个字面量都管不着。2026-09-11 交付的清单里
    四张图的 `text_legibility: pass` 因此全是伪证——`image inspect`
    那次一遍都没跑成功过，没有任何东西量过可读性。

    三种取值，含义不同，不许混：

    | 值 | 含义 |
    |---|---|
    | `pass` / `fail` | **机器验过**，来自 inspect 记录 |
    | `declared` | 人声明看过了，机器没验——AI 生图这类没有 HTML 可探 |
    | `not_reviewed` | 既没机器验也没人声明 |
    """
    method = str(item.get("generation_method") or "")
    human = "declared" if reviewed else "not_reviewed"
    block: dict[str, Any] = {
        # 语义复核：方向、推导、否定词、must_cover。**与画面检查是两类证据**，
        # inspect 全过也不代表图讲对了——见 _semantic_block。
        "semantic_review": _semantic_block(asset_id, item,
                                           asset_directory=asset_directory,
                                           sha=sha, plan=plan),
        # 尺寸这一项一直是真的：上面刚按交付像素比对过。
        "dimensions": "pass",
        "sequence": "pass",
        # 事实边界机器判不了（要读正文与证据），只能是人的声明。
        "factual_scope": human,
        "file_size_bytes": image_path.stat().st_size,
        "sha256": sha,
    }
    if method not in INSPECTABLE_METHODS:
        # 没有 HTML 可探。**如实标注，不要借机写 pass。**
        block.update({"crop": human, "text_legibility": human,
                      "inspection": {"applicable": False, "reason": f"{method} 无 HTML 可探"}})
        return block

    record = read_inspection(asset_directory, asset_id)
    if record is None:
        raise ValueError(
            f"{asset_id} 缺少检查记录。确定性渲染的图必须先过 "
            f"`python3 -m byclaw_caps.image inspect <源.html> --plan <plan.json> "
            f"--asset {asset_id} --render <出.png>`——"
            "**没有记录就没有证据说这张图可读**，清单里不会替你写 pass。")
    if str(record.get("status") or "") != "pass":
        raise ValueError(
            f"{asset_id} 的检查记录是 {record.get('status')!r}，不是 pass："
            + "；".join(str(f.get("detail") or "") for f in (record.get("failures") or []))
            + "。修 HTML 后重跑 inspect。")
    if str(record.get("plan_id") or "") != str(plan.get("plan_id") or ""):
        # 契约里的 `PLAN_FINGERPRINT_MISMATCH` 就是这一条：产物所依据的计划
        # 与当前计划不是同一份。**按错误码分类而不是只给一句人话**——
        # 调用方要能区分"来源变了""计划变了""图换了"，三者的修法完全不同。
        raise ValueError(
            f"{PLAN_FINGERPRINT_MISMATCH}：{asset_id} 的检查记录属于另一份计划"
            f"（{record.get('plan_id')}），当前是 {plan.get('plan_id')}。重跑 inspect。")
    # **这一条是整条证据链的锚点**：记录里的 PNG 哈希必须等于正在登记的这张图。
    # 对不上说明图在检查之后又被重渲或替换过——那份检查就不再作数。
    if str(record.get("output_sha256") or "") != sha:
        raise ValueError(
            f"{asset_id} 的检查记录对应的不是这张图（哈希不符）。"
            "多半是 inspect 之后又重渲过，或 inspect 时没带 --render。"
            "重跑一次带 --render 的 inspect。")
    block.update({
        "crop": "pass",
        "text_legibility": "pass",
        "inspection": {
            "applicable": True,
            "source": record.get("source"),
            "source_sha256": record.get("source_sha256"),
            "inspected_at": record.get("inspected_at"),
            "warnings": [str(w.get("check") or "") for w in (record.get("warnings") or [])],
            "min_font_px": (record.get("stats") or {}).get("min_font_px"),
            "min_landing_px": (record.get("stats") or {}).get("min_landing_px"),
        },
    })
    return block


def _declares_evidence(plan: dict[str, Any]) -> bool:
    return any((entry.get("depends_on") or {}).get("evidence")
               for entry in (plan.get("visuals") or {}).values())


def _current_evidence(plan: dict[str, Any]) -> dict[str, dict]:
    """当前的证据表——从 ArticlePlan 重新读，不用计划里存的那份快照。

    **快照是"当时是什么"，判定要问的是"现在是什么"。** 拿快照跟自己比，
    这一项永远相等，等于没查。
    """
    from ..shared import visual_semantics as vs

    raw = str((plan.get("document") or {}).get("article_plan_path")
              or plan.get("article_plan_path") or "")
    path = Path(raw)
    if not path.is_file():
        if _declares_evidence(plan):
            # 声明了证据依赖却找不到证据来源：**不放行也不猜**。
            raise ValueError(
                f"计划声明了证据依赖，却找不到 ArticlePlan：{path or '（未记录路径）'}。"
                "无法判断证据是否仍然成立。重跑一编，让它把 article_plan_path 记进来。")
        return {}
    text = path.read_text(encoding="utf-8")
    try:
        import yaml  # type: ignore

        article_plan = yaml.safe_load(text) or {}
    except ImportError:
        article_plan = json.loads(text)
    return vs.evidence_index(article_plan if isinstance(article_plan, dict) else {})


def _check_sources_fresh(plan: dict[str, Any]) -> None:
    """这份计划的依据，还是当前正文吗。

    **按 `visual_id` 逐张判，不看全文指纹。** 只比全文哈希的话，改第 5 节
    会让第 1 节的图也失配——PNG 还在，却进不了门禁，"局部复用"名存实亡。

    没有 `visuals` 记录的（存量、或没走二编的）一概跳过：
    存量的豁免与规划豁免必须同口径，否则这条会变成"所有旧会话都跑不通"。
    """
    visuals = plan.get("visuals") or {}
    if not visuals:
        return
    article = Path(str((plan.get("document") or {}).get("article_path")
                       or plan.get("article_path") or ""))
    if not article.is_file():
        # 正文找不到时**不放行也不猜**：说清楚缺什么。
        raise ValueError(
            "计划带了按图粒度的依赖记录，却找不到它依据的正文："
            f"{article}。无法判断依据是否仍然成立。")
    from ..shared import visual_semantics as vs

    markdown = article.read_text(encoding="utf-8")
    # **证据也要重新读一遍。** 不读的话当前证据表恒为空，于是每一条
    # `depends_on.evidence` 都查不到对应项、一律判成"变了"——
    # 凡是声明了证据依赖的图都登记不了，而输入其实一个字没动。
    stale = vs.stale_visuals(
        plan, vs.current_fingerprints(markdown, _current_evidence(plan)))
    if stale:
        raise ValueError(
            f"{INPUT_FINGERPRINT_MISMATCH}：这几张图的依据已经变了——"
            f"{'、'.join(stale)}。\n"
            "它们所依据的那一节正文（或证据）在出图之后被改过，"
            "**旧图配新正文正是这道门禁要拦的**。\n"
            "重跑二编与语义复核；没被改到的图不受影响，不用重做。")


def _session_is_new(asset_directory: Path) -> bool:
    """这个会话是不是本契约之后新建的——**问工作流，不问调用方**。

    判据是 `init_workflow` 盖在状态里的 `contract_era`：它出自工具链，
    调用方给不了也省不掉。配图与排版据此用**同一套任务分类**，
    不各自解释一遍。

    读不到状态时按存量处理：那多半是脱离会话在跑（调试、单测），
    此时硬判成新任务只会把存量路径一起堵死。
    """
    try:
        from ..workflow import load_state
    except ImportError:  # pragma: no cover - 能力层被单独安装时
        return False
    root = Path(asset_directory).resolve().parent
    try:
        return bool(load_state(root).get("contract_era") or "")
    except Exception:
        return False


def _current_review_input_sha256(asset_id: str, item: dict[str, Any], *,
                                 asset_directory: Path) -> str:
    """按**当前**的计划项与设计重算复核输入指纹。

    **重算不出来就失败，不回落到缓存值。**

    早先这里在"文件不存在 / JSON 损坏 / 找不到这个 visual_id"三种情况下
    都返回 `None`，调用方随即跳过这一项——于是出现了比不查更糟的局面：
    设计文件完整时，改 `must_avoid` 会被正确阻断；**把那个文件删掉或弄坏，
    反而放行**。等于"损坏证据"成了通过的办法，而这一项要查的恰恰是
    "报告绑的是不是当前这一版设计"。

    无从重算属于"判不了"，判不了不能当通过——与语义复核里
    `inconclusive` 的处理是同一条规矩。
    """
    import json as _json

    from ..shared import visual_semantics as vs

    design_path = asset_directory / ".meta" / "visual-design.json"
    if not design_path.is_file():
        raise ValueError(
            f"{asset_id} 的计划带了复核指纹，却找不到 VisualDesign"
            f"（{design_path}）。\n"
            "**无从重算不等于校验通过**——没有设计就无法判断报告绑的是哪一版。\n"
            "重跑二编，或从交接里取回 visual-design.json。")
    try:
        document = _json.loads(design_path.read_text(encoding="utf-8"))
    except (ValueError, OSError) as failure:
        raise ValueError(
            f"{asset_id} 的 VisualDesign 读不出来：{failure}\n"
            "**损坏的证据不是缺席的证据**，更不是通过。"
            "重跑二编产出这份文件，不要手工补 JSON。") from failure
    design = next((one for one in (document.get("visuals") or [])
                   if isinstance(one, dict)
                   and str(one.get("visual_id") or "") == asset_id), None)
    if design is None:
        raise ValueError(
            f"VisualDesign 里没有 {asset_id} 这一项，无法重算它的复核指纹。\n"
            "计划里有这张图、设计里没有，说明两者不是同一轮产出的。重跑二编。")
    return vs.review_input_sha256(vs.build_review_input(
        visual_id=asset_id, sources=item.get("sources") or {},
        plan_item=item, design=design))


def _semantic_block(asset_id: str, item: dict[str, Any], *,
                    asset_directory: Path, sha: str,
                    plan: dict[str, Any]) -> dict[str, Any]:
    """语义复核这一项。

    **有规划的图必须有复核，没规划的存量不卡。** 两处豁免同口径：
    若复核是登记前置、而存量允许无规划，存量就会被复核卡死
    ——那会把这条改动变成"所有旧会话都跑不通"。

    判据是 `semantic_planned`：二编产出的计划会带 `True`，
    存量走兼容路径时显式标 `False`。
    """
    # **先按工作流判任务分类，再谈任何兼容分支。**
    #
    # 上一轮把这个判定只加在了 `semantic_planned=false` 那一支，
    # 而它前面还有一支：计划没盖 `semantic_contract` 就整体豁免。
    # 于是新会话换一份旧编译器出的计划，照样免掉整条语义链——
    # **兼容分支自己成了绕过口**。任务分类必须先问，不能各分支各判一次。
    new_session = _session_is_new(asset_directory)
    if new_session and not plan.get("semantic_contract"):
        raise ValueError(
            f"{asset_id} 用的计划没有 semantic_contract 标记，"
            "而这是本契约之后新建的会话。\n"
            "**新任务不能拿旧编译器出的计划来豁免**——"
            "那等于用一份过期的工具链绕开整条语义链。\n"
            "重跑一编与二编，产出带标记的计划。")
    if not plan.get("semantic_contract"):
        # 存量会话 + 旧编译器出的计划：整体豁免。
        #
        # **判据是工具链盖在计划上的标记，不是调用方填没填字段。**
        # 用后者的话，省掉一个字段就能豁免整条语义链；反过来，
        # 把"字段缺失"一律判成错，又会让所有存量会话当场跑不通。
        return semantic_review.skipped(
            "计划无 semantic_contract 标记：出自一期之前的编译器，按存量处理")
    if "semantic_planned" not in item:
        # 新编译器出的计划**必须**逐项说明。说不清就不能登记。
        raise ValueError(
            f"{asset_id} 的计划带 semantic_contract 却没有 semantic_planned 字段，"
            "无法判断它走的是语义规划路径还是存量兼容路径。\n"
            "**省掉这个字段不构成豁免**：走二编的计划会带 true；"
            "存量要显式写 false 并给 compat_reason。")
    if not item.get("semantic_planned"):
        # **豁免不能由被豁免的一方自己声明。**
        #
        # 早先这里只要 `compat_reason` 非空就放行——那是一段调用方自己写的文本，
        # 填「存量兼容」四个字就能免掉整条语义链。写不写得出理由不是判据，
        # **这个会话是不是新任务才是**，而那件事只有工作流说了算。
        if new_session:
            raise ValueError(
                f"{asset_id} 标了 semantic_planned: false，但这是本契约之后"
                "新建的会话，**新任务没有存量豁免**。\n"
                "走二编产出语义规划，再做语义复核；"
                "确实画不出来时用 `encoding: none_fit` 保留待办，"
                "那条路不登记完成，但也不会假装验过。")
        reason = str(item.get("compat_reason") or "").strip()
        if not reason:
            raise ValueError(
                f"{asset_id} 标了 semantic_planned: false 却没写 compat_reason。"
                "存量豁免也要留痕，否则它和「忘了规划」长得一模一样。")
        return semantic_review.skipped(
            f"semantic_planned 为假：存量会话的兼容路径（{reason}），不要求语义复核")
    record = semantic_review.read_review(asset_directory, asset_id)
    # **复核报告绑的是哪一版输入，必须一起核。** 只比 PNG 哈希的话，
    # 设计改了而图恰好没重渲时，旧报告照样返回 pass。
    if record is None:
        # 连报告都没有时，先说这件事——比"缺指纹"切题得多。
        # 两者都拦，差别只在报出来的那句话有没有指向下一步。
        return semantic_review.check_review(record, asset_id=asset_id,
                                            output_sha256=sha)
    expected = str(((plan.get("visuals") or {}).get(asset_id) or {})
                   .get("review_input_sha256") or "")
    if not expected:
        # **指纹缺失不是"这一项不用查"。**
        # 早先这里写 `... or None`，而 `check_review` 收到 None 就跳过这一项——
        # 于是把计划里那行删掉就能让任意旧报告通过，绕开的正是"报告绑的是哪一版"。
        # 计划带 semantic_contract 却没有这个值，只说明二编没跑或跑的是旧版。
        raise ValueError(
            f"{asset_id} 的计划里没有 review_input_sha256，无法核对复核报告"
            "绑定的是不是当前这一版设计。\n"
            "**缺指纹不等于免核**：重跑二编，让它把这个值算进计划。")
    # **缓存的指纹要跟当前状态重算一遍。**
    #
    # 只比"报告 ≟ 计划里存的那个值"是拿快照跟自己比：`must_avoid` 在计划里
    # 改成禁止图中已有的内容之后，真实的复核输入变了，而缓存值纹丝不动，
    # 于是旧报告照样对上、照样 pass。**判据被它所判定的那一方改写了。**
    current = _current_review_input_sha256(asset_id, item,
                                           asset_directory=asset_directory)
    if current != expected:
        raise ValueError(
            f"{PLAN_FINGERPRINT_MISMATCH}：{asset_id} 的语义约束在二编之后被改过"
            "（`must_cover` / `must_avoid` / 结构任一），"
            "而计划里存的复核指纹还是旧的。\n"
            "**拿旧指纹去核旧报告，两边都是旧的，当然对得上。**\n"
            "重跑二编与语义复核。")
    return semantic_review.check_review(record, asset_id=asset_id,
                                        output_sha256=sha,
                                        review_input_sha256=expected)


#: 两张图的成句文字重合到这个比例就告警。
OVERLAP_RATIO = 0.5
#: 少于三条成句文字时比例没有意义。
OVERLAP_MIN_PHRASES = 3


def _warn_overlapping_renders(asset_directory: Path, asset_ids: list[str]) -> list[str]:
    """按**渲染后的实际文字**比对两张图是否在讲同一件事。

    编译期也有一条同名检查，但它比的是计划里的 `must_keep`——那是"要画什么"的
    描述性文字（"三行 × 四个维度"），与画出来的短句（"只用它查数与录数"）
    字面对不上，`structure.nodes` 为空时更是完全失效。
    2026-09-12 实测中两张图画面高度重合，那条检查一声没吭。

    这里比的是 inspect 记录里落下的 `phrases`，**那就是画面上的原话**。
    """
    phrases = {}
    for asset_id in asset_ids:
        record = read_inspection(asset_directory, asset_id) or {}
        found = {str(x) for x in (record.get("phrases") or [])}
        if len(found) >= OVERLAP_MIN_PHRASES:
            phrases[asset_id] = found
    warnings: list[str] = []
    ids = sorted(phrases)
    for left, right in ((a, b) for i, a in enumerate(ids) for b in ids[i + 1:]):
        shared = phrases[left] & phrases[right]
        smaller = min(len(phrases[left]), len(phrases[right]))
        if not smaller or len(shared) / smaller < OVERLAP_RATIO:
            continue
        warnings.append(
            f"{left} 与 {right} 画面上的文字重合 {len(shared) / smaller:.0%}"
            f"（{'、'.join(sorted(shared)[:4])}）——"
            "两张图在讲同一件事，确认是不是能合成一张")
    return warnings


def finalize(
    plan: dict[str, Any],
    manifest: dict[str, Any],
    *,
    asset_files: dict[str, str],
    reviewed_ids: set[str],
    validated_at: str | None = None,
) -> dict[str, Any]:
    if str(plan.get("schema_version") or "") != "1.1":
        raise ValueError("VisualPlan.schema_version 必须为 1.1")
    plan_items = [item for item in (plan.get("items") or []) if isinstance(item, dict)]
    assets = [item for item in (manifest.get("assets") or []) if isinstance(item, dict)]
    expected_ids = [str(item.get("asset_id") or "") for item in plan_items]
    if [str(item.get("asset_id") or "") for item in assets] != expected_ids:
        raise ValueError("ImageAssetManifest.assets 必须按顺序覆盖 VisualPlan.items")
    if set(asset_files) != set(expected_ids):
        raise ValueError("--asset 必须完整覆盖 VisualPlan.items")
    if reviewed_ids != set(expected_ids):
        raise ValueError("视觉人工检查必须完整覆盖所有 asset_id")
    # 依据变没变，要在写 validated 之前判——写完再说就晚了。
    _check_sources_fresh(plan)

    asset_directory = Path(str(plan.get("asset_directory") or "")).resolve()
    manifest["schema_version"] = SCHEMA_VERSION
    manifest["status"] = "validated"
    manifest["asset_directory"] = str(asset_directory)
    manifest["warnings"] = list(plan.get("warnings") or manifest.get("warnings") or [])
    manifest["errors"] = []
    # validated_at 会进入被 sha256 哈希并受不可变机制保护的 ImageAssetManifest。
    # 契约要求它非空，因此保留字段，但允许显式注入，使"同样内容重跑得到同样哈希"成为可能；
    # 不注入时才取当前时间。重跑 finalize 前应带上原值，否则哈希漂移无法复现。
    manifest["validated_at"] = (
        validated_at.strip()
        if isinstance(validated_at, str) and validated_at.strip()
        else datetime.now().astimezone().isoformat(timespec="seconds")
    )

    for asset, item in zip(assets, plan_items):
        asset_id = str(asset["asset_id"])
        image_path = resolve_asset_path(asset_directory, asset_files[asset_id])
        if not image_path.is_file() or image_path.stat().st_size <= 0:
            raise ValueError(f"图片不存在或为空: {image_path}")
        width, height = png_dimensions(image_path)
        method = str(item.get("generation_method") or "")
        layout = (int(item.get("width") or 0), int(item.get("height") or 0))
        # 交付像素 = layout × scale。**"尺寸"原先一个词指三件事**，于是
        # `raster` 默认 2 倍出图、而这里要求严格等于计划宽高，两条规矩互相打架；
        # 2026-09-11 实测中助理为了过这一关把图重渲成 1 倍，降了清晰度。
        scale = int(item.get("delivery_scale") or 0) or delivery_scale_for(method)
        expected_size = delivered_size(layout[0], layout[1], scale)
        if (width, height) != expected_size:
            raise ValueError(
                f"{asset_id} PNG 尺寸 {width}x{height} 与预期交付尺寸 "
                f"{expected_size[0]}x{expected_size[1]} 不一致"
                f"（layout {layout[0]}x{layout[1]} × scale {scale}）。"
                f"渲染时用 --scale {scale}。"
            )
        sha = file_sha256(image_path)
        validation = _validation_block(
            asset_id, item, asset_directory=asset_directory, plan=plan,
            image_path=image_path, sha=sha, reviewed=asset_id in reviewed_ids)
        relative_path = image_path.relative_to(asset_directory).as_posix()
        asset.update(
            {
                "status": "validated",
                "file_path": relative_path,
                "asset_role": item.get("asset_role") or "body",
                "visual_goal": item.get("visual_goal"),
                "diagram_subtype": item.get("diagram_subtype") or "",
                "content_type": item.get("content_type"),
                "generation_method": method,
                "layout_width": layout[0],
                "layout_height": layout[1],
                "delivery_scale": scale,
                "width": width,
                "height": height,
                "alt_text": item.get("alt_text") or "",
                "validation": validation,
            }
        )
    # 跨图重叠：按渲染后的实际文字比，只告警不拒绝——要不要两张是上游的判断。
    manifest["warnings"] = list(manifest.get("warnings") or []) +         _warn_overlapping_renders(asset_directory, expected_ids)

    # **由代码说清"哪几张是机器验的"，不让人去数。**
    #
    # 0913 那轮的回执写着"4 张 inspect pass"，而实际只有三张正文图有机器检查
    # 记录——封面走 `cover_composite`，没有 HTML 可探，那一项是 `n/a`。
    # 数字本身不算撒谎，但它把"人看过"与"机器验过"算成了同一件事，
    # 而这两者的可信度差着一整个量级。
    #
    # 清单里本来就有 `validation.inspection.applicable`，是回执要自己去汇总，
    # 于是每次都得手数一遍——**手数就会数错，而且错法总是往好听里数**。
    manifest["verification_summary"] = _verification_summary(manifest)

    errors = validate_manifest(manifest, plan)
    if errors:
        raise ValueError("；".join(errors))
    return manifest


def _verification_summary(manifest: dict[str, Any]) -> dict[str, Any]:
    """这批图各自被验到什么程度——**按证据分类，不按张数汇总**。"""
    machine, not_applicable, reviewed, exempt = [], [], [], []
    for asset in (manifest.get("assets") or []):
        if not isinstance(asset, dict):
            continue
        asset_id = str(asset.get("asset_id") or "?")
        validation = asset.get("validation") or {}
        inspection = validation.get("inspection") or {}
        if inspection.get("applicable"):
            machine.append(asset_id)
        else:
            not_applicable.append(
                {"asset_id": asset_id,
                 "reason": str(inspection.get("reason") or "无 HTML 可探")})
        semantic = validation.get("semantic_review") or {}
        if semantic.get("applicable"):
            reviewed.append(asset_id)
        else:
            exempt.append({"asset_id": asset_id,
                           "reason": str(semantic.get("reason") or "")})
    return {
        "machine_inspected": machine,
        "inspection_not_applicable": not_applicable,
        "semantic_reviewed": reviewed,
        "semantic_review_exempt": exempt,
        "note": ("`machine_inspected` 才是机器验过画面的那几张；"
                 "其余项没有 HTML 可探，只能由人确认。"
                 "**回执里不要把两者合并计数。**"),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Finalize ImageAssetManifest JSON and YAML")
    parser.add_argument("--plan", required=True, help="VisualPlan 1.1 JSON")
    parser.add_argument("--manifest", help="Manifest JSON；默认使用 VisualPlan.asset_directory")
    parser.add_argument("--asset", action="append", default=[], help="asset_id=relative-or-absolute.png")
    parser.add_argument("--reviewed", action="append", default=[], help="已完成视觉检查的 asset_id")
    parser.add_argument("--reviewed-all", action="store_true", help="确认已打开并检查全部图片")
    parser.add_argument("--validated-at", help="显式指定 validated_at，使重跑可复现同一哈希；缺省取当前时间")
    args = parser.parse_args()

    plan_path = Path(args.plan).expanduser().resolve()
    plan = read_json(plan_path)
    manifest_path = (
        Path(args.manifest).expanduser().resolve()
        if args.manifest
        else Path(str(plan.get("asset_directory") or "")) / "image-asset-manifest.json"
    )
    manifest = read_json(manifest_path)
    asset_files = parse_asset_mapping(args.asset)
    expected_ids = {str(item.get("asset_id") or "") for item in (plan.get("items") or [])}
    reviewed_ids = expected_ids if args.reviewed_all else set(args.reviewed)
    result = finalize(
        plan,
        manifest,
        asset_files=asset_files,
        reviewed_ids=reviewed_ids,
        validated_at=args.validated_at,
    )
    json_path, yaml_path = write_manifest_pair(manifest_path, result)
    print(
        json.dumps(
            {"ok": True, "json_path": str(json_path), "yaml_path": str(yaml_path), "manifest": result},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
