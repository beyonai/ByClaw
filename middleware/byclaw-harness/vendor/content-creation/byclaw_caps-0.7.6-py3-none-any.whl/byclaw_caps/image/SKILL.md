---
name: image-size-verify
description: 当需要 AI 生成配图、并确认产出画幅精确时使用。本能力的价值不是"生成图片"而是"保证画幅精确"——实测平台原生生图把请求的 1080×1440 悄悄降级为 864×1152，而图文卡片正需那一档，降级后卡片在小红书会被裁掉底部。校验按实际像素逐一比对，不接受"接近"；格式按文件头魔数判定，不认扩展名。事实类图形不要用本能力，改用 image-rasterize 确定性渲染。
---

# 生图画幅校验

## 调用

```bash
# 校验产出图的实际像素与格式是否等于请求尺寸
python3 -m byclaw_caps.image verify <图片路径> <请求尺寸>   # 尺寸写成 1080x1440

# 列出三个业务画幅
python3 -m byclaw_caps.image sizes
```

退出码：`0` 画幅相符，`1` 不符（业务失败，**不要放行**），`2` 用法错误或文件读不了。
加 `--result-file <路径>` 可同时落盘。

## 三个业务画幅

| 名称 | 尺寸 | 用途 |
| --- | --- | --- |
| `video_landscape` | 1280×720 | 视频横屏底图 |
| `card` | 1080×1440 | 图文卡片，小红书竖版 |
| `scene` | 1920×1080 | 场景大图 |

## 为什么必须逐张校验

生图服务**接受任意尺寸参数，却不保证按此出图**。实测请求 1080×1440 拿回 864×1152——
比例一样、像素少两成，接口返回成功，元数据里也写着"成功"。只有量实际像素才发现得了。

因此：**每张图生成后立即 verify，不符就重生成，不要攒到最后一起查**。攒到最后意味着
整批返工。

## 画面级检查：`inspect`

`verify` 比的是**像素**，`inspect` 看的是**画面**。两者查的不是一类问题，都要跑。

```bash
# 检查 + 出图，一条命令。**这是确定性渲染拿到合法 PNG 的唯一路径**
python3 -m byclaw_caps.image inspect <源.html> \
    --plan <visual-plan.json> --asset visual-003 --render <出.png>

# 只查不出图（改 HTML 时快速看一眼）
python3 -m byclaw_caps.image inspect <源.html> --width 1280 --height 800
```

退出码：`0` 通过，`1` 有 `failures`（**不要放行**），`2` 用法错误或没有浏览器。

**检查不通过时不产出 PNG。** 顺序不能反：先渲染后检查的话，图已经落盘，
检查失败也拦不住下游拿去用——2026-09-11 实测里助理正是先渲染、后来干脆跳过检查。

**倍率由生成方式决定，不用自己填**：确定性渲染恒 2 倍，`ai_image` 与
`cover_composite` 恒 1 倍。`--plan` 里的 `width`/`height` 是**布局尺寸**，
交付像素 = 布局 × 倍率。

### 检查记录：让"检查过"成为可核验的事实

带 `--plan` + `--asset` 时，结果会落盘到 `<资产目录>/.inspections/<asset_id>.json`，
记录里绑定**三样东西**：哪份计划、哪个 HTML（sha256）、哪张 PNG（sha256）。

`finalize-assets` 读它来填 `validation`，任意一条不满足就拒绝置 `validated`：

| 情况 | 结果 |
|---|---|
| 没有记录 | 拒绝，并告诉你该跑哪条命令 |
| 记录 `status` 不是 `pass` | 拒绝，并回显失败项 |
| 记录属于另一份计划 | 拒绝 |
| 记录里的 PNG 哈希 ≠ 正在登记的图 | 拒绝（**检查之后又重渲过，那份检查就不作数**） |

> 原先 `finalize_assets` 把 `crop` / `text_legibility` / `factual_scope`
> **无条件写成字面量 `"pass"`**，`--reviewed-all` 连这几个字面量都管不着。
> 2026-09-11 交付的清单里四张图的 `text_legibility: pass` 因此全是伪证——
> 那次 `inspect` 一遍都没跑成功过。**现在 `pass` 只能来自记录。**

没有 HTML 可探的产物（`ai_image` / `cover_composite` / `source_asset`）不需要记录，
清单里如实记为 `declared`（人声明看过），**不写 `pass`**。

查六项，前四项是硬失败：

| 检查 | 拦的是什么 |
|---|---|
| `overflow` | 内容比画布高／宽。浏览器**不报错**，只把多出来的画到画布外，截图按视口裁——最后一块整块消失，退出码仍是 0 |
| `min_font` | 文字设计字号低于 16px。公众号正文图按约 677px 宽显示，1280px 的图缩放系数 0.53，16px 落地只剩 8.5px |
| `expected_text` | `structure.nodes[].label` 没出现在画面上。**整片缺失多半是容器没装中文字体**——那种情况 Chromium 按 fallback 渲染或渲成方框，退出码 0 |
| `emoji` | 用 emoji 当图标。跨平台渲染不一致，在渲染容器里常直接变成方框 |
| `cjk_fallback`（告警） | 中文落在西文兜底字体上——缺字体的先兆 |
| `palette` / `glossary`（告警） | 色值不在设计令牌里；图上术语与正文对不上 |

**为什么在浏览器里查而不是对着 PNG 查**：PNG 只能上 OCR，慢、不准，且说不出是哪个字段丢了。
`inspect` 复制一份 HTML、追加一段探针脚本读 `getComputedStyle`，直接报出
「`structure.nodes[2].label` 没出现在画面上」。这条理由与 `infographic-dsl.md`
第六节一致，那里已经踩过一次。

**跑的时机是出图之前。** 它检查的是 HTML，修的也是 HTML——
等 `finalize-assets` 再发现，整批都要重渲。

## 判定方式

- **像素严格相等**，不接受"接近""同比例"。
- **格式看文件头魔数**，不看扩展名——服务返回 JPEG 而文件名写 `.png` 是常见情况。
- 不依赖 Pillow：直接解析 PNG 的 IHDR 与 JPEG 的 SOF 段，少一个部署依赖。

## 生图

```bash
python3 -m byclaw_caps.image generate --agent-id <agentId> \
    --prompt "<提示词>" --size 1080x1440 --output <会话根>/…/cover.png \
    [--model <覆盖模型名>] [--watermark] [--session-root <会话根>]
```

**发请求之前先跑 `plan`**：volcengine 的像素下限会把三个业务画幅全部放大
（1080×1440 → 1776×2368）。生成完再返工意味着整批重来。

```bash
python3 -m byclaw_caps.image plan <尺寸> --agent-id <agentId>
```

**供应商不是可选项**，是这个 agent 绑了哪个模型决定的。`plan` 的 `--provider`
只用于离线比较两家规则——**不默认某一家**，因为默认值会被当成「可以挑」，
而挑错了发出去就是 400（实测踩过：拿 qwen 与 volcengine 比夹取结果，
挑了「比例更接近」的 qwen，而凭据是 VOLCENGINE，qwen 压根打不通）。

`generate` **发请求前会本地预检尺寸**：不合这家规矩就当场拒，并报出该按哪个尺寸生成。
封面尤其要注意——渠道规格 900×383 只有 34 万像素，远低于 volcengine 的 3.69M 下限，
正路是按夹取后的尺寸出背景，再合成／缩到 900×383。

## 凭据按 agentId 解析

`ARK_API_KEY` 等环境变量已废除。`credentials resolve --kind image` 按 agent 绑定的
模型查出 `apiEndpoint` / `apiToken` / `providerName`，会话内缓存。

**`providerName` 决定按谁的协议拼请求**（`VOLCENGINE` / `QWEN`），认不出直接报用法错误
（退出码 2），**不静默降级到别的服务商**——供应商不同出图风格不同，
静默换供应商等于悄悄改了成品；而用错协议报出来的是 400 或鉴权失败，
与真正的原因隔了两层。

**该 agent 没绑文生图模型时报「未配置文生图模型」**，去后台绑一个，不是去查密钥。
