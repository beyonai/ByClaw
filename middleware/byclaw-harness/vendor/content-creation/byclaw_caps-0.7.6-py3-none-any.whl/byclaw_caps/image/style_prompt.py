"""按小黑风格档确定性拼装生图提示词。

提示词模板与视觉规范来自 references/styles/ian-xiaohei.md。用脚本拼装而不是每次让
模型自由发挥，是为了保证批量生产的风格一致：同样的输入永远得到同样的提示词。

产出的提示词与模型无关，可直接交给 python3 -m byclaw_caps.image（豆包 Seedream）执行。

风格档提示词拼装。**确定性拼装，不交给模型改写**——
交给模型改写会破坏同一风格档的可复现性。
"""

from __future__ import annotations

import argparse
import json
import sys

VERSION = "1.0.0"

# 八种构图模式，与 references/styles/ian-xiaohei.md 一致。
STRUCTURE_TYPES = (
    "Workflow 流程",
    "系统局部",
    "前后对比",
    "角色状态",
    "概念隐喻",
    "方法分层",
    "地图路线",
    "小漫画分镜",
)

MAX_LABELS = 8
MIN_LABEL_CHARS = 2
MAX_LABEL_CHARS = 8
MAX_ELEMENTS = 6

VISUAL_DNA = (
    "Pure white background. Minimalist black hand-drawn line art. Slightly wobbly pen "
    "lines. Lots of empty white space. Sparse red/orange/blue handwritten Chinese "
    "annotations. Clean absurd product-sketch feeling. No gradients, no shadows, no "
    "paper texture, no complex background, no commercial vector style, no PPT "
    "infographic look, no cute mascot poster, no children's illustration, no realistic UI."
)

IP_RULE = (
    "小黑, a small solid-black absurd creature with white dot eyes, tiny thin legs, "
    "blank serious expression, slightly uneven hand-drawn body shape. 小黑 must perform "
    "the core conceptual action, not decorate the scene. Make 小黑 serious, deadpan, "
    "and slightly bizarre, not cute."
)

COLOR_RULE = (
    "Black for main line art and 小黑. Orange for main flow/path/arrows. Red only for "
    "key warnings/problems/results. Blue only for secondary notes or feedback/system state."
)

CONSTRAINTS = (
    "One image explains only one core structure. Keep the main subject around 40%-60% "
    "of the canvas. Preserve at least 35% blank white space. Use at most 5-8 short "
    "handwritten Chinese labels. Do not write a title in the top-left corner. Do not "
    "write the structure type on the image. Do not make it a formal diagram, course "
    "slide, or dense explainer. Do not copy prior examples or reuse known case "
    "compositions; invent a fresh visual metaphor for this specific content. It should "
    "be clear but not instructional, interesting but not childish, strange but clean."
)


class XiaoheiPromptError(ValueError):
    """提示词输入不满足小黑风格档约束。"""


def _text(value: object, field: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise XiaoheiPromptError(f"{field} 不能为空")
    return text


def _sequence(value: object, field: str, limit: int) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str) or not hasattr(value, "__iter__"):
        raise XiaoheiPromptError(f"{field} 必须是字符串数组")
    items = [str(item).strip() for item in value]
    items = [item for item in items if item]
    if len(items) > limit:
        raise XiaoheiPromptError(f"{field} 最多 {limit} 项，当前 {len(items)} 项")
    return items


def _labels(value: object) -> list[str]:
    labels = _sequence(value, "labels", MAX_LABELS)
    if not labels:
        raise XiaoheiPromptError("labels 至少 1 项；小黑图靠中文批注承担解释")
    for label in labels:
        if not (MIN_LABEL_CHARS <= len(label) <= MAX_LABEL_CHARS):
            raise XiaoheiPromptError(
                f"标注「{label}」长度 {len(label)}，必须在 "
                f"{MIN_LABEL_CHARS}-{MAX_LABEL_CHARS} 字之间"
            )
    return labels


def build_prompt(
    *,
    theme: str,
    structure_type: str,
    core_idea: str,
    composition: str,
    elements: object = None,
    labels: object = None,
) -> str:
    """拼装一张小黑配图的完整英文提示词。

    Args:
        theme: 正文配图主题。
        structure_type: 八种构图模式之一，见 STRUCTURE_TYPES。
        core_idea: 这张图要表达的核心意思。
        composition: 具体画面：小黑在哪里、做什么、主要物件、信息如何流动。
        elements: 建议元素，最多 6 项。
        labels: 中文手写标注，1-8 项，每项 2-8 字。

    Raises:
        XiaoheiPromptError: 任一输入不满足风格档约束。
    """
    theme_text = _text(theme, "theme")
    structure = _text(structure_type, "structure_type")
    if structure not in STRUCTURE_TYPES:
        raise XiaoheiPromptError(
            f"structure_type 必须是八种构图模式之一：{'、'.join(STRUCTURE_TYPES)}"
        )
    idea = _text(core_idea, "core_idea")
    layout = _text(composition, "composition")
    element_list = _sequence(elements, "elements", MAX_ELEMENTS)
    label_list = _labels(labels)

    blocks = [
        "Generate one standalone 16:9 horizontal Chinese article illustration.",
        "",
        "Visual DNA:",
        VISUAL_DNA,
        "",
        "Recurring IP character required:",
        IP_RULE,
        "",
        "Theme:",
        theme_text,
        "",
        "Structure type:",
        structure,
        "",
        "Core idea:",
        idea,
        "",
        "Composition:",
        layout,
    ]
    if element_list:
        blocks += ["", "Suggested elements:", " / ".join(element_list)]
    blocks += [
        "",
        "Chinese handwritten labels:",
        " / ".join(label_list),
        "",
        "Color use:",
        COLOR_RULE,
        "",
        "Constraints:",
        CONSTRAINTS,
    ]
    return "\n".join(blocks)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="按小黑风格档拼装生图提示词，输出可直接交给 python3 -m byclaw_caps.image"
    )
    parser.add_argument("--theme", required=True, help="正文配图主题")
    parser.add_argument(
        "--structure-type", required=True, choices=list(STRUCTURE_TYPES), help="构图模式"
    )
    parser.add_argument("--core-idea", required=True, help="这张图要表达的核心意思")
    parser.add_argument("--composition", required=True, help="具体画面描述")
    parser.add_argument("--element", action="append", default=[], help="建议元素，可重复")
    parser.add_argument("--label", action="append", default=[], help="中文标注，可重复")
    parser.add_argument("--json", action="store_true", help="以 JSON 输出，便于脚本消费")
    args = parser.parse_args()

    try:
        prompt = build_prompt(
            theme=args.theme,
            structure_type=args.structure_type,
            core_idea=args.core_idea,
            composition=args.composition,
            elements=args.element,
            labels=args.label,
        )
    except XiaoheiPromptError as exc:
        payload = {"status": "failed", "error_code": "invalid_input", "message": str(exc)}
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 2

    if args.json:
        print(json.dumps({"status": "ok", "prompt": prompt}, ensure_ascii=False, indent=2))
    else:
        print(prompt)
    return 0


if __name__ == "__main__":
    sys.exit(main())
