# -*- coding: utf-8 -*-
"""语义复核记录：能力层这一侧的读取与门禁。

方案《配图语义规划方案.md》§3.7、§4.3。

skill 侧的 `scripts/review_visual.py` 负责**生成**复核输入包、由子 Agent 填结论；
这里负责**登记时把关**——`finalize-assets` 写 `validated` 之前调它。

**两边都要有，不能只有一边。** 只有 skill 脚本的话，跑不跑全凭助理自觉，
而"忘了跑"和"跑了但没过"在清单上长得一模一样；只有能力层的话，
助理拿不到该给复核者什么。

判定与 `inspect` 记录同一套办法：绑哈希、逐项结论、缺失/失败/过期一律不登记。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

#: 复核结论目录。与 `.inspections/` 并列——它们是两类证据：
#: inspect 查画面（溢出、字号、术语），复核查语义（方向、推导、否定词）。
REVIEW_DIR = ".reviews"

METHODS = ("deterministic", "reviewed", "declared", "n/a")
RESULT_PASS = "pass"
RESULT_FAIL = "fail"
RESULT_INCONCLUSIVE = "inconclusive"
RESULTS = (RESULT_PASS, RESULT_FAIL, RESULT_INCONCLUSIVE)

#: 必查项。少一项都不算复核过——**清单是固定的**，
#: 让调用方自选查哪几项，等于让它自己决定门槛。
REQUIRED_CHECKS = (
    "relation_direction",
    "derivation_holds",
    "no_meaning_drift",
    "coverage_claims",
    "must_cover_complete",
    "must_avoid_absent",
    "no_undeclared_claims",
)

REVIEW_STALE = "REVIEW_STALE"

from byclaw_caps.shared.render_contract import (  # noqa: E402
    DigestFormatError, digests_match,
)


class ReviewRejected(ValueError):
    """复核不通过。带错误码与差在哪，不是一句"校验失败"。"""

    def __init__(self, code: str, message: str, **detail: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.detail = detail


def review_path(asset_directory: Path, asset_id: str) -> Path:
    return Path(asset_directory) / REVIEW_DIR / f"{asset_id}.json"


def read_review(asset_directory: Path, asset_id: str) -> dict | None:
    path = review_path(asset_directory, asset_id)
    if not path.is_file():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def check_review(
    record: Mapping[str, Any] | None,
    *,
    asset_id: str,
    output_sha256: str,
    review_input_sha256: str | None = None,
) -> dict:
    """这张图的语义复核过不过得了门禁。

    返回 `{"applicable": True, "result": "pass", …}`，不通过则抛 `ReviewRejected`。

    **`reviewed` 不是一种"通过"。** 它是 `method`——说的是谁验的；
    过没过看 `result`。两者混成一列的话，一个来源标记就冒充了结论，
    那正是 `text_legibility: pass` 全是伪证的同一个形状。
    """
    if record is None:
        raise ReviewRejected(
            "REVIEW_MISSING",
            f"{asset_id} 缺少语义复核记录。`inspect` 查的是画面（溢出、字号、术语），"
            "查不出依赖方向画反、否定词被截掉、must_cover 漏了一条——"
            "**必需检查缺失不是通过**。"
            f"先跑 `scripts/review_visual.py prepare` 生成输入包，由**另一个**助理填结论。")

    reviewer = str(record.get("reviewer") or "").strip()
    designer = str(record.get("designer") or "").strip()
    if designer and reviewer == designer:
        raise ReviewRejected(
            "REVIEW_SELF_SIGNED",
            f"{asset_id} 的复核者就是产出 VisualDesign 的那个助理（{reviewer}）——那是自证。"
            "派一个子 Agent，且它不读 rationale。")

    bound = record.get("bound") or {}
    # **按归一化后的摘要比，不比字面量。**
    #
    # 本仓库里两种写法同时在用：`image.manifest.file_sha256` 出大写，
    # `shared.render_contract.sha256_file` 出小写。裸 `!=` 会把"同一个文件"
    # 判成"图换过了"，而那条报错给的修法（重跑复核）根本不解决问题——
    # 真正错的是两种写法在同一个比较里相遇。
    #
    # 归一放在**比较边界**，不改两侧各自的输出格式：改 `file_sha256`
    # 会波及所有既有清单，那是比这个 bug 更大的一次改动。
    #
    # 格式不合法单独报：**记录写坏了 ≠ 内容变了**，两者的修法完全不同。
    try:
        if not digests_match(bound.get("output_sha256"), output_sha256,
                             field="bound.output_sha256"):
            raise ReviewRejected(
                REVIEW_STALE,
                f"{asset_id} 的复核记录对应的不是这张图（哈希不符）——"
                "图在复核之后又重渲或替换过，那份结论就不再作数。重跑复核。")
        if review_input_sha256 is not None and \
                not digests_match(bound.get("review_input_sha256"),
                                  review_input_sha256,
                                  field="bound.review_input_sha256"):
            raise ReviewRejected(
                REVIEW_STALE,
                f"{asset_id} 的复核记录绑的是旧输入：来源或设计已经变过。重跑复核。")
    except DigestFormatError as failure:
        raise ReviewRejected(
            "REVIEW_MALFORMED",
            f"{asset_id} 的复核记录里摘要格式不对：{failure}\n"
            "**这不是「内容变了」**，是记录本身写坏了——重新产出复核记录；"
            "摘要要由工具读文件算出来，不要手填。") from failure

    checks = record.get("checks") or {}
    missing = [key for key in REQUIRED_CHECKS if key not in checks]
    if missing:
        raise ReviewRejected(
            "REVIEW_INCOMPLETE",
            f"{asset_id} 的复核少了 {len(missing)} 项：{missing}")

    bad: list[str] = []
    for key in REQUIRED_CHECKS:
        entry = checks[key] if isinstance(checks[key], Mapping) else {}
        method = entry.get("method")
        result = entry.get("result")
        if method not in METHODS or result not in RESULTS:
            raise ReviewRejected(
                "REVIEW_MALFORMED",
                f"{asset_id} 的 {key} 要同时有 method（谁验的）与 result（验出什么）："
                f"method∈{METHODS}，result∈{RESULTS}；实际 {method!r}/{result!r}")
        if result != RESULT_PASS:
            detail = str(entry.get("detail") or "").strip()
            bad.append(f"{key}={result}" + (f"（{detail}）" if detail else ""))

    if bad:
        raise ReviewRejected(
            "REVIEW_NOT_PASSED",
            f"{asset_id} 的语义复核未全部通过：{'；'.join(bad)}。"
            "**inconclusive 不是通过**——它和 fail 一样挡住登记，"
            "区别只在于前者要补材料、后者要改图。")

    return {
        "applicable": True,
        "result": RESULT_PASS,
        "reviewer": reviewer,
        "reviewed_at": record.get("reviewed_at"),
        "review_input_sha256": str(bound.get("review_input_sha256") or ""),
        "checks": {key: {"method": checks[key].get("method"),
                         "result": checks[key].get("result")}
                   for key in REQUIRED_CHECKS},
    }


def skipped(reason: str) -> dict:
    """存量兼容：不做语义复核时如实标注。

    **存量的复核豁免与规划豁免必须同口径**（§3.6）：若复核是登记前置，
    而存量允许无规划，则存量会被复核卡死——两处豁免要写成同一条规则。
    """
    return {"applicable": False, "reason": reason}


__all__ = ["REVIEW_DIR", "REVIEW_STALE", "REQUIRED_CHECKS", "ReviewRejected",
           "review_path", "read_review", "check_review", "skipped"]
