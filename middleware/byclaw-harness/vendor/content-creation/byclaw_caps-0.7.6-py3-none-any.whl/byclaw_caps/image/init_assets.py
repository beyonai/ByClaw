#!/usr/bin/env python3
"""Initialize a media-neutral asset directory from a JSON VisualPlan."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from byclaw_caps.image.manifest import write_manifest_pair


# infographic、html_svg 与 svg_file 同属确定性渲染，数值均由输入决定，不会编造。
DETERMINISTIC_METHODS = frozenset({"html_svg", "infographic", "svg_file"})
#: `cover_composite` 是**封面的两层合成**：背景归模型，文字归 `compose_cover.py`。
#: 编译器给 `asset_role=cover` 的项设的就是它（见 compile_article_visual_plan.py
#: 的 `item["generation_method"] = "cover_composite"`）。
#:
#: **这里原先漏了它**，后果是任何带封面的文章在 `init-assets` 这一步就被拒，
#: 报的还是含糊的"generation_method 非法"。编译器产出的每一个取值都必须在这张表里，
#: 否则两处对同一个契约给出了不同答案——而先跑的是编译器。
VALID_GENERATION_METHODS = frozenset(
    DETERMINISTIC_METHODS | {"ai_image", "source_asset", "cover_composite"}
)

def initialize(plan: dict[str, Any], *, overwrite: bool = False) -> dict[str, Any]:
    if str(plan.get("schema_version") or "") not in {"1.0", "1.1"}:
        raise ValueError("VisualPlan.schema_version 必须为 1.0|1.1")
    required = ("plan_id", "brief_id", "topic_id", "modality", "channel_ref", "asset_directory")
    missing = [key for key in required if not str(plan.get(key) or "").strip()]
    if missing:
        raise ValueError(f"VisualPlan 缺少字段: {', '.join(missing)}")
    items = plan.get("items") or []
    if not isinstance(items, list):
        raise ValueError("items 必须是数组")
    output_root = Path(str(plan["asset_directory"])).expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    manifest_path = output_root / "image-asset-manifest.json"
    yaml_manifest_path = manifest_path.with_suffix(".yaml")
    if (manifest_path.exists() or yaml_manifest_path.exists()) and not overwrite:
        raise FileExistsError(f"manifest 已存在: {manifest_path} 或 {yaml_manifest_path}")

    assets = []
    seen: set[str] = set()
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            raise ValueError(f"items[{index}] 必须是对象")
        asset_id = str(item.get("asset_id") or "").strip()
        if not asset_id or asset_id in seen:
            raise ValueError(f"items[{index}].asset_id 缺失或重复")
        seen.add(asset_id)
        purpose = str(item.get("purpose") or "").strip()
        content_type = str(item.get("content_type") or "").strip()
        method = str(item.get("generation_method") or "").strip()
        if not purpose or method not in VALID_GENERATION_METHODS:
            raise ValueError(f"items[{index}] 缺少 purpose 或 generation_method 非法")
        if content_type not in {"diagram", "chart", "table", "card", "illustration", "screenshot_reference"}:
            raise ValueError(f"items[{index}].content_type 非法")
        if method == "ai_image" and content_type != "illustration":
            raise ValueError(f"items[{index}] 只有 illustration 可以使用 ai_image")
        if method == "source_asset" and content_type != "screenshot_reference":
            raise ValueError(f"items[{index}] source_asset 必须对应 screenshot_reference")
        if content_type == "screenshot_reference" and not str(item.get("source_ref") or "").strip():
            raise ValueError(f"items[{index}] screenshot_reference 缺少 source_ref")
        if content_type == "chart" and not (item.get("evidence_refs") or []):
            raise ValueError(f"items[{index}] chart 缺少 evidence_refs")
        width, height = int(item.get("width") or 0), int(item.get("height") or 0)
        if width <= 0 or height <= 0:
            raise ValueError(f"items[{index}] width/height 必须大于0")
        assets.append({
            "asset_id": asset_id,
            "order": item.get("order", index + 1),
            "status": "initialized",
            "file_path": None,
            "preview_url": None,
            "asset_role": item.get("asset_role") or "body",
            "visual_goal": item.get("visual_goal"),
            "diagram_subtype": item.get("diagram_subtype") or "",
            "content_type": content_type,
            "generation_method": method,
            "width": width,
            "height": height,
            "alt_text": item.get("alt_text") or "",
            "validation": {},
        })
    manifest = {
        "schema_version": "1.1",
        "workflow": dict(plan.get("workflow") or {}),
        "producer": dict(plan.get("producer") or {"skill": "generate-content-images", "version": "1.2.0"}),
        "source_artifacts": list(plan.get("source_artifacts") or []),
        "manifest_id": f"manifest-{plan['plan_id']}",
        "plan_id": plan["plan_id"],
        "brief_id": plan["brief_id"],
        "topic_id": plan["topic_id"],
        "status": "initialized",
        "asset_directory": str(output_root),
        "assets": sorted(assets, key=lambda item: item["order"]),
        "warnings": list(plan.get("warnings") or []),
        "errors": [],
        "validated_at": None,
    }
    json_path, yaml_path = write_manifest_pair(manifest_path, manifest)
    return {
        "ok": True,
        "manifest_path": str(json_path),
        "yaml_manifest_path": str(yaml_path),
        "manifest": manifest,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Initialize content image assets")
    parser.add_argument("--plan", required=True, help="JSON VisualPlan file")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    print(json.dumps(initialize(plan, overwrite=args.overwrite), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
