"""校验 AntV Infographic DSL 是否符合本项目约定。

DSL 交给 antv-infographic-creator 渲染前先在本侧把关三件事：

1. **统一手绘主题**——否则事实类信息图与 ian-xiaohei 小黑图在同一篇内容里风格割裂。
2. **图标用固定 ID**——语义关键词要走蚂蚁公网检索接口，SSR 下失败时**静默丢弃**，
   出图后才发现少了图标。
3. **模板族与数据字段匹配**——AI 生成 DSL 时最容易错的一处。

本脚本完全离线，不解析完整 DSL 语义，只做上述约定检查；语法正确性由
antv-infographic-creator 的 validate.mjs 负责。

Infographic DSL 校验。确定性校验，文章与卡片共用。

**光栅化必须走浏览器**：其正文文字位于 `<foreignObject>` 中，
resvg / librsvg / sharp 会静默丢失全部中文——产出一张只有色块、
一个中文都没有的图，而且不报错。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

VERSION = "1.0.0"

REQUIRED_THEME = "hand-drawn"

# 模板族 → 必需的数据字段，与 AntV Infographic 的模板库一致。
FAMILY_DATA_FIELD = {
    "list": "lists",
    "sequence": "sequences",
    "hierarchy": "root",
    "compare": "compares",
    "relation": "nodes",
    "chart": "values",
    "quadrant": "quadrants",
}

# 稳定图标 ID 形如 `mingcute/server-line`：图标集 + 斜杠 + 短横线名称。
STABLE_ICON = re.compile(r"^[a-z0-9][a-z0-9._-]*/[a-z0-9][a-z0-9._-]*$")
HEX_COLOR = re.compile(r"^#[0-9a-fA-F]{3,8}$")


def _strip_noise(text: str) -> list[str]:
    """去掉 markdown 围栏与注释行；LLM 输出常带这些噪音。"""
    lines: list[str] = []
    for raw in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        stripped = raw.strip()
        if stripped.startswith("```"):
            continue
        if stripped.startswith("#") or stripped.startswith("//"):
            continue
        lines.append(raw.rstrip())
    return lines


def _error(code: str, message: str, line: int | None = None) -> dict[str, Any]:
    return {"code": code, "message": message, "line": line}


def validate_dsl(text: str, *, expected_theme: str = REQUIRED_THEME) -> dict[str, Any]:
    """返回 {status, template, template_family, errors[], warnings[]}。

    ``expected_theme`` **默认仍是 hand-drawn**：文章配图与图文卡片链路在用它，
    改默认会让那两条线全部报错。视频走暗色时显式传 ``dark``。
    """
    lines = _strip_noise(text or "")
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    body = [line for line in lines if line.strip()]
    if not body:
        return {
            "status": "fail",
            "template": None,
            "template_family": None,
            "errors": [_error("empty_dsl", "DSL 为空")],
            "warnings": [],
        }

    # ── 头部 ────────────────────────────────────────────────────────
    template: str | None = None
    family: str | None = None
    header = body[0].strip()
    if not header.startswith("infographic "):
        errors.append(
            _error("header_missing", "首行必须是 `infographic <模板名>`", 1)
        )
    else:
        template = header[len("infographic ") :].strip()
        if not template:
            errors.append(_error("header_missing", "`infographic` 后缺少模板名", 1))
        else:
            family = template.split("-", 1)[0]
            if family not in FAMILY_DATA_FIELD:
                errors.append(
                    _error(
                        "unknown_template_family",
                        f"未知模板族 `{family}`，必须是 "
                        f"{'/'.join(sorted(FAMILY_DATA_FIELD))} 之一",
                        1,
                    )
                )
                family = None

    joined = "\n".join(lines)

    # ── 标题 ────────────────────────────────────────────────────────
    if not re.search(r"^\s+title\s+\S", joined, re.MULTILINE):
        errors.append(_error("title_missing", "data 块缺少非空 title"))

    # ── 数据字段与模板族匹配 ────────────────────────────────────────
    if family:
        expected = FAMILY_DATA_FIELD[family]
        if not re.search(rf"^\s+{re.escape(expected)}\s*$", joined, re.MULTILINE):
            present = [
                field
                for field in FAMILY_DATA_FIELD.values()
                if re.search(rf"^\s+{re.escape(field)}\s*$", joined, re.MULTILINE)
            ]
            errors.append(
                _error(
                    "data_field_mismatch",
                    f"模板族 `{family}` 要求数据字段 `{expected}`"
                    + (f"，实际为 {'、'.join(present)}" if present else "，但未找到任何数据字段"),
                )
            )

    # ── 主题 ────────────────────────────────────────────────────────
    theme_lines = _theme_block(lines)
    if theme_lines is None:
        errors.append(
            _error(
                "theme_missing",
                f"缺少 theme 块；必须显式声明 `name {expected_theme}`，"
                "否则回落默认主题，与小黑手绘图风格割裂",
            )
        )
    else:
        name_match = re.search(r"^\s*name\s+(\S+)", "\n".join(theme_lines), re.MULTILINE)
        if not name_match:
            errors.append(_error("theme_not_hand_drawn", "theme 块缺少 name"))
        elif name_match.group(1) != expected_theme:
            errors.append(
                _error(
                    "theme_not_hand_drawn",
                    f"theme.name 必须是 `{expected_theme}`，当前为 `{name_match.group(1)}`",
                )
            )
        palette_match = re.search(
            r"^\s*palette\s+(.+)$", "\n".join(theme_lines), re.MULTILINE
        )
        if not palette_match:
            errors.append(
                _error("palette_missing", "theme 块缺少 palette；品牌配色不得依赖引擎默认值")
            )
        else:
            colors = palette_match.group(1).split()
            bad = [c for c in colors if not HEX_COLOR.match(c)]
            if bad:
                errors.append(
                    _error("palette_invalid", f"palette 含非法色值：{'、'.join(bad)}")
                )

    # ── 图标 ────────────────────────────────────────────────────────
    for index, line in enumerate(lines, start=1):
        match = re.match(r"^\s*icon\s+(.+?)\s*$", line)
        if not match:
            continue
        value = match.group(1)
        if not STABLE_ICON.match(value):
            errors.append(
                _error(
                    "icon_not_stable_id",
                    f"图标 `{value}` 是语义关键词；必须用固定 ID（形如 "
                    "`mingcute/server-line`）。语义检索走公网接口，"
                    "SSR 下失败时静默丢弃，出图后才会发现缺图标",
                    index,
                )
            )

    return {
        "status": "fail" if errors else "pass",
        "template": template,
        "template_family": family,
        "errors": errors,
        "warnings": warnings,
    }


def _theme_block(lines: list[str]) -> list[str] | None:
    """取出 theme 块的缩进内容；不存在时返回 None。"""
    start = None
    for index, line in enumerate(lines):
        if line.strip() == "theme" and not line.startswith(" "):
            start = index
            break
    if start is None:
        return None
    block: list[str] = []
    for line in lines[start + 1 :]:
        if line.strip() and not line.startswith(" "):
            break
        if line.strip():
            block.append(line)
    return block


def main() -> int:
    parser = argparse.ArgumentParser(
        description="校验 Infographic DSL 是否符合本项目约定（主题 / 图标 / 数据字段）"
    )
    parser.add_argument("--input", required=True, help=".ifgc 文件路径，- 表示标准输入")
    args = parser.parse_args()

    text = sys.stdin.read() if args.input == "-" else Path(args.input).read_text(encoding="utf-8")
    result = validate_dsl(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "pass" else 2


if __name__ == "__main__":
    sys.exit(main())
