#!/usr/bin/env python3
"""配图画面级检查：在**渲染的同一个浏览器里**读 DOM，而不是事后从 PNG 反查。

## 为什么不从 PNG 查

`image verify` 只比像素与文件头魔数。它挡得住"画幅被悄悄降级"，挡不住
"画幅正确但画面是坏的"——而后者恰恰是这条线上最常见的坏法：

| 坏法 | 退出码 | 谁会发现 |
|---|---|---|
| 容器缺中文字体，字渲成方框或直接丢 | 0 | 读者 |
| 内容比画布高，最后一块溢出到画面外 | 0 | 读者 |
| 图上 14px 的字，落到 677px 宽的正文里只剩 7px | 0 | 读者 |
| 每张图自己发明配色，五张图并排才看得出不成套 | 0 | 没人 |

`SKILL.md` 原先把这些交给 `--reviewed-all`——一个荣誉制的开关，
并且它自己写着"这道门禁挡的正是渲染成功但画面是坏的，而那种坏法机器查不出来"。
**其中四类查得出来**，只要在浏览器里问，而不是对着 PNG 猜。

从 PNG 反查只能上 OCR：慢、不准，且说不出是哪个字段丢了。DOM 断言直接给出
"`structure.nodes[2].label` 没出现在画面上"。这条理由与 `infographic-dsl.md`
第六节完全一致，那里已经踩过一次。

## 实现：注入探针 + --dump-dom

Chrome 的 `--dump-dom` 给的是执行完 JS 的 DOM，但不含计算样式。所以复制一份 HTML，
在末尾追加一段探针脚本：它遍历 DOM 取 `getComputedStyle`，把结果 **base64** 后塞进
一个 `<pre>`，再由这边解出来。base64 是为了绕开 HTML 转义——
JSON 里的引号与尖括号在 `--dump-dom` 输出里会被转义，直接解析必然出错。
"""

from __future__ import annotations

import base64
import json
import math
import re
import subprocess
import tempfile
from contextlib import ExitStack
from datetime import datetime
from pathlib import Path
from typing import Any

from byclaw_caps.raster import (
    RasterError, chromium_common_flags, chromium_profile_dir, find_browser,
    frame_forward_js, rasterize_html, run_chromium_with_retries, sandbox_hint,
    viewport_frame_html,
)

try:
    from byclaw_caps.shared.diagram_tokens import (
        COMFORTABLE_LANDING_FONT_PX, DEFAULT_DISPLAY_WIDTH,
        MIN_ARGUMENT_FONT_PX, MIN_FONT_PX, MIN_LANDING_FONT_PX,
        allowed_colors, delivered_size, landing_px, render_scale,
    )
except ImportError:  # pragma: no cover - 共享库缺失时给出可执行的下一步
    raise RasterError(
        "读不到 byclaw_caps.shared.diagram_tokens——配图设计令牌是本检查的判据来源，"
        "缺了它无法判断色板与字号是否合规。请确认安装的是 0.6.11 及以后的版本。"
    ) from None

# **在模块顶层导入，不在 try 里。**
#
# 早先这三个名字是在 `try:` 内部导入、而同一个 `try` 的 `except AxisError:`
# 又要用 `AxisError`。装的是旧版能力层时（没有 axis_check），
# 导入抛 ImportError，异常子句求值随即抛 **NameError** ——
# 报出来的是"name 'AxisError' is not defined"，
# 与真正的原因（能力层没升级）隔着两层，而这次线上撞的正是旧包。
try:
    from byclaw_caps.shared.axis_check import (
        AxisError, check_axis_covers, check_log_axis_annotations,
    )
except ImportError:  # pragma: no cover
    raise RasterError(
        "读不到 byclaw_caps.shared.axis_check——数值图的几何校验靠它。"
        "请确认安装的是 0.6.33 及以后的版本。"
    ) from None

#: 文字面积占画布低于这个比例就告警。**只拦"离谱"，不当版面裁判**——
#: 判不准的门禁比没有门禁更糟（见下面第 8 项的注释）。
#:
#: 阈值是量出来的，不是拍的。五套骨架实测 10.9% – 14.5%
#: （nested 10.9、matrix 12.9、layered 12.9、comparison 14.0、composite 14.5）；
#: 复刻 2026-09-11 那张"三条通栏各只装六个字"的稀疏图是 5.0%。
#: 取 7% 落在这条缝里：比最稀的骨架还低三分之一，又高于那张确实该被问一句的图。
MIN_TEXT_AREA_RATIO = 0.07

#: 图文重复检查的三个阈值。
#: 只看 ≥6 字的成句文字：层名、列头这类短词与正文一致是**术语统一**，不是重复。
COPIED_PHRASE_MIN_CHARS = 6
#: 至少命中三条才算"成片"，一两条可能只是引用原文里的关键表述。
COPIED_PHRASE_MIN_HITS = 3
#: 成句文字里有四成来自正文，就该问一句这张图凭什么存在。
COPIED_PHRASE_RATIO = 0.4
#: 单句判定为「搬运」的三字片段重合率。
COPIED_GRAM_RATIO = 0.5

DEFAULT_TIMEOUT = 60
_PROBE_ID = "__byclaw_inspect__"
_PAYLOAD = re.compile(
    r'<pre id="%s"[^>]*>([A-Za-z0-9+/=\s]*)</pre>' % _PROBE_ID, re.S)

#: 真 emoji（图形表情、旗帜）。**硬失败**：它们在渲染容器里基本必然是
#: 方框或黑白轮廓，且尺寸不受 CSS 控制。
_EMOJI = re.compile("[\U0001F000-\U0001FAFF\U0001F1E6-\U0001F1FF]")

#: Dingbats 与杂项符号（✓ ✗ ⚠ ★ 之类）。**只告警。**
#:
#: 它们不是 emoji——`✓` 是 U+2713，矩阵格子里打勾是几十年的排版惯例。
#: 但部分平台（尤其 iOS）会把它们渲成彩色 emoji 变体，字号与基线都不受控。
#:
#: 第一版把这一段并进 `_EMOJI` 一起硬失败，报错还写着"使用了 emoji"——
#: 2026-09-11 实测里助理拿着 `✓/✗` 被拦，而 **matrix 骨架的图标精灵里
#: 根本没有对勾和叉**。规则说"图标一律内联 SVG"，却不给这一类最常用的 SVG，
#: 那就只是把人堵死。现在两件事一起做：降为告警，并在骨架里补上 `i-check`／`i-cross`。
#:
#: **不含 U+2190–U+21FF 的箭头**（`→` `←` `↔`）。那一段是**行文标点**，
#: 中文技术写作里 "A → B" 到处都是，它没有、也不该有 SVG 替代品——
#: 把它一起拦下只会制造无从下手的告警。第一版就误报过 `matrix.html`
#: 注解面板里的一句"同一概念在不同行改了名 → 跨行引用要先翻译一次"。
#:
#: 留下的是**有 SVG 替代品的那些**：对勾、叉、警告、星标等。
_DINGBAT = re.compile("[\U00002600-\U000027BF\U00002B00-\U00002BFF]")

#: 字体缺失时 Chromium 会静默回落。这些是常见的西文兜底族——
#: 中文文本落到它们身上，多半意味着容器里没有中文字体。
_LATIN_FALLBACKS = {"times new roman", "dejavu serif", "liberation serif", "serif"}

_PROBE_JS = """
(function () {
  function collect() {
  function visible(el) {
    var s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity) === 0)
      return false;
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  var SHAPES = ['path','rect','circle','ellipse','line','polygon','polyline','text'];
  var texts = [], colors = {}, seen = 0;
  var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
  var node;
  while ((node = walker.nextNode())) {
    var raw = node.nodeValue;
    if (!raw || !raw.trim()) continue;
    var el = node.parentElement;
    if (!el || !visible(el)) continue;
    var s = getComputedStyle(el);
    // **量文字节点自己的盒子，不是父元素的。** 块级元素的 getBoundingClientRect
    // 给的是整条容器宽度——拿它算"文字占多少面积"会把容器算成文字，
    // 通栏条里只有六个字也能报出两成以上。Range 给的是这段字真正占的位置。
    var range = document.createRange();
    range.selectNodeContents(node);
    var r = range.getBoundingClientRect();
    if (!r.width || !r.height) r = el.getBoundingClientRect();
    texts.push({
      text: raw.trim(),
      // 选择器线索：失败时要说得出"这个 14px 是哪个元素的"。
      // 2026-09-11 实测里助理以为是缓存，grep 两轮才发现是 `.th .id` 的单独规则。
      // 用 classList，不用正则切 className：正则里的反斜杠要在 Python 字符串里
      // 再转义一层，少写一层就是一条 SyntaxWarning，而这里 classList 本来就够用。
      sel: el.tagName.toLowerCase()
           + (el.classList.length
              ? '.' + Array.prototype.join.call(el.classList, '.') : ''),
      font_px: parseFloat(s.fontSize),
      weight: s.fontWeight,
      family: (s.fontFamily || '').split(',')[0].replace(/["']/g, '').trim(),
      color: s.color,
      background: s.backgroundColor,
      x: Math.round(r.left), y: Math.round(r.top),
      w: Math.round(r.width), h: Math.round(r.height)
    });
    if (++seen > 4000) break;
  }
  // 画面上实际出现的颜色：文字色、背景色、描边色。
  // **只数可见元素**：图标精灵放在 display:none 的 <defs> 里，把它们算进来
  // 会凭空多出一批 #000000（SVG fill 的初始值），报成「色板不合规」。
  var all = document.querySelectorAll('*');
  for (var i = 0; i < all.length && i < 4000; i++) {
    var el = all[i];
    if (el.closest('defs') || !visible(el)) continue;
    var st = getComputedStyle(el);
    var picks = [st.backgroundColor];
    // 边框色只在真的画了边框时才算。border-width:0 时 borderTopColor 仍会
    // 计算出一个值（通常是继承的文字色），照单全收会凭空多出一批黑。
    if (parseFloat(st.borderTopWidth) > 0) picks.push(st.borderTopColor);
    // 文字色只在这个元素直接含文字时才算——继承来的颜色不落到任何像素上。
    var own = Array.prototype.some.call(el.childNodes, function (n) {
      return n.nodeType === 3 && n.nodeValue && n.nodeValue.trim();
    });
    if (own) picks.push(st.color);
    // SVG 只数**形状**，不数容器。<svg>／<g>／<use> 这些容器的 fill 初始值就是
    // rgb(0,0,0)，它们一个像素都不画，却会让每张图都报出几十个「黑」。
    if (SHAPES.indexOf(el.tagName.toLowerCase()) >= 0
        && el.namespaceURI === 'http://www.w3.org/2000/svg') {
      picks.push(st.fill, st.stroke);
    }
    picks.forEach(function (c) { if (c) colors[c] = (colors[c] || 0) + 1; });
  }
  // 指名要量的元素：**几何一律从这里取，不从调用方的声明里取**。
  // 声明只说"哪个元素是刻度、哪个是量尺"，长度与位置由页面自己回答。
  var targets = {};
  try {
    var wanted = window.__BYCLAW_TARGETS__ || [];
    for (var t = 0; t < wanted.length; t++) {
      var sel = wanted[t];
      var el = document.querySelector(sel);
      if (!el) { targets[sel] = null; continue; }
      var tr = el.getBoundingClientRect();
      targets[sel] = {
        x: tr.left + (window.scrollX || 0), y: tr.top + (window.scrollY || 0),
        w: tr.width, h: tr.height,
        text: (el.textContent || '').trim().slice(0, 80)
      };
    }
  } catch (e) { targets = {}; }
  var d = document.documentElement, b = document.body;
  var report = {
    resources_ready: true,
    targets: targets,
    viewport: { w: window.innerWidth, h: window.innerHeight },
    content: {
      w: Math.max(d.scrollWidth, b.scrollWidth),
      h: Math.max(d.scrollHeight, b.scrollHeight)
    },
    texts: texts,
    colors: colors
  };
  var payload = btoa(unescape(encodeURIComponent(JSON.stringify(report))));
  var pre = document.createElement('pre');
  pre.id = '__PROBE_ID__';
  pre.textContent = payload;
  pre.style.display = 'none';
  document.body.appendChild(pre);
  // 装在取景框里时，--dump-dom 只会拿到外层的 DOM，所以把 payload 递出去。
  __FRAME_FORWARD__
  }
  function afterLoad() {
    // load 等待普通图片；额外检查仍在加载的图片，再等字体完成布局。
    var images = Array.prototype.map.call(document.images, function (img) {
      if (img.complete) return Promise.resolve();
      return new Promise(function (resolve) {
        img.addEventListener('load', resolve, {once: true});
        img.addEventListener('error', resolve, {once: true});
      });
    });
    Promise.all(images).then(function () {
      return document.fonts ? document.fonts.ready : Promise.resolve();
    }).then(collect);
  }
  if (document.readyState === 'complete') afterLoad();
  else window.addEventListener('load', afterLoad, {once: true});
})();
""".replace("__PROBE_ID__", _PROBE_ID)\
   .replace("__FRAME_FORWARD__", frame_forward_js("payload"))
# 用 replace 而不是 %-格式化：JS 与注释里随时可能出现百分号（"占 20% 以上"），
# 而 %-模板会把它当成格式符，报的是 `unsupported format character` ——
# 与"你在注释里写了个百分号"之间隔着两层。写这段时就踩了两次。


def _rgb_to_hex(value: str) -> str | None:
    match = re.match(r"rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)", value or "")
    if not match:
        return None
    # 全透明的颜色不算"画面上出现的颜色"：它没有落到任何一个像素上。
    alpha = re.match(r"rgba\([^)]*,\s*(0|0?\.0+)\s*\)", value or "")
    if alpha:
        return None
    return "#%02X%02X%02X" % tuple(int(g) for g in match.groups())


def _echoes(phrase: str, prose: str) -> bool:
    """这句图上的话，是不是从正文里搬来的。

    **不能用整句 `in`。** 转写往往会改尾巴：正文写"在不改真实数据的前提下回答…"，
    图上写"不改真实数据就能推演"——核心一模一样，整句比对却判成不重复。
    2026-09-12 实测中正是这样漏掉了 5 条里的 2 条，比例卡在阈值下方。

    改看**三字片段的重合率**：短到能跨过改写的尾巴，长到不会因为
    "数据""方法"这种通用词乱命中。
    """
    grams = {phrase[i:i + 3] for i in range(len(phrase) - 2)}
    if not grams:
        return False
    return sum(gram in prose for gram in grams) / len(grams) >= COPIED_GRAM_RATIO


def probe(
    source: str | Path,
    *,
    width: int,
    height: int,
    browser: str | None = None,
    timeout: int = DEFAULT_TIMEOUT,
    wait: int = 1,
    targets: list[str] | None = None,
) -> dict[str, Any]:
    """在浏览器里跑一遍探针，取回文本、计算样式与内容尺寸。

    `targets` 是要逐个量的 CSS 选择器——**数值图的几何从这里取**，
    不从调用方的声明里取。
    """
    import os

    src = Path(source)
    if not src.is_file():
        raise RasterError(f"源文件不存在：{src}")
    html = src.read_text(encoding="utf-8", errors="replace")
    executable = find_browser(browser)

    # **视口靠取景框，不靠 `--window-size`。**
    #
    # dump-dom 和直接截图都有窗口尺寸限制，PNG 的尺寸不能证明布局视口正确。
    # raster 的截图与这里的检查共用固定尺寸 iframe，按同一个宽高排版。
    #
    # 早先这里是"绕开"：溢出那一条改成跟目标画幅比，而不是跟
    # `innerWidth/innerHeight` 比。那只挡住了误报，没解决**版面本身排在了
    # 另一个视口下**——`vh`、高度媒体查询、流式折行在两处算出不同布局。
    # 实测 `height:108vh` 的页面，`raster` 报截断 864，
    # 而 `image inspect --render` 退出码 0、`truncated=false`，PNG 底部已缺。
    #
    # 取景框把页面装进一个尺寸精确的 iframe：**iframe 的视口就是它自己的盒子**，
    # 于是检查与截图看的是同一张版面。详见 `raster.viewport_frame_html`。
    report = _probe_once(src, html, executable, int(width), int(height),
                         work_wait=wait, timeout=timeout, targets=targets)
    got = report.get("viewport") or {}
    report["viewport_matched"] = (
        int(got.get("w") or 0) == int(width)
        and int(got.get("h") or 0) == int(height))
    return report


def _probe_once(src: Path, html: str, executable: str, win_w: int, win_h: int,
                *, work_wait: int, timeout: int,
                targets: list[str] | None) -> dict[str, Any]:
    """在**精确等于 `win_w×win_h`** 的视口下跑一次探针。"""
    import os

    wait = work_wait
    with tempfile.TemporaryDirectory() as work, ExitStack() as cleanup:
        def write_temporary(text: str, prefix: str) -> Path:
            # 同目录保留相对资源基准；独占创建，失败时也只清理自己的文件。
            fd, name = tempfile.mkstemp(dir=src.parent, prefix=prefix,
                                       suffix=".html")
            path = Path(name)
            cleanup.callback(path.unlink, missing_ok=True)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(text)
            return path

        # 要量哪些元素，先告诉页面。**几何由页面回答，不由调用方声明。**
        preload = ("<script>window.__BYCLAW_TARGETS__=%s;</script>\n"
                   % json.dumps(list(targets or []), ensure_ascii=False))
        try:
            probed = write_temporary(
                html + "\n" + preload + f"<script>{_PROBE_JS}</script>\n",
                ".byclaw-inspect-")
            framed = write_temporary(viewport_frame_html(
                probed.name, width=win_w, height=win_h,
                receiver_js=("var pre=document.createElement('pre');"
                             "pre.id=%r;pre.style.display='none';"
                             "pre.textContent=v;document.body.appendChild(pre);"
                             % _PROBE_ID)), ".byclaw-inspect-frame-")
        except OSError as exc:
            raise RasterError(f"无法在源目录创建检查临时文件：{src.parent}（{exc}）") from None
        try:
            argv = [
                executable, "--headless", *chromium_common_flags(),
                "--hide-scrollbars",
                # 外层窗口只要装得下取景框的加载，**不参与版面计算**。
                "--window-size=1280,900",
                # 结果要经 load → postMessage 递到外层才写进 DOM，
                # 预算给少了 `--dump-dom` 会在这之前就把 DOM 拿走。
                "--virtual-time-budget=%d" % max(wait * 1000, 3000),
                "--user-data-dir=%s" % chromium_profile_dir(work),
                "--dump-dom",
                framed.resolve().as_uri(),
            ]
            done = run_chromium_with_retries(
                argv, timeout=timeout,
                accept=lambda result: bool(_PAYLOAD.search(result.stdout or "")),
                runner=subprocess.run,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            raise RasterError(f"浏览器启动失败：{executable}（{exc}）") from None

    match = _PAYLOAD.search(done.stdout or "")
    if not match:
        raw = (done.stderr or done.stdout or "").strip()
        # 出路必须在失败点那行字里。`raster.sandbox_hint` 的 docstring 就是为这条
        # 写的——"一个 agent 只读得到失败点上的那行字"。第一版没复用它，
        # 结果 2026-09-11 实测中助理拿到一句没有下一步的报错，**转头放弃了这道门禁**，
        # 只给 raster 设了 HTML_IMAGE_NO_SANDBOX 就直接去渲染了。
        hint = sandbox_hint(raw)
        raise RasterError(
            "探针没有回报——页面可能根本没渲染出来。"
            f"浏览器输出：{raw[:300] or '（无）'}"
            + (f"\n{hint}" if hint else ""))
    return json.loads(base64.b64decode(
        re.sub(r"\s+", "", match.group(1))).decode("utf-8"))


#: 画面上写的倍数，例如 "≈1000×"、"5.3 倍"、"x8760"。
_RATIO_TEXT = re.compile(r"(?:≈|约|~)?\s*([0-9]+(?:[.,][0-9]+)?)\s*(?:×|x|X|倍)")


def _numeric_targets(numeric: dict[str, Any] | None) -> list[str]:
    """这次要量哪些元素。"""
    out: list[str] = []
    for key in ("ticks", "annotations"):
        for one in (numeric or {}).get(key) or []:
            for field in ("selector", "label_selector"):
                value = str(one.get(field) or "")
                if value and value not in out:
                    out.append(value)
    return out


def _parse_ratio(text: str) -> float | None:
    """从画面文字里读出那个倍数。读不出返回 `None`。"""
    match = _RATIO_TEXT.search(str(text or ""))
    if not match:
        return None
    try:
        return float(match.group(1).replace(",", ""))
    except ValueError:
        return None


def _measure_numeric(numeric: dict[str, Any],
                     measured: dict[str, Any]) -> tuple[list, list, list]:
    """把数值声明**绑到实际 DOM** 上：几何从页面量，倍数从画面文字读。

    **声明只负责指认元素，不负责提供数字。**

    早先这里直接用声明里的 `px` 与 `ratio` 去互相验证——那是拿输入跟自己比：
    HTML 里那根 669px 的量尺仍写着「≈1000×」，只要把计划里的声明改成 8760，
    检查就从 fail 变成 pass，而**图一个像素都没改**。
    实测复现过，这是同一个"快照跟自己比"的错误第四次出现。

    现在：`selector` 指哪个元素，长度就量哪个元素；倍数从那个元素
    （或 `label_selector` 指的元素）的**文字**里解析。计划改不动画面，
    也就骗不过这道检查。

    量不到的元素回报到 `missing`——**量不到不是通过**。
    """
    missing: list[str] = []

    def rect(selector: str):
        found = measured.get(selector)
        if not found:
            missing.append(selector)
        return found

    ticks = []
    for one in numeric.get("ticks") or []:
        selector = str(one.get("selector") or "")
        if not selector:
            # **没有 DOM 绑定就不是"退回声明值"，是查不了。**
            #
            # 上一版在这里退回调用方给的 `px`，理由写的是"留给没有对应 DOM
            # 的场景"。那条退路把整道检查还原成了自校验：HTML 里那根 669px
            # 的量尺仍写着「≈1000×」，只要不给 selector、把声明改成 8760，
            # 正式 inspect 就返回 pass——**图一个像素都没改**。
            #
            # 一条静默的退路等于一个开关：谁想绕过，不给字段即可。
            missing.append("刻度缺 selector（value=%r）——没有 DOM 绑定就无法核对"
                           % one.get("value"))
            continue
        found = rect(selector)
        if found:
            ticks.append({"px": float(found["x"]), "value": one.get("value")})

    annotations = []
    for one in numeric.get("annotations") or []:
        selector = str(one.get("selector") or "")
        if not selector:
            # 同上：量尺不指认元素就**核不了**，不是"按声明算"。
            missing.append("量尺缺 selector（label=%r）——没有 DOM 绑定就无法核对"
                           % one.get("label"))
            continue
        found = rect(selector)
        if not found:
            continue
        label_selector = str(one.get("label_selector") or "")
        label_text = found.get("text") or ""
        if label_selector:
            label_found = rect(label_selector)
            label_text = (label_found or {}).get("text") or ""
        ratio = _parse_ratio(label_text)
        if ratio is None:
            missing.append(
                "%s 的文字里读不出倍数：%r" % (label_selector or selector,
                                            label_text[:24]))
            continue
        annotations.append({"label": label_text.strip()[:24],
                            "ratio": ratio, "px": float(found["w"])})
    return ticks, annotations, missing


def inspect_visual(
    source: str | Path,
    *,
    width: int,
    height: int,
    expect_texts: list[str] | None = None,
    expect_identifiers: list[str] | None = None,
    glossary: list[str] | None = None,
    section_excerpt: str | None = None,
    design_width: int | None = None,
    display_width: int | None = None,
    numeric: dict[str, Any] | None = None,
    browser: str | None = None,
    timeout: int = DEFAULT_TIMEOUT,
) -> dict[str, Any]:
    """跑全部检查，返回 `{ok, failures, warnings, stats}`。

    `failures` 非空即业务失败（退出码 1）；`warnings` 不阻断，但会写进结果供人看。
    """
    report = probe(source, width=width, height=height,
                   browser=browser, timeout=timeout,
                   targets=_numeric_targets(numeric))
    design_w = design_width or width
    # **显示宽度是外面告诉我们的，不是这里猜的。**
    # 不给就用缺省，但缺省只是「不知道时的退路」——知道的调用方必须传，
    # 否则这道检查判的是一个跟读者无关的宽度。
    display_w = int(display_width or DEFAULT_DISPLAY_WIDTH)
    failures: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    texts = report.get("texts") or []

    # ── 1 溢出：内容比画布大 ────────────────────────────────────────
    # **这一条是三条里最容易中的。** 浏览器不会报错，只是把多出来的内容画到
    # 画布外——截图按视口裁，于是最后一个区块整块消失，而退出码是 0。
    #
    # 比的是**目标画幅**，不是 `window.innerWidth/innerHeight`：`--dump-dom` 下
    # `--window-size` 要扣掉浏览器外框（实测 1280×800 → 1262×704），
    # 拿它当基准会把每一张合格的图都判成溢出。真正出图的 `raster html`
    # 用的是 `--screenshot`，画布严格等于请求的宽高。
    content, viewport = report.get("content") or {}, report.get("viewport") or {}
    over_h = int(content.get("h", 0)) - height
    over_w = int(content.get("w", 0)) - width
    if over_h > 1 or over_w > 1:
        failures.append({
            "check": "overflow",
            "detail": f"内容超出画布：高 +{max(over_h, 0)}px、宽 +{max(over_w, 0)}px",
            "fix": "删条目或换更高的画幅档位（body_std / body_tall）。"
                   "**不要缩字号**——缩到 16px 以下读者那边就是看不清。",
        })

    # ── 2 字号：**按落地字号判，不按设计字号** ──────────────────────
    #
    # 早先这一段的注释就是这么写的，而代码筛的是 `t["font_px"]`（设计字号）。
    # 注释与代码相反，于是这道检查判的其实是「设计稿上字够不够大」——
    # 那个数跟读者看不看得清没有关系：同一份设计稿放大一倍出 PNG，
    # 设计字号不变、落地字号也不变，而把它塞进 364px 宽的手机正文里就是看不清。
    #
    # 实测过放过去的样子：一张条形图刻度 16px、行名 21px、数值 23px，
    # 设计字号全都 ≥ 16，检查报 `pass`、`warnings=[]`；
    # 而在 420px 手机预览里等效字号只有 4.6 / 6.0 / 6.5px，必须放大才读得出数值。
    #
    # 缩放系数用 `render_scale` 取，**不再借道 `landing_px(1.0, …)`**——
    # 后者会把 0.5289 舍成 0.5，系数先掉 5.5% 再乘进每一处字号。
    scale = render_scale(design_w, display_w)
    # **换算方向：落地下限 ÷ 缩放 = 设计字号下限。**
    #
    # 早先写的是 `MIN_FONT_PX * scale`——那算出来的是"16px 设计字号落地后有多大"，
    # 却被当成"设计字号至少要多大"填进修复提示。方向反了，数值差得很远：
    # 设计宽 1280、显示宽 364 时，它提示"设计字号不低于 4px"，
    # 而正确答案是 28.13px。**照着提示改只会把字越调越小，然后再失败一轮。**
    #
    # 向上取一位小数：取整或四舍五入都可能给出一个刚好仍不达标的数，
    # 那会让人改完再撞一次同一堵墙。
    min_design_px = math.ceil(MIN_LANDING_FONT_PX / scale * 10) / 10 if scale else 0.0
    too_small = sorted(
        ({"text": t["text"][:24], "selector": t.get("sel", ""),
          "font_px": t["font_px"],
          "landing_px": round(t["font_px"] * scale, 1)}
         for t in texts
         if round(t.get("font_px", 0) * scale, 1) < MIN_LANDING_FONT_PX),
        key=lambda x: x["landing_px"])
    if too_small:
        culprits = sorted({item["selector"] for item in too_small if item["selector"]})
        failures.append({
            "check": "min_font",
            "detail": f"{len(too_small)} 处文字落地字号低于 {MIN_LANDING_FONT_PX}px"
                      f"（按图片显示宽 {display_w}px、设计宽 {design_w}px，"
                      f"缩放 {scale:.3f} 折算）"
                      + (f"，来自 {len(culprits)} 类元素：{'、'.join(culprits[:6])}"
                         if culprits else ""),
            "samples": too_small[:6],
            # **报出选择器**，否则改了 CSS 却不生效时无从判断是改错了地方还是没生效。
            "selectors": culprits,
            "fix": f"落地字号要 ≥ {MIN_LANDING_FONT_PX}px。在 {design_w}px 设计宽下，"
                   f"这意味着设计字号不低于 {min_design_px:.1f}px。\n"
                   "**加大 PNG 分辨率没用**——那只增加像素密度，不改变文字在页面上占多宽。"
                   "要么把关键文字调大、要么减少这张图要说的东西、"
                   "要么改成适合窄屏的纵向布局。\n"
                   "改完仍报同一个选择器，多半是更具体的规则盖住了你改的那条"
                   "（CSS 优先级），不是没生效。",
        })

    # 舒适线：过了硬下限不等于读得舒服。
    #
    # 8px 是「勉强能认」。正文 16px，图里承载数值的文字掉到它的一半以下，
    # 读者就得放大——**而放大过的图基本不会再被读第二遍**。
    # 这一档只告警：判得准的硬失败才值得阻断，这条还没有校准过。
    uncomfortable = sorted(
        ({"text": t["text"][:24], "selector": t.get("sel", ""),
          "font_px": t["font_px"],
          "landing_px": round(t["font_px"] * scale, 1)}
         for t in texts
         if MIN_LANDING_FONT_PX
         <= round(t.get("font_px", 0) * scale, 1) < COMFORTABLE_LANDING_FONT_PX),
        key=lambda x: x["landing_px"])
    if uncomfortable:
        warnings.append({
            "check": "small_font",
            "detail": f"{len(uncomfortable)} 处文字落地字号在 "
                      f"{MIN_LANDING_FONT_PX}–{COMFORTABLE_LANDING_FONT_PX}px 之间"
                      f"（显示宽 {display_w}px），能认但要凑近看",
            "samples": uncomfortable[:6],
            "fix": "承载数值、行名这类要读的文字优先调大；纯装饰的角标可以留在这一档。",
        })

    # ── 3 期望文本：节点主名与边标注必须真的在画面上 ──────────────────
    # 缺中文字体时 Chromium 不报错，按 fallback 渲染或渲成方框，退出码仍是 0。
    rendered = "\n".join(t["text"] for t in texts)
    missing = [want for want in (expect_texts or []) if want and want not in rendered]
    if missing:
        failures.append({
            "check": "expected_text",
            "detail": f"{len(missing)} 项计划里的文字没有出现在画面上",
            "samples": missing[:8],
            "fix": "对照 structure.nodes[].label 逐项检查。整片缺失多半是渲染容器"
                   "没装中文字体（装 fonts-noto-cjk），个别缺失是 HTML 里漏填。",
        })

    # ── 3b 代码标识：**告警，不是硬失败** ──────────────────────────
    #
    # 设计档要求的是"标识**出现时**必须逐字取自原文，不得自己编"，
    # 不是"每个标识都必须挤进画面"。第一版把它和 label 一起钉成硬失败，
    # 与 16px 下限撞在一起就**无解**：矩阵行头只有约 300px 宽，
    # 而标识是 `methodology_becomes_object` 这种长 snake_case。
    #
    # 2026-09-11 实测里助理为此反复了七八轮，最后靠注入 inline style 顶过去，
    # 产物上留下 `interface_transl / ator`、`knowledge_retrie / val`
    # 三处从中间断开的行头——**为了过门禁把图弄坏了**。
    absent_ids = [
        want for want in (expect_identifiers or []) if want and want not in rendered
    ]
    if absent_ids:
        warnings.append({
            "check": "identifier_absent",
            "detail": f"{len(absent_ids)} 个代码标识没有出现在画面上，"
                      "这些节点只剩一个信息寄存器",
            "samples": absent_ids[:8],
            "fix": "标识是深度的主要来源（读者同时拿到抽象角色和它的实现），"
                   "能放下就放。**放不下时移到图例条或注解面板，不要硬塞进行头**——"
                   "挤进去再缩到 16px 以下，或者断词换行，都比不放更糟。",
        })

    # ── 3c 数值图：标出来的倍数与画出来的长度必须是同一回事 ──────────
    #
    # **这一条拦的错误不在文字里，在几何里。**
    #
    # 0913 交付的 visual-004 是一张对数轴图：刻度落在干净的对数尺上
    # （k≈73.8，四段一致），而图上一根 669px 的量尺标着「≈1000×」——
    # 按该尺度它其实是 8698×，小时到年本就是 8760 倍。
    #
    # 上面几条都查不出来：溢出看盒子、字号看 px、术语看字符串，
    # 没有一条同时看「文字说的数」和「像素画的长度」。语义复核也放行了它——
    # 「≈1000×」在正文里找不到可比的原句。
    #
    # 所以要图自己把数值说出来（`numeric`），然后拿它和几何对。
    # **不声明就不查**：不能凭 DOM 猜哪根线是量尺，猜错了会把对的图拦下来。
    if numeric:
        try:
            measured = report.get("targets") or {}
            ticks, annotations, missing = _measure_numeric(numeric, measured)
            for selector in missing:
                failures.append({
                    "check": "numeric_target_missing",
                    "detail": f"数值声明指向的元素在页面上找不到：{selector}",
                    "fix": "选择器写错、或那个元素根本没渲染出来。"
                           "**声明与画面对不上时不能放行**——"
                           "量不到就等于没查。",
                })
            found = list(check_log_axis_annotations(ticks, annotations))
            found += check_axis_covers(
                ticks, claimed_span=numeric.get("claimed_span"))
            for item in found:
                failures.append({
                    "check": "numeric_geometry",
                    "detail": item.message,
                    "samples": [item.detail],
                    "fix": "**倍数标注与轴刻度必须来自同一份数据。**\n"
                           "对数轴上长度与 ln(值之比) 成正比：想标 N×，"
                           "那根量尺就得是 k·ln(N) 长。\n"
                           "改数字不改几何、或改几何不改数字，都会再撞一次。",
                })
        except AxisError as failure:
            # 轴本身不成立时**先报轴**：拿一个错误的尺度去算倍数，
            # 只会产出更离谱的结论，而那个结论会把人引到错的地方去改。
            failures.append({
                "check": "numeric_axis",
                "detail": failure.message,
                "samples": [failure.detail],
                "fix": "先把刻度与值对上，再谈量尺。",
            })

    # ── 4 中文回落到西文字体：字体缺失的先兆 ────────────────────────
    cjk_on_latin = [
        t["text"][:20] for t in texts
        if re.search(r"[一-鿿]", t.get("text", ""))
        and (t.get("family") or "").lower() in _LATIN_FALLBACKS
    ]
    if cjk_on_latin:
        warnings.append({
            "check": "cjk_fallback",
            "detail": f"{len(cjk_on_latin)} 处中文落在西文兜底字体上，容器可能没装中文字体",
            "samples": cjk_on_latin[:5],
        })

    # ── 5 emoji 当图标（硬失败）与 dingbats（告警）────────────────────
    with_emoji = [t["text"][:20] for t in texts if _EMOJI.search(t.get("text", ""))]
    if with_emoji:
        failures.append({
            "check": "emoji",
            "detail": f"{len(with_emoji)} 处使用了 emoji",
            "samples": with_emoji[:5],
            "fix": "图标一律内联 SVG + currentColor。emoji 跨平台渲染不一致，"
                   "在渲染容器里常直接变成方框或黑白轮廓。",
        })
    dingbats = sorted({
        ch for t in texts for ch in _DINGBAT.findall(t.get("text", ""))
    })
    if dingbats:
        warnings.append({
            "check": "dingbat",
            "detail": f"用了 {len(dingbats)} 种符号字符当标记：{' '.join(dingbats)}",
            "fix": "这些不是 emoji，但部分平台会渲成彩色变体，字号与基线不受 CSS 控制。"
                   "骨架的图标精灵里有 `i-check` / `i-cross` / `i-warn`，"
                   "用 `<svg class=\"icon\"><use href=\"#i-check\"></use></svg>` 替代；"
                   "或者干脆用文字（PASS / FAIL），矩阵里反而更好扫。",
        })

    # ── 6 色板合规 ─────────────────────────────────────────────────
    allowed = allowed_colors()
    stray: dict[str, int] = {}
    for raw, count in (report.get("colors") or {}).items():
        hexed = _rgb_to_hex(raw)
        if hexed and hexed not in allowed:
            stray[hexed] = stray.get(hexed, 0) + int(count)
    if stray:
        top = sorted(stray.items(), key=lambda kv: -kv[1])[:8]
        warnings.append({
            "check": "palette",
            "detail": f"{len(stray)} 个色值不在设计令牌里",
            "samples": [{"color": c, "count": n} for c, n in top],
            "fix": "色板不够用时补语义位，不要破例——破例一次整篇的一致性就失效了。",
        })

    # ── 7 内容分布：画幅是海报，中间不该有大片死区 ────────────────────
    #
    # **不能用"内容高度占画布比例"来判。** 2026-09-11 的 visual-001 里，
    # 卡片边框与页脚都延伸到 y=745/800 = 93%，任何按 DOM 高度或元素包围盒
    # 算出来的占比都会超过 80% 而不触发，**而卡片内部空了 40%**。
    #
    # 量的是**文字块之间的最大空档**：它自动忽略空的容器与贴底的页脚，
    # 正好对上肉眼看到的那片空白。实测 visual-001 此值 329px，与像素扫描
    # 得到的 323px 一致。
    spans = sorted((int(t["y"]), int(t["y"]) + max(int(t["h"]), 1)) for t in texts)
    merged: list[list[int]] = []
    for top, bottom in spans:
        if merged and top <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], bottom)
        else:
            merged.append([top, bottom])
    gap, gap_at = 0, 0
    for earlier, later in zip(merged, merged[1:]):
        if later[0] - earlier[1] > gap:
            gap, gap_at = later[0] - earlier[1], earlier[1]
    if height and gap > height * 0.2:
        warnings.append({
            "check": "content_distribution",
            "detail": f"版面中间有 {gap}px 的空档（y={gap_at} 起），占画布 "
                      f"{round(gap / height * 100)}%",
            "fix": "内容集中在一侧，画幅偏大。**先收容器高度、字号与间距，"
                   "或换更矮的画幅档位**——不要为了填满画布去加内容，"
                   "凑上去的那几行读者也要读。",
        })

    # ── 8 文字密度：画布是不是大部分都空着 ──────────────────────────
    #
    # 量的是**文字占画布的面积比**，作为 `stats` 常驻回报；
    # 只有低到离谱时才告警。
    #
    # 为什么不做成"容器宽度 vs 其内文字宽度"：矩阵的单元格天然是
    # 宽容器里居中一小段文字（visual-002 的格子约 57%），
    # 而通栏条是宽容器里靠左一小段（visual-001 约 17%）——
    # 两者形状相同、性质不同，按比例判会把合格的矩阵一起误伤。
    # **判不准的门禁比没有门禁更糟**，所以这里只报数，不当裁判。
    text_area = sum(max(int(t.get("w", 0)), 0) * max(int(t.get("h", 0)), 0) for t in texts)
    canvas_area = max(width * height, 1)
    density = text_area / canvas_area
    if texts and density < MIN_TEXT_AREA_RATIO:
        warnings.append({
            "check": "text_density",
            "detail": f"文字只占画布 {density:.1%}，画面大部分是空的",
            "fix": "要么这张图的信息本来就少（那就换更小的画幅档，或并进相邻那张），"
                   "要么容器开得太宽而内容靠边。**不要靠放大字号填**——"
                   "字阶是全篇统一的。",
        })

    # ── 9 图文重复：这张图是不是在把正文再抄一遍 ──────────────────
    #
    # **这是唯一还没被机制覆盖的大问题。**
    #
    # `information_gain` 是**自证的**——每张图单看都说得出"我比文字多给了什么"，
    # 而没有任何环节拿它和正文比过。2026-09-12 实测里两张图都填了像样的
    # information_gain，其中一张写的是"替代三段文字里的重复交代"，
    # 而正文并没有因此缩短；另一张所在的那段正文甚至直接写着
    # "把这三句并成一张表，就是下面的落位表"——**正文自己宣告了图是它的转写**。
    #
    # 比对的是**画面上的实际文字**与**该节正文原文**，不是计划里的描述性字段：
    # `must_include` 写的是"要画什么"（"三行 × 四个维度"），
    # 与画出来的短句（"只用它查数与录数"）字面对不上，比了也白比。
    excerpt = str(section_excerpt or "")
    if excerpt:
        # 只看够长的句子。两三个字的层名、列头本来就该与正文一致，
        # 那是术语统一，不是重复。
        phrases = [
            t["text"] for t in texts
            if len(t.get("text", "")) >= COPIED_PHRASE_MIN_CHARS
        ]
        copied = [phrase for phrase in phrases if _echoes(phrase, excerpt)]
        if len(copied) >= COPIED_PHRASE_MIN_HITS and phrases and (
                len(copied) / len(phrases) >= COPIED_PHRASE_RATIO):
            warnings.append({
                "check": "duplicates_prose",
                "detail": f"画面上 {len(copied)}/{len(phrases)} 条成句文字"
                          f"与本节正文高度重合，这张图接近正文的转写",
                "samples": copied[:5],
                "fix": "图该给的是文字给不了的东西——拓扑、数量关系、空间结构、"
                       "可对照查的取用方式。**如果它只是把同样几句话换个排版，"
                       "就回去确认 information_gain 是否真的成立**："
                       "要么让正文把这几句删掉（图替代文字），"
                       "要么这张图本来就不该出。",
            })

    # ── 10 术语一致 ─────────────────────────────────────────────────
    off_glossary = [
        term for term in (glossary or [])
        if term and term not in rendered and any(
            ch in rendered for ch in term if "一" <= ch <= "鿿")
    ]
    if off_glossary:
        warnings.append({
            "check": "glossary",
            "detail": "这些锁定术语没有在图上原样出现，可能被改写了",
            "samples": off_glossary[:6],
            "fix": "图上术语必须与正文逐字一致。写『编排层』而正文写『调度层』，"
                   "读者会以为那是两个东西。",
        })

    return {
        "ok": not failures,
        "status": "fail" if failures else "pass",
        "source": str(source),
        # 供 write_inspection 落盘，用于跨图重叠比对
        "_phrases": sorted({t["text"] for t in texts
                            if len(t.get("text", "")) >= COPIED_PHRASE_MIN_CHARS}),
        "failures": failures,
        "warnings": warnings,
        "stats": {
            "text_runs": len(texts),
            "min_font_px": min((t["font_px"] for t in texts), default=0),
            "min_landing_px": round(
                min((t["font_px"] for t in texts), default=0) * scale, 1),
            "design_width": design_w,
            # **显示宽度要落进报告。** 同一张图按 677 判和按 364 判结论相反，
            # 报告里不写清按哪个宽度判的，事后就说不清那句 pass 到底代表什么。
            "display_width": display_w,
            "render_scale": round(scale, 4),
            "min_landing_limit": MIN_LANDING_FONT_PX,
            "target": {"w": width, "h": height},
            # 探针那一跑的实际视口，**比 target 略小**（浏览器外框）。
            # 骨架把画幅写死在 body 上，所以版面按 target 排，不受这点差异影响；
            # 不写死画幅的页面，这里的差值就是排版可能有偏移的提示。
            "probe_viewport": viewport,
            "content": content,
            # 版面到底排在哪个视口下——下游据此决定能不能复用这个高度。
            "viewport_matched": bool(report.get("viewport_matched")),
            "resources_ready": report.get("resources_ready") is True,
            "distinct_colors": len(report.get("colors") or {}),
            "phrase_count": len([t for t in texts
                                 if len(t.get("text", "")) >= COPIED_PHRASE_MIN_CHARS]),
            # 常驻回报，便于横向比较同一篇里几张图的密度差异。
            "text_area_ratio": round(density, 4),
        },
    }


# ── 检查记录：让"检查过"成为可核验的事实 ──────────────────────────────
#
# 原先 `finalize_assets.py` 把 `crop` / `text_legibility` / `factual_scope`
# **无条件写成 `"pass"`**，而 `--reviewed-all` 只断言"你声称看过了"，
# 连那几个字面量都不受它控制。2026-09-11 交付的清单里四张图的
# `text_legibility: pass` 因此全是伪证——`inspect` 一次都没跑成功过。
#
# 记录把三样东西绑在一起：**哪份计划、哪个 HTML、哪张 PNG**。
# 任意一样变了，哈希就对不上，`finalize` 拒绝置 validated。
INSPECTION_DIR = ".inspections"
INSPECTION_SCHEMA = "1.0"


def inspection_path(asset_directory: str | Path, asset_id: str) -> Path:
    return Path(asset_directory) / INSPECTION_DIR / f"{asset_id}.json"


#: 复用 manifest 那份实现，**不要另写一个**。
#: 第一版这里自己算了一遍 sha256，只差在大小写（manifest 返回大写），
#: 于是 finalize 比对哈希时每一张合法资产都被判成"不是被检查过的那张"。
#: 两份等价实现就是这么开始漂的。
from byclaw_caps.image.manifest import file_sha256 as _sha256


def write_inspection(
    result: dict[str, Any],
    *,
    asset_directory: str | Path,
    asset_id: str,
    plan_id: str,
    source: str | Path,
    layout: tuple[int, int],
    scale: int,
    output: str | Path | None = None,
) -> Path:
    """把一次检查落盘。`output` 给了才记 PNG 哈希——没渲染就不该声称验过成品。"""
    source_path = Path(source)
    record = {
        "schema_version": INSPECTION_SCHEMA,
        "asset_id": asset_id,
        "plan_id": plan_id,
        "status": result.get("status"),
        "source": source_path.name,
        "source_sha256": _sha256(source_path),
        "layout": list(layout),
        "scale": scale,
        "delivered": list(delivered_size(layout[0], layout[1], scale)),
        "output": Path(output).name if output else None,
        "output_sha256": _sha256(Path(output)) if output else None,
        # 画面上的成句文字：留给 finalize 做**跨图重叠**比对。
        # 编译期那条 `_warn_overlapping_visuals` 比的是计划里的 `must_keep`，
        # 而 must_keep 是"要画什么"的描述（"三行 × 四个维度"），
        # 与画出来的短句（"只用它查数与录数"）字面对不上——粒度不对，比了也白比。
        # 真正能比的是**渲染之后的实际文字**，而那只有这里拿得到。
        "phrases": list(result.get("_phrases") or []),
        "failures": result.get("failures") or [],
        "warnings": result.get("warnings") or [],
        "stats": result.get("stats") or {},
        "inspected_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    target = inspection_path(asset_directory, asset_id)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def read_inspection(asset_directory: str | Path, asset_id: str) -> dict[str, Any] | None:
    target = inspection_path(asset_directory, asset_id)
    if not target.is_file():
        return None
    try:
        value = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def inspect_and_render(
    source: str | Path,
    *,
    layout: tuple[int, int],
    scale: int,
    output: str | Path,
    browser: str | None = None,
    **checks: Any,
) -> dict[str, Any]:
    """先检查，通过了才渲染。

    **顺序不能反。** 反过来的话，渲染已经落盘，检查失败也拦不住下游拿去用——
    2026-09-11 实测里助理正是先渲染、后来干脆跳过检查。
    检查不通过时**不产出 PNG**，让"拿到图"这件事本身依赖于"检查通过"。
    """
    result = inspect_visual(
        source, width=layout[0], height=layout[1], browser=browser, **checks)
    if not result["ok"]:
        result["rendered"] = False
        return result
    # **页面高度这里已经量过了**，别让 `rasterize_html` 再启一次浏览器去量。
    #
    # 探针那一跑读的就是 `content.h`（DOM 的 scrollHeight），与截断检查要的
    # 是同一个数。不传的话，每出一张图都要多一次冷启动——实测那一跑在
    # 2–15 秒之间波动，一篇文章四五张图就是分钟级的白等，
    # 而且每次都在系统临时目录里留下一个浏览器 profile。
    #
    # 这一条也正是 `rasterize_html(content_height=…)` 那个参数存在的理由。
    # **只有视口对齐且资源就绪时才复用。** 对不上时那个数是在另一个版面下量的，
    # 传下去等于让截断检查拿错的基准去判——实测 `108vh` 的页面就是这么
    # 被判成"没截断"的，而 PNG 底部确实缺了一块。
    # 对不上就传 None，让 `rasterize_html` 自己去做校准过的那次探测。
    measured = ((result.get("stats") or {}).get("content") or {}).get("h")
    stats = result.get("stats") or {}
    if not (stats.get("viewport_matched") and stats.get("resources_ready")):
        measured = None
    render = rasterize_html(
        source, output, width=layout[0], height=layout[1],
        scale=scale, browser=browser,
        content_height=int(measured) if measured else None)
    result["rendered"] = True
    result["output"] = render["output"]
    result["delivered_size"] = render["size"]
    # 溢出那一条已经在 inspect 里判过（`check: overflow`），这里只如实带出来，
    # 不再重复报错——同一件事报两遍，修的人会以为是两个问题。
    result["truncated"] = render.get("truncated")
    return result


__all__ = [
    "inspect_visual", "probe", "inspect_and_render",
    "write_inspection", "read_inspection", "inspection_path",
    "INSPECTION_DIR", "INSPECTION_SCHEMA",
]
