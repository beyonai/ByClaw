#!/usr/bin/env python3
"""Validate VisualPlan and synchronized ImageAssetManifest JSON/YAML."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from byclaw_caps.image.manifest import read_json, read_yaml, validate_manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate finalized image assets")
    parser.add_argument("--plan", required=True, help="VisualPlan 1.1 JSON")
    parser.add_argument("--manifest", help="Manifest JSON；默认使用 VisualPlan.asset_directory")
    args = parser.parse_args()

    plan = read_json(Path(args.plan).expanduser().resolve())
    manifest_path = (
        Path(args.manifest).expanduser().resolve()
        if args.manifest
        else Path(str(plan.get("asset_directory") or "")) / "image-asset-manifest.json"
    )
    yaml_path = manifest_path.with_suffix(".yaml")
    if not manifest_path.is_file() or not yaml_path.is_file():
        raise FileNotFoundError("ImageAssetManifest JSON 和 YAML 必须同时存在")
    manifest = read_json(manifest_path)
    yaml_manifest = read_yaml(yaml_path)
    errors = validate_manifest(manifest, plan, yaml_manifest=yaml_manifest)
    result = {"status": "fail" if errors else "pass", "failures": errors}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
