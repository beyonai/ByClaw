#!/usr/bin/env python3
"""生图：画幅精确性校验。

**本能力的价值不是「生成图片」，是「保证画幅精确」。**

实测平台原生生图：1280×720 精确，但 **1080×1440 降级为 864×1152**（0.8×），且输出为
JPEG 却命名 ``.png``。三个真实业务画幅中有一个达不到，而图文卡片正需 1080×1440——
这就是不能直接用内置工具、必须自建这项能力的全部理由。

现有 ``image_providers.py`` 356 行做了周全的**请求前**约束（``ARK_MIN_PIXELS``、
``QWEN_MAX_PIXELS``、比例裁剪），却**请求后完全不验**：全文没有一处检查返回的图实际
是多大。静默降级正是从这里漏过去的。本模块补上这一道。

**不引入 Pillow。** 本项目第三方依赖只有 ``httpx`` 与 ``yaml``，为读个宽高再加一个
不划算；PNG 的 IHDR 与 JPEG 的 SOF 直接解头即可。
"""

from __future__ import annotations

import re
import struct
from pathlib import Path
from typing import Any

VERSION = "1.0.0"

#: 三个真实业务画幅。``card`` 正是平台原生会降级的那一档。
BUSINESS_SIZES: dict[str, tuple[int, int]] = {
    "video_landscape": (1280, 720),
    "card": (1080, 1440),
    "scene": (1920, 1080),
}

# 火山（方舟）用 x，通义用 *——两家分隔符不同，调用方不该关心
_SIZE = re.compile(r"^\s*(\d+)\s*[x*×]\s*(\d+)\s*$", re.I)

# JPEG 中携带尺寸的帧起始标记；C4／C8／CC 是别的用途，须排除
_SOF = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}


class ImageError(ValueError):
    """尺寸串非法、文件不可读，或格式无法识别。"""


def parse_size(value: str) -> tuple[int, int]:
    match = _SIZE.match(str(value or ""))
    if not match:
        raise ImageError(f"无法解析尺寸 {value!r}，须形如 1080x1440 或 1080*1440。")
    width, height = int(match.group(1)), int(match.group(2))
    if width <= 0 or height <= 0:
        raise ImageError(f"尺寸必须为正：{value!r}")
    return width, height


def read_format(path: str | Path) -> str:
    """按魔数判断真实格式。

    **不看扩展名**——平台原生输出 JPEG 却命名 ``.png``，只看扩展名会被骗过去。
    """
    target = Path(path)
    if not target.is_file():
        raise ImageError(f"文件不存在：{target}")
    head = target.read_bytes()[:12]
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head.startswith(b"\xff\xd8"):
        return "jpeg"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    raise ImageError(f"无法识别的图片格式：{target}")


def read_dimensions(path: str | Path) -> tuple[int, int]:
    """读实际像素。PNG 解 IHDR，JPEG 扫 SOF。"""
    target = Path(path)
    kind = read_format(target)
    data = target.read_bytes()

    if kind == "png":
        # 8 字节签名 + 4 长度 + 4 类型 IHDR，随后是宽高各 4 字节大端
        if len(data) < 24 or data[12:16] != b"IHDR":
            raise ImageError(f"PNG 头损坏：{target}")
        return struct.unpack(">II", data[16:24])

    if kind == "jpeg":
        index = 2
        while index + 9 < len(data):
            if data[index] != 0xFF:
                index += 1
                continue
            marker = data[index + 1]
            if marker in _SOF:
                height, width = struct.unpack(">HH", data[index + 5 : index + 9])
                return width, height
            if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
                index += 2
                continue
            segment = struct.unpack(">H", data[index + 2 : index + 4])[0]
            index += 2 + segment
        raise ImageError(f"JPEG 中未找到 SOF 帧：{target}")

    raise ImageError(f"暂不支持读取 {kind} 的尺寸：{target}")


def verify_output(path: str | Path, requested: str) -> dict[str, Any]:
    """出图后的门禁：像素必须**精确相等**，格式必须与扩展名相符。

    不接受「差不多」——一像素之差同样是不合约。降级不得被当作成功：那正是平台原生
    1080×1440 → 864×1152 能悄悄溜过去的原因。
    """
    target = Path(path)
    want_w, want_h = parse_size(requested)

    if not target.is_file():
        return {
            "ok": False,
            "code": "MISSING_OUTPUT",
            "expected": (want_w, want_h),
            "hint": f"出图未落盘：{target}。请检查 provider 返回与下载环节。",
        }

    try:
        kind = read_format(target)
        actual = read_dimensions(target)
    except ImageError as exc:
        return {
            "ok": False,
            "code": "UNREADABLE",
            "expected": (want_w, want_h),
            "hint": str(exc),
        }

    suffix = target.suffix.lower().lstrip(".")
    suffix = "jpeg" if suffix == "jpg" else suffix
    if suffix and suffix != kind:
        return {
            "ok": False,
            "code": "FORMAT_MISMATCH",
            "expected": (want_w, want_h),
            "actual": actual,
            "format": kind,
            "hint": (
                f"文件名后缀是 .{suffix}，实际却是 {kind}——平台原生生图有此行为。"
                "请按真实格式重命名，或改用能按请求格式返回的 provider。"
            ),
        }

    if actual != (want_w, want_h):
        scale = round(actual[0] / want_w, 4) if want_w else 0.0
        return {
            "ok": False,
            "code": "SIZE_MISMATCH",
            "expected": (want_w, want_h),
            "actual": actual,
            "scale": scale,
            "format": kind,
            "hint": (
                f"请求 {want_w}×{want_h}，实得 {actual[0]}×{actual[1]}（{scale}×）。"
                "画幅不精确即不合约——改用可直出目标尺寸的 provider（通义默认可出三个业务画幅），"
                "不要在下游拉伸补救，那会糊。"
            ),
        }

    return {"ok": True, "expected": (want_w, want_h), "actual": actual, "format": kind}


__all__ = [
    "VERSION",
    "BUSINESS_SIZES",
    "ImageError",
    "parse_size",
    "read_format",
    "read_dimensions",
    "verify_output",
]


# ── 供应商尺寸规则（A3）────────────────────────────────────────────────────
#
# 由 `generate-content-images/scripts/image_providers.py` 迁入。
#
# **搬进来时验证了一个假设，结果是否定的。** 曾猜测线上那次「请求 1080×1440 拿回
# 864×1152」是被这套客户端夹取规则改的。实测：qwen 对 1080×1440 原样透传（1.56M 像素
# 落在它 0.26M–4.19M 的合法区间内，不触发任何缩放）。**所以那次降级来自服务端，不是这里。**
#
# 这反而让 `verify_output` 更不能省：客户端规则可以提前算，服务端给什么只能量。
#
# 客户端夹取本身仍然真实存在且影响很大——ark 的下限是 3.69M 像素，三个业务画幅
# **全部会被放大**（1080×1440 → 1776×2368）。所以本节提供 `plan_size`：发请求之前先说清
# 这家会给你什么，别等生成完再返工。

import math as _math
import re as _re

_SIZE_RE = _re.compile(r"^(\d+)\s*[xX×*]\s*(\d+)$")

#: 每家的合法区间不同——同一请求在两家会得到不同尺寸，不能混用。
PROVIDERS: dict[str, dict] = {
    # 键与平台的 `providerName` 同名（小写）。火山引擎的生图 API 叫「方舟」，
    # 但平台存的是 VOLCENGINE——**两处用不同的名字，换环境时只会改到一处**。
    "volcengine": {
        "min_pixels": 3_686_400,        # 2560×1440
        "max_pixels": 16_777_216,       # 4096×4096
        "target_pixels": 4_200_000,
        "min_ratio": 1 / 16,
        "max_ratio": 16.0,
    },
    "qwen": {
        "min_pixels": 512 * 512,
        "max_pixels": 2048 * 2048,
        "target_pixels": 1024 * 1024,
        "min_ratio": 1 / 8,
        "max_ratio": 8.0,
    },
}
DEFAULT_PROVIDER = "qwen"


def scale_into(width: float, height: float, *, min_pixels: int, max_pixels: int,
               target_pixels: int, min_ratio: float, max_ratio: float) -> tuple[int, int]:
    """把任意 W×H 收进供应商的合法区间，保持宽高比，**对齐到 8 的倍数**。

    8 倍数对齐不能省：多数生图模型的隐空间按 8 像素分块，不对齐会被服务端自己取整，
    取到哪个方向不确定。自己对齐，至少结果可预测。
    """
    ratio = width / height
    if ratio > max_ratio:
        width = height * max_ratio
    elif ratio < min_ratio:
        height = width / min_ratio

    pixels = width * height
    if pixels < min_pixels or pixels > max_pixels:
        scale = (target_pixels / pixels) ** 0.5
        width, height = width * scale, height * scale
        pixels = width * height
        if pixels < min_pixels:
            factor = (min_pixels / pixels) ** 0.5
            width, height = width * factor, height * factor
        elif pixels > max_pixels:
            factor = (max_pixels / pixels) ** 0.5
            width, height = width * factor, height * factor

    w = max(8, int(round(width / 8)) * 8)
    h = max(8, int(round(height / 8)) * 8)
    if w / h > max_ratio:
        h = max(h, _math.ceil(w / max_ratio / 8) * 8)
    elif w / h < min_ratio:
        w = max(w, _math.ceil(h * min_ratio / 8) * 8)
    # 对齐后可能刚好越过上限，再夹一次
    while w * h > max_pixels and w > 8 and h > 8:
        w = max(8, int(w * 0.98 / 8) * 8)
        h = max(8, int(h * 0.98 / 8) * 8)
    return w, h


def plan_size(provider: str, size: str) -> dict:
    """发请求之前预告实际会拿到的画幅。

    `downgraded=True` 时**先决定要不要换供应商或改画幅**，别等生成完再返工——
    攒到最后发现意味着整批重来。
    """
    spec = PROVIDERS.get(str(provider))
    if spec is None:
        raise ImageError(
            f"未知生图供应商 {provider!r}。可用：{'、'.join(sorted(PROVIDERS))}。")
    match = _SIZE_RE.match(str(size or "").strip())
    if not match:
        raise ImageError(f"尺寸格式非法 {size!r}，应形如 1080x1440。")
    width, height = int(match.group(1)), int(match.group(2))
    if width <= 0 or height <= 0:
        raise ImageError(f"尺寸必须为正 {size!r}。")
    w, h = scale_into(width, height, **spec)
    return {
        "provider": provider,
        "requested": f"{width}x{height}",
        "effective": f"{w}x{h}",
        "downgraded": (w, h) != (width, height),
        "requested_pixels": width * height,
        "effective_pixels": w * h,
    }


# ── 生图执行：端点、请求体、响应解析、凭据 ────────────────────────────────
#
# 由 `generate-content-images/scripts/image_providers.py` 迁入。该 Skill 保留
# 「决定要画什么图」的判断（VisualPlan、构图、风格档、信息密度），执行搬到这里。
#
# **供应商差异只有四块**：端点、尺寸规则、请求体、响应解析。抽象只抽这四块——
# 多抽一层，加第三家时反而要先理解抽象。

# `ARK_URL` / `QWEN_LEGACY_HOST` / `QWEN_SYNC_PATH` / `QWEN_DEFAULT_REGION` 删掉了：
# 端点现在来自 `credentials resolve` 的 `apiEndpoint`，**原样用、不拼后缀**。
# 留着一份写死的地址，只会在后台改了地址之后让人以为还在打新的。

#: 供应商标识**归一成小写**。`providerName` 从平台来是大写（`VOLCENGINE`、`QWEN`），
#: 而本模块的分支按小写写。归一在一个地方做，别让两种写法在代码里并存。
#:
#: 叫 `API_PROVIDERS` 而不是 `PROVIDERS`：本模块下方已有一个 `PROVIDERS`
#: 是**画幅规则表**（`plan_size` 用），同名会把它整个盖掉，而报出来的是
#: `'frozenset' object has no attribute 'get'`——与生图毫无关系。
API_PROVIDERS = frozenset({"volcengine", "qwen"})


def _spec(provider: str) -> str:
    name = str(provider or "").strip().lower()
    if name not in API_PROVIDERS:
        # **认不出就报错，不猜协议。** 猜错会用一家的请求体打另一家的地址，
        # 对面回 400，错误信息指向参数，而根因是选错了客户端。
        raise ImageError(
            f"认不出的生图供应商 {provider!r}。支持：{'、'.join(sorted(API_PROVIDERS))}。"
            "端点与令牌由 credentials resolve --kind image 给，"
            "providerName 决定按谁的协议拼请求。")
    return name


def build_request(provider: str, *, prompt: str, size: str,
                  watermark: bool, model: str) -> dict:
    if _spec(provider) == "volcengine":
        request = {
            "model": model, "prompt": prompt,
            "sequential_image_generation": "disabled",
            "response_format": "url", "size": size,
            "stream": False, "watermark": watermark,
        }
        # Seedream 5 supports an explicit output format. Request PNG so the
        # returned bytes match the article illustration asset contract.
        if re.fullmatch(r"doubao-seedream-5-0(?:-lite)?-\d+", str(model).strip()):
            request["output_format"] = "png"
        return request
    return {
        "model": model,
        "input": {"messages": [{"role": "user", "content": [{"text": prompt}]}]},
        "parameters": {
            "size": size, "n": 1, "watermark": watermark,
            # 提示词由风格档确定性拼装；交给模型改写会破坏同一风格档的可复现性。
            # 思考模式只增加耗时，一并关闭。
            "prompt_extend": False, "enable_thinking": False,
        },
    }


def extract_image_url(provider: str, payload) -> str:
    """取图片 URL。**取不到就报错，不返回空串**——空 URL 会让下游拿去下载，错在更远的地方。"""
    payload = payload or {}
    if _spec(provider) == "volcengine":
        data = payload.get("data") or []
        if data and data[0].get("url"):
            return str(data[0]["url"])
        raise ImageError(f"未获取到图片 URL，API 返回：{payload}")
    if payload.get("code"):
        raise ImageError(
            f"通义生图失败 {payload.get('code')}: {payload.get('message') or ''}".strip())
    output = payload.get("output") or {}
    if output.get("code"):
        raise ImageError(
            f"通义生图任务失败 {output.get('code')}: {output.get('message') or ''}".strip())
    for choice in output.get("choices") or []:
        for item in ((choice.get("message") or {}).get("content")) or []:
            if item.get("image"):
                return str(item["image"])
    raise ImageError(f"未获取到图片 URL，API 返回：{payload}")


# ── 生图（接进 CLI）──────────────────────────────────────────────────────
#
# `build_request` 与 `extract_image_url` 长期只有定义没有调用方。**够不着的能力
# 等于没有**——调用方只能自己 import 或绕过去手拼，而绕过去的那份没人测。
#
# 端点与令牌不再来自环境变量：`credentials resolve --kind image` 按 agentId 查出
# `apiEndpoint` / `apiToken` / `providerName`，这里只负责按协议发出去、把图落盘。

DEFAULT_GENERATE_TIMEOUT = 180


class DefaultHttp:
    """默认传输。**可注入**——不可注入就没法在无凭据、无网络的环境里测。

    与 `tts/minimax.py` 的 `default_http` 同形，用 `urllib`，不引入新依赖。
    """

    @staticmethod
    def post(url: str, *, payload: dict, headers: dict,
             timeout: int = DEFAULT_GENERATE_TIMEOUT) -> dict:
        import json as _json
        import urllib.request as _request

        body = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = _request.Request(url, data=body, method="POST", headers=headers)
        with _request.urlopen(req, timeout=timeout) as response:
            return _json.loads(response.read().decode("utf-8"))

    @staticmethod
    def download(url: str, target, timeout: int = DEFAULT_GENERATE_TIMEOUT) -> None:
        import urllib.request as _request

        from pathlib import Path as _Path

        destination = _Path(str(target))
        destination.parent.mkdir(parents=True, exist_ok=True)
        with _request.urlopen(url, timeout=timeout) as response:
            destination.write_bytes(response.read())


def _headers(provider: str, token: str) -> dict:
    if provider == "qwen":
        # 通义要显式声明同步返回，否则给的是异步任务 id。
        return {"Authorization": "Bearer " + token, "Content-Type": "application/json"}
    return {"Authorization": "Bearer " + token, "Content-Type": "application/json"}


def preflight_size(provider: str, size: str) -> dict:
    """发请求之前判一次尺寸合不合这家的规矩。**本地能判的事不要送到对面去判。**

    实测：封面是 900×383（渠道规格），而 volcengine 的像素下限是 3.69M，
    发出去服务端直接 400——而 `plan_size` 早就算得出来，只是没人拦在 `generate` 前面。
    对面的 400 只说「参数不合法」，不会说「你该先按 3144×1336 生成再合成下来」。
    """
    planned = plan_size(provider, size)
    if not planned.get("downgraded"):
        return planned
    effective = planned["effective"]
    raise ImageError(
        f"{provider} 出不了 {size}：它会被夹到 {effective}（像素下限／上限所致）。"
        f"**不要换一家来迁就尺寸**——供应商由 agent 绑的模型决定，不是可选项。"
        f"正路是按 {effective} 生成，再用渠道规格把它合成／缩到 {size}"
        f"（封面走 compose_cover）。")


def generate_image(*, credential, prompt: str, size: str, output,
                   model: str = "", watermark: bool = False,
                   http=None, timeout: int = DEFAULT_GENERATE_TIMEOUT) -> dict:
    """生成一张图并落盘。

    `credential` 是 `credentials.resolve.resolve_credentials(..., kind="image")` 的返回。
    **本函数不自己去解析凭据**：解析要打平台内网，注入进来才能在测试里跑。

    返回里**不带令牌**——回执是要交出去的。
    """
    from pathlib import Path as _Path

    provider = _spec(credential.get("providerName"))
    endpoint = str(credential.get("apiEndpoint") or "").strip()
    token = str(credential.get("apiToken") or "").strip()
    if not endpoint or not token:
        raise ImageError(
            "凭据不完整：apiEndpoint 与 apiToken 都要有。"
            "先跑 credentials resolve --kind image 看它报什么。")

    preflight_size(provider, size)

    chosen = str(model or credential.get("modelCode") or "").strip()
    if not chosen:
        raise ImageError(
            "没有模型型号：凭据里的 modelCode 是空的，也没有显式 --model。")

    client = http or DefaultHttp
    payload = build_request(provider, prompt=prompt, size=size,
                            watermark=watermark, model=chosen)
    response = client.post(endpoint, payload=payload,
                           headers=_headers(provider, token), timeout=timeout)
    url = extract_image_url(provider, response)

    target = _Path(str(output))
    client.download(url, str(target), timeout=timeout)
    return {
        "ok": True,
        "output": str(target),
        "provider": provider,
        "model": chosen,
        "size": size,
        "source_url": url,
    }
