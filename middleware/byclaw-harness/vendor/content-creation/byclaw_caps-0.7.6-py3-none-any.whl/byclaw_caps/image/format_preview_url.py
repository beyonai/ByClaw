#!/usr/bin/env python3
"""将文件绝对路径拼接为带服务发现的图片预览 URL。

通过 by_framework 服务发现解析后端服务地址，拼接成：
    {protocol}://{host}:{port}/byaiService/commonFile/preview?filePath={filePath}
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import threading
from pathlib import Path
from typing import Any
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).parent))

SERVICE_ENV = "BE_DOMAINNAME"
SERVICE_FALLBACK = "ByaiService"
PREVIEW_PATH = "/commonFile/preview"
DEFAULT_PATH_PREFIX = "byaiService"

# 内网服务发现 host:port → 外网可访问源(origin，含协议、不带端口)的映射表。
# DiscoveryClient 返回的内网 host:port 集群外无法访问；命中此表则整段替换为外网源，
# 未命中则按服务发现的 protocol/host/port 自行拼接。新增映射只需加一行，不依赖环境变量。
HOST_MAP: dict[str, str] = {
    "byclaw-be.by-service.svc.cluster.local:8086": "http://www.beyonai.cn",
    "192.168.0.83:8086": "http://123.56.153.229:8080",
}


def _apply_public_host(host: str, port: Any, protocol: str) -> str:
    """服务发现的 host:port -> URL 源(origin，含协议)。

    先查 HOST_MAP：key 为 host:port，value 为完整外网源（如 http://www.beyonai.cn），
    命中则直接返回 map 的值；未命中则用 protocol/host/port 自行拼接。
    """
    mapped = HOST_MAP.get(f"{host}:{port}")
    if mapped:
        return mapped
    return f"{protocol}://{host}:{port}"


def _read_params() -> dict[str, Any]:
    raw = sys.argv[1] if len(sys.argv) > 1 else sys.stdin.read().strip()
    if not raw:
        raise ValueError("缺少 JSON 入参，需要 file_path")
    params = json.loads(raw)
    if not isinstance(params, dict):
        raise ValueError("入参必须是 JSON 对象")
    return params


def _normalize_file_path(params: dict[str, Any]) -> str:
    raw = params.get("file_path")
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError("file_path 为必填参数，请传入文件的绝对路径")
    return raw.strip()


def _service_name() -> str:
    """优先使用环境变量中的后端服务名，空值时回退默认名称。"""
    return os.environ.get(SERVICE_ENV, "").strip() or SERVICE_FALLBACK


def _init_discovery_redis() -> None:
    from by_framework.common.redis_client import init_redis  # type: ignore[import-untyped]

    init_redis(
        host=os.getenv("REDIS_HOST", "localhost"),
        port=int(os.getenv("REDIS_PORT", "6379")),
        db=int(os.getenv("REDIS_DATABASE", "0")),
        password=os.getenv("REDIS_PASSWORD") or None,
        username=os.getenv("REDIS_USERNAME") or None,
    )


async def _discover_base_url(service_name: str) -> str:
    from by_framework.core.discovery import DiscoveryClient  # type: ignore[import-untyped]

    _init_discovery_redis()
    client = DiscoveryClient(cache_interval=5)
    try:
        instance = await client.discover(service_name, health_threshold_ms=-1)
    finally:
        await client.close()

    if not instance:
        raise ValueError(f"服务发现未找到可用实例: {service_name}")

    protocol = (getattr(instance, "protocol", "") or "http").strip() or "http"
    prefix = (getattr(instance, "path_prefix", "") or "").strip("/") or DEFAULT_PATH_PREFIX
    origin = _apply_public_host(instance.host, instance.port, protocol)
    return f"{origin}/{prefix}"


def _run_async(coro: Any) -> Any:
    """同步执行协程。

    by_framework 的 Redis 客户端是全局单例，脚本场景下没有正在运行的事件循环，
    直接 asyncio.run 即可；若外层已有事件循环则退到独立线程中运行。
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    result: dict[str, Any] = {}
    error: dict[str, BaseException] = {}

    def runner() -> None:
        try:
            result["value"] = asyncio.run(coro)
        except BaseException as exc:  # noqa: BLE001
            error["exc"] = exc

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    thread.join()
    if "exc" in error:
        raise error["exc"]
    return result.get("value")


def run(params: dict[str, Any]) -> dict[str, Any]:
    file_path = _normalize_file_path(params)
    service_name = _service_name()
    base_url = _run_async(_discover_base_url(service_name))
    url = f"{base_url}{PREVIEW_PATH}?filePath={quote(file_path, safe='')}"

    return {
        "ok": True,
        "url": url,
        "base_url": base_url,
        "service_name": service_name,
        "file_path": file_path,
    }


def main() -> None:
    print(json.dumps(run(_read_params()), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), flush=True)
        sys.exit(1)
