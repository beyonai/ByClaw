"""Shared ImageAssetManifest 1.1 serialization and validation helpers.

资产清单契约。由 `generate-content-images/scripts/asset_manifest_contract.py`
迁入——纯记账，无业务判断（原文件里「文章」「卡片」各出现 0 次），
文章配图与卡片图文共用同一套。
"""

from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
import struct
from typing import Any
from byclaw_caps.shared.diagram_tokens import delivered_size, delivery_scale_for

try:
    import yaml
except ImportError as exc:  # pragma: no cover - environment failure
    raise SystemExit("PyYAML is required for ImageAssetManifest YAML") from exc


SCHEMA_VERSION = "1.1"
MANIFEST_STATUSES = {"initialized", "generated", "validated", "failed"}
ASSET_STATUSES = {"initialized", "generated", "validated", "failed"}
REQUIRED_REVIEW_CHECKS = ("crop", "text_legibility", "factual_scope", "sequence")
#: 可发布的取值。**`not_reviewed` 与 `fail` 不在其中**——
#: 前者是"没人也没机器看过"，后者是"看过且不合格"。
#: `declared` 表示人声明看过但机器没验，适用于 AI 生图这类没有 HTML 可探的产物；
#: 它比假装 `pass` 诚实，也让"哪些是真验过的"在清单里一眼可分。
ACCEPTED_REVIEW_VALUES = frozenset({"pass", "declared"})


def _version_at_least(value: Any, minimum: tuple[int, int, int]) -> bool:
    try:
        parts = tuple(int(part) for part in str(value).split(".")[:3])
    except ValueError:
        return False
    return parts + (0,) * (3 - len(parts)) >= minimum


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON 顶层必须是对象: {path}")
    return value


def read_yaml(path: Path) -> dict[str, Any]:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"YAML 顶层必须是对象: {path}")
    return value


def _same_directory(left: Any, right: Any) -> bool:
    """两个路径是不是同一个目录。**比目录，不比字符串。**

    两边都为空视为一致——那说明谁都没声明，不是声明冲突。
    """
    left_text, right_text = str(left or "").strip(), str(right or "").strip()
    if not left_text or not right_text:
        return left_text == right_text
    try:
        return Path(left_text).resolve() == Path(right_text).resolve()
    except OSError:
        return left_text == right_text


def _dump_yaml(manifest: dict[str, Any]) -> str:
    """PyYAML 3.x 不认 `sort_keys`。

    别处（`validate_article_plan.py` 的 `dump_yaml_compatible`）早留了这个兼容，
    这里漏了，于是在 3.x 上直接抛 `dump_all() got an unexpected keyword argument`。
    """
    try:
        return yaml.safe_dump(manifest, allow_unicode=True, sort_keys=False)
    except TypeError as exc:
        if "sort_keys" not in str(exc):
            raise
        return yaml.safe_dump(manifest, allow_unicode=True)


def write_manifest_pair(json_path: Path, manifest: dict[str, Any]) -> tuple[Path, Path]:
    """两份要么都写成，要么一份都不留。

    原先先写 JSON、再写 YAML。YAML 那步一旦失败，**JSON 已经落盘而 YAML 没有**，
    目录停在半初始化状态；校验器只会说「JSON 和 YAML 必须同时存在」，
    看到的人会以为自己漏了一步，其实是上一步写坏了。

    所以先把两份都序列化出来，都成功了再落盘。
    """
    json_path = json_path.resolve()
    yaml_path = json_path.with_suffix(".yaml")
    json_text = json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    yaml_text = _dump_yaml(manifest)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json_text, encoding="utf-8")
    yaml_path.write_text(yaml_text, encoding="utf-8")
    return json_path, yaml_path


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) < 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"当前图片资产契约只接受 PNG: {path}")
    return struct.unpack(">II", header[16:24])


def file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def resolve_asset_path(asset_directory: Path, file_path: str) -> Path:
    candidate = Path(file_path)
    if candidate.is_absolute():
        resolved = candidate.resolve()
    else:
        resolved = (asset_directory / candidate).resolve()
    try:
        resolved.relative_to(asset_directory.resolve())
    except ValueError as exc:
        raise ValueError(f"图片路径越出 asset_directory: {file_path}") from exc
    return resolved


def validate_manifest(
    manifest: dict[str, Any],
    plan: dict[str, Any],
    *,
    yaml_manifest: dict[str, Any] | None = None,
) -> list[str]:
    errors: list[str] = []
    if str(manifest.get("schema_version") or "") != SCHEMA_VERSION:
        errors.append(f"ImageAssetManifest.schema_version 必须为 {SCHEMA_VERSION}")
    if manifest.get("status") not in MANIFEST_STATUSES:
        errors.append("ImageAssetManifest.status 非法")
    if yaml_manifest is not None and yaml_manifest != manifest:
        errors.append("ImageAssetManifest JSON 与 YAML 内容不一致")
    for field in ("plan_id", "brief_id", "topic_id"):
        if str(manifest.get(field) or "") != str(plan.get(field) or ""):
            errors.append(f"ImageAssetManifest.{field} 与 VisualPlan 不一致")
    # `asset_directory` 两边比的是**同一个目录**，不是同一个字符串。
    # `initialize` 存的是 resolve() 之后的路径，而计划里常写相对路径或带软链的路径
    # （Windows 上 %TEMP% 就是 C:\Users\XXXXXX~1\... 与 C:\Users\完整名\... 两副面孔）。
    # 按字符串比，等价的两个路径会被判成漂移，而这条错误信息只会说「不一致」。
    if _same_directory(manifest.get("asset_directory"), plan.get("asset_directory")):
        pass
    else:
        errors.append("ImageAssetManifest.asset_directory 与 VisualPlan 不一致")
    for field in ("workflow", "producer", "source_artifacts"):
        # 计划没写这一项时，清单里那份是 `initialize` 填的缺省，**不是漂移**。
        # 原先按裸值比：计划里没有是 None，清单里被规整成 {} 或 []，恒不相等——
        # 于是 init-assets 之后紧接着 finalize-assets 必失败，而两步都没做错。
        expected = plan.get(field)
        if expected in (None, {}, []):
            continue
        if manifest.get(field) != expected:
            errors.append(f"ImageAssetManifest.{field} 与 VisualPlan 不一致")
    workflow = manifest.get("workflow") or {}
    producer = manifest.get("producer") or {}
    requires_asset_allocation = (
        producer.get("skill") == "generate-content-images"
        and _version_at_least(producer.get("version"), (1, 2, 0))
    )
    if workflow.get("workflow_id") and requires_asset_allocation:
        asset_allocation = str(workflow.get("asset_allocation_path") or "").strip()
        if not asset_allocation:
            errors.append("ImageAssetManifest.workflow.asset_allocation_path 不能为空")
        else:
            logical_parts = tuple(part.lower() for part in Path(*asset_allocation.split("/")).parts)
            actual_parts = tuple(part.lower() for part in Path(str(manifest.get("asset_directory") or "")).resolve().parts)
            if len(actual_parts) < len(logical_parts) or actual_parts[-len(logical_parts) :] != logical_parts:
                errors.append("ImageAssetManifest.workflow.asset_allocation_path 与 asset_directory 不一致")

    plan_items = [item for item in (plan.get("items") or []) if isinstance(item, dict)]
    assets = [item for item in (manifest.get("assets") or []) if isinstance(item, dict)]
    plan_ids = [str(item.get("asset_id") or "") for item in plan_items]
    asset_ids = [str(item.get("asset_id") or "") for item in assets]
    if asset_ids != plan_ids:
        errors.append("ImageAssetManifest.assets 必须按顺序覆盖 VisualPlan.items")
        return errors

    asset_directory = Path(str(manifest.get("asset_directory") or "")).resolve()
    for index, (asset, item) in enumerate(zip(assets, plan_items), 1):
        prefix = f"assets[{index}]"
        for field in (
            "asset_role",
            "visual_goal",
            "diagram_subtype",
            "content_type",
            "generation_method",
        ):
            expected = item.get(field) or ("" if field == "diagram_subtype" else None)
            actual = asset.get(field) or ("" if field == "diagram_subtype" else None)
            if actual != expected:
                errors.append(f"{prefix}.{field} 与 VisualPlan 不一致")
        # 画幅按**交付像素**比，不是按计划里的 layout。
        # `raster` 默认 2 倍出图，而这里原先要求严格等于 layout——两条规矩打架，
        # 2026-09-11 实测中助理为了过关把图重渲成 1 倍，降了清晰度。
        layout = (int(item.get("width") or 0), int(item.get("height") or 0))
        scale = (int(item.get("delivery_scale") or 0)
                 or delivery_scale_for(item.get("generation_method")))
        expected_delivered = delivered_size(layout[0], layout[1], scale)
        if (int(asset.get("width") or 0), int(asset.get("height") or 0)) != expected_delivered:
            errors.append(
                f"{prefix} 画幅与交付尺寸不一致：应为 "
                f"{expected_delivered[0]}x{expected_delivered[1]}"
                f"（layout {layout[0]}x{layout[1]} × scale {scale}）")
        if asset.get("status") not in ASSET_STATUSES:
            errors.append(f"{prefix}.status 非法")
        file_path = str(asset.get("file_path") or "").strip()
        if not file_path:
            errors.append(f"{prefix}.file_path 不能为空")
            continue
        try:
            image_path = resolve_asset_path(asset_directory, file_path)
        except ValueError as exc:
            errors.append(str(exc))
            continue
        if not image_path.is_file() or image_path.stat().st_size <= 0:
            errors.append(f"{prefix} 图片不存在或为空: {image_path}")
            continue
        try:
            width, height = png_dimensions(image_path)
        except ValueError as exc:
            errors.append(str(exc))
            continue
        if (width, height) != (int(asset.get("width") or 0), int(asset.get("height") or 0)):
            errors.append(f"{prefix} 实际 PNG 尺寸与 manifest 不一致")
        validation = asset.get("validation") or {}
        if validation.get("dimensions") != "pass":
            errors.append(f"{prefix}.validation.dimensions 必须为 pass")
        # **不再一律要求 `pass`。** 原先这里和 finalize 一起，把
        # `crop`/`text_legibility`/`factual_scope` 钉成必须是 "pass"，
        # 而 finalize 又是无条件写上去的——两处合起来，这三项从来就没有被验过，
        # 只是被要求"写着 pass"。2026-09-11 交付的清单里它们全是伪证。
        #
        # 现在的取值有含义：`pass` = 机器验过（inspect 记录），
        # `declared` = 人声明看过（AI 生图这类没有 HTML 可探），
        # `not_reviewed` / `fail` = 不可发布。
        for check in REQUIRED_REVIEW_CHECKS:
            value = str(validation.get(check) or "")
            if value not in ACCEPTED_REVIEW_VALUES:
                errors.append(
                    f"{prefix}.validation.{check} 为 {value or '<空>'}，"
                    f"必须是 {'/'.join(sorted(ACCEPTED_REVIEW_VALUES))} 之一")
        if int(validation.get("file_size_bytes") or 0) != image_path.stat().st_size:
            errors.append(f"{prefix}.validation.file_size_bytes 不一致")
        if str(validation.get("sha256") or "") != file_sha256(image_path):
            errors.append(f"{prefix}.validation.sha256 不一致")

    if manifest.get("status") == "validated" and any(asset.get("status") != "validated" for asset in assets):
        errors.append("manifest.status=validated 时所有资产必须为 validated")
    if manifest.get("status") != "validated":
        errors.append("发布前 ImageAssetManifest.status 必须为 validated")
    if not str(manifest.get("validated_at") or "").strip():
        errors.append("ImageAssetManifest.validated_at 不能为空")
    return errors
