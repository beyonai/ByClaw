#!/usr/bin/env python3
"""生图能力 CLI：画幅精确性校验，与资产清单的三步。

本能力的价值不是「生成图片」，是「保证画幅精确」——实测平台原生生图把 1080×1440 降级为
864×1152，而图文卡片正需那一档。

## 为什么资产清单那三步也在这里

`init_assets`／`finalize_assets`／`validate_image_assets` 三个模块早就写好了，
各自带 `main()`，但**都没接进这个 CLI，也没有任何 SKILL.md 教过**。

2026-08-28 实测的后果：配图助理手上有一个必须严格符合 schema 的
ImageAssetManifest 要写，而**能正确写出它的代码它够不着**。于是它手拼了一份，
再把 `validate_article_plan.py` 读了四遍反推 schema，前后约 25 次工具调用。

能力写好了没接出口，等于没有。三个子命令复用原函数，**不重写逻辑**。
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from byclaw_caps._cli import UsageError, add_common, business, dispatch
from byclaw_caps.image import (
    BUSINESS_SIZES, PROVIDERS, ImageError, generate_image, plan_size, verify_output,
)


def _plan_provider(args) -> str:
    """`plan` 用哪一家：优先显式 `--provider`，否则按 agent 绑的模型解析。

    **两个都不给就报用法错误，不默认某一家。** 默认过 `qwen`，实测的后果是：
    助理拿 `--provider qwen` 与 `--provider volcengine` 比了一遍夹取结果，
    挑了「比例更接近」的 qwen，然后 generate 直接 400——凭据是 VOLCENGINE，
    qwen 压根打不通。**它不是判断错了，是命令给了它一个不存在的选择。**
    """
    if args.provider:
        return args.provider
    if not args.agent_id:
        raise ImageError(
            "plan 要知道是哪一家：传 `--agent-id`（按 agent 绑的模型解析，常规用法），"
            "或显式 `--provider`（只在离线比较两家规则时用）。"
            "**不默认某一家**——默认值会被当成「可以挑」。")
    from byclaw_caps.credentials.resolve import resolve_credentials

    resolved = resolve_credentials(
        args.agent_id, kind="image", session_root=args.session_root)
    return str(resolved.get("providerName") or "").lower()
from byclaw_caps.image.finalize_assets import finalize, parse_asset_mapping
from byclaw_caps.image.init_assets import initialize
from byclaw_caps.image.manifest import (
    read_json, read_yaml, validate_manifest, write_manifest_pair,
)


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="byclaw_caps.image", description="画幅校验")
    sub = parser.add_subparsers(dest="command", required=True)
    verify = sub.add_parser("verify", help="校验产出图的实际像素与格式")
    verify.add_argument("path", help="待校验的图片")
    verify.add_argument("size", help="请求尺寸，如 1080x1440")
    sizes = sub.add_parser("sizes", help="列出三个业务画幅")
    plan = sub.add_parser(
        "plan", help="发请求**之前**预告实际会拿到的画幅")
    plan.add_argument("size", help="请求尺寸，如 1080x1440")
    plan.add_argument("--agent-id", default="", help=(
        "按这个数字员工绑的模型决定供应商。**这才是常规用法**——"
        "供应商不是你选的"))
    plan.add_argument("--provider", default=None, choices=sorted(PROVIDERS), help=(
        "只在离线比较两家规则时用。**不要拿它挑一家**："
        "实际能打通的只有 agent 绑的那一家，挑错了发出去就是 400"))
    plan.add_argument("--session-root", help="凭据缓存落点")

    generate = sub.add_parser("generate", help="按 agentId 解析凭据并生成一张图")
    generate.add_argument("--agent-id", required=True, help="agent 运行上下文里的 agentId")
    generate.add_argument("--prompt", required=True)
    generate.add_argument("--size", required=True, help="如 1080x1440")
    generate.add_argument("--output", required=True, help="落盘路径，写会话根之内")
    generate.add_argument("--model", default="", help="覆盖凭据里的 modelCode（模型型号）")
    generate.add_argument("--watermark", action="store_true")
    generate.add_argument("--session-root", help="凭据缓存落点；不给则每次重新解析")

    init = sub.add_parser(
        "init-assets",
        help="按 VisualPlan 建 ImageAssetManifest；**落在图片目录，不是 .meta/**")
    init.add_argument("--plan", required=True, help="VisualPlan 1.0|1.1 JSON")
    init.add_argument("--overwrite", action="store_true",
                      help="覆盖已有清单；**会冲掉已登记的哈希，想清楚再用**")

    final = sub.add_parser(
        "finalize-assets",
        help="图出齐后落盘 JSON+YAML 双份并置 validated")
    final.add_argument("--plan", required=True, help="VisualPlan 1.1 JSON")
    final.add_argument("--manifest",
                       help="清单 JSON；缺省取 VisualPlan.asset_directory 下那份")
    final.add_argument("--asset", action="append", default=[], dest="assets",
                       metavar="ID=文件名",
                       help="asset_id=相对图片目录的文件名；必须覆盖全部 items")
    final.add_argument("--reviewed", action="append", default=[],
                       help="已完成人工视觉检查的 asset_id")
    final.add_argument("--reviewed-all", action="store_true",
                       help="确认已逐张打开看过；**没看就别传**")
    final.add_argument("--validated-at",
                       help="显式指定时间戳，使重跑得到同一哈希；缺省取当前时间")

    check = sub.add_parser(
        "validate-assets", help="校验清单与 VisualPlan 一致（发布前必过）")
    check.add_argument("--plan", required=True, help="VisualPlan 1.1 JSON")
    check.add_argument("--manifest", help="清单 JSON；缺省同上")

    look = sub.add_parser(
        "inspect",
        help="画面级检查：溢出、字号、图上文字、emoji、色板。**在浏览器里读 DOM，"
             "不是从 PNG 反查**——出图前跑，别等 finalize")
    look.add_argument("source", help="待检查的 HTML（不是 PNG）")
    look.add_argument("--plan", help="VisualPlan 1.1 JSON；给了就按它取期望文字与画幅")
    look.add_argument("--asset", help="plan 里的 asset_id；--plan 给了就必须给它")
    look.add_argument("--width", type=int, help="布局宽；缺省取 plan 里该资产的画幅")
    look.add_argument("--height", type=int, help="布局高；同上")
    look.add_argument("--render", help=(
        "检查通过后渲染到这个 PNG，并落盘检查记录。"
        "**这是拿到合法产物的唯一路径**——finalize-assets 要按记录里的哈希"
        "核对交付的就是被检查过的那张图"))
    look.add_argument("--scale", type=int, help=(
        "渲染倍率；缺省按生成方式定（确定性渲染 2 倍，AI 生图与封面合成 1 倍）"))
    look.add_argument("--display-width", type=int, help=(
        "**图片在读者屏幕上实际显示多宽**（像素），字号是否看得清按它折算。"
        "缺省 677（公众号正文的常见宽度）；手机窄屏正文里通常只有 360 上下，"
        "**按 677 判会把落地字号高估近一倍**——知道真实宽度就传进来"))
    look.add_argument("--browser", help="显式指定浏览器路径")

    for one in (generate, verify, sizes, plan, init, final, check, look):
        add_common(one)
    return parser


def _load_plan(path: str) -> dict:
    """读不到计划是用法错误，不是业务失败——业务失败意味着输入合法。"""
    target = Path(path).expanduser()
    if not target.is_file():
        raise UsageError(f"VisualPlan 不存在：{target}")
    try:
        return json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise UsageError(f"VisualPlan 读不出来：{exc}") from None


def _manifest_path(plan: dict, explicit: str | None) -> Path:
    """缺省跟着 `asset_directory` 走——**清单与图片同目录**。

    `validate_article_plan.py` 按图片所在目录去找这两个文件，
    放进 `.meta/` 它找不到。这个缺省值是那条契约的唯一来源。
    """
    if explicit:
        return Path(explicit).expanduser().resolve()
    directory = str(plan.get("asset_directory") or "").strip()
    if not directory:
        raise UsageError("VisualPlan.asset_directory 为空，且没给 --manifest")
    return Path(directory).expanduser().resolve() / "image-asset-manifest.json"


def handle(args: argparse.Namespace):
    if args.command == "generate":
        from byclaw_caps.credentials.resolve import resolve_credentials

        credential = resolve_credentials(
            args.agent_id, kind="image", session_root=args.session_root)
        result = generate_image(
            credential=credential, prompt=args.prompt, size=args.size,
            output=args.output, model=args.model, watermark=args.watermark)
        return result, 0
    if args.command == "plan":
        result = plan_size(_plan_provider(args), args.size)
        result["ok"] = True
        if result["downgraded"]:
            result["hint"] = ("这家供应商会把该尺寸夹到合法区间并对齐到 8 的倍数。"
                              "**先决定换供应商还是改画幅，别等生成完再返工。**")
        return result, 0
    if args.command == "sizes":
        return {"ok": True, "sizes": {k: list(v) for k, v in BUSINESS_SIZES.items()}}, 0

    if args.command == "init-assets":
        plan = _load_plan(args.plan)
        try:
            result = initialize(plan, overwrite=args.overwrite)
        except FileExistsError as exc:
            # 清单已在，是业务失败不是用法错误：参数没写错，是这一步不该再做。
            # 归成 2 的话 agent 会照守则去报「部署问题」，而根因是它该走 finalize。
            return business({
                "ok": False, "status": "MANIFEST_EXISTS", "error": str(exc),
                "hint": "已初始化过。要重来加 --overwrite，"
                        "但那会冲掉已登记的哈希；通常你该走 finalize-assets。",
            })
        except (ValueError, TypeError) as exc:
            return business({"ok": False, "status": "INVALID_PLAN", "error": str(exc)})
        return result, 0

    if args.command == "finalize-assets":
        plan = _load_plan(args.plan)
        path = _manifest_path(plan, args.manifest)
        if not path.is_file():
            raise UsageError(f"清单不存在：{path}。先跑 init-assets。")
        try:
            asset_files = parse_asset_mapping(args.assets)
        except (ValueError, TypeError) as exc:
            raise UsageError(f"--asset 写法应为 ID=文件名：{exc}") from None
        expected = {str(item.get("asset_id") or "")
                    for item in (plan.get("items") or []) if isinstance(item, dict)}
        reviewed = expected if args.reviewed_all else set(args.reviewed)
        try:
            manifest = finalize(plan, read_json(path), asset_files=asset_files,
                                reviewed_ids=reviewed,
                                validated_at=args.validated_at)
        except (ValueError, TypeError) as exc:
            return business({"ok": False, "status": "FINALIZE_REJECTED",
                             "error": str(exc)})
        except OSError as exc:
            raise UsageError(f"读写清单失败：{exc}") from None
        json_path, yaml_path = write_manifest_pair(path, manifest)
        return {"ok": True, "status": "validated",
                "manifest_path": str(json_path),
                "yaml_manifest_path": str(yaml_path),
                "assets": [item["asset_id"] for item in manifest["assets"]]}, 0

    if args.command == "inspect":
        from byclaw_caps.image.inspect_visual import (
            inspect_and_render, inspect_visual, write_inspection,
        )
        from byclaw_caps.raster import RasterError
        from byclaw_caps.shared.diagram_tokens import delivery_scale_for

        expect: list[str] = []
        identifiers: list[str] = []
        glossary: list[str] = []
        section_excerpt = ""
        plan_id = ""
        asset_directory = ""
        method = ""
        numeric = None
        width, height = args.width, args.height
        if args.plan:
            if not args.asset:
                raise UsageError("给了 --plan 就要给 --asset：一份计划里有多张图，"
                                 "不指名就不知道该拿哪张的期望文字与画幅")
            plan = _load_plan(args.plan)
            items = [i for i in (plan.get("items") or [])
                     if isinstance(i, dict) and i.get("asset_id") == args.asset]
            if not items:
                raise UsageError(
                    f"VisualPlan 里没有 asset_id={args.asset}。已有："
                    + "、".join(str(i.get("asset_id")) for i in (plan.get("items") or [])))
            item = items[0]
            plan_id = str(plan.get("plan_id") or "")
            asset_directory = str(plan.get("asset_directory") or "")
            method = str(item.get("generation_method") or "")
            width = width or int(item.get("width") or 0) or None
            height = height or int(item.get("height") or 0) or None
            structure = item.get("structure") or {}
            # **label 硬失败，identifier 只告警。** 两者都钉死的话会与 16px
            # 下限撞成无解——见 inspect_visual 里 3b 的注释。
            for node in structure.get("nodes") or []:
                label = str(node.get("label") or "").strip()
                if label and label not in expect:
                    expect.append(label)
                ident = str(node.get("identifier") or "").strip()
                if ident and ident not in identifiers:
                    identifiers.append(ident)
            for edge in structure.get("edges") or []:
                value = str(edge.get("label") or "").strip()
                if value and value not in expect:
                    expect.append(value)
            # 数值约束：有就查，没有就不查。**不能凭 DOM 猜哪根线是量尺**——
            # 猜错了会把画对的图拦下来，而误报比漏报更快毁掉一道检查。
            numeric = item.get("numeric") or None
            digest = item.get("context_digest") or {}
            glossary = list(digest.get("glossary") or [])
            # 该节正文原文：用来判断这张图是不是在把正文再抄一遍。
            section_excerpt = str(digest.get("section_excerpt") or "")
        if not width or not height:
            raise UsageError("画幅未知：给 --width/--height，或给 --plan + --asset")
        scale = args.scale or delivery_scale_for(method or "html_svg")
        checks = {"expect_texts": expect, "expect_identifiers": identifiers,
                  "glossary": glossary, "section_excerpt": section_excerpt,
                  "design_width": width, "numeric": numeric,
                  "display_width": getattr(args, "display_width", None)}
        try:
            if args.render:
                result = inspect_and_render(
                    args.source, layout=(width, height), scale=scale,
                    output=args.render, browser=args.browser, **checks)
            else:
                result = inspect_visual(
                    args.source, width=width, height=height,
                    browser=args.browser, **checks)
        except RasterError as exc:
            # 环境不具备（没浏览器、页面没渲出来）是用法错误，不是"这张图不合格"。
            raise UsageError(str(exc)) from None

        # 落盘检查记录：**让"检查过"成为可核验的事实，而不是一句声明。**
        # finalize-assets 按记录里的 output_sha256 核对"交付的就是被检查过的那张"。
        if args.plan and args.asset:
            if not asset_directory:
                raise UsageError("VisualPlan.asset_directory 为空，检查记录无处落盘")
            result["inspection_record"] = str(write_inspection(
                result, asset_directory=asset_directory, asset_id=args.asset,
                plan_id=plan_id, source=args.source, layout=(width, height),
                scale=scale, output=args.render if result.get("rendered") else None))
        elif args.render:
            result.setdefault("warnings", []).append({
                "check": "no_record",
                "detail": "没给 --plan/--asset，检查记录没有落盘",
                "fix": "finalize-assets 会因为找不到记录而拒绝登记。补上 --plan 与 --asset。",
            })
        return business(result)

    if args.command == "validate-assets":
        plan = _load_plan(args.plan)
        path = _manifest_path(plan, args.manifest)
        yaml_path = path.with_suffix(".yaml")
        if not path.is_file() or not yaml_path.is_file():
            # 两份缺一就报用法错误：这是路径或流程的问题，不是内容不合约。
            raise UsageError(
                f"ImageAssetManifest JSON 和 YAML 必须同时存在：{path} / {yaml_path}")
        failures = validate_manifest(read_json(path), plan,
                                     yaml_manifest=read_yaml(yaml_path))
        return business({"ok": not failures,
                         "status": "fail" if failures else "pass",
                         "failures": failures})

    return business(verify_output(args.path, args.size))


def main() -> int:
    """控制台入口点。

    `python -m byclaw_caps.<能力>` 与安装后的 `byclaw-<能力>` 走同一条路——
    两条路行为分叉的话，文档里写的那条迟早是错的。
    """
    return dispatch(build(), handle, usage_errors=(ImageError,))


if __name__ == "__main__":
    raise SystemExit(main())
