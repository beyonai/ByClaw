"""Small explicit catalog for public illustration implementations."""

from __future__ import annotations

from importlib import resources
from typing import Any

import yaml


def _definitions() -> list[dict[str, Any]]:
    root = resources.files("byclaw_caps.image.components").joinpath("definitions")
    result: list[dict[str, Any]] = []
    for path in sorted(root.iterdir(), key=lambda item: item.name):
        if path.suffix.lower() != ".yaml":
            continue
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or not isinstance(value.get("id"), str):
            raise ValueError(f"配图组件定义无效：{path.name}")
        value["definition_path"] = str(path)
        result.append(value)
    return result


def list_components(*, stage_id: str | None = None,
                    profile_id: str | None = None,
                    status: str | None = None) -> list[dict[str, Any]]:
    values = _definitions()
    if stage_id:
        values = [item for item in values if item.get("stage_id") == stage_id]
    if profile_id:
        values = [item for item in values
                  if profile_id in (item.get("supported_profiles") or [])]
    if status:
        values = [item for item in values if item.get("status") == status]
    return values


def get_component(component_id: str) -> dict[str, Any]:
    for item in _definitions():
        if item.get("id") == component_id:
            return item
    raise KeyError(f"公共配图组件未注册：{component_id}")
