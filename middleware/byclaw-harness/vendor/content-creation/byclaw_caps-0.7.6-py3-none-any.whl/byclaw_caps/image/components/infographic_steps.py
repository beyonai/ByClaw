"""Deterministic information-graphic renderer for ordered article facts.

It is intentionally separate from ``diagram.architecture``: a process or
business case is read as a sequence of cards, while an architecture is read as
layers or relationships.  Text and numbers are always rendered from the
request, so the component does not introduce model transcription errors.
"""

from __future__ import annotations

from html import escape
import math
import re
from typing import Any

from .architecture import PALETTE, ArchitectureError, _defs, _esc, _visual_system, _wrap, _apply_visual_system


def _required(value: Any, field: str) -> str:
    result = str(value or "").strip()
    if not result:
        raise ArchitectureError(f"{field} 不能为空")
    return result


def validate_infographic_request(request: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(request, dict):
        raise ArchitectureError("信息图请求必须是对象")
    title = _required(request.get("title"), "title")
    subtype = str(request.get("infographic_subtype") or request.get("diagram_subtype") or "steps").strip().lower()
    aliases = {"business_loop": "business-loop", "process": "steps"}
    subtype = aliases.get(subtype, subtype)
    if subtype not in {"steps", "business-loop", "comparison", "summary", "timeline"}:
        raise ArchitectureError(f"infographic_subtype 不支持：{subtype}")
    raw_steps = request.get("steps") or request.get("items")
    if not isinstance(raw_steps, list) or not raw_steps:
        raise ArchitectureError("steps 必须是非空数组")
    steps: list[dict[str, Any]] = []
    ids: set[str] = set()
    for index, raw in enumerate(raw_steps, 1):
        if not isinstance(raw, dict):
            raise ArchitectureError(f"steps[{index}] 必须是对象")
        step_id = str(raw.get("id") or f"step-{index:02d}").strip()
        if step_id in ids:
            raise ArchitectureError(f"steps id 重复：{step_id}")
        ids.add(step_id)
        label = _required(raw.get("label") or raw.get("title"), f"steps[{index}].label")
        body = raw.get("body") or raw.get("details") or raw.get("facts") or []
        if isinstance(body, str): body = [body]
        if not isinstance(body, list): raise ArchitectureError(f"steps[{index}].body 必须是数组或字符串")
        facts = [str(item).strip() for item in body if str(item).strip()]
        steps.append({"id": step_id, "label": label, "body": facts,
                      "number": str(raw.get("number") or index),
                      "icon": str(raw.get("icon") or "").strip(),
                      "color": str(raw.get("color") or "").strip(),
                      "source_ref": str(raw.get("source_ref") or "").strip()})
    supporting = request.get("supporting_layers") or []
    if not isinstance(supporting, list): raise ArchitectureError("supporting_layers 必须是数组")
    normalized_support: list[dict[str, Any]] = []
    for index, item in enumerate(supporting, 1):
        if isinstance(item, dict):
            label = str(item.get("label") or item.get("title") or "").strip()
            values = item.get("items") or item.get("body") or []
            if isinstance(values, str): values = [values]
            if not isinstance(values, list):
                raise ArchitectureError(f"supporting_layers[{index}].items 必须是数组或字符串")
            values = [str(value).strip() for value in values if str(value).strip()]
        else:
            label, values = str(item).strip(), []
        if label: normalized_support.append({"label": label, "items": values})
    request_metadata = request.get("metadata") if isinstance(request.get("metadata"), dict) else {}
    raw_groups = request.get("visual_groups") or request_metadata.get("visual_groups") or []
    if not isinstance(raw_groups, list):
        raise ArchitectureError("visual_groups 必须是数组")
    visual_groups: list[dict[str, Any]] = []
    covered: list[str] = []
    for index, raw in enumerate(raw_groups, 1):
        if not isinstance(raw, dict):
            raise ArchitectureError(f"visual_groups[{index}] 必须是对象")
        title_value = _required(raw.get("title"), f"visual_groups[{index}].title")
        summary = _required(raw.get("summary"), f"visual_groups[{index}].summary")
        members = raw.get("step_ids") or []
        if not isinstance(members, list) or not members:
            raise ArchitectureError(f"visual_groups[{index}].step_ids 必须是非空数组")
        member_ids = [str(value).strip() for value in members if str(value).strip()]
        unknown = [value for value in member_ids if value not in ids]
        if unknown:
            raise ArchitectureError(
                f"visual_groups[{index}] 引用了不存在的步骤：{', '.join(unknown)}"
            )
        covered.extend(member_ids)
        visual_groups.append({"title": title_value, "summary": summary, "step_ids": member_ids})
    if visual_groups:
        duplicates = sorted({value for value in covered if covered.count(value) > 1})
        missing = [value for value in ids if value not in covered]
        if duplicates or missing:
            detail = []
            if duplicates:
                detail.append(f"重复步骤 {', '.join(duplicates)}")
            if missing:
                detail.append(f"未覆盖步骤 {', '.join(missing)}")
            raise ArchitectureError("visual_groups 覆盖无效：" + "；".join(detail))
        if covered != [step["id"] for step in steps]:
            raise ArchitectureError("visual_groups 必须保持来源步骤顺序")
    profile_id = str(request.get("profile_id") or "").strip()
    width = max(800, int(request.get("width") or 1600))
    height = max(500, int(request.get("height") or 900))
    if subtype == "business-loop" and len(steps) > 6:
        # Eight factual steps need enough vertical room for readable body text,
        # connectors and the supporting layers.  The WeChat profile deliberately
        # uses two columns, so it needs four rows and a taller canvas.
        minimum_height = round((1450 if visual_groups else (
            2400 if profile_id == "wechat.public_article" else 1500
        )) * width/2200)
        height = max(height, minimum_height)
    return {"title": title, "subtitle": str(request.get("subtitle") or "").strip(),
            "infographic_subtype": subtype, "theme_id": str(request.get("theme_id") or "blueprint"),
            "profile_id": profile_id,
            "width": width,
            "height": height,
            "steps": steps, "supporting_layers": normalized_support,
            "visual_groups": visual_groups,
            "visual_system": _visual_system(request),
            "loop": request.get("loop") or {},
            "legend": [str(item).strip() for item in (request.get("legend") or []) if str(item).strip()],
            "metadata": {k: v for k, v in request.items()
                         if k not in {"title", "subtitle", "infographic_subtype", "diagram_subtype",
                                      "theme_id", "profile_id", "width", "height", "steps", "items",
                                      "supporting_layers", "loop", "legend", "visual_groups",
                                      "visual_system", "style", "palette", "density", "layout"}}}


def _display_steps(data: dict[str, Any]) -> tuple[list[dict[str, Any]], bool]:
    """Group the visual hierarchy while displaying every original fact."""
    groups = data.get("visual_groups") or []
    if not groups:
        return data["steps"], False
    by_id = {step["id"]: step for step in data["steps"]}
    colors = ["blue", "cyan", "purple", "green"]
    return [{"id": f"phase-{i+1:02d}", "label": group["title"], "body": [],
             "number": str(i+1), "color": colors[i%len(colors)],
             "substeps": [by_id[key] for key in group["step_ids"]],
             "source_ref": " / ".join(group["step_ids"])}
            for i, group in enumerate(groups)], True


def _phase_content(step: dict[str, Any], width: float) -> tuple[int, float, list[list[tuple[str, str]]]]:
    substeps = step.get("substeps") or []
    cols = min(2, len(substeps))
    cell_w = (width-56-24*(cols-1))/max(1, cols)
    cells = []
    for sub in substeps:
        lines = [("substep-title", line) for line in _wrap(f'{sub["number"]}. {sub["label"]}', max(6, int(cell_w/19)))]
        for fact in sub["body"]:
            lines.extend(("step-body", line) for line in _wrap(fact, max(7, int(cell_w/18))))
        cells.append(lines)
    row_h = max((len(lines)*26+16 for lines in cells), default=0)
    return cols, row_h, cells


def _phase_card(parts: list[str], step: dict[str, Any], x: float, y: float, w: float, h: float, index: int) -> None:
    fill, stroke, _ = PALETTE[step["color"]]
    parts.append(f'<g data-source-steps="{_esc(step["source_ref"])}">')
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="22" fill="{fill}" stroke="{stroke}" stroke-opacity=".35" stroke-width="1.5" filter="url(#shadow)"/>')
    parts.append(f'<rect x="{x+22:.1f}" y="{y+22:.1f}" width="38" height="38" rx="12" fill="{stroke}"/><text x="{x+41:.1f}" y="{y+49:.1f}" text-anchor="middle" font-size="24" font-weight="800" fill="white">{_esc(step["number"])}</text>')
    title_lines = _wrap(step["label"], max(8, int((w-106)/26)))
    if len(title_lines) > 1:
        raise ArchitectureError("阶段标题过长，请缩短或拆图")
    parts.append(f'<text x="{x+76:.1f}" y="{y+49:.1f}" font-size="26" font-weight="800" fill="{stroke}">{_esc(step["label"])}</text>')
    cols, row_h, cells = _phase_content(step, w)
    cell_w = (w-56-24*(cols-1))/cols
    for i, lines in enumerate(cells):
        row, col = divmod(i, cols)
        tx, ty = x+28+col*(cell_w+24), y+96+row*row_h
        if col:
            parts.append(f'<path d="M{tx-12:.1f} {ty-20:.1f} V{ty+row_h-30:.1f}" stroke="{stroke}" stroke-opacity=".15"/>')
        for cls, line in lines:
            parts.append(f'<text x="{tx:.1f}" y="{ty:.1f}" class="{cls}">{_esc(line)}</text>'); ty += 26
    parts.append('</g>')


def _card(parts: list[str], step: dict[str, Any], x: float, y: float, w: float, h: float, index: int) -> None:
    fill, stroke, accent = PALETTE.get(step.get("color") or "", list(PALETTE.values())[index % len(PALETTE)])
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="22" fill="{fill}" stroke="{stroke}" stroke-width="2.5" filter="url(#shadow)"/>')
    parts.append(f'<path d="M{x+22:.1f} {y:.1f} H{x+w-22:.1f} Q{x+w:.1f} {y:.1f} {x+w:.1f} {y+22:.1f} V{y+72:.1f} H{x:.1f} V{y+22:.1f} Q{x:.1f} {y:.1f} {x+22:.1f} {y:.1f} Z" fill="{stroke}" opacity=".94"/>')
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="6" height="{h:.1f}" rx="3" fill="{stroke}"/>')
    parts.append(f'<circle cx="{x+36:.1f}" cy="{y+36:.1f}" r="22" fill="white" fill-opacity=".95"/><text x="{x+36:.1f}" y="{y+44:.1f}" text-anchor="middle" font-size="19" font-weight="800" fill="{stroke}">{_esc(step["number"])}</text>')
    title_lines = _wrap(step["label"], max(9, int((w-108)/23)))
    for title_index, line in enumerate(title_lines[:2]):
        parts.append(f'<text x="{x+74:.1f}" y="{y+44+title_index*26:.1f}" class="step-title">{_esc(line)}</text>')
    cursor = y + 105 + max(0, len(title_lines[:2])-1)*26
    needed_lines = 0
    wrapped_facts: list[list[str]] = []
    for fact in step.get("body") or []:
        lines = _wrap(fact, max(10, int((w-70)/19)))
        wrapped_facts.append(lines)
        needed_lines += len(lines)
    content_height = needed_lines * 27 + max(0, len(wrapped_facts) - 1) * 5
    available_height = y + h - cursor - 12
    if content_height > available_height:
        raise ArchitectureError(
            f"步骤 {step['id']} 文本超出卡片容量（需要 {content_height:.0f}px，"
            f"可用 {available_height:.0f}px）；"
            "请缩短正文或增大画布"
        )
    for lines in wrapped_facts:
        parts.append(f'<circle cx="{x+28:.1f}" cy="{cursor-6:.1f}" r="4" fill="{stroke}"/>')
        for line in lines:
            parts.append(f'<text x="{x+46:.1f}" y="{cursor:.1f}" class="step-body">{_esc(line)}</text>')
            cursor += 27
        cursor += 5
    if step.get("icon"):
        parts.append(f'<text x="{x+w-27:.1f}" y="{y+30:.1f}" text-anchor="middle" font-size="16" fill="{stroke}">{_esc(step["icon"][:2])}</text>')


def _arrow(parts: list[str], x1: float, y1: float, x2: float, y2: float, *, dashed: bool = False) -> None:
    dash = ' stroke-dasharray="8 6"' if dashed else ""
    parts.append(f'<path d="M{x1:.1f} {y1:.1f} L{x2:.1f} {y2:.1f}" fill="none" stroke="#64748b" stroke-width="2.5" marker-end="url(#arrow)"{dash}/>')


def _card_min_height(step: dict[str, Any], width: float) -> float:
    """Return the minimum card height without silently dropping any text."""
    if step.get("substeps"):
        cols, row_h, cells = _phase_content(step, width)
        return 94 + math.ceil(len(cells)/cols)*row_h
    title_lines = _wrap(step["label"], max(9, int((width - 108) / 23)))[:2]
    if len(_wrap(step["label"], max(9, int((width - 108) / 23)))) > 2:
        raise ArchitectureError(f"步骤 {step['id']} 标题过长，请缩短标题或增大画布")
    body_lines = 0
    facts = step.get("body") or []
    for fact in facts:
        body_lines += len(_wrap(fact, max(10, int((width - 70) / 19))))
    title_extra = max(0, len(title_lines) - 1) * 26
    fact_gaps = max(0, len(facts) - 1) * 5
    return 105 + title_extra + body_lines * 27 + fact_gaps + 18


def _step_position(index: int, cols: int, snake: bool) -> tuple[int, int]:
    row, offset = divmod(index, cols)
    if snake and row % 2:
        return row, cols - 1 - offset
    return row, offset


def _connect_cards(
    parts: list[str],
    previous: tuple[float, float, float, float],
    current: tuple[float, float, float, float],
) -> None:
    px, py, pw, ph = previous
    x, y, w, h = current
    if abs(py - y) < 1:
        if x > px:
            _arrow(parts, px + pw + 3, py + ph / 2, x - 4, y + h / 2)
        else:
            _arrow(parts, px - 3, py + ph / 2, x + w + 4, y + h / 2)
        return
    _arrow(parts, px + pw / 2, py + ph + 3, x + w / 2, y - 4)


def _support_layer(parts: list[str], layer: dict[str, Any], x: float, y: float, w: float, h: float, index: int) -> None:
    colors = [("#f5f3ff", "#7c3aed"), ("#eff6ff", "#2563eb")]
    fill, stroke = colors[index % len(colors)]
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="20" fill="{fill}" stroke="{stroke}" stroke-width="2" filter="url(#soft-shadow)"/>')
    parts.append(f'<text x="{x+24:.1f}" y="{y+31:.1f}" class="support-title">{_esc(layer["label"])}</text>')
    items = layer.get("items") or []
    if not items:
        return
    available = w - 48
    slot = available / len(items)
    for item_index, item in enumerate(items):
        item_x = x + 24 + item_index*slot
        lines = _wrap(item, max(8, int((slot-18)/14)))
        if len(lines) > 2:
            raise ArchitectureError(f"支撑层 {layer['label']} 的条目过长：{item}")
        parts.append(f'<circle cx="{item_x+5:.1f}" cy="{y+61:.1f}" r="4" fill="{stroke}"/>')
        for line_index, line in enumerate(lines):
            parts.append(f'<text x="{item_x+17:.1f}" y="{y+67+line_index*20:.1f}" class="support-item">{_esc(line)}</text>')


def render_infographic_svg(request: dict[str, Any]) -> str:
    data = validate_infographic_request(request)
    output_w, output_h = data["width"], data["height"]
    scale = output_w/1600
    width, height = 1600, output_h/scale
    steps, grouped = _display_steps(data)
    colors = data["visual_system"]["semantic_colors"]
    steps = [{**step, "color": colors.get(step["id"], step.get("color", ""))} for step in steps]
    is_loop = data["infographic_subtype"] == "business-loop"
    mobile = data["profile_id"] == "wechat.public_article"
    cols = min(2, len(steps)) if grouped or mobile else min(4, len(steps))
    if data["visual_system"]["density"] == "minimal":
        cols = min(2, cols)
    rows = math.ceil(len(steps)/cols)
    margin_x, top, gap_x, gap_y = 74, 140, 42, 48
    card_w = (width-2*margin_x-gap_x*(cols-1))/cols
    card_h = max(_card_min_height(step, card_w) for step in steps)
    support_h, support_gap = 98, 16
    support_total = len(data["supporting_layers"])*(support_h+support_gap)
    flow_h = rows*card_h+(rows-1)*gap_y
    legend_h = 34 if data["legend"] else 0
    required = top+flow_h+(60 if support_total else 36)+support_total+legend_h+24
    if required > height:
        raise ArchitectureError(f"信息图高度不足（至少需要 {required*scale:.0f}px，当前 {output_h}px）；请增大画布、减少分组内容或拆图")
    # Keep foundations next to the flow instead of pinning them to the canvas
    # bottom and leaving a large, accidental void in the middle.
    top += min(48, (height-required)/2)
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height:.2f}" width="{output_w}" height="{output_h}">', _defs(data["visual_system"]),
             '<style>.step-title{font-size:27px;font-weight:800;fill:white}.step-body{font-size:18px;fill:#294a67}.substep-title{font-size:19px;font-weight:800;fill:#173a59}.support-title{font-size:21px;font-weight:800;fill:#173a59}.support-item{font-size:18px;fill:#38536b}.note{font-size:15px;fill:#52708d}</style>',
             '<rect width="100%" height="100%" fill="url(#bg)"/><rect width="100%" height="100%" fill="url(#dot-grid)"/>']
    parts.append(f'<text x="{width/2:.1f}" y="60" text-anchor="middle" class="title">{_esc(data["title"])}</text>')
    if data["subtitle"]:
        parts.append(f'<text x="{width/2:.1f}" y="91" text-anchor="middle" class="subtitle">{_esc(data["subtitle"])}</text>')
    positions = []
    for i, step in enumerate(steps):
        row, col = _step_position(i, cols, is_loop)
        x, y = margin_x+col*(card_w+gap_x), top+row*(card_h+gap_y)
        (_phase_card if grouped else _card)(parts, step, x, y, card_w, card_h, i)
        positions.append((x, y, card_w, card_h))
        if i:
            _connect_cards(parts, positions[i-1], positions[i])
    if is_loop and len(steps) > 1:
        first_x, first_y, _, _ = positions[0]
        last_x, last_y, last_w, last_h = positions[-1]
        # Exit the last card away from the grid, then return in an outer lane.
        # This also handles an odd final row without crossing earlier cards.
        exit_left = last_x < width/2
        start_x = last_x-3 if exit_left else last_x+last_w+3
        start_y = last_y+last_h/2
        lane_x = 28 if exit_left else width-28
        below = top+flow_h+24
        route = f'M{start_x:.1f} {start_y:.1f} H{lane_x:.1f}'
        if not exit_left:
            route += f' V{below:.1f} H28'
        route += f' V{first_y+card_h/2:.1f} H{first_x-4:.1f}'
        parts.append(f'<path d="{route}" fill="none" stroke="#2563eb" stroke-width="2.5" marker-end="url(#arrow-blue)"/>')
        label = str((data.get("loop") or {}).get("label") or "结果回写 · 形成业务闭环")
        # Place the label beside the return lane, never over a transition arrow.
        parts.append(f'<text x="18" y="{top+flow_h/2:.1f}" text-anchor="middle" transform="rotate(-90 18 {top+flow_h/2:.1f})" font-size="15" font-weight="700" fill="#2563eb">{_esc(label)}</text>')
    support_y = top+flow_h+60
    for i, layer in enumerate(data["supporting_layers"]):
        _support_layer(parts, layer, margin_x, support_y+i*(support_h+support_gap), width-2*margin_x, support_h, i)
    if data["legend"]:
        note_y = support_y+support_total+6 if support_total else top+flow_h+38
        parts.append(f'<text x="{margin_x:.1f}" y="{note_y:.1f}" class="note">{_esc(" · ".join(data["legend"]))}</text>')
    parts.append("</svg>")
    return _apply_visual_system("".join(parts), data["visual_system"])
