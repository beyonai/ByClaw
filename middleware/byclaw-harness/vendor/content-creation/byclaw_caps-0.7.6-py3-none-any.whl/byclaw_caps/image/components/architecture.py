"""Deterministic, semantic technical-diagram renderer.

The renderer deliberately keeps business wording in the input and does not
ask an image model to redraw labels, arrows, or facts.  It supports the
layouts used by the illustration stage (layered, radial, flow and
business-loop) while retaining the small public API used by older callers.
"""

from __future__ import annotations

from html import escape
import math
import re
from typing import Any, Iterable


class ArchitectureError(ValueError):
    """The architecture diagram request is invalid."""


PALETTE = {
    "blue": ("#eff6ff", "#2563eb", "#dbeafe"),
    "cyan": ("#ecfeff", "#0891b2", "#cffafe"),
    "purple": ("#f5f3ff", "#7c3aed", "#ede9fe"),
    "orange": ("#fff7ed", "#ea580c", "#ffedd5"),
    "green": ("#f0fdf4", "#16a34a", "#dcfce7"),
    "slate": ("#f8fafc", "#475569", "#e2e8f0"),
}

# A visual system is part of the article plan, not a renderer-local whim.
# Keep the token set small so related figures share the same semantic colors.
VISUAL_SYSTEMS = {
    "blueprint": {
        "background": "#F7F8FA",
        "grid": "#DDE5EE",
        "text": "#0F172A",
        "muted": "#64748B",
        "surface": "#FFFFFF",
        "border": "#CBD5E1",
        "flow_out": "#EA580C",
        "flow_back": "#2563EB",
    },
}


def _visual_system(request: dict[str, Any]) -> dict[str, Any]:
    selected = request.get("visual_system") or {}
    if not isinstance(selected, dict):
        selected = {}
    style_id = str(selected.get("style") or request.get("style") or request.get("theme_id") or "blueprint").strip()
    palette_id = str(selected.get("palette") or request.get("palette") or "blue-cyan-purple").strip()
    tokens = dict(VISUAL_SYSTEMS.get(style_id, VISUAL_SYSTEMS["blueprint"]))
    tokens["style"] = style_id
    tokens["palette"] = palette_id
    tokens["density"] = str(selected.get("density") or request.get("density") or "balanced").strip()
    tokens["layout"] = str(selected.get("layout") or request.get("layout") or "auto").strip()
    tokens["language"] = str(selected.get("language") or "zh-CN")
    colors = selected.get("semantic_colors") or {}
    if not isinstance(colors, dict) or any(value not in PALETTE for value in colors.values()):
        raise ArchitectureError("semantic_colors 必须将实体 ID 映射到已支持的语义色")
    tokens["semantic_colors"] = dict(colors)
    if tokens["style"] not in {"blueprint", "scientific"}:
        raise ArchitectureError(f"确定性组件不支持 style：{tokens['style']}")
    if tokens["palette"] not in {"blue-cyan-purple", "mono-ink"}:
        raise ArchitectureError(f"确定性组件不支持 palette：{tokens['palette']}")
    if tokens["density"] not in {"minimal", "balanced", "per-section", "rich"}:
        raise ArchitectureError(f"不支持 density：{tokens['density']}")
    return tokens


def _apply_visual_system(svg: str, tokens: dict[str, Any]) -> str:
    """Apply rendering tokens only to markup, never to business labels."""
    if tokens["style"] == "scientific":
        svg = svg.replace('<rect width="100%" height="100%" fill="url(#dot-grid)"/>', "")
        svg = re.sub(r' filter="url\(#(?:soft-)?shadow\)"', "", svg)
    if tokens["palette"] == "mono-ink":
        # Change SVG paint attributes and CSS declarations; a source label
        # containing a hex value must remain byte-for-byte intact.
        def ink(match: re.Match[str]) -> str:
            value = match.group(2).lower()
            rgb = [int(value[i:i+2], 16) for i in (1, 3, 5)]
            color = "#F5F5F4" if sum(rgb) > 650 else "#334155"
            return match.group(1) + color
        svg = re.sub(r'((?:fill|stroke|stop-color)="|(?:fill|stroke):)(#[0-9a-fA-F]{6})', ink, svg)
    return svg


def _palette_key(value: Any, index: int = 0) -> str:
    key = str(value or "").strip()
    if key in PALETTE:
        return key
    return list(PALETTE)[index % len(PALETTE)]


def _text(value: Any, field: str, *, required: bool = True) -> str:
    text = str(value or "").strip()
    if required and not text:
        raise ArchitectureError(f"{field} 不能为空")
    return text


def _number(value: Any, default: int, field: str) -> int:
    try:
        number = int(value or default)
    except (TypeError, ValueError) as exc:
        raise ArchitectureError(f"{field} 必须是整数") from exc
    return number


def _lines(value: Any) -> list[str]:
    if isinstance(value, str):
        return [line.strip() for line in value.splitlines() if line.strip()]
    if isinstance(value, (list, tuple)):
        return [str(line).strip() for line in value if str(line).strip()]
    return []


def _normalize_group(raw: Any, index: int) -> dict[str, str]:
    if isinstance(raw, str):
        title = _text(raw, f"groups[{index}]")
        return {"id": re.sub(r"\W+", "-", title.lower()).strip("-") or f"group-{index}",
                "title": title, "subtitle": "", "color": "blue"}
    if not isinstance(raw, dict):
        raise ArchitectureError(f"groups[{index}] 必须是对象")
    title = _text(raw.get("title") or raw.get("label"), f"groups[{index}].title")
    group_id = _text(raw.get("id") or f"group-{index}", f"groups[{index}].id")
    color = str(raw.get("color") or "blue").strip()
    if color not in PALETTE:
        color = "blue"
    return {"id": group_id, "title": title,
            "subtitle": str(raw.get("subtitle") or "").strip(), "color": color}


def _normalize_sidebar(raw: Any, index: int) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ArchitectureError(f"sidebars[{index}] 必须是对象")
    title = _text(raw.get("title") or raw.get("label"), f"sidebars[{index}].title")
    side = str(raw.get("side") or ("left" if index == 1 else "right")).strip().lower()
    if side not in {"left", "right"}:
        raise ArchitectureError(f"sidebars[{index}].side 只能是 left 或 right")
    items = _lines(raw.get("items") or raw.get("body"))
    if not items:
        raise ArchitectureError(f"sidebars[{index}].items 不能为空")
    return {"title": title, "subtitle": str(raw.get("subtitle") or "").strip(),
            "side": side, "items": items}


def validate_architecture_request(request: dict[str, Any]) -> dict[str, Any]:
    """Normalize and validate a semantic diagram request.

    The returned value is safe to pass to :func:`render_architecture_svg` and
    retains every display-relevant field.  Unknown optional fields are kept in
    ``metadata`` for provenance rather than silently being discarded.
    """
    if not isinstance(request, dict):
        raise ArchitectureError("架构图请求必须是对象")
    title = _text(request.get("title"), "title")
    subtype = str(request.get("diagram_subtype") or request.get("layout") or "layered").strip().lower()
    aliases = {"architecture": "layered", "radial-model": "radial", "business_loop": "business-loop"}
    subtype = aliases.get(subtype, subtype)
    allowed = {"layered", "radial", "flow", "sequence", "swimlane", "business-loop"}
    if subtype not in allowed:
        raise ArchitectureError(f"diagram_subtype 不支持：{subtype}；可选 {sorted(allowed)}")
    nodes = request.get("nodes")
    if not isinstance(nodes, list) or not nodes:
        raise ArchitectureError("nodes 必须是非空数组")
    edges = request.get("edges", [])
    if not isinstance(edges, list):
        raise ArchitectureError("edges 必须是数组")
    node_ids: set[str] = set()
    normalized_nodes: list[dict[str, Any]] = []
    for index, raw in enumerate(nodes, 1):
        if not isinstance(raw, dict):
            raise ArchitectureError(f"nodes[{index}] 必须是对象")
        node_id = _text(raw.get("id"), f"nodes[{index}].id")
        if node_id in node_ids:
            raise ArchitectureError(f"节点 ID 重复：{node_id}")
        node_ids.add(node_id)
        label = _text(raw.get("label") or raw.get("title"), f"nodes[{index}].label")
        group = str(raw.get("group") or raw.get("layer") or "").strip()
        normalized_nodes.append({
            "id": node_id, "label": label,
            "subtitle": str(raw.get("subtitle") or "").strip(),
            "body": _lines(raw.get("body") or raw.get("details")),
            "group": group, "icon": str(raw.get("icon") or "").strip(),
            "color": str(raw.get("color") or "").strip(),
            "order": raw.get("order", index),
            "metadata": {k: v for k, v in raw.items()
                         if k not in {"id", "label", "title", "subtitle", "body", "details",
                                      "group", "layer", "icon", "color", "order"}},
        })
    normalized_edges: list[dict[str, Any]] = []
    for index, raw in enumerate(edges, 1):
        if not isinstance(raw, dict):
            raise ArchitectureError(f"edges[{index}] 必须是对象")
        source = _text(raw.get("source"), f"edges[{index}].source")
        target = _text(raw.get("target"), f"edges[{index}].target")
        if source not in node_ids or target not in node_ids:
            raise ArchitectureError(f"edges[{index}] 引用了不存在的节点：{source} -> {target}")
        direction = str(raw.get("direction") or "forward").strip().lower()
        if direction not in {"forward", "back", "both", "none"}:
            raise ArchitectureError(f"edges[{index}].direction 非法：{direction}")
        normalized_edges.append({
            "source": source, "target": target,
            "label": str(raw.get("label") or "").strip(),
            "direction": direction,
            "dashed": bool(raw.get("dashed", False)),
            "color": str(raw.get("color") or "#64748b").strip(),
        })
    groups_raw = request.get("groups", [])
    if not isinstance(groups_raw, list):
        raise ArchitectureError("groups 必须是数组")
    groups = [_normalize_group(value, index + 1) for index, value in enumerate(groups_raw)]
    if not groups:
        group_ids = []
        for node in normalized_nodes:
            if node["group"] and node["group"] not in group_ids:
                group_ids.append(node["group"])
        groups = [{"id": item, "title": item, "subtitle": "", "color":
                   (list(PALETTE)[index % len(PALETTE)])}
                  for index, item in enumerate(group_ids)]
    group_ids = {group["id"] for group in groups}
    for node in normalized_nodes:
        if node["group"] and node["group"] not in group_ids:
            raise ArchitectureError(f"节点 {node['id']} 引用了不存在的分组：{node['group']}")
    group_edges_raw = request.get("group_edges", [])
    if not isinstance(group_edges_raw, list):
        raise ArchitectureError("group_edges 必须是数组")
    normalized_group_edges: list[dict[str, Any]] = []
    for index, raw in enumerate(group_edges_raw, 1):
        if not isinstance(raw, dict):
            raise ArchitectureError(f"group_edges[{index}] 必须是对象")
        source = _text(raw.get("source"), f"group_edges[{index}].source")
        target = _text(raw.get("target"), f"group_edges[{index}].target")
        if source not in group_ids or target not in group_ids:
            raise ArchitectureError(f"group_edges[{index}] 引用了不存在的分组：{source} -> {target}")
        normalized_group_edges.append({
            "source": source, "target": target,
            "label": str(raw.get("label") or "").strip(),
            "direction": str(raw.get("direction") or "forward").strip(),
            "color": str(raw.get("color") or "#2563eb").strip(),
        })
    sidebars_raw = request.get("sidebars", [])
    if not isinstance(sidebars_raw, list):
        raise ArchitectureError("sidebars 必须是数组")
    sidebars = [_normalize_sidebar(value, index + 1)
                for index, value in enumerate(sidebars_raw)]
    width = _number(request.get("width"), 1600, "width")
    height = _number(request.get("height"), 900, "height")
    if width < 800 or height < 500:
        raise ArchitectureError("专业信息图画布至少为 800x500")
    normalized = {
        "title": title,
        "subtitle": str(request.get("subtitle") or "").strip(),
        "diagram_subtype": subtype,
        "theme_id": str(request.get("theme_id") or "blueprint").strip(),
        "profile_id": str(request.get("profile_id") or "").strip(),
        "width": width, "height": height,
        "nodes": normalized_nodes, "edges": normalized_edges,
        "groups": groups,
        "group_edges": normalized_group_edges,
        "sidebars": sidebars,
        "annotations": [str(item) for item in (request.get("annotations") or [])],
        "legend": [str(item) for item in (request.get("legend") or [])],
        "supporting_layers": request.get("supporting_layers") or [],
        "center_id": str(request.get("center_id") or "").strip(),
        "visual_system": _visual_system(request),
        "metadata": {k: v for k, v in request.items()
                     if k not in {"title", "subtitle", "diagram_subtype", "layout", "theme_id",
                                  "profile_id", "width", "height", "nodes", "edges", "groups",
                                  "group_edges", "sidebars", "annotations", "legend",
                         "supporting_layers", "center_id", "visual_system", "style", "palette",
                         "density", "layout"}},
    }
    if subtype == "radial" and normalized["center_id"] and normalized["center_id"] not in node_ids:
        raise ArchitectureError(f"center_id 引用了不存在的节点：{normalized['center_id']}")
    if subtype == "radial" and not normalized["center_id"]:
        normalized["center_id"] = normalized_nodes[0]["id"]
    semantic_colors = normalized["visual_system"]["semantic_colors"]
    for item in [*normalized_nodes, *groups]:
        item["color"] = semantic_colors.get(item["id"], item.get("color", ""))
    return normalized


def _wrap(text: str, max_chars: int) -> list[str]:
    text = str(text or "")
    if not text:
        return []
    # Keep Latin technical terms intact where possible and wrap Chinese by
    # character.  SVG text uses the measured line count, so no clipping is
    # hidden by a fixed one-line label.
    result: list[str] = []
    for paragraph in text.splitlines() or [text]:
        # Technical identifiers are semantic atoms.  Keeping a short Latin
        # token on one line is preferable to producing an invalid API name.
        if (re.fullmatch(r"[A-Za-z][A-Za-z0-9_.:/-]{5,24}", paragraph)
                and len(paragraph) <= max_chars + 5):
            result.append(paragraph)
            continue
        while len(paragraph) > max_chars:
            cut = max_chars
            spaces = [m.start() for m in re.finditer(r"\s", paragraph[:max_chars])]
            if spaces and len(paragraph[:max_chars]) > max_chars * 0.55:
                cut = spaces[-1]
            result.append(paragraph[:cut].strip())
            paragraph = paragraph[cut:].strip()
        if paragraph:
            result.append(paragraph)
    return result or [""]


def _esc(value: Any) -> str:
    return escape(str(value or ""), quote=True)


def _color(node: dict[str, Any], index: int = 0) -> tuple[str, str, str]:
    return PALETTE[_palette_key(node.get("color"), index)]


def _gradient_id(node: dict[str, Any], index: int = 0, *, group: bool = False) -> str:
    prefix = "group" if group else "card"
    return f"{prefix}-{_palette_key(node.get('color'), index)}"


def _natural_card_height(node: dict[str, Any], width: float, *, compact: bool = False) -> float:
    """Estimate the content height for a card before choosing its layout.

    Earlier versions gave every node a large fixed rectangle.  That made a
    node containing only a title and subtitle look unfinished, especially in
    a layered diagram.  Sizing from the actual semantic content keeps the
    canvas breathable while preserving room for longer, factual descriptions.
    """
    title_width = max(8, int(width / (24 if compact else 22)))
    subtitle_width = max(12, int(width / 28))
    body_width = max(14, int(width / (13 if compact else 16)))
    title_lines = _wrap(node.get("label", ""), title_width)[:3]
    subtitle_lines = _wrap(node.get("subtitle", ""), subtitle_width)[:2]
    body_lines: list[str] = []
    for raw in node.get("body") or []:
        body_lines.extend(_wrap(raw, body_width))
    # top padding + title + subtitle/body + bottom padding.  Keep enough
    # height for the accent band and the optional icon.
    height = 30 + max(1, len(title_lines)) * 24
    if subtitle_lines:
        height += 3 + len(subtitle_lines) * 20
    if body_lines:
        height += 6 + len(body_lines) * 20
    return max(108, height + 18)


def _defs(tokens: dict[str, str] | None = None, width: float = 1600) -> str:
    tokens = tokens or VISUAL_SYSTEMS["blueprint"]
    markup = """<defs>
      <filter id="shadow" x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy="7" stdDeviation="9" flood-color="#1e3a5f" flood-opacity=".14"/></filter>
      <filter id="soft-shadow" x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy="4" stdDeviation="7" flood-color="#1e3a5f" flood-opacity=".09"/></filter>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbfdff"/><stop offset=".58" stop-color="#f3f8fd"/><stop offset="1" stop-color="#edf4fb"/></linearGradient>
      <linearGradient id="center-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0f5fbd"/><stop offset="1" stop-color="#083b86"/></linearGradient>
      <linearGradient id="card-blue" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f7fbff"/><stop offset="1" stop-color="#e4efff"/></linearGradient>
      <linearGradient id="card-cyan" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f5feff"/><stop offset="1" stop-color="#d8f8fb"/></linearGradient>
      <linearGradient id="card-purple" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbfaff"/><stop offset="1" stop-color="#eee9ff"/></linearGradient>
      <linearGradient id="card-orange" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fffdf9"/><stop offset="1" stop-color="#fff0dc"/></linearGradient>
      <linearGradient id="card-green" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f9fffb"/><stop offset="1" stop-color="#e2f8e9"/></linearGradient>
      <linearGradient id="card-slate" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#edf2f7"/></linearGradient>
      <linearGradient id="group-blue" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#e8f2ff"/><stop offset="1" stop-color="#f8fbff"/></linearGradient>
      <linearGradient id="group-cyan" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ddf9fb"/><stop offset="1" stop-color="#f7feff"/></linearGradient>
      <linearGradient id="group-purple" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ece8ff"/><stop offset="1" stop-color="#faf9ff"/></linearGradient>
      <linearGradient id="group-orange" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff0db"/><stop offset="1" stop-color="#fffaf5"/></linearGradient>
      <linearGradient id="group-green" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#e2f8e9"/><stop offset="1" stop-color="#f8fffa"/></linearGradient>
      <linearGradient id="group-slate" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#e8eef5"/><stop offset="1" stop-color="#fbfcfd"/></linearGradient>
      <linearGradient id="vivid-blue" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#248cff"/><stop offset="1" stop-color="#1754d1"/></linearGradient>
      <linearGradient id="vivid-cyan" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#10cfd1"/><stop offset="1" stop-color="#0797ba"/></linearGradient>
      <linearGradient id="vivid-purple" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#6038d6"/></linearGradient>
      <linearGradient id="vivid-orange" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff9a3d"/><stop offset="1" stop-color="#f35b14"/></linearGradient>
      <linearGradient id="vivid-green" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#34c98c"/><stop offset="1" stop-color="#119b60"/></linearGradient>
      <linearGradient id="vivid-slate" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#64748b"/><stop offset="1" stop-color="#334155"/></linearGradient>
      <pattern id="dot-grid" width="28" height="28" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1.2" fill="#7aa2c8" opacity=".16"/></pattern>
      <marker id="arrow" viewBox="0 0 12 12" refX="10" refY="6" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0 0L12 6L0 12z" fill="#64748b"/></marker>
      <marker id="arrow-blue" viewBox="0 0 12 12" refX="10" refY="6" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0 0L12 6L0 12z" fill="#2563eb"/></marker>
      <style>
      text{font-family:"Noto Sans CJK SC","Microsoft YaHei","PingFang SC",sans-serif;}
      .title{font-size:40px;font-weight:800;fill:#0f2742}.subtitle{font-size:20px;fill:#52708d}
      .group-title{font-size:22px;font-weight:750;fill:#183b5b}.group-sub{font-size:15px;fill:#63809a}
      .node-title{font-size:24px;font-weight:800;fill:#112a44}.node-sub{font-size:17px;fill:#43637f}.node-body{font-size:16px;fill:#3f5b74}
      .edge-label{font-size:16px;fill:#315b86;font-weight:700}.legend{font-size:15px;fill:#38536b}
      .chip-title{font-size:23px;font-weight:800;fill:#102a43}.chip-sub{font-size:16px;fill:#486681}
      .radial-title{font-size:24px;font-weight:800;fill:white}.radial-sub{font-size:17px;fill:#f8fbff}.radial-body{font-size:17px;fill:#eef7ff}
      </style>
    </defs>"""
    scale = max(1.0, width / 1600)
    for size in (40, 28, 27, 24, 22, 20, 18, 17, 16, 15):
        markup = markup.replace(f"font-size:{size}px", f"font-size:{size * scale:.1f}px")
    return markup


def _svg_text(parts: list[str], x: float, y: float, lines: Iterable[str],
              cls: str, *, anchor: str = "start", line_height: int = 20) -> float:
    current = y
    for line in lines:
        parts.append(f'<text x="{x:.1f}" y="{current:.1f}" text-anchor="{anchor}" class="{cls}">{_esc(line)}</text>')
        current += line_height
    return current


def _card(parts: list[str], node: dict[str, Any], x: float, y: float, w: float, h: float,
          index: int, *, compact: bool = False) -> None:
    fill, stroke, accent = _color(node, index)
    gradient = _gradient_id(node, index)
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="16" fill="url(#{gradient})" stroke="{stroke}" stroke-width="2" filter="url(#shadow)"/>')
    parts.append(f'<path d="M{x+16:.1f} {y:.1f} H{x+w-16:.1f} Q{x+w:.1f} {y:.1f} {x+w:.1f} {y+16:.1f} V{y+60:.1f} H{x:.1f} V{y+16:.1f} Q{x:.1f} {y:.1f} {x+16:.1f} {y:.1f} Z" fill="{accent}" opacity=".48"/>')
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="7" height="{h:.1f}" rx="3" fill="{stroke}"/>')
    title_lines = _wrap(node["label"], max(8, int(w / (24 if compact else 22))))
    tx = x + 20
    ty = y + (31 if compact else 34)
    ty = _svg_text(parts, tx, ty, title_lines[:3], "node-title", line_height=24)
    if node.get("subtitle"):
        ty = _svg_text(parts, tx, ty + 3, _wrap(node["subtitle"], max(12, int(w / 28)))[:2], "node-sub", line_height=20)
    body: list[str] = []
    for raw in node.get("body") or []:
        body.extend(_wrap(raw, max(14, int(w / (13 if compact else 16)))))
    available = max(1, int((y + h - ty - 16) / 20))
    if len(body) > available:
        raise ArchitectureError(
            f"节点 {node['id']} 文本超出卡片容量（需要 {len(body)} 行，可用 {available} 行）；"
            "请缩短正文或增大画布"
        )
    if body:
        _svg_text(parts, tx, ty + 6, body, "node-body", line_height=20)
    if node.get("icon"):
        parts.append(f'<circle cx="{x+w-28:.1f}" cy="{y+27:.1f}" r="16" fill="white" opacity=".92"/><circle cx="{x+w-28:.1f}" cy="{y+27:.1f}" r="15" fill="{accent}"/><text x="{x+w-28:.1f}" y="{y+32:.1f}" text-anchor="middle" font-size="13" font-weight="800" fill="{stroke}">{_esc(str(node["icon"])[:2])}</text>')


def _edge(parts: list[str], edge: dict[str, Any], positions: dict[str, tuple[float, float, float, float]], *, curved: bool = False) -> None:
    sx, sy, sw, sh = positions[edge["source"]]
    tx, ty, tw, th = positions[edge["target"]]
    # Connect nearest sides for a clean horizontal/vertical diagram.
    if abs((sx + sw/2) - (tx + tw/2)) > abs((sy + sh/2) - (ty + th/2)):
        x1, y1 = (sx + sw, sy + sh/2) if tx >= sx else (sx, sy + sh/2)
        x2, y2 = (tx, ty + th/2) if tx >= sx else (tx + tw, ty + th/2)
    else:
        x1, y1 = (sx + sw/2, sy + sh) if ty >= sy else (sx + sw/2, sy)
        x2, y2 = (tx + tw/2, ty) if ty >= sy else (tx + tw/2, ty + th)
    color = edge.get("color") or "#64748b"
    dash = ' stroke-dasharray="8 6"' if edge.get("dashed") else ""
    marker = ' marker-end="url(#arrow-blue)"' if edge.get("direction") in {"forward", "both"} else ""
    marker_start = ' marker-start="url(#arrow)"' if edge.get("direction") in {"back", "both"} else ""
    if curved:
        cx = (x1 + x2) / 2
        d = f"M{x1:.1f} {y1:.1f} Q{cx:.1f} {(y1+y2)/2-40:.1f} {x2:.1f} {y2:.1f}"
    else:
        d = f"M{x1:.1f} {y1:.1f} L{x2:.1f} {y2:.1f}"
    parts.append(f'<path d="{d}" fill="none" stroke="{_esc(color)}" stroke-width="2.5"{dash}{marker_start}{marker}/>')
    if edge.get("label"):
        lx, ly = (x1+x2)/2, (y1+y2)/2 - 7
        label_width = max(58, len(edge["label"]) * 14 + 22)
        parts.append(f'<rect x="{lx-label_width/2:.1f}" y="{ly-17:.1f}" width="{label_width:.1f}" height="23" rx="11.5" fill="#f8fbff" stroke="#d7e5f3" opacity=".96"/>')
        parts.append(f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="middle" class="edge-label">{_esc(edge["label"])}</text>')


def _header(parts: list[str], data: dict[str, Any]) -> None:
    width = data["width"]
    parts.append(f'<text x="{width/2:.1f}" y="60" text-anchor="middle" class="title">{_esc(data["title"])}</text>')
    if data.get("subtitle"):
        parts.append(f'<text x="{width/2:.1f}" y="91" text-anchor="middle" class="subtitle">{_esc(data["subtitle"])}</text>')


def _chip_lines(node: dict[str, Any], width: float) -> tuple[list[str], list[str]]:
    titles = _wrap(node["label"], max(5, int((width - 40) / 23)))
    details = _wrap(node.get("subtitle", ""), max(8, int((width - 40) / 16)))
    for fact in node.get("body") or []:
        details.extend(_wrap(fact, max(8, int((width - 40) / 16))))
    return titles, details


def _render_layered(data: dict[str, Any], parts: list[str]) -> None:
    groups = data["groups"] or [{"id": "all", "title": "业务结构", "subtitle": "", "color": "blue"}]
    width, height = data["width"], data["height"]
    margin, rail, top = 50, 236, 132
    gap_x, gap_y = 18, 14
    density = data["visual_system"]["density"]
    padding = 24 if density != "minimal" else 32
    layouts = []
    for group in groups:
        members = [node for node in data["nodes"] if node.get("group") in {group["id"], group["title"]}]
        if len(groups) == 1 and not members:
            members = data["nodes"]
        if not members:
            raise ArchitectureError(f"分层 {group['title']} 没有节点")
        count = len(members)
        max_cols = 3 if density == "minimal" else 4
        candidates = range(1, min(max_cols, count) + 1)
        cols = min(candidates, key=lambda n: (math.ceil(count/n), math.ceil(count/n)*n-count, -n))
        card_w = (width - 2*margin - rail - 2*padding - (cols-1)*gap_x) / cols
        if card_w < 210:
            raise ArchitectureError(f"分层 {group['title']} 节点过多，请拆图")
        card_h = max(80, max(26 + len(_chip_lines(n, card_w)[0])*28 + len(_chip_lines(n, card_w)[1])*22 for n in members))
        rows = math.ceil(count/cols)
        layer_h = max(130, 2*padding + rows*card_h + (rows-1)*gap_y)
        titles = _wrap(group["title"], 10)
        subtitles = _wrap(group.get("subtitle", ""), 13)
        layer_h = max(layer_h, 46 + len(titles)*30 + len(subtitles)*22)
        layouts.append((group, members, cols, card_w, card_h, layer_h, titles, subtitles))
    gap = 46
    required = top + sum(row[5] for row in layouts) + gap*(len(layouts)-1) + 42
    if required > height:
        raise ArchitectureError(f"分层图高度不足（至少需要 {required:.0f}px，当前 {height:.0f}px）；请增大画布或拆图")
    # Spread breathing room between complete layers, never inside empty cards.
    spare = height-required
    if len(layouts) > 1:
        gap += min(24, spare/(len(layouts)-1))
    y = top + max(0, spare - (gap-46)*(len(layouts)-1))/2
    positions = {}; group_positions = {}
    for gi, (group, members, cols, card_w, card_h, layer_h, titles, subtitles) in enumerate(layouts):
        _, stroke, _ = PALETTE.get(group["color"], PALETTE["blue"])
        parts.append(f'<rect x="{margin}" y="{y:.1f}" width="{width-2*margin:.1f}" height="{layer_h:.1f}" rx="24" fill="url(#{_gradient_id(group, gi, group=True)})" stroke="{stroke}" stroke-opacity=".35" stroke-width="1.5" filter="url(#soft-shadow)"/>')
        parts.append(f'<rect x="{margin}" y="{y:.1f}" width="7" height="{layer_h:.1f}" rx="3.5" fill="{stroke}"/>')
        text_y = y + (layer_h-(len(titles)*30+len(subtitles)*22))/2 + 23
        text_y = _svg_text(parts, margin+28, text_y, titles, "group-title", line_height=30)
        _svg_text(parts, margin+28, text_y+4, subtitles, "group-sub", line_height=22)
        for ni, node in enumerate(members):
            row, col = divmod(ni, cols)
            row_count = min(cols, len(members)-row*cols)
            row_w = row_count*card_w+(row_count-1)*gap_x
            x = margin+rail+padding + (width-2*margin-rail-2*padding-row_w)/2 + col*(card_w+gap_x)
            card_y = y+padding+row*(card_h+gap_y)
            positions[node["id"]] = (x, card_y, card_w, card_h)
            _layered_chip(parts, {**node, "color": node.get("color") or group["color"]}, x, card_y, card_w, card_h, ni)
        group_positions[group["id"]] = (margin, y, width-2*margin, layer_h)
        y += layer_h+gap
    pairs = {(e["source"], e["target"]) for e in data["group_edges"]}
    for edge in data["group_edges"]:
        reciprocal = (edge["target"], edge["source"]) in pairs
        offset = 0
        if reciprocal:
            offset = -190 if group_positions[edge["target"]][1] > group_positions[edge["source"]][1] else 190
        _group_edge(parts, edge, group_positions, offset=offset)
    for edge in data["edges"]:
        _edge(parts, edge, positions)
    _render_support(parts, data, y=height-34)


def _layered_chip(parts: list[str], node: dict[str, Any], x: float, y: float,
                  w: float, h: float, index: int) -> None:
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="14" fill="white" fill-opacity=".82"/>')
    titles, details = _chip_lines(node, w)
    content_h = len(titles)*28 + len(details)*22
    ty = y+(h-content_h)/2+23
    ty = _svg_text(parts, x+20, ty, titles, "chip-title", line_height=28)
    _svg_text(parts, x+20, ty+2, details, "chip-sub", line_height=22)


def _render_radial(data: dict[str, Any], parts: list[str]) -> None:
    sidebars = data.get("sidebars") or []
    article_layout = data.get("profile_id") == "wechat.public_article" and bool(sidebars)
    width, height = data["width"], data["height"]
    center_id = data["center_id"]
    center = next(node for node in data["nodes"] if node["id"] == center_id)
    others = [node for node in data["nodes"] if node["id"] != center_id]
    if len(sidebars) > 2:
        raise ArchitectureError("径向图最多容纳两个上下文区，请拆图")
    if len(others) > 8:
        raise ArchitectureError("径向图节点过多，请分组或拆图")
    graph_top = 260 if article_layout else 150
    graph_bottom = height-(86 if data["legend"] else 44)
    rows = max(1, math.ceil(len(others)/2))
    card_w = 350 if article_layout or not sidebars else 235
    graph_left = 70 if article_layout or not sidebars else 350
    graph_right = width-graph_left-card_w
    cx, cy = width/2, (graph_top+graph_bottom)/2
    cw, ch = 400, 216
    if graph_right < cx+cw/2+32:
        raise ArchitectureError("径向图横向空间不足，请减少侧栏或拆图")
    positions = {center_id: (cx-cw/2, cy-ch/2, cw, ch)}
    row_space = (graph_bottom-graph_top)/rows
    for i, node in enumerate(others):
        side, row = i%2, i//2
        titles = _wrap(node["label"], int((card_w-56)/24))
        subs = _wrap(node.get("subtitle", ""), int((card_w-56)/17))
        body = [line for fact in node.get("body") or [] for line in _wrap(fact, int((card_w-62)/17))]
        card_h = max(156, 68+len(titles)*30+len(subs)*24+len(body)*24)
        if card_h+24 > row_space:
            raise ArchitectureError(f"节点 {node['id']} 文本超出径向卡片容量，请增大画布或拆图")
        positions[node["id"]] = (graph_left if side==0 else graph_right, graph_top+(row+.5)*row_space-card_h/2, card_w, card_h)
    for edge in data["edges"]:
        _edge(parts, edge, positions)
    for i, node in enumerate(others):
        _radial_card(parts, node, *positions[node["id"]], i)
    center_x, center_y = cx-cw/2, cy-ch/2
    parts.append(f'<rect x="{center_x-10:.1f}" y="{center_y-10:.1f}" width="{cw+20:.1f}" height="{ch+20:.1f}" rx="38" fill="#dbeafe"/>')
    center_gradient = f"vivid-{center['color']}" if center.get("color") in PALETTE else "center-bg"
    parts.append(f'<rect x="{center_x:.1f}" y="{center_y:.1f}" width="{cw:.1f}" height="{ch:.1f}" rx="30" fill="url(#{center_gradient})" filter="url(#shadow)"/>')
    title_lines = _wrap(center["label"], 8)
    sub_lines = _wrap(center.get("subtitle", ""), 18)
    body_lines = [line for fact in center.get("body") or [] for line in _wrap(fact, 20)]
    content_h = len(title_lines)*50+len(sub_lines)*26+len(body_lines)*24
    if content_h > ch-36:
        raise ArchitectureError("中心节点文本过多，请缩短或拆图")
    ty = center_y+(ch-content_h)/2+39
    for line in title_lines:
        parts.append(f'<text x="{cx:.1f}" y="{ty:.1f}" text-anchor="middle" font-size="44" font-weight="800" fill="white">{_esc(line)}</text>'); ty += 50
    for line in sub_lines:
        parts.append(f'<text x="{cx:.1f}" y="{ty-5:.1f}" text-anchor="middle" font-size="19" fill="#f8fbff">{_esc(line)}</text>'); ty += 26
    for line in body_lines:
        parts.append(f'<text x="{cx:.1f}" y="{ty-5:.1f}" text-anchor="middle" font-size="17" fill="#dbeafe">{_esc(line)}</text>'); ty += 24
    if article_layout:
        margin, gap = 70, 24
        banner_w = (width-2*margin-gap)/2
        for i, sidebar in enumerate(sidebars):
            _sidebar_banner(parts, sidebar, margin+i*(banner_w+gap), 118, banner_w, 108)
    else:
        for sidebar in sidebars:
            _sidebar(parts, sidebar, width, height)
    if data["legend"]:
        _legend(parts, data["legend"], 65, height-38, total_width=width-130,
                colors=[_palette_key(node.get("color"), i) for i, node in enumerate(others)])


def _radial_card(parts: list[str], node: dict[str, Any], x: float, y: float,
                 w: float, h: float, index: int) -> None:
    color_key = _palette_key(node.get("color"), index)
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="26" fill="url(#vivid-{color_key})" filter="url(#shadow)"/>')
    parts.append(f'<rect x="{x+2:.1f}" y="{y+2:.1f}" width="{w-4:.1f}" height="{h-4:.1f}" rx="24" fill="none" stroke="white" stroke-opacity=".35" stroke-width="2"/>')
    tx = x + 28
    title = _wrap(node["label"], max(8, int((w - 56) / 24)))
    ty = _svg_text(parts, tx, y + 42, title, "radial-title", line_height=30)
    subtitle = _wrap(node.get("subtitle", ""), max(11, int((w - 56) / 17)))
    ty = _svg_text(parts, tx, ty + 3, subtitle, "radial-sub", line_height=24)
    body: list[str] = []
    for raw in node.get("body") or []:
        body.extend(_wrap(raw, max(12, int((w - 62) / 17))))
    available = max(0, int((y + h - ty - 15) / 24))
    if len(body) > available:
        raise ArchitectureError(f"节点 {node['id']} 文本超出径向卡片容量")
    _svg_text(parts, tx, ty + 5, body, "radial-body", line_height=24)


def _render_flow(data: dict[str, Any], parts: list[str]) -> None:
    nodes = sorted(data["nodes"], key=lambda n: (int(n.get("order", 0)) if str(n.get("order", "")).isdigit() else 999, data["nodes"].index(n)))
    cols = 4 if len(nodes) > 4 else max(1,len(nodes))
    rows = math.ceil(len(nodes)/cols)
    xgap = 22; ygap = 22; margin_x = 55; top = 135
    w = (data["width"]-2*margin_x-(cols-1)*xgap)/cols
    h = min(180, (data["height"]-top-110-(rows-1)*ygap)/max(1,rows))
    if w < 210 or h < 120: raise ArchitectureError("流程信息图卡片过密，请拆成多张图")
    positions: dict[str,tuple[float,float,float,float]] = {}
    for i,node in enumerate(nodes):
        row,col=divmod(i,cols); x=margin_x+col*(w+xgap); y=top+row*(h+ygap)
        positions[node["id"]]=(x,y,w,h); _card(parts,node,x,y,w,h,i,compact=False)
    for edge in data["edges"]: _edge(parts,edge,positions,curved=False)
    _render_support(parts,data,y=data["height"]-48)


def _group_edge(
    parts: list[str],
    edge: dict[str, Any],
    positions: dict[str, tuple[float, float, float, float]],
    *,
    offset: float = 0.0,
) -> None:
    sx, sy, sw, sh = positions[edge["source"]]
    tx, ty, tw, th = positions[edge["target"]]
    if ty >= sy:
        x1, y1, x2, y2 = sx + sw/2 + offset, sy + sh + 2, tx + tw/2 + offset, ty - 2
    else:
        x1, y1, x2, y2 = sx + sw/2 + offset, sy - 2, tx + tw/2 + offset, ty + th + 2
    color = _esc(edge.get("color") or "#2563eb")
    parts.append(f'<path d="M{x1:.1f} {y1:.1f} L{x2:.1f} {y2:.1f}" fill="none" stroke="{color}" stroke-width="3" marker-end="url(#arrow-blue)"/>')
    if edge.get("label"):
        label = _esc(edge["label"])
        lx, ly = (x1+x2)/2, (y1+y2)/2 - 5
        label_width = max(100, len(edge["label"])*14 + 20)
        parts.append(f'<rect x="{lx-label_width/2:.1f}" y="{ly-17:.1f}" width="{label_width:.1f}" height="22" rx="8" fill="#f8fbff" opacity=".95"/>')
        parts.append(f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="middle" class="edge-label">{label}</text>')


def _sidebar(parts: list[str], sidebar: dict[str, Any], width: float, height: float) -> None:
    side = sidebar["side"]
    x = 48 if side == "left" else width - 348
    w = 300
    content_h = 125 + sum(max(1, len(_wrap(item, 12))) * 25 + 31 for item in sidebar["items"])
    h = min(height - 260, max(500, content_h))
    y = (height - h) / 2 + 15
    parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="26" fill="white" fill-opacity=".90" stroke="#a6c8e8" stroke-width="2" filter="url(#shadow)"/>')
    parts.append(f'<rect x="{x}" y="{y}" width="6" height="{h}" rx="3" fill="#2563eb"/>')
    parts.append(f'<text x="{x+24}" y="{y+43}" font-size="27" font-weight="800" fill="#173a59">{_esc(sidebar["title"])}</text>')
    if sidebar.get("subtitle"):
        parts.append(f'<text x="{x+24}" y="{y+70}" font-size="17" fill="#63809a">{_esc(sidebar["subtitle"])}</text>')
    cursor = y + 118
    for item in sidebar["items"]:
        lines = _wrap(item, 12)
        parts.append(f'<circle cx="{x+31}" cy="{cursor-7}" r="5" fill="#2563eb"/>')
        cursor = _svg_text(parts, x+50, cursor, lines, "node-sub", line_height=25) + 31


def _sidebar_banner(parts: list[str], sidebar: dict[str, Any], x: float, y: float, w: float, h: float) -> None:
    """Render radial context as a compact banner instead of a tall side rail."""
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="18" fill="url(#card-blue)" stroke="#a6c8e8" stroke-width="1.7" filter="url(#soft-shadow)"/>')
    parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="7" height="{h:.1f}" rx="3" fill="#2563eb"/>')
    parts.append(f'<text x="{x+24:.1f}" y="{y+32:.1f}" class="group-title">{_esc(sidebar["title"])}</text>')
    if sidebar.get("subtitle"):
        parts.append(f'<text x="{x+24:.1f}" y="{y+55:.1f}" class="group-sub">{_esc(sidebar["subtitle"])}</text>')
    summary = " · ".join(sidebar.get("items") or [])
    lines = _wrap(summary, max(24, int((w - 48) / 16)))
    if len(lines) > 2:
        raise ArchitectureError("上下文区内容过多，请缩短或拆图")
    for line_index, line in enumerate(lines):
        parts.append(f'<text x="{x+24:.1f}" y="{y+79+line_index*19:.1f}" class="legend">{_esc(line)}</text>')


def _render_support(parts: list[str], data: dict[str, Any], *, y: float) -> None:
    layers = data.get("supporting_layers") or []
    if not layers: return
    values=[]
    for item in layers:
        if isinstance(item, dict): values.append(str(item.get("title") or item.get("label") or ""))
        else: values.append(str(item))
    values=[v for v in values if v]
    if not values:return
    gap=10; x=55; w=(data["width"]-110-gap*(len(values)-1))/len(values)
    for i,v in enumerate(values):
        xx=x+i*(w+gap); parts.append(f'<rect x="{xx:.1f}" y="{y:.1f}" width="{w:.1f}" height="28" rx="14" fill="#e2e8f0" stroke="#94a3b8"/><text x="{xx+w/2:.1f}" y="{y+19:.1f}" text-anchor="middle" class="legend">{_esc(v)}</text>')


def _legend(parts: list[str], values: list[str], x: float, y: float,
            *, total_width: float | None = None, colors: list[str] | None = None) -> None:
    if not values:
        return
    gap = 10
    if total_width:
        width = (total_width - gap * (len(values) - 1)) / len(values)
        widths = [width] * len(values)
    else:
        widths = [max(86, len(value) * 14 + 24) for value in values]
    current = x
    palette = list(PALETTE.values())
    for index, (value, width) in enumerate(zip(values, widths)):
        _, stroke, accent = PALETTE[colors[index]] if colors and index < len(colors) else palette[index % len(palette)]
        parts.append(f'<rect x="{current:.1f}" y="{y-21:.1f}" width="{width:.1f}" height="32" rx="9" fill="#f8fbff" stroke="#d7e5f3"/>')
        parts.append(f'<rect x="{current+10:.1f}" y="{y-11:.1f}" width="12" height="12" rx="3" fill="{stroke}"/>')
        parts.append(f'<text x="{current+31:.1f}" y="{y+2:.1f}" class="legend">{_esc(value)}</text>')
        current += width + gap


def render_architecture_svg(request: dict[str, Any]) -> str:
    data = validate_architecture_request(request)
    width, height = data["width"], data["height"]
    scale = width/1600
    data = {**data, "width": 1600, "height": height/scale}
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 {data["height"]:.2f}" width="{width}" height="{height}">', _defs(data["visual_system"]), '<rect width="100%" height="100%" fill="url(#bg)"/><rect width="100%" height="100%" fill="url(#dot-grid)"/>']
    _header(parts, data)
    if data["diagram_subtype"] == "layered": _render_layered(data, parts)
    elif data["diagram_subtype"] == "radial": _render_radial(data, parts)
    else: _render_flow(data, parts)
    parts.append("</svg>")
    return _apply_visual_system("".join(parts), data["visual_system"])
