"""Public illustration component implementations.

The component catalog is deliberately small.  Skill packages provide the
workflow and business-facing definition; this package provides deterministic
rendering and validation that can be reused by more than one Skill.
"""

from .catalog import get_component, list_components
from .architecture import render_architecture_svg, validate_architecture_request
from .infographic_steps import render_infographic_svg, validate_infographic_request

__all__ = [
    "get_component",
    "list_components",
    "render_architecture_svg",
    "validate_architecture_request",
    "render_infographic_svg",
    "validate_infographic_request",
]
