"""DataCloud 驱动。

由 `datacloud-knowledge-retrieval`（1734 行）迁入。迁过来的是**查询语义**——域到对象编码的
映射、平台配额、响应归一；没迁的是那套传输。

**传输为什么不照搬。** 旧 `client.py` 完全建在 `by_framework` 上：服务发现（Redis 支撑）
拿实例，`Beyond-Token` 也从 Redis 读，**没有一个可直连的 URL**。能力层依赖只有 httpx 与
PyYAML，把平台包拉进来，能力就装不进没有平台运行时的环境——而本地文件夹驱动本来可以独立跑。

所以传输**注入**。副产品是这套逻辑第一次可测：旧代码要跑起来得先有 Redis 和平台包，
921 行 `query_objects.py` 至今零测试。

对象映射与调用约束见同目录 `DATACLOUD-DRIVER.md`。
"""

from __future__ import annotations

import hashlib
from typing import Any, Callable, Iterable, Mapping

from byclaw_caps.query import (
    KIND_DOCUMENTS,
    KIND_FILE,
    KIND_OBJECTS,
    STATUS_NO_SOURCE,
    STATUS_OK,
    STATUS_UNREACHABLE,
    STATUS_UNSUPPORTED,
)

DEFAULT_BASE_ID = "BYCLAW_DATACLOUD"
STRUCTURED_PATH = "/api/v1/ontologyBases/{base_id}/instances/search"
UNSTRUCTURED_PATH = "/api/v1/rpc/search/searchObjectInstancesUnstructured"

#: 平台侧的性能与配额规则，**只对本驱动成立**——本地文件夹没有这套枷锁。
#: 原先它写在选题 Skill 的 references 里，让本地用户也背着它。
MAX_SEMANTIC_QUERIES = 3
MAX_QUERY_LENGTH = 40
MAX_TOTAL_QUERY_LENGTH = 80
MAX_LIMIT = 100

#: 知识域 → 对象编码。业务侧只写 domain，这张表是驱动的实现细节。
DOMAIN_OBJECTS: dict[str, tuple[str, ...]] = {
    "素材.产品": (
        "Product", "Ability", "Concept", "Example", "Feature", "Methodology",
        "Operation", "ProductMap", "TechArchitecture", "TechComponent",
        "TechSpec", "Validation", "Vendor",
    ),
    "素材.事件": ("Event",),
    "素材.会议纪要": ("MeetingMinutes",),
    "写法.模板": ("WritingTemplate",),
    "写法.资产": ("WritingAsset",),
    "写法.参考": ("ReferenceArticle", "ArticleAnalysis"),
    "成品": ("Collection", "WritingOutput"),
    "运营": ("WritingReview",),
    "渠道": ("Channel", "AudiencePersona", "BrandVoice"),
}
# `ChannelStyleGuide`、`Document`、`NewsItem` 刻意不映射——内容是平台规则而非用户数据，
# 或 0 实例且属性已被 `Event` 覆盖。

_LIST_KEYS = ("items", "results", "instances", "records", "hits", "content",
              "knowledge_refs")
_ID_KEYS = ("instance_id", "instanceId", "id", "instance_code", "instanceCode", "code")
_NAME_KEYS = ("instance_name", "instanceName", "name")


def unwrap_items(response: Any) -> list[dict[str, Any]]:
    """剥壳并取出条目列表。

    键名变体不是啰嗦——每一个都是接口实际返回过的形状。删掉任何一个，
    换个端点就静默取到空列表。
    """
    data = response.get("data", response) if isinstance(response, Mapping) else response
    if isinstance(data, Mapping) and set(data) == {"data"}:
        data = data["data"]
    if isinstance(data, list):
        return [item for item in data if isinstance(item, Mapping)]
    if not isinstance(data, Mapping):
        return []
    for key in _LIST_KEYS:
        value = data.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, Mapping)]
    flattened: list[dict[str, Any]] = []
    for value in data.values():
        if isinstance(value, list):
            flattened.extend(item for item in value if isinstance(item, Mapping))
    return flattened


def _first(item: Mapping[str, Any], keys: Iterable[str]) -> str:
    for key in keys:
        value = item.get(key)
        if value not in (None, ""):
            return str(value)
    return ""


def normalize_item(
    item: Mapping[str, Any], object_code: str, *, source_id: str = "datacloud",
    body: str | None = None,
) -> dict[str, Any]:
    """归一成与本地驱动可合并的形状。

    ``digest_basis`` 必须声明：远端摘要没有文件字节，哈希只能按身份算，而本地按内容算。
    不说清楚，跨源去重会**静默失效**——同一篇文章两边都出现却不合并，看到重复项的人
    无从知道为什么。
    """
    properties = item.get("properties") or item.get("fields") or item.get("attrs") or {}
    if not isinstance(properties, Mapping):
        properties = {}
    instance_id = _first(item, _ID_KEYS)
    title = _first(item, _NAME_KEYS) or _first(properties, ("name", "title"))
    code = str(item.get("object_code") or item.get("objectCode") or object_code)
    if body is None:
        basis = "identity"
        digest = hashlib.sha256(f"{code}\x00{instance_id}".encode("utf-8")).hexdigest()
    else:
        basis = "content"
        digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
    result = {
        "source": source_id,
        "path": f"{code}/{instance_id}" if instance_id else code,
        "title": title,
        "sha256": digest,
        "digest_basis": basis,
        "chunk": item.get("chunk"),
        "score": item.get("score"),
        "object_code": code,
        "instance_id": instance_id,
        "properties": dict(properties),
    }
    locator = {
        "kb_id": item.get("kb_id") or item.get("kbId"),
        "kb_resource_id": item.get("kb_resource_id") or item.get("kbResourceId"),
        "kb_file_path": (item.get("file_name") or item.get("kb_file_path")
                         or item.get("kbFilePath")),
    }
    for key, value in locator.items():
        if value not in (None, ""):
            result[key] = value
    if body is not None:
        result["content"] = body
    return result


def _check_quota(queries: list[str]) -> str | None:
    """超限在**发请求之前**拒绝——平台会拒，白跑一趟还占着那次调用。"""
    if len(queries) > MAX_SEMANTIC_QUERIES:
        return (f"一次最多 {MAX_SEMANTIC_QUERIES} 个查询词，收到 {len(queries)} 个。"
                "用主题词与上位概念召回，不要写完整候选论点。")
    for text in queries:
        if len(text) > MAX_QUERY_LENGTH:
            return f"单个查询词不得超过 {MAX_QUERY_LENGTH} 字符：{text[:20]}…"
    total = sum(len(text) for text in queries)
    if total > MAX_TOTAL_QUERY_LENGTH:
        return f"查询词合计不得超过 {MAX_TOTAL_QUERY_LENGTH} 字符，收到 {total}。"
    return None


def default_transport(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    """走平台的服务发现。缺平台运行时会抛 ``ModuleNotFoundError``，由驱动翻译成 UNREACHABLE。"""
    from byclaw_caps._platform_http import post_json

    return post_json(path, payload)


class DataCloudDriver:
    """本体对象 API 驱动。"""

    backend = "datacloud"
    CAPABILITIES: dict[str, Any] = {
        # 本地源没有对象概念——这一条正是远端存在的理由。
        "kinds": frozenset({KIND_OBJECTS, KIND_DOCUMENTS, KIND_FILE}),
        "filters": frozenset({"where"}),
        "recall": frozenset({"enumerate", "semantic"}),
        "write": "none",
    }

    @classmethod
    def query(
        cls, source: Mapping[str, Any], request: Mapping[str, Any],
        *, transport: Callable[[str, dict[str, Any]], Any] | None = None,
    ) -> tuple[str, list[dict[str, Any]], dict[str, Any]]:
        domain = request["domain"]
        configured_objects = source.get("object_map")
        if isinstance(configured_objects, Mapping):
            objects = tuple(str(value) for value in (configured_objects.get(domain) or []))
        else:
            # 1.x 配置没有映射字段，继续使用驱动内置默认，保证兼容。
            objects = DOMAIN_OBJECTS.get(domain) or ()
        configured_kbs = source.get("knowledge_base_map")
        knowledge_base_ids = (
            tuple(str(value) for value in (configured_kbs.get(domain) or []))
            if isinstance(configured_kbs, Mapping) else ()
        )
        if not objects and not knowledge_base_ids:
            return (
                STATUS_NO_SOURCE, [],
                {"hint": (f"源 {source['id']} 未映射知识域 {domain}。"
                          "请在 sources.yaml 2.0 的 ontology_objects.codes 或 "
                          "knowledge_bases.ids 中补齐。")},
            )

        kind = request.get("kind") or KIND_DOCUMENTS
        if kind not in cls.CAPABILITIES["kinds"]:
            return (STATUS_UNSUPPORTED, [],
                    {"hint": f"本驱动不支持 kind={kind}。"})

        queries = [str(q) for q in (request.get("queries") or []) if str(q).strip()]
        if request.get("query"):
            queries.append(str(request["query"]))
        problem = _check_quota(queries)
        if problem:
            return STATUS_UNSUPPORTED, [], {"hint": problem}

        limit = min(int(request.get("limit") or 10), MAX_LIMIT)
        base_id = str(source.get("base_id") or DEFAULT_BASE_ID)
        post = transport or default_transport
        items: list[dict[str, Any]] = []
        try:
            if knowledge_base_ids and not queries:
                return (STATUS_UNSUPPORTED, [], {
                    "hint": "知识库检索必须提供 query/queries；知识库不能按域枚举全部正文。"
                })
            # 纯知识库映射只发一次请求；有对象映射则逐对象查询，保持原有配额和归一行为。
            targets: tuple[str | None, ...] = tuple(objects) or (None,)
            for code in targets:
                if len(items) >= limit:
                    break
                if queries:
                    path = UNSTRUCTURED_PATH
                    params: dict[str, Any] = {
                        "base_id": base_id, "queries": queries,
                        "top_k": limit - len(items),
                        "enable_chunk_recall": bool(request.get("enable_chunk_recall")),
                    }
                    if code:
                        params["object_codes"] = [code]
                    if knowledge_base_ids:
                        params["knowledge_base_ids"] = list(knowledge_base_ids)
                    payload = {"params": params}
                else:
                    assert code is not None
                    path = STRUCTURED_PATH.format(base_id=base_id)
                    payload = {"objectCode": code,
                               "pageSize": min(limit - len(items), MAX_LIMIT)}
                    if request.get("where"):
                        payload["where"] = request["where"]
                for raw in unwrap_items(post(path, payload)):
                    items.append(normalize_item(
                        raw, code or "KnowledgeDocument", source_id=source["id"]))
        except ModuleNotFoundError as exc:
            # 平台运行时缺失 ≠ 网络不通 ≠ 没有数据。旧代码把三者混成同一个异常，
            # 结果是有人去补数据，而真正该做的是修部署。
            return (STATUS_UNREACHABLE, [],
                    {"hint": (f"平台运行时不可用（{exc}）。本驱动经 by_framework 的服务发现"
                              "调用 DataCloud，没有可直连的 URL；请在具备平台运行时的环境中"
                              "运行，或改挂本地源。")})
        except Exception as exc:  # noqa: BLE001
            return (STATUS_UNREACHABLE, [],
                    {"hint": f"DataCloud 调用失败：{type(exc).__name__}: {exc}"})

        seen: set[str] = set()
        unique = []
        for item in items:
            if item["sha256"] in seen:
                continue
            seen.add(item["sha256"])
            unique.append(item)
        return STATUS_OK, unique[:limit], {}
