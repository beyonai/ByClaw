"""统一联网搜索后端：SearXNG、Tavily 或腾讯云 WSA，抓取与 Skill 解耦。"""

from __future__ import annotations

import hashlib
import hmac as _hmac
import ipaddress
import json
import os
import shlex
import shutil
import time as _time
from datetime import datetime, timezone
from pathlib import Path
import socket
import subprocess
from html.parser import HTMLParser
from typing import Any, Mapping
from urllib.parse import urljoin, urlparse

from byclaw_caps.credentials import resolve_credential


TAVILY_ENDPOINT = "https://api.tavily.com/search"


class WebBackendError(RuntimeError):
    """后端、网络、依赖或响应不可用。"""


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag.lower() in {"script", "style", "noscript", "svg"}:
            self._skip += 1
        elif tag.lower() in {"p", "br", "li", "h1", "h2", "h3", "h4", "section", "article"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() in {"script", "style", "noscript", "svg"} and self._skip:
            self._skip -= 1
        elif tag.lower() in {"p", "li", "section", "article"}:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self._skip and data.strip():
            self.parts.append(data.strip())

    def text(self) -> str:
        lines = [" ".join(line.split()) for line in " ".join(self.parts).splitlines()]
        return "\n\n".join(line for line in lines if line)


def _safe_public_url(url: str, *, resolve_dns: bool = False) -> str:
    parsed = urlparse(str(url).strip())
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise WebBackendError(f"只允许公开 http/https URL：{url!r}")
    host = parsed.hostname.lower()
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise WebBackendError("不允许抓取本机或内网地址")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        pass
    else:
        if not address.is_global:
            raise WebBackendError("不允许抓取本机、保留或私有 IP 地址")
    if resolve_dns:
        try:
            addresses = {
                item[4][0] for item in socket.getaddrinfo(
                    host, parsed.port or (443 if parsed.scheme == "https" else 80),
                    type=socket.SOCK_STREAM)
            }
        except socket.gaierror as exc:
            raise WebBackendError(f"URL 域名无法解析：{host}") from exc
        if not addresses or any(not ipaddress.ip_address(value).is_global
                                for value in addresses):
            raise WebBackendError("URL 域名解析到本机、保留或私有 IP 地址")
    return parsed.geturl()


def fetch_public_url(url: str, *, timeout: float = 30.0) -> dict[str, Any]:
    """抓取公开网页并逐字提取正文；不调用模型概括。"""
    import httpx

    safe = _safe_public_url(url, resolve_dns=True)
    try:
        with httpx.Client(
                timeout=timeout, follow_redirects=False,
                headers={"User-Agent": "byclaw-web-retrieval/1.0"}) as client:
            response = None
            current = safe
            for _ in range(6):
                response = client.get(current)
                if response.status_code not in {301, 302, 303, 307, 308}:
                    break
                location = str(response.headers.get("location") or "").strip()
                if not location:
                    raise WebBackendError("重定向响应缺少 Location")
                current = _safe_public_url(urljoin(current, location), resolve_dns=True)
            else:
                raise WebBackendError("网页重定向次数超过 5 次")
        assert response is not None
        response.raise_for_status()
    except Exception as exc:  # noqa: BLE001
        raise WebBackendError(f"抓取失败：{type(exc).__name__}: {exc}") from exc
    content_type = str(response.headers.get("content-type") or "").lower()
    if len(response.content) > 5 * 1024 * 1024:
        raise WebBackendError("抓取正文超过 5 MiB 上限")
    if "html" in content_type:
        parser = _TextExtractor()
        parser.feed(response.text)
        content = parser.text()
    else:
        content = response.text
    if not content.strip():
        raise WebBackendError("抓取结果为空")
    return {"url": str(response.url), "title": "", "content": content,
            "fetch_mode": "simple", "content_type": content_type}


class SearXNGAdapter:
    provider = "searxng"

    def __init__(self, integration: Mapping[str, Any], *, env: Mapping[str, str] | None = None):
        self.integration = dict(integration)
        self.env = os.environ if env is None else env

    #: 自带件的落点。与 ffmpeg、CJK 字体同一约定——能力层只认这一个确定路径，
    #: **不去满文件系统搜 skill 装在哪**，那种搜法脆而且慢。放置由
    #: `setup-environment` 负责：它知道自己在哪，也就知道并排的 skill 在哪。
    BUNDLED = "by/.prereqs/searxng/searxng_cli.py"

    def _command(self) -> list[str]:
        """三级定位：显式指定 → 自带件 → 系统安装。

        原先只有第 1、3 级，而平台上两者都没有——**恰好漏掉了唯一能用的那一级**。
        自带的那份是 20MB 源码 + 19 个 pip 依赖，实测能真搜出结果，且不要 API key。
        """
        import sys

        explicit = str(self.env.get("SEARXNG_CLI") or "").strip()
        if explicit:
            return shlex.split(explicit)

        home = self.env.get("HOME") or self.env.get("USERPROFILE") or ""
        bundled = Path(home) / self.BUNDLED if home else None
        if bundled is not None and bundled.is_file():
            # 它是 .py 不是可执行文件，直接当命令跑会 Permission denied。
            return [sys.executable, str(bundled)]

        found = shutil.which("searxng-cli")
        if not found:
            raise WebBackendError(
                f"未找到 SearXNG CLI。三处都没有：环境变量 SEARXNG_CLI、"
                f"自带件 ~/{self.BUNDLED}、系统 PATH。"
                "传 searxng-runtime skill 后跑一次 setup-environment 即可装上；"
                "或把 provider 改成 tavily 并配密钥")
        return [found]

    def search(self, query: str, *, limit: int, filters: Mapping[str, Any] | None = None
               ) -> list[dict[str, Any]]:
        filters = filters or {}
        cmd = self._command() + [query, "--max-results", str(limit)]
        options = {
            "category": "--category", "language": "--language",
            "time_range": "--time-range", "safesearch": "--safesearch",
        }
        for key, flag in options.items():
            value = filters.get(key)
            if value not in (None, ""):
                cmd.extend([flag, str(value)])
        timeout = float(self.integration.get("timeout_seconds") or 60)
        try:
            done = subprocess.run(cmd, capture_output=True, text=True,
                                  timeout=max(60.0, timeout + 30.0), check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise WebBackendError(f"SearXNG 调用失败：{exc}") from exc
        if done.returncode != 0:
            raise WebBackendError(
                f"SearXNG 返回退出码 {done.returncode}：{(done.stderr or '')[-500:]}")
        try:
            payload = json.loads(done.stdout or "{}")
        except json.JSONDecodeError as exc:
            raise WebBackendError("SearXNG 返回非 JSON") from exc
        results = payload.get("results") or payload.get("items") or []
        return [{
            "title": str(item.get("title") or ""),
            "url": str(item.get("url") or ""),
            "snippet": str(item.get("content") or item.get("snippet") or ""),
            "score": item.get("score"),
            "engine": item.get("engine") or item.get("engines"),
            "published_at": item.get("publishedDate") or item.get("published_at"),
        } for item in results[:limit] if isinstance(item, Mapping)]

    def fetch(self, urls: list[str], *, timeout: float = 30.0) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for url in urls:
            try:
                results.append(fetch_public_url(url, timeout=timeout))
            except WebBackendError as exc:
                results.append({"url": url, "error": str(exc)})
        return results


class TavilyAdapter:
    provider = "tavily"

    def __init__(self, integration: Mapping[str, Any], *, env: Mapping[str, str] | None = None,
                 secret_resolver=None, http=None):
        self.integration = dict(integration)
        self.env = os.environ if env is None else env
        self.secret_resolver = secret_resolver
        self.http = http

    def search(self, query: str, *, limit: int, filters: Mapping[str, Any] | None = None
               ) -> list[dict[str, Any]]:
        import httpx

        credential = resolve_credential(
            "web_search", self.integration, env=self.env,
            secret_resolver=self.secret_resolver)
        filters = filters or {}
        payload: dict[str, Any] = {
            "query": query, "max_results": limit, "include_answer": False,
            "include_raw_content": False, "include_images": False,
            "safe_search": bool(filters.get("safesearch", 1)),
        }
        if filters.get("time_range"):
            payload["time_range"] = filters["time_range"]
        if self.integration.get("search_depth"):
            payload["search_depth"] = self.integration["search_depth"]
        timeout = float(self.integration.get("timeout_seconds") or 30)
        call = self.http or httpx.post
        try:
            response = call(
                TAVILY_ENDPOINT, json=payload,
                headers={"Authorization": f"Bearer {credential['value']}"},
                timeout=timeout,
            )
            if hasattr(response, "raise_for_status"):
                response.raise_for_status()
            data = response.json() if hasattr(response, "json") else response
        except Exception as exc:  # noqa: BLE001
            raise WebBackendError(f"Tavily 调用失败：{type(exc).__name__}: {exc}") from exc
        if not isinstance(data, Mapping):
            raise WebBackendError("Tavily 返回非 JSON 对象")
        return [{
            "title": str(item.get("title") or ""),
            "url": str(item.get("url") or ""),
            "snippet": str(item.get("content") or ""),
            "score": item.get("score"),
            "engine": "tavily",
            "published_at": item.get("published_date"),
        } for item in (data.get("results") or [])[:limit] if isinstance(item, Mapping)]

    def fetch(self, urls: list[str], *, timeout: float = 30.0) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for url in urls:
            try:
                results.append(fetch_public_url(url, timeout=timeout))
            except WebBackendError as exc:
                results.append({"url": url, "error": str(exc)})
        return results


_FRESHNESS_MAP: dict[str, str] = {
    "day": "d", "d": "d", "d1": "d",
    "week": "d7",
    "month": "m", "m": "m", "m1": "m",
    "year": "y", "y": "y", "y1": "y",
    "3month": "m3", "quarter": "m3",
}


def _map_freshness(time_range: str) -> str | None:
    """把通用 time_range 值（SearXNG/Tavily 惯用）映射到腾讯云 Freshness 格式。"""
    if not time_range:
        return None
    mapped = _FRESHNESS_MAP.get(str(time_range).lower())
    if mapped:
        return mapped
    import re
    if re.match(r"^[dmy]\d{0,2}$", time_range):
        return time_range
    return None


class TencentWSAAdapter:
    """腾讯云联网搜索（Web Search API，标准版）。

    API 文档：wsa.tencentcloudapi.com  Action=SearchPro  Version=2025-05-08
    签名：TC3-HMAC-SHA256（腾讯云 API v3 标准）

    integration 配置项：
        secret_id_env  (str)  读取 SecretId 的环境变量名，默认 TENCENTCLOUD_SECRET_ID
        secret_key_env (str)  读取 SecretKey 的环境变量名，默认 TENCENTCLOUD_SECRET_KEY
        mode           (int)  0=自然结果 1=权威VR卡 2=混合（默认 2，标准版支持）
        timeout_seconds(int)  HTTP 超时，默认 30
    """

    provider = "tencent_wsa"
    ENDPOINT = "https://wsa.tencentcloudapi.com"
    ACTION = "SearchPro"
    VERSION = "2025-05-08"
    SERVICE = "wsa"
    HOST = "wsa.tencentcloudapi.com"

    def __init__(self, integration: Mapping[str, Any], *, env: Mapping[str, str] | None = None):
        self.integration = dict(integration)
        self.env = os.environ if env is None else env

    def _credentials(self) -> tuple[str, str]:
        id_env = str(self.integration.get("secret_id_env") or "TENCENTCLOUD_SECRET_ID")
        key_env = str(self.integration.get("secret_key_env") or "TENCENTCLOUD_SECRET_KEY")
        secret_id = str(self.env.get(id_env) or "").strip()
        secret_key = str(self.env.get(key_env) or "").strip()
        missing = [v for v, val in [(id_env, secret_id), (key_env, secret_key)] if not val]
        if missing:
            raise WebBackendError(f"腾讯云密钥未配置：{', '.join(missing)}")
        return secret_id, secret_key

    def _tc3_auth(self, secret_id: str, secret_key: str, body: str) -> tuple[str, str]:
        """返回 (Authorization 头值, X-TC-Timestamp 值)。"""
        timestamp = int(_time.time())
        date = datetime.fromtimestamp(timestamp, tz=timezone.utc).strftime("%Y-%m-%d")

        content_type = "application/json; charset=utf-8"
        canonical_headers = f"content-type:{content_type}\nhost:{self.HOST}\n"
        signed_headers = "content-type;host"
        hashed_payload = hashlib.sha256(body.encode("utf-8")).hexdigest()
        canonical_request = "\n".join([
            "POST", "/", "", canonical_headers, signed_headers, hashed_payload,
        ])

        credential_scope = f"{date}/{self.SERVICE}/tc3_request"
        string_to_sign = "\n".join([
            "TC3-HMAC-SHA256",
            str(timestamp),
            credential_scope,
            hashlib.sha256(canonical_request.encode("utf-8")).hexdigest(),
        ])

        def _h(key: bytes, msg: str) -> bytes:
            return _hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

        sk = _h(("TC3" + secret_key).encode("utf-8"), date)
        sk = _h(_h(sk, self.SERVICE), "tc3_request")
        signature = _hmac.new(sk, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

        authorization = (
            f"TC3-HMAC-SHA256 Credential={secret_id}/{credential_scope}, "
            f"SignedHeaders={signed_headers}, Signature={signature}"
        )
        return authorization, str(timestamp)

    def search(self, query: str, *, limit: int,
               filters: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        import httpx

        secret_id, secret_key = self._credentials()
        filters = filters or {}

        payload: dict[str, Any] = {"Query": query}
        mode = filters.get("mode", self.integration.get("mode", 2))
        try:
            payload["Mode"] = int(mode)
        except (TypeError, ValueError):
            payload["Mode"] = 2

        freshness = _map_freshness(str(filters.get("time_range") or ""))
        if freshness:
            payload["Freshness"] = freshness

        site = str(filters.get("site") or self.integration.get("site") or "").strip()
        if site:
            payload["Site"] = site

        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        authorization, timestamp_str = self._tc3_auth(secret_id, secret_key, body)

        headers = {
            "Authorization": authorization,
            "Content-Type": "application/json; charset=utf-8",
            "Host": self.HOST,
            "X-TC-Action": self.ACTION,
            "X-TC-Version": self.VERSION,
            "X-TC-Timestamp": timestamp_str,
        }
        timeout = float(self.integration.get("timeout_seconds") or 30)
        try:
            response = httpx.post(self.ENDPOINT, content=body.encode("utf-8"),
                                  headers=headers, timeout=timeout)
            response.raise_for_status()
            data = response.json()
        except Exception as exc:  # noqa: BLE001
            raise WebBackendError(f"腾讯云 WSA 调用失败：{type(exc).__name__}: {exc}") from exc

        resp = (data.get("Response") or {})
        error = resp.get("Error")
        if error:
            code = error.get("Code", "")
            msg = error.get("Message", "")
            raise WebBackendError(f"腾讯云 WSA 返回错误 {code}：{msg}")

        results: list[dict[str, Any]] = []
        for raw in (resp.get("Pages") or []):
            try:
                item = json.loads(raw) if isinstance(raw, str) else raw
            except (ValueError, TypeError):
                continue
            if not isinstance(item, Mapping):
                continue
            results.append({
                "title": str(item.get("title") or ""),
                "url": str(item.get("url") or ""),
                "snippet": str(item.get("passage") or ""),
                "score": item.get("score"),
                "engine": "tencent_wsa",
                "published_at": item.get("date"),
            })
        return results[:limit]

    def fetch(self, urls: list[str], *, timeout: float = 30.0) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for url in urls:
            try:
                results.append(fetch_public_url(url, timeout=timeout))
            except WebBackendError as exc:
                results.append({"url": url, "error": str(exc)})
        return results


def make_web_backend(integration: Mapping[str, Any], **kwargs):
    if integration.get("enabled") is False:
        raise WebBackendError("联网检索已禁用；请在 sources.yaml 的对应知识域下打开 web_search.enabled")
    provider = str(integration.get("provider") or "").strip().lower()
    if provider == "searxng":
        return SearXNGAdapter(integration, env=kwargs.get("env"))
    if provider == "tavily":
        return TavilyAdapter(integration, env=kwargs.get("env"),
                             secret_resolver=kwargs.get("secret_resolver"),
                             http=kwargs.get("http"))
    if provider == "tencent_wsa":
        return TencentWSAAdapter(integration, env=kwargs.get("env"))
    raise WebBackendError(
        "未配置联网检索 provider。请在 sources.yaml 的顶层 web_search 段选择 "
        "tencent_wsa（默认）、searxng 或 tavily")


__all__ = [
    "WebBackendError", "SearXNGAdapter", "TavilyAdapter", "TencentWSAAdapter",
    "make_web_backend", "fetch_public_url",
]
