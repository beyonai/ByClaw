---
name: data-query
description: 当创作流程需要取素材、成品、写法资产或运营数据时使用。两个数据源——项目云盘与联网检索——Skill 只声明要哪个知识域，去哪拿由 /.user_settings 下的两份映射决定，人挪了云盘目录不用改 Skill。三种意图都能表达：不写则默认挂载的源全查；--extra-sources 在默认之外追加；--only-sources 限定只查某几个源。追加与限定不能同时给。云盘支持两种召回：找相关内容带 --query 走语义检索，要全量清单不带 --query 按域枚举。数据源不支持某种检索时明确报 UNSUPPORTED_BY_SOURCE，不静默降级；映射指向的目录已不存在时报 MAPPING_STALE，不报成「没有素材」。
---

# 数据查询

## 调用

```bash
# sources.yaml 是**可选**的：不配就用内置默认（项目云盘默认挂载、
# 联网检索按需追加）。只有要改「哪个知识域允许联网」时才需要它。
python3 -m byclaw_caps.query init --project-root <Project Root>

# 上线前检查配置；不发外部请求，也不按当前工作目录猜项目
python3 -m byclaw_caps.query validate --project-root <Project Root>
python3 -m byclaw_caps.query doctor --project-root <Project Root>

# 按知识域取数据（云盘）
python3 -m byclaw_caps.query search --project-root <Project Root> \
    --resource-id <cloudResourceId> --domain <知识域> \
    [--limit 10] [--include-body] [--session-root <Session Root>] \
    [--extra-sources <源名> ...] [--per-source-limit N]

# 联网采用两阶段协议：先搜索候选，再只抓选中的公开 URL 原文
python3 -m byclaw_caps.query search --project-root <Project Root> \
    --domain <知识域> --only-sources 联网检索 --query <检索词>
python3 -m byclaw_caps.query search --project-root <Project Root> \
    --domain <知识域> --only-sources 联网检索 --operation fetch \
    --url <公开 URL> --session-root <Session Root>

# 列出受控知识域词表
python3 -m byclaw_caps.query domains
```

退出码：`0` 取到，`1` 业务失败（域无源可用／源不可达），`2` 用法错误或环境不具备
（云盘 CLI 找不到、映射缺失、缺 resourceId）。

**两类失败必须分开看**：`1` 是「查了，没有」，该去补素材；`2` 是「压根没查成」，
该去修部署或补映射。混成一个码，agent 会反复换问法重试一个根本查不动的源。

## 只声明知识域，不声明位置

Skill 里**写 `--domain 素材.产品`，不写路径**。云盘目录由人自由组织，
落点由两份映射决定：

```
/.user_settings/_project.yaml     团队公共，作基底，项目创建时由平台生成
/.user_settings/<工号>.yaml       个人，按域整条覆盖，成员加入时生成
```

**旧的 `sources.yaml` 要删掉。** 迁移前那份声明 `backend: local`，
而本地驱动随项目空间一起废除了——留着它取数直接报错，报的是
「这份配置是迁移前的旧配置」，不是「少装了什么」。

知识域是**受控词表**，`domains` 子命令列出全部。写不在词表里的域会报用法错误——
拼错域名比取不到数据更难查，因为它静默地查了别的地方。

**映射读不到就报错，不回落到遍历云盘。** 遍历看起来能跑：云盘 `list` 单层不递归，
从 `/` 逐层摸既慢又不准，而摸不到的结果与「查过了，确实没有」长得一模一样。

报的是 `MAPPING_MISSING`，**错误里自带下一步动作**：让用户对「全媒体创作官」说
「初始化云盘映射」，由写作支持助理生成那两份文件。
**把错误原文带进回执**——那句话是给用户看的，转述会丢。

## 云盘要三样东西

| 参数 | 从哪来 | 漏了会怎样 |
|---|---|---|
| `--resource-id` | 会话上下文的 `cloudResourceId` / `cloud_resource_id` | 直接报错。**不要猜 ID，也不要拿普通知识库的 resourceId 冒充** |
| `--user-code` | 不传则读环境变量 `USER_CODE` | 不知道读哪份个人映射 |
| `--app-id` | 不传则读环境变量 `WECHAT_APPID` | 用到 `${APP_ID}` 的域（成品、运营、渠道.账号档案）报错 |

`--cloud-cli` 一般不用传。查找顺序：

1. `--cloud-cli` 显式指定
2. 环境变量 `BYCLAW_SKILLS_ROOT`（装在别处时不改代码就能指路）
3. **`/app/skills/`**——平台的规范部署位置
4. `workspace-*/skills/`——旧约定，作回落

**规范位置必须排在工作区之前**：工作区下那些多半是 2026-09-01 重写之前的
Node 副本，先看工作区会拿旧的去跑，而新旧两版连命令名都不一样。

报 `CLOUD_CLI_NOT_FOUND` 时**先看错误里列出的「找过这几处」**。
它多半不是「平台没部署」——照那个结论去找平台方要部署是要不到的。

## 云盘有语义检索，默认走它

```bash
# 找特定内容：带 --query，走语义检索
python3 -m byclaw_caps.query search --domain 素材.事件 --query "本体论之争"     --resource-id <id>

# 要全量清单（查重、系列衔接）：不带 --query，按域枚举
python3 -m byclaw_caps.query search --domain 素材.事件 --resource-id <id>

# 两者都能加 --include-body 取正文
python3 -m byclaw_caps.query search --domain 素材.事件 --query "本体论之争"     --include-body --resource-id <id> --session-root <Session Root>
```

**按目的选，不是按习惯选：**

| 目的 | 带不带 `--query` | 为什么 |
|---|---|---|
| 找与某个话题相关的素材 | **带** | 枚举回一堆标题让模型筛，是拿上下文换检索 |
| 查重、系列衔接、看这个域一共有什么 | **不带** | 检索给的是 top-k，不是全量。**拿 top-k 判「没写过」会漏** |

检索**按 `resourceId` 打整个云盘**，靠映射路径拼一个 `filePath` 前缀过滤把它约束回本域。
所以一个域映射的路径不能太多——超过 12 条会报 `UNSUPPORTED_BY_SOURCE` 并说清哪里超了，
**不会少查几条凑合**：少查的结果看起来完全正常。

**检索 0 条就是 0 条，不会自动补一次枚举。** 刚上传的文件约 1 分钟后才能被检索到，
这段窗口里检索确实查不到——那是「还没构建好」，不是「没有」，更不是 `MAPPING_STALE`。

取正文要 `--session-root`：内容先落盘再进上下文，**同一份素材一次创作只下载一次**，
后面的阶段读本地副本。


## 三种意图，三个写法

| 用户说的 | 参数 | 效果 |
| --- | --- | --- |
| 「查一下素材」 | 不写 | `default_mount: true` 的源**全查**，结果合并去重 |
| 「联网查一下」 | `--only-sources 联网检索` | **只**查外网 |
| 「这次只查云盘，别打联网」 | `--only-sources 项目云盘` | **只**查这几个，关掉其余默认挂载 |
| 「默认之外再加一个源」 | `--extra-sources <源名>` | 默认那些**再加**这些 |

### 只要外网结果时用 `--only-sources`

云盘是默认挂载的，`--extra-sources 联网检索` 会把云盘也一起查了。那未必是坏事
（两片素材合并去重），但**你拿到的结果里混着项目自己的东西**。
「参考外部报道」这类场景要的是纯外网，那就 `--only-sources 联网检索`。

**追加仍是默认语义**：「不够想再多查点」的意图是补充不是替换。


**限定要显式说。** 名字刻意不叫 `--sources`——它与 `--extra-sources` 只差一个词而语义
相反，写错会静默少查东西，不报错。

两个一起给会被**拒绝**（退出码 2）。**源名写错立刻报错**，不静默查出 0 条。

## 多源合并按内容去重

同一份东西在两个源里都有时合并成一条，并标 `also_in` 指出还存在于哪些源。
**按内容哈希去重，不按路径**——路径会变，内容不变才是同一份。

枚举阶段没有内容，也就没有哈希，此时**退回按路径去重**。
（以 `None` 作键会把整批枚举结果折叠成一条，而且不报错。）

## 状态码的意义

| 逐源状态 | 含义 | 计不计失败 |
| --- | --- | --- |
| `ok` | 服务了 | 计入结果 |
| `NO_SOURCE_FOR_DOMAIN` | **该源不服务这个域** | **不计失败**——常态 |
| `UNSUPPORTED_BY_SOURCE` | 服务这个域，但不支持这种检索 | 结果不完整 |
| `MAPPING_STALE` | **映射指向的目录已不存在** | 结果不完整 |
| `UNREACHABLE` | 该服务却够不着 | 结果不完整 |

顶层 `status` 三取一：

| 顶层 | 含义 | 退出码 |
| --- | --- | --- |
| `ok` | 该服务的源都服务了 | 0 |
| `PARTIAL` | 有源该服务却没服务，`incomplete` 点名是哪几个 | 1 |
| `NO_SOURCE_FOR_DOMAIN` | **没有任何源服务这个域** | 1 |

### `MAPPING_STALE`：唯一会静默给错结论的地方

云盘对不可达、超时、鉴权失败都抛明确错误码。**唯独目录不存在这一种，
后端多半返回成功加空列表**：

```
映射写着  素材.事件 → /2026年3月/AI专题
用户三月底改名成  /2026Q1/AI专题
list 返回空
助理判定「没有素材」——而素材就在那儿
```

所以取数用**乐观验证**：`list` 目标目录，非空即通过（一次调用）；
**只在空结果时**才多问一次父目录，看目标是否还在。不在就报 `MAPPING_STALE`，
并把父目录下现有的目录列出来供改映射。

碰到它**不要去补素材**，去更新 `/.user_settings` 下的映射，或问用户新位置在哪。

### 「不服务」不是故障

源与知识域是**多对多**。素材可以来自云盘或联网检索；而成品、渠道、写法是用户自己的
东西——联网检索不可能有。

所以「这个源不服务这个域」是常态。把它计为失败的后果很具体：只要挂上联网源，每一次查成品
都会失败，agent 按「退出码 1 是业务失败」的规则会停下，用户为了让流程别停就只能把联网源
摘掉——**被逼回单源**，正是多源架构要避免的局面。

不计失败，但**在逐源报告里照常列出**：也得让人看见联网源根本没参与，
否则「为什么联网了还是这些结果」没人解释得清。

**`UNSUPPORTED_BY_SOURCE` 不会被静默降级成「枚举全部再截断」。** 源不支持某种检索时
它明说，而不是返回前 N 条让你以为那是检索结果。分不清「检索到的前 10 条」和
「随便给的前 10 条」，选题会建立在假相关性上。

## 两个驱动的能力边界

| | `cloud` 项目云盘 | `web` 公开互联网 |
|---|---|---|
| `kinds` | documents、file | documents |
| `recall` | enumerate、semantic | semantic |
| `filters` | 无 | domain/category/language/time_range/safesearch |
| 前置 | `python3` + 云盘 CLI + `--resource-id` + 两份映射 | `sources.yaml` 的 `web_search.provider` |

两个源都能做语义召回，但**查的是两片不相干的东西**：云盘是这个项目自己的素材与成品，
联网是公开互联网。要哪片就点名哪片，不写则默认挂载的都查。

## 账号维度已经进了路径

**没有 `--scope`**。`成品`、`运营` 的账号层在云盘路径里
（`/成品/<channel>/<APP_ID>/…`），映射展开 `${APP_ID}` 时就定死了，
不需要再来一道运行期参数。

`渠道` 拆成两个域：

| 域 | 装什么 |
|---|---|
| `渠道` | 项目公共：渠道规范、受众库、品牌音库 |
| `渠道.账号档案` | 随号走：`<APP_ID>/audience.md` 等 |

**拆开是必须的**，不是整洁问题：混成一条，读错号会按错误的读者画像写，且不报错。
