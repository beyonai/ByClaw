#!/usr/bin/env python3
"""数据查询能力 CLI。

唯一面向三种数据组织方式设计的能力。Skill 只声明知识域，去哪拿由配置路由。
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path

from byclaw_caps._cli import add_common, dispatch, EXIT_BUSINESS, EXIT_OK
from byclaw_caps.query import DOMAINS, QueryError, load_sources, resolve_sources, run_metadata_query, run_query
from byclaw_caps.query.source_config import doctor_sources, init_sources, sources_path


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="byclaw_caps.query", description="数据查询")
    sub = parser.add_subparsers(dest="command", required=True)
    search = sub.add_parser("search", help="按知识域取素材")
    search.add_argument("--config", help="sources.yaml 路径；不传时从 Project Root 确定性解析")
    search.add_argument("--project-root", help="项目根目录；配置默认是 <root>/sources.yaml")
    search.add_argument("--domain", required=True)
    search.add_argument("--resource-id", help=(
        "项目云盘的 cloudResourceId（会话上下文的 cloud_resource_id）。"
        "取不到就报错——不要猜 ID，也不要拿普通知识库的 resourceId 冒充。"))
    search.add_argument("--cloud-cli", help=(
        "项目云盘脚本的绝对路径；不传时按固定模式查找，命中 0 个或多个都报错。"))
    search.add_argument("--user-code", help="工号；不传时读环境变量 USER_CODE。决定读哪份个人映射。")
    search.add_argument("--app-id", help="公众号 APP_ID；不传时读环境变量 WECHAT_APPID。展开 ${APP_ID}。")
    search.add_argument("--query")
    search.add_argument("--operation", choices=("search", "fetch"), default="search")
    search.add_argument("--url", dest="urls", action="append", default=[])
    search.add_argument("--category", default="general")
    search.add_argument("--language", default="zh-CN")
    search.add_argument("--time-range", choices=("day", "week", "month", "year"))
    search.add_argument("--safesearch", type=int, choices=(0, 1, 2), default=1)
    search.add_argument("--limit", type=int, default=10)
    search.add_argument("--include-body", action="store_true")
    search.add_argument(
        "--manifest-only", action="store_true",
        help=(
            "只对 --operation fetch 有效：**全部落盘，但不把正文回给你**，"
            "只回一份清单（云盘路径 / 本地路径 / 字节数 / sha256）。"
            "批量取几十上百篇时用它——一次调用取完，要看哪几篇再本地读；"
            "不加的话正文会全部进上下文。"
        ),
    )
    search.add_argument(
        "--where-json", default="",
        help=(
            "把语义检索收窄到域内的某个子目录（JSON，Agent DSL）。"
            "与知识域的根路径**自动 and 起来**，收窄不放宽。"
            "按目录收窄用 filePath 前缀："
            "'{\"prefix\":{\"fieldName\":\"filePath\",\"value\":\"/素材/公共/产品\"}}'。"
            "不传时在整个域内检索。"
        ),
    )
    search.add_argument("--session-root", help="联网原文的落盘根；include-body/fetch 时必填")
    search.add_argument("--extra-sources", nargs="*", default=[],
                        help="默认挂载之外**追加**：本地不够时再多查一个库")
    search.add_argument(
        "--only-sources", nargs="*", default=[],
        help="**只**查这几个源，关掉其余默认挂载：这次只查本地、别打联网。"
             "刻意不叫 --sources——与 --extra-sources 只差一个词而语义相反，"
             "写错会静默少查东西",
    )
    search.add_argument("--per-source-limit", type=int)
    domains = sub.add_parser("domains", help="列出受控知识域词表")
    init = sub.add_parser("init", help="在 Project Root 生成 sources.yaml 2.0 模板")
    init.add_argument("--project-root", required=True)
    init.add_argument("--force", action="store_true")
    validate = sub.add_parser("validate", help="校验并解析 sources.yaml")
    validate.add_argument("--config")
    validate.add_argument("--project-root")
    doctor = sub.add_parser("doctor", help="显示知识域最终解析到的源，不发外部请求")
    doctor.add_argument("--config")
    doctor.add_argument("--project-root")
    meta_search = sub.add_parser(
        "metadata-search",
        help="按结构化条件枚举云盘文件（无语义检索，有 total 和分页）",
    )
    meta_search.add_argument("--config", help="sources.yaml 路径")
    meta_search.add_argument("--project-root")
    meta_search.add_argument("--domain", required=True)
    meta_search.add_argument("--resource-id", help=(
        "项目云盘的 cloudResourceId。取不到就报错，不要猜 ID。"))
    meta_search.add_argument("--cloud-cli", help=(
        "项目云盘脚本的绝对路径；不传时按固定模式查找。"))
    meta_search.add_argument("--user-code")
    meta_search.add_argument("--app-id")
    meta_search.add_argument(
        "--where-json", default="",
        help=(
            "Agent DSL 过滤条件（JSON 字符串）；不传时匹配域内全部文件。"
            "路径过滤（filePath）由 --domain 自动注入，不要重复写。"
        ),
    )
    meta_search.add_argument(
        "--metadata-field", dest="metadata_fields", action="append", default=[],
        help="要返回的元数据字段名；可重复传入。系统字段（fileName/fileType/updatedAt 等）无需注册。",
    )
    meta_search.add_argument("--page-num", type=int, default=1)
    meta_search.add_argument("--page-size", type=int, default=20)
    for one in (search, meta_search, domains, init, validate, doctor):
        add_common(one)
    return parser


def handle(args: argparse.Namespace):
    if args.command == "domains":
        return {"ok": True, "domains": sorted(DOMAINS)}, 0
    if args.command == "init":
        target = init_sources(args.project_root, force=args.force)
        return {"ok": True, "path": str(target), "schema_version": "2.0"}, EXIT_OK
    config_path = sources_path(
        config=getattr(args, "config", None), project_root=getattr(args, "project_root", None))
    config = load_sources(config_path)
    if args.command == "validate":
        return {"ok": True, "path": config["path"],
                "schema_version": config["schema_version"],
                "sources": [source["id"] for source in config["sources"]]}, EXIT_OK
    if args.command == "doctor":
        result = doctor_sources(config)
        return result, EXIT_OK if result["ok"] else EXIT_BUSINESS
    if args.command == "metadata-search":
        import json as _json

        picked = [dict(s) for s in resolve_sources(config, request={"domain": args.domain})]
        _prepare_cloud(picked, args)
        where: dict = {}
        if args.where_json.strip():
            try:
                where = _json.loads(args.where_json)
            except ValueError as exc:
                raise QueryError(f"--where-json 不是合法 JSON：{exc}") from exc
        result = run_metadata_query(
            {
                "domain": args.domain,
                "resource_id": args.resource_id or "",
                "where": where,
                "metadata_fields": args.metadata_fields,
                "page_num": args.page_num,
                "page_size": args.page_size,
            },
            sources=picked,
        )
        return result, EXIT_OK if result["ok"] else EXIT_BUSINESS
    if args.only_sources and args.extra_sources:
        # 两者语义相反，同时给必有一个被忽略；静默忽略会让人以为都生效了。
        raise QueryError(
            "--only-sources 与 --extra-sources 不能同时使用：前者限定、后者追加。"
            "要在默认之外多查一个源用 --extra-sources；要只查某几个源用 --only-sources。"
        )
    request = {
        "domain": args.domain,
        "operation": args.operation,
        "limit": args.limit,
        "include_body": args.include_body,
        "manifest_only": args.manifest_only,
        "extra_sources": args.extra_sources,
        "urls": args.urls,
        "session_root": args.session_root,
        "filters": {
            "category": args.category,
            "language": args.language,
            "time_range": args.time_range,
            "safesearch": args.safesearch,
        },
    }
    if args.only_sources:
        request["sources"] = args.only_sources
    if args.query:
        request["query"] = args.query
    if getattr(args, "where_json", "").strip():
        import json as _json
        try:
            request["where"] = _json.loads(args.where_json)
        except ValueError as exc:
            raise QueryError(f"--where-json 不是合法 JSON：{exc}") from exc
    if args.per_source_limit is not None:
        request["per_source_limit"] = args.per_source_limit
    picked = [dict(source) for source in resolve_sources(config, request=request)]
    request["resource_id"] = args.resource_id or ""
    _prepare_cloud(picked, args)
    result = run_query(request, sources=picked)
    return result, EXIT_OK if result["ok"] else EXIT_BUSINESS


def _prepare_cloud(sources: list[dict], args: argparse.Namespace) -> None:
    """给云盘源补上脚本路径与解析好的映射。

    **映射在这里解析一次，不在驱动里逐次解析**：一次 search 可能查多条路径，
    每条都重读一遍映射就是每条都多两次 download。
    """
    from byclaw_caps.cloud import locate_cli
    from byclaw_caps.query.cloud import make_reader
    from byclaw_caps.query.mapping import MappingError, load_mapping

    targets = [s for s in sources if s.get("backend") == "cloud"]
    if not targets:
        return

    cli = locate_cli(args.cloud_cli)
    # **不传会话缓存。** 映射是配置，读它要落进会话的素材缓存里既脏账
    # （`.runtime/retrieval` 是「读了哪些素材」的账）又会把映射缓存一整个会话——
    # 人照提示改好映射后同一会话重试，读到的还是旧的。
    reader = make_reader(cli=cli, resource_id=args.resource_id or "")
    mapping = load_mapping(
        reader=reader,
        user_code=args.user_code or os.environ.get("USER_CODE", ""),
        app_id=args.app_id or os.environ.get("WECHAT_APPID", ""),
    )
    for source in targets:
        source["cloud_cli"] = str(cli)
        # 映射覆盖 sources.yaml 里可能残留的 map。**落点只有一个来源**——
        # 两处都能配的话，改了一处不生效是最难查的一类问题。
        source["map"] = mapping


def main() -> int:
    """控制台入口点。

    `python -m byclaw_caps.<能力>` 与安装后的 `byclaw-<能力>` 走同一条路——
    两条路行为分叉的话，文档里写的那条迟早是错的。
    """
    from byclaw_caps.cloud import CloudError
    from byclaw_caps.query.mapping import MappingError

    # 三者都是「环境不具备」，退 2 而不是退 1：调用方该去修部署或补映射，
    # 不是去改检索词。业务失败与环境失败混成一个码，agent 会反复换问法重试。
    return dispatch(build(), handle, usage_errors=(QueryError, CloudError, MappingError))


if __name__ == "__main__":
    raise SystemExit(main())
