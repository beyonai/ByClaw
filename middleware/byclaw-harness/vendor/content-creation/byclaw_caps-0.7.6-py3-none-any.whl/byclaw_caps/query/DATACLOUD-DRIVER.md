# DataCloud 驱动的对象映射与调用约束

本文是**驱动的实现细节**，不属于业务 Skill。原先它写在
`discover-writing-topics/references/knowledge-sources.md` 里，导致两个问题：数据位置一变
就得改 Skill 重发包；而其中的平台配额规则在本地文件夹方案下**根本不存在**，却让本地用户
也背着那套枷锁。

**驱动已实现**（`datacloud.py` + `_datacloud_transport.py`）。本文是它的对象映射与调用
约束来源，改这里要同步改 `DOMAIN_OBJECTS`——`tests/test_query_datacloud.py` 会核对。

**传输没有照搬旧实现的可直连形态，因为不存在。** 旧 `client.py` 完全建在 `by_framework`
上：服务发现拿实例、Beyond-Token 从 Redis 读，**没有 URL 可直连**。故传输独立成
`_datacloud_transport.py`，驱动侧改为注入——缺平台运行时时报 `UNREACHABLE` 并指明缺的是
运行时，不是网络、不是没数据。这三者在旧代码里会混成同一个异常。

副产品：这套查询逻辑第一次可测。旧的 921 行 `query_objects.py` 要跑起来得先有 Redis 和
平台包，至今零测试。

## 知识域 → 对象编码

业务侧只写 `domain`，映射在此。

| 知识域 | 对象编码 |
|---|---|
| `素材.产品` | Product, Ability, Concept, Example, Feature, Methodology, Operation, ProductMap, TechArchitecture, TechComponent, TechSpec, Validation, Vendor |
| `素材.事件` | Event |
| `素材.会议纪要` | MeetingMinutes |
| `写法.模板` | WritingTemplate |
| `写法.资产` | WritingAsset |
| `写法.参考` | ReferenceArticle, ArticleAnalysis |
| `成品` | Collection, WritingOutput |
| `运营` | WritingReview |
| `渠道` | Channel, AudiencePersona, BrandVoice |

`ChannelStyleGuide`、`Document`、`NewsItem` 不再映射——内容是平台规则而非用户数据，
或 0 实例且属性被 `Event` 覆盖。

## 调用约束

以下全部是**平台侧的性能与配额规则**，只对本驱动成立：

- 单次命令最多 2 个对象请求；完成一批立即保存结果，再按缺口决定下一批。
- 含 `query`／`queries` 的批次**只能有 1 个请求**。
- 一次最多 3 个查询词，每项 ≤40 字符、合计 ≤80 字符；用主题词与上位概念召回，
  不写完整候选论点。同一对象的多个召回词用一次 `queries` 数组表达，不拆成重复命令。
- `term`、`connection` 请求必须单独执行；两个已取得 `kb_resource_id + kb_file_path` 的
  `body` 请求可以组成一批。
- 有可靠字段条件时优先 `where`。不要假设无条件枚举能覆盖语义索引中的实例。
- 语义检索超时时保留已取得的结构化结果，并标记该请求未解决。

## 取正文

先查身份与摘要，再对进入论证的对象用结果中的 `kb_resource_id + kb_file_path` 发起
`kind=body` 下载。**对象结果已给出这两个字段后，不得再次按标题语义查询同一对象。**

词面查重只在标题或上下文不完整时，对最相近的 1–3 篇补取正文；下载失败则保留元数据并把
语义查重标记为 provisional。

## 典型批次顺序

选题发现通常三轮：历史作品 → 含原文的运营复盘 → 候选同梯队正文补取。

- 第一批：单独语义查 `成品`，用当前主题及其上位概念召回并查重。历史库少于 20 篇时
  `limit=20`，未知规模时至少 `limit=10`。
- 第二批：单独语义查 `运营`，`limit=1`、`include_body=true`，直接读最相关复盘的完整原文。
  不要请求正文章节对应的虚构属性，也不要对同一来源再发 `kind=body`。
- 后续：复盘已覆盖目标读者、内容角色、渠道表达三类中的至少两类且渠道已明确时，记
  `channel_audience_resolution=sufficient_from_review` 并停止；否则只查缺失的渠道信息。
- 按需批次：从 `素材.产品`、`成品`、`素材.会议纪要`、`素材.事件` 中挑真正影响判断的至多 2 类。
  用户附件已能提供事件事实时，不重复查询同一事实。

低词面相似度时先完成候选级语义选文，再按计划最多下载 2 篇并增量重跑。不因「摘要字段不存在」
增加一次正文下载。

## 落地

本驱动取回的一切内容都是**外部内容**，必须落地会话的 `.runtime/retrieval/`——原句门禁要在
本地文件中逐字定位引文，不落地就过不了那道门。
