"""两级映射：知识域 → 云盘路径。

云盘目录由人自由组织，**写死路径必错**；域名仍然是 Skill 唯一要写的地址，
落点由映射文件给。这与旧 `sources.yaml` 是同一件事，只是落点从本地目录换成云盘目录。

    /.user_settings/_project.yaml        团队公共，作基底
    /.user_settings/<USER_CODE>.yaml     个人，按域整条覆盖

分两级的理由与旧配置一样（`query/__init__.py`：用户级作基底，项目级覆盖）：
`写法`、`渠道` 这些值全团队同一个，全放个人文件就是同一个值存 N 份，
团队挪一次目录只有说过话的那个人会更新。

**读不到就报错，不回落到遍历。** 回落看起来能跑：`list` 单层不递归，
从 `/` 逐层摸既慢又不准，而摸不到的结果与「查过了，确实没有」长得一模一样——
后者不是故障，没有人会去查。
"""

from __future__ import annotations

import re
from typing import Any, Callable, Mapping

from byclaw_caps.query import DOMAINS, STATUS_UNREACHABLE

#: 缺映射时给用户的**下一步动作**。
#:
#: 原文是「请让平台补齐」——那是个死胡同：用户不知道找谁、说什么，助理也帮不上。
#: 而写作支持助理能直接补（`setup_environment.py --project-id X --init-mapping`），
#: 所以要把人指到那条路上。
#:
#: **给的是一句「用户发给组长的话」，不是「你去叫谁」**——助理之间不互相调用，
#: 写成后者会诱导它去调别人，而那条路不通。
INIT_HINT = (
    "**下一步**：把这句话发给「全媒体创作官」——「初始化云盘映射」。"
    "它会让写作支持助理生成这两份文件（模板，生成后你随时可以改）。"
)

#: 固定路径。云盘上没有「配置放哪」这个问题——约定死，才不需要先找配置再读配置。
MAPPING_DIR = "/.user_settings"
PROJECT_MAPPING = "_project.yaml"

#: `(cloud_path) -> text`，读不到抛 `FileNotFoundError`。驱动注入。
Reader = Callable[[str], str]

_PLACEHOLDER = re.compile(r"\$\{(\w+)\}")


class MappingError(RuntimeError):
    """映射读不到、拼错，或占位符没有值。

    **一律按「够不着」上报，不按「没数据」。** 报成没数据的话，调用方会去补素材，
    补完还是查不到——真正要做的是让平台把映射生成出来。
    """

    def __init__(self, message: str, *, code: str = "MAPPING_MISSING") -> None:
        super().__init__(message)
        self.code = code

    @property
    def status(self) -> str:
        return STATUS_UNREACHABLE


def parse_mapping(text: str, *, label: str) -> dict[str, list[str]]:
    """一份映射文件。键必须是受控知识域，值是路径列表。"""
    import yaml

    try:
        data = yaml.safe_load(text) or {}
    except yaml.YAMLError as exc:
        raise MappingError(f"{label} 不是合法 YAML：{exc}", code="MAPPING_INVALID") from exc
    if not isinstance(data, Mapping):
        raise MappingError(f"{label} 的顶层应是「知识域: 路径列表」的映射表。",
                           code="MAPPING_INVALID")

    result: dict[str, list[str]] = {}
    for key, value in data.items():
        domain = str(key).strip()
        if domain not in DOMAINS:
            # 不做模糊匹配：把 `素材` 当成 `素材.产品` 会静默查错地方，
            # 而查错地方的结果看起来完全正常。
            raise MappingError(
                f"{label} 里的 {domain!r} 不是受控知识域。"
                f"可用：{'、'.join(sorted(DOMAINS))}。",
                code="MAPPING_INVALID",
            )
        if isinstance(value, str):
            paths = [value]
        elif isinstance(value, (list, tuple)):
            paths = [str(v) for v in value]
        else:
            raise MappingError(
                f"{label} 的 {domain} 应是路径或路径列表，收到 {type(value).__name__}。",
                code="MAPPING_INVALID",
            )
        result[domain] = [p.strip() for p in paths if str(p).strip()]
    return result


def merge_mapping(project: Mapping[str, list[str]],
                  personal: Mapping[str, list[str]]) -> dict[str, list[str]]:
    """公共作基底，个人**按域整条覆盖**。

    整条覆盖而不是逐项合并——逐项合并的话「个人想去掉公共那条」就做不到，
    而那正是个人映射存在的一半理由（公共给的目录里混着自己不看的东西）。
    """
    merged = {domain: list(paths) for domain, paths in project.items()}
    merged.update({domain: list(paths) for domain, paths in personal.items()})
    return merged


def expand(mapping: Mapping[str, list[str]], *, user_code: str, app_id: str
           ) -> dict[str, list[str]]:
    """展开 `${USER_CODE}` 与 `${APP_ID}`。

    **缺值就报错，不留原样。** 留着的话会去 `list` 一个字面叫 `${APP_ID}` 的目录，
    云盘返回空列表且 `code=0`——与「这个号还没发过东西」无法区分。

    只对**实际用到**该占位符的域报错：只查 `素材` 时手上没有 APP_ID 是正常的。
    """
    values = {"USER_CODE": str(user_code or "").strip(), "APP_ID": str(app_id or "").strip()}

    def _one(path: str, domain: str) -> str:
        def sub(match: "re.Match[str]") -> str:
            name = match.group(1)
            value = values.get(name, "")
            if not value:
                raise MappingError(
                    f"知识域 {domain} 的路径 {path} 用到 ${{{name}}}，但当前没有它的值。"
                    "留着占位符会去查一个字面同名的目录，返回空且不报错。",
                    code="MAPPING_INVALID",
                )
            return value
        return _PLACEHOLDER.sub(sub, path)

    return {domain: [_one(p, domain) for p in paths] for domain, paths in mapping.items()}


def load_mapping(*, reader: Reader, user_code: str, app_id: str) -> dict[str, list[str]]:
    """读两份、合并、展开。

    两份**都必须在**。个人那份由平台在用户登录前按规则生成，缺了说明初始化没跑，
    **不是「这个人没有个性化配置」**——静默用公共的顶上，个人素材会整个消失，
    而助理只会看到「素材比想象中少」。
    """
    code = str(user_code or "").strip()
    if not code:
        raise MappingError(
            "缺少 USER_CODE，无法确定读哪份个人映射。它由平台注入（见 prereqs 的 platform 段），"
            "**没有它是部署问题，不是映射问题**——补映射也解决不了。",
            code="MAPPING_MISSING",
        )

    project = _read_one(reader, PROJECT_MAPPING)
    personal = _read_one(reader, code + ".yaml")
    return expand(merge_mapping(project, personal), user_code=code, app_id=app_id)


def _read_one(reader: Reader, name: str) -> dict[str, list[str]]:
    path = MAPPING_DIR + "/" + name
    try:
        text = reader(path)
    except FileNotFoundError as exc:
        # **先摆事实，再给结论。** 上一版直接断言「映射还没初始化」，而底下
        # 九种 CloudError（CLI 找不到 / 命中多份 / resource_id 缺 / 后端超时 /
        # 返回体解析失败 …）全被压成这一句，原始 code 只留在 __cause__ 里不打印。
        # 实测后果：文件明明在云盘上，报错却说没初始化，还附一句「去让写作支持
        # 助理初始化」——用户与两个 agent 一起被带偏了三轮，真因是 resource_id
        # 用了本体库的号。**可能原因按概率排序给，不要只给一个。**
        raise MappingError(
            f"读不到映射：{exc}\n\n"
            "映射决定知识域落到哪个云盘目录，缺了取不了材。**按概率依次排查**：\n"
            "1. **resource_id 用错了库**（最常见）——项目云盘的 ID 用 "
            "`project-context basic --project-id <id>` 取 `cloudResourceId`，"
            "**不要猜，也不要拿本体库/其它知识库的 ID 顶替**；\n"
            "2. 上面那行方括号里的 code 指向部署问题（CLI 找不到、后端超时…）——"
            "那是环境不具备，**不是内容问题，不要改内容迁就它**；\n"
            f"3. 确属未初始化——资源号没错、路径 {path} 也确实空着。\n\n"
            "**不要手工遍历云盘代替它**——`list` 单层不递归，摸出来的结果与"
            "「查过了，确实没有」长得一模一样。\n"
            "**只有第 3 种**才需要：" + INIT_HINT,
            code="MAPPING_MISSING",
        ) from exc
    return parse_mapping(text, label=path)


__all__ = [
    "INIT_HINT",
    "MAPPING_DIR",
    "PROJECT_MAPPING",
    "MappingError",
    "parse_mapping",
    "merge_mapping",
    "expand",
    "load_mapping",
]
