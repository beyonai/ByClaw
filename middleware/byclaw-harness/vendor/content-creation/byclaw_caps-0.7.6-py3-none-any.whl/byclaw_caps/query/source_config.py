"""``sources.yaml`` 1.x/2.0 兼容解析与项目确定性寻址。"""

from __future__ import annotations

import os
import re
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

import yaml


#: 没有 `sources.yaml` 时用的默认源。
#:
#: **这个文件现在只剩一件事**：哪个知识域允许联网。那件事有合理默认值，
#: 所以它是可选的覆盖，不是必需的前置——项目空间 `/by/projects/{projectId}`
#: 已作废，要求那儿有个文件等于要求一个废掉的目录还在。
#:
#: 实测撞过：平台上那份是迁移前的老文件，声明 `backend: local`，
#: 而本地驱动已经删了，取数直接报「后端 local 未注册」。
#:
#: 云盘**默认挂载**（素材都在那儿），联网**默认不挂**——联网要花钱要轮次，
#: 默认挂上等于每次查素材都顺便打一次外网。
DEFAULT_SOURCES: dict[str, Any] = {
    "schema_version": "2.0",
    "sources": [
        {"id": "项目云盘", "backend": "cloud", "default_mount": True},
        # 只服务素材类域：`成品`／`运营`／`渠道`／`写法` 是项目自己的东西，
        # 外面不可能有，查那些域会得 NO_SOURCE_FOR_DOMAIN 而不拖累整体成败。
        {"id": "联网检索", "backend": "web", "default_mount": False,
         "integration": {
             "provider": "tencent_wsa",
             "secret_id_env": "TENCENTCLOUD_SECRET_ID",
             "secret_key_env": "TENCENTCLOUD_SECRET_KEY",
         },
         "domains": ["素材", "素材.产品", "素材.事件", "素材.会议纪要"]},
    ],
    "path": "(内置默认)",
}


def sources_path(*, config: str | Path | None = None,
                 project_root: str | Path | None = None,
                 env: Mapping[str, str] | None = None):
    """显式配置优先，其次 Project Root；都没有返回 `None`（用内置默认）。

    **不按 CWD 猜测**——猜出来的配置指向哪儿谁也说不清。
    """
    from byclaw_caps.query import QueryError

    if config:
        return Path(config).expanduser().resolve()
    environment = os.environ if env is None else env
    root = project_root or environment.get("BAIYING_PROJECT_ROOT")
    if not root:
        # 没有就是没有，用内置默认。**不再抛错**：这个文件已经是可选的覆盖。
        return None
    return (Path(root).expanduser().resolve() / "sources.yaml")


def _relative_path(value: Any, *, field: str) -> str:
    from byclaw_caps.query import QueryError

    text = str(value or "").strip().replace("\\", "/")
    path = PurePosixPath(text)
    if (not text or path.is_absolute() or text.startswith("/")
            or re.match(r"^[A-Za-z]:/", text) or ".." in path.parts):
        raise QueryError(f"{field} 必须是 Project Root 内的相对路径，不能是绝对路径或包含 ..")
    return path.as_posix()


def _list(value: Any, *, field: str) -> list[Any]:
    from byclaw_caps.query import QueryError

    if value in (None, ""):
        return []
    if not isinstance(value, list):
        raise QueryError(f"{field} 必须是列表")
    return value


def _normalize_v2(data: Mapping[str, Any], *, target: Path,
                  valid_domains: set[str] | frozenset[str]) -> dict[str, Any]:
    from byclaw_caps.credentials import reject_plaintext_secrets
    from byclaw_caps.query import QueryError

    domains = data.get("domains")
    if not isinstance(domains, Mapping) or not domains:
        raise QueryError(f"sources.yaml 2.0 缺少 domains：{target}")

    object_map: dict[str, list[str]] = {}
    knowledge_base_map: dict[str, list[str]] = {}
    web_domains: list[str] = []
    for raw_domain, raw_spec in domains.items():
        domain = str(raw_domain).strip()
        if domain not in valid_domains:
            raise QueryError(f"未知知识域 {domain!r}。可用：{'、'.join(sorted(valid_domains))}。")
        if not isinstance(raw_spec, Mapping):
            raise QueryError(f"domains.{domain} 必须是对象")
        if raw_spec.get("files"):
            # **不静默忽略。** 忽略的话，配置里明明写着 `files.paths: [素材/产品]`，
            # 取数却去了完全不同的地方——改了配置不生效是最难查的一类问题。
            raise QueryError(
                f"domains.{domain}.files 已废除：素材落点改由云盘映射决定"
                "（/.user_settings/_project.yaml 与 <工号>.yaml）。"
                "请把路径搬到映射文件，并从 sources.yaml 删掉 files 段。")
        knowledge = raw_spec.get("knowledge_bases") or {}
        ontology = raw_spec.get("ontology_objects") or {}
        web = raw_spec.get("web_search") or {}
        if not all(isinstance(value, Mapping) for value in (knowledge, ontology, web)):
            raise QueryError(
                f"domains.{domain} 的 knowledge_bases/ontology_objects/web_search 必须是对象")

        ids = [str(item).strip() for item in _list(
            knowledge.get("ids"), field=f"domains.{domain}.knowledge_bases.ids")
               if str(item).strip()]
        if ids:
            knowledge_base_map[domain] = ids
        codes = [str(item).strip() for item in _list(
            ontology.get("codes"), field=f"domains.{domain}.ontology_objects.codes")
                 if str(item).strip()]
        if codes:
            object_map[domain] = codes
        enabled = web.get("enabled", False)
        if not isinstance(enabled, bool):
            raise QueryError(f"domains.{domain}.web_search.enabled 必须是布尔值")
        mode = str(web.get("mode") or ("on_demand" if enabled else "disabled"))
        if mode not in {"disabled", "on_demand"}:
            raise QueryError(f"domains.{domain}.web_search.mode 只允许 disabled|on_demand")
        if enabled and mode != "disabled":
            web_domains.append(domain)

    # 项目云盘**恒挂载**，且不带 map：落点在 /.user_settings 的两份映射里，
    # 运行时解析后注入。这里再放一份就是两个地方都能配同一件事。
    sources: list[dict[str, Any]] = [
        {"id": "项目云盘", "backend": "cloud", "default_mount": True},
    ]
    if object_map or knowledge_base_map:
        sources.append({
            "id": "DataCloud", "backend": "datacloud", "default_mount": True,
            "base_id": str(data.get("base_id") or "BYCLAW_DATACLOUD"),
            "object_map": object_map,
            "knowledge_base_map": knowledge_base_map,
        })
    if web_domains:
        # 联网选项从 `integrations.yaml` 搬到这里——那个文件随两个 API KEY 一起废除，
        # 而 provider、超时、密钥变量名这几样仍然要有地方放。
        # **仍然过一遍明文密钥门禁**：换了个文件不等于换了规矩。
        options = dict(data.get("web_search") or {})
        reject_plaintext_secrets(options, path="web_search")
        options.setdefault("provider", "tencent_wsa")
        options.setdefault("secret_id_env", "TENCENTCLOUD_SECRET_ID")
        options.setdefault("secret_key_env", "TENCENTCLOUD_SECRET_KEY")
        sources.append({"id": "联网检索", "backend": "web", "default_mount": True,
                        "domains": web_domains, "integration": options})
    return {"schema_version": "2.0", "sources": sources, "path": str(target.resolve())}


def normalize_sources(data: Mapping[str, Any], *, target: Path,
                      valid_domains: set[str] | frozenset[str]) -> dict[str, Any]:
    """把 2.0 映射转换成现有 Driver 可消费的统一 source 列表。"""
    from byclaw_caps.query import QueryError

    if str(data.get("schema_version") or "").startswith("2") or "domains" in data:
        return _normalize_v2(data, target=target, valid_domains=valid_domains)
    raw_sources = data.get("sources")
    if not isinstance(raw_sources, list) or not raw_sources:
        raise QueryError(f"源配置缺少 sources 或 domains：{target}")
    base = target.resolve().parent
    resolved: list[dict[str, Any]] = []
    for index, raw_source in enumerate(raw_sources):
        if not isinstance(raw_source, Mapping):
            raise QueryError(f"sources[{index}] 必须是对象")
        item = dict(raw_source)
        if not str(item.get("id") or "").strip() or not str(item.get("backend") or "").strip():
            raise QueryError(f"sources[{index}] 缺少 id 或 backend")
        if str(item.get("backend")) == "local":
            # 只报「后端 local 未注册」不够——那听着像少装了什么。
            # 真相是这份配置是迁移前的，而项目空间整个作废了。
            raise QueryError(
                f"{target} 是**迁移前的旧配置**：`sources[{index}]` 声明 backend "
                "`local`，而本地驱动随项目空间一起废除了，素材现在都在项目云盘上。"
                "删掉这个文件即可——不配它就用内置默认（云盘默认挂载、"
                "联网按需追加）；只有要改哪个域允许联网时才需要它。")
        raw_root = item.get("root")
        if raw_root and not Path(str(raw_root)).is_absolute():
            item["root"] = str(base / str(raw_root))
        resolved.append(item)
    return {"schema_version": str(data.get("schema_version") or "1.0"),
            "sources": resolved, "path": str(target.resolve())}


def load_sources_file(path: str | Path, *, valid_domains: set[str] | frozenset[str]
                      ) -> dict[str, Any]:
    from byclaw_caps.query import QueryError

    if path is None:
        return dict(DEFAULT_SOURCES)
    target = Path(path)
    if not target.is_file():
        # 项目空间作废之后，那儿多半就是没有这个文件。用默认，别拦着取数。
        return dict(DEFAULT_SOURCES)
    data = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
    if not isinstance(data, Mapping):
        raise QueryError(f"源配置必须是对象：{target}")
    return normalize_sources(data, target=target, valid_domains=valid_domains)


def init_sources(project_root: str | Path, *, force: bool = False) -> Path:
    """在项目根生成可修改的 2.0 模板；已有文件默认不覆盖。"""
    from byclaw_caps.query import QueryError

    root = Path(project_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    target = root / "sources.yaml"
    if target.exists() and not force:
        raise QueryError(f"sources.yaml 已存在：{target}；如需覆盖请显式传 --force")
    template = {
        "schema_version": "2.0",
        # provider 选项：tencent_wsa（默认）/ searxng / tavily
        # tencent_wsa 需配 TENCENTCLOUD_SECRET_ID + TENCENTCLOUD_SECRET_KEY 两个环境变量
        "web_search": {
            "provider": "tencent_wsa",
            "secret_id_env": "TENCENTCLOUD_SECRET_ID",
            "secret_key_env": "TENCENTCLOUD_SECRET_KEY",
        },
        "domains": {
            "素材.产品": {"web_search": {"enabled": False, "mode": "disabled"}},
        },
    }
    guidance = (
        "# 项目管理员维护本文件；Skill 和用户对话都不填写物理目录或 API 地址。\n"
        "# **这里不再配素材落点。** 云盘上的落点在 /.user_settings/_project.yaml 与\n"
        "# /.user_settings/<工号>.yaml 两份映射里，由平台生成、用户可改。\n"
        "# 需要更多知识域时复制本块；完整受控词表用 `byclaw-query domains` 查看。\n"
        "# 本文件现在只表达一件事：哪个知识域允许联网。\n"
    )
    target.write_text(guidance + yaml.safe_dump(template, allow_unicode=True),
                      encoding="utf-8")
    return target


def doctor_sources(config: Mapping[str, Any]) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for source in config.get("sources") or []:
        row: dict[str, Any] = {
            "id": source.get("id"), "backend": source.get("backend"),
            "default_mount": bool(source.get("default_mount")),
        }
        if source.get("backend") == "cloud":
            # **不在 doctor 里打云盘。** 这个子命令的约定是「不发外部请求」，
            # 而云盘可达性、映射是否过期都要发请求才知道——那是 search 与
            # prereqs 的事。这里只说清落点从哪来。
            row.update({"reachable": None,
                        "mapping": "/.user_settings/_project.yaml + <工号>.yaml"})
        elif source.get("backend") == "datacloud":
            row.update({"reachable": None,
                        "ontology_domains": sorted((source.get("object_map") or {}).keys()),
                        "knowledge_base_domains": sorted(
                            (source.get("knowledge_base_map") or {}).keys())})
        elif source.get("backend") == "web":
            row.update({"reachable": None, "domains": sorted(source.get("domains") or [])})
        rows.append(row)
    reachable = all(row.get("reachable") is not False for row in rows)
    return {"ok": reachable, "schema_version": config.get("schema_version"), "sources": rows}


__all__ = [
    "sources_path", "normalize_sources", "load_sources_file", "init_sources",
    "doctor_sources",
]
