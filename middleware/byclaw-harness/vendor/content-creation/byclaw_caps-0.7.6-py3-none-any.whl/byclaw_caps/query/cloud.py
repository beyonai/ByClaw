"""项目云盘驱动。

云盘 CLI **没有检索接口**：只有单层不递归的 `list` 和按完整路径的 `download`。
所以这个驱动与旧的本地驱动同形——按域枚举拿标题，选中的再取正文，
`include_body` 单独控制。带 `--query` 一律拒绝：把「列目录再字面匹配」伪装成
语义召回，会给出看似有结果实则漏检的答案，比报错更糟。

**乐观验证**是这里唯一防静默错误的机制。云盘 CLI 对不可达、超时、鉴权失败都抛
明确错误码，唯独「目录不存在」多半是 `code=0` 加空列表——`items: []` 原样返回，
不报错，而助理据此判定「没有素材」。所以：非空即通过（一次调用），
**只在空结果时**才多问一次父目录，用来把「映射过期」与「真的是空的」分开。
"""

from __future__ import annotations

import hashlib
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping

from byclaw_caps.query import (
    KIND_DOCUMENTS,
    KIND_FILE,
    STATUS_NO_SOURCE,
    STATUS_OK,
    STATUS_UNREACHABLE,
    STATUS_UNSUPPORTED,
    UNINFORMATIVE_STEMS,
    resolve_title,
)
from byclaw_caps.cloud import (
    CloudError, normalise_list, normalise_metadata_search,
    normalise_search, normalise_search_files, run as run_cloud,
)

#: 映射写的位置已经不在了。**与「查过了，确实没有」必须分开**——
#: 前者去改映射（或问用户新位置），后者去补素材。混成一种，用户会去补素材，
#: 补完还是查不到，因为查的根本不是那个目录。
STATUS_MAPPING_STALE = "MAPPING_STALE"

#: 取回的正文落在会话根下这里，同一次创作复用。
RETRIEVAL_CACHE = ".runtime/retrieval"

#: 往下走几层。成品埋在 `<合集>/<作品名>/正文.md`，映射指到 `<APP_ID>` 时隔着两层。
#: 留一层余量；**到顶要报出来，不静默截断**——悄悄停在某一层，
#: 结果看起来只是「东西比想象中少」。
MAX_WALK_DEPTH = 3

#: 一次取数最多 list 多少目录。宽树上不设上限会打出几十次往返。
MAX_WALK_CALLS = 40

#: Agent DSL 的叶子条件上限（`references/agent-dsl.md`）。一个域的映射路径
#: 超过这个数就拼不出过滤条件——**要报出来，不要静默少查几个目录**：
#: 少查的结果看起来完全正常。
MAX_WHERE_LEAVES = 12

#: `(argv, cli=..., resource_id=...) -> dict`，测试可注入。
Invoke = Callable[..., "dict[str, Any]"]

class CloudDriver:
    backend = "cloud"
    CAPABILITIES: dict[str, Any] = {
        "kinds": frozenset({KIND_DOCUMENTS, KIND_FILE}),
        "filters": frozenset(),
        "recall": frozenset({"enumerate", "semantic"}),
        "write": "upload",
    }

    @staticmethod
    def _roots(source: Mapping[str, Any], domain: str) -> list[str] | None:
        mapping = source.get("map") or {}
        if domain not in mapping:
            return None
        value = mapping[domain]
        return list(value) if isinstance(value, (list, tuple)) else [value]

    @classmethod
    def query(cls, source: Mapping[str, Any], request: Mapping[str, Any], *,
              invoke: Invoke | None = None
              ) -> tuple[str, list[dict[str, Any]], dict[str, Any]]:
        domain = request["domain"]
        roots = cls._roots(source, domain)
        if roots is None:
            return (STATUS_NO_SOURCE, [], {"hint": (
                f"映射里没有知识域 {domain}。请在 /.user_settings/_project.yaml 或"
                f" /.user_settings/<工号>.yaml 中补一条，或改查已声明的域。")})

        kind = request.get("kind") or KIND_DOCUMENTS
        if kind not in cls.CAPABILITIES["kinds"]:
            return (STATUS_UNSUPPORTED, [], {"hint": (
                f"云盘不支持 kind={kind}——它是文件存储，没有对象概念。"
                f"可用：{'、'.join(sorted(cls.CAPABILITIES['kinds']))}。")})
        call = invoke or run_cloud
        cli = source.get("cloud_cli")
        resource_id = request.get("resource_id") or source.get("resource_id") or ""
        want_body = bool(request.get("include_body"))
        cache = _cache_dir(request.get("session_root"))

        # **operation 以前在这里被整个吞掉。** 现在要么真的执行，要么明确报不支持。
        operation = str(request.get("operation") or "search").strip() or "search"
        if operation == "fetch":
            urls = [str(u).strip() for u in (request.get("urls") or []) if str(u).strip()]
            if not urls:
                return (STATUS_UNSUPPORTED, [], {"hint": (
                    "operation=fetch 必须给 --url <云盘绝对路径>，可重复传。"
                    "路径从 metadata-search 的 filePath 取。")})
            if cache is None:
                return (STATUS_UNSUPPORTED, [], {"hint": (
                    "operation=fetch 需要 --session-root：正文必须先落盘再进上下文。")})
            try:
                return _fetch_paths(call, urls, roots=roots, kind=kind, cli=cli,
                                    resource_id=resource_id, cache=cache,
                                    source_id=source["id"],
                                    manifest_only=bool(request.get("manifest_only")))
            except CloudError as exc:
                return (status_for_code(exc.code), [],
                        {"hint": f"[{exc.code}] {exc}", "error_code": exc.code})
        if request.get("manifest_only"):
            return (STATUS_UNSUPPORTED, [], {"hint": (
                "--manifest-only 只对 --operation fetch 有效。"
                "语义检索本来就不回全文，不需要它。")})
        if operation != "search":
            return (STATUS_UNSUPPORTED, [], {"hint": (
                f"云盘域不支持 operation={operation}。可用：search（语义检索）、"
                "fetch（按绝对路径直接取）。")})
        if request.get("urls"):
            return (STATUS_UNSUPPORTED, [], {"hint": (
                "给了 --url 但 operation 不是 fetch。要按路径取正文请加 "
                "--operation fetch；**不加的话 --url 会被忽略**。")})

        query = str(request.get("query") or "").strip()
        if not query and request.get("where"):
            # 不带 --query 走的是枚举，`where` 到不了后端——**说出来，别静默丢掉**。
            return (STATUS_UNSUPPORTED, [], {"hint": (
                "--where-json 只对语义检索（带 --query）有效。"
                "要按结构化条件枚举请用 metadata-search，它有 total 和分页。")})
        if query:
            try:
                where = _where_for(roots, user_where=request.get("where"))
            except ValueError as exc:
                return (STATUS_UNSUPPORTED, [], {"hint": str(exc)})
            try:
                return _search(call, query, where=where, kind=kind,
                               cli=cli, resource_id=resource_id, cache=cache,
                               source_id=source["id"], want_body=want_body,
                               limit=int(request.get("limit") or 10))
            except CloudError as exc:
                return (status_for_code(exc.code), [],
                        {"hint": f"[{exc.code}] {exc}", "error_code": exc.code})

        items: list[dict[str, Any]] = []
        stale: list[str] = []
        # **与 stale 分开装。** 「映射指向的目录没了」要去改映射；
        # 「云盘返回了东西但类型认不出」映射是好的，要改的是我们的词表。
        # 混进同一个桶就会报成 MAPPING_STALE，把人指去改一份正确的映射。
        unreadable: list[str] = []
        truncated = False
        try:
            for root in roots:
                listed = _list(call, root, cli=cli, resource_id=resource_id)
                if listed["unknown"] and not listed["files"] and not listed["dirs"]:
                    # **有东西，只是类型认不出**——这不是「映射过期」。
                    # 报成映射过期会让人去改一份本来正确的映射，改完还是不通。
                    # 把那几个词原样带出来，才补得了 `cloud.DIR_TYPES`／`FILE_TYPES`。
                    seen = sorted({str(u["type"]) for u in listed["unknown"]})
                    unreadable.append(
                        f"{root} 下有 {len(listed['unknown'])} 条，但 type 认不出："
                        f"{'、'.join(seen)}。**映射没问题**，是取数这边的类型词表少了这几个词，"
                        "请把它们加进 byclaw_caps.cloud 的 DIR_TYPES／FILE_TYPES。")
                    continue
                if not listed["files"] and not listed["dirs"]:
                    hint = _explain_empty(call, root, cli=cli, resource_id=resource_id)
                    if hint:
                        stale.append(hint)
                    continue
                found, capped = _walk(call, root, listed, kind=kind,
                                      cli=cli, resource_id=resource_id)
                truncated = truncated or capped
                for remote in found:
                    items.append(_item(call, remote, source_id=source["id"],
                                       cli=cli, resource_id=resource_id,
                                       cache=cache, want_body=want_body))
        except CloudError as exc:
            return (status_for_code(exc.code), [], {
                "hint": f"[{exc.code}] {exc}",
                "error_code": exc.code,
            })

        if unreadable and not items:
            return (STATUS_UNREACHABLE, [], {"hint": "；".join(unreadable)})
        if stale and not items:
            return (STATUS_MAPPING_STALE, [], {"hint": "；".join(stale)})
        extra: dict[str, Any] = {}
        if stale:
            extra["stale"] = stale
        if unreadable:
            extra["unreadable"] = unreadable
        if truncated:
            extra["truncated"] = True
            extra["hint"] = (
                f"目录层数超过遍历**深度**上限（{MAX_WALK_DEPTH} 层）或调用上限"
                f"（{MAX_WALK_CALLS} 次），**结果不完整**。"
                "把映射指得深一点，或把作品收拢到更浅的层级。")
        return (STATUS_OK, items, extra)


    @classmethod
    def metadata_query(
        cls,
        source: Mapping[str, Any],
        request: Mapping[str, Any],
        *,
        invoke: Invoke | None = None,
    ) -> "tuple[str, dict[str, Any]]":
        """按结构化条件枚举文件，不做语义检索，返回带分页的文件列表。

        与 `query()` 不同：结果不归并、不去重，调用方直接拿完整分页 dict。
        返回 `(status, result_dict)`。
        """
        import json as _json

        domain = request["domain"]
        roots = cls._roots(source, domain)
        if roots is None:
            return (STATUS_NO_SOURCE, {
                "hint": (
                    f"映射里没有知识域 {domain}。请在 /.user_settings/_project.yaml 或"
                    f" /.user_settings/<工号>.yaml 中补一条，或改查已声明的域。"
                )
            })

        call = invoke or run_cloud
        cli = source.get("cloud_cli")
        resource_id = request.get("resource_id") or source.get("resource_id") or ""

        try:
            path_filter = _where_for(roots)
        except ValueError as exc:
            return (STATUS_UNSUPPORTED, {"hint": str(exc)})

        user_where = request.get("where") or {}
        combined = {"and": [path_filter, user_where]} if user_where else path_filter

        cmd: list[str] = [
            "metadata-search",
            "--where-json", _json.dumps(combined, ensure_ascii=False),
            "--page-num", str(int(request.get("page_num") or 1)),
            "--page-size", str(int(request.get("page_size") or 20)),
        ]
        for field in (request.get("metadata_fields") or []):
            cmd.extend(["--metadata-field", str(field)])

        try:
            payload = call(cmd, cli=cli, resource_id=resource_id)
        except CloudError as exc:
            return (status_for_code(exc.code), {
                "hint": f"[{exc.code}] {exc}", "error_code": exc.code,
            })

        result = normalise_metadata_search(payload)
        result["domain"] = domain
        return (STATUS_OK, result)


def status_for_code(code: str) -> str:
    """云盘错误码 → 逐源状态。

    **全部归到 `UNREACHABLE`，包括未知码。** 云盘的错误码没有一个表示「查了，没有」——
    「没有」是命中 0 条。所以只要报了错，就是够不着，该去修部署或修权限。
    """
    return STATUS_UNREACHABLE


def _count_leaves(node: Any) -> int:
    """数 Agent DSL 里的叶子条件。`and`/`or` 是枝，其余算一片叶。"""
    if isinstance(node, Mapping):
        for key in ("and", "or"):
            if key in node:
                return sum(_count_leaves(child) for child in (node[key] or []))
        return 1
    if isinstance(node, (list, tuple)):
        return sum(_count_leaves(child) for child in node)
    # 认不出来的节点**算一片叶，不算零**——
    # 算零会把超限的条件放过去，而超限的后果是静默少查。
    return 1


def _where_for(roots: list, *, user_where: Any = None) -> dict:
    """把映射路径拼成 Agent DSL 的 `filePath` 前缀过滤。

    **`search` 按 resourceId 检索整个云盘，不接受目录参数。** 不加这个过滤，
    `--domain 素材.事件` 会把成品、渠道、别人的个人素材全检索进来——
    知识域这层路由就等于没有。

    `user_where` 是调用方要的**进一步收窄**（`--where-json`），与域根 `and` 起来：
    **只会更窄，不会更宽**——所以给一个别的域的路径不会越界，只会一条都不命中。

    叶子上限 12（`references/agent-dsl.md`），超了报出来：
    **静默少查几个目录，返回看起来完全正常。**
    """
    if len(roots) > MAX_WHERE_LEAVES:
        raise ValueError(
            f"这个知识域映射了 {len(roots)} 条路径，超过 Agent DSL 的叶子上限"
            f"（{MAX_WHERE_LEAVES}），拼不出检索过滤条件。"
            "**不会少查几条凑合**——那样结果看起来正常而其实漏了。"
            "请把映射合并到更少的目录，或改用不带 --query 的枚举。")
    leaves = [{"prefix": {"fieldName": "filePath", "value": p}} for p in roots]
    base: dict = leaves[0] if len(leaves) == 1 else {"or": leaves}
    if not user_where:
        return base
    combined = {"and": [base, user_where]}
    total = _count_leaves(combined)
    if total > MAX_WHERE_LEAVES:
        raise ValueError(
            f"域根（{len(leaves)} 条）加上 --where-json 一共 {total} 片叶子，"
            f"超过 Agent DSL 上限（{MAX_WHERE_LEAVES}）。"
            "**不会替你砍掉几条凑合**——那样结果看起来正常而其实漏了。"
            "请把 --where-json 写简单些，或改用 metadata-search 枚举。")
    return combined


def _search(call: Invoke, query: str, *, where: dict, kind: str, cli, resource_id,
            cache, source_id: str, want_body: bool, limit: int) -> tuple:
    """带检索词时走这条。

    `--include-body` 决定用哪个命令：只要路径与分数时用 `search-file`，
    要正文时用 `search`——**后者会把命中片段带进来**，而那正是
    `--include-body` 要控制的东西。

    **检索 0 条就是 0 条，不补一次枚举**（构建时延约 1 分钟，兜底那条已撤），
    **也不判 `MAPPING_STALE`**——没构建过的文件本来就检索不到，
    误报成「映射过期」会让人去改一个本来正确的映射。
    """
    import json as _json

    command = "search" if want_body else "search-file"
    payload = call([command, "--query", query, "--top-k", str(limit),
                    "--where-json", _json.dumps(where, ensure_ascii=False)],
                   cli=cli, resource_id=resource_id)
    # `--search-mode` 不透传：调用方没有依据选它，用默认 mixedRecall。
    hits = normalise_search(payload) if want_body else normalise_search_files(payload)

    items = []
    for hit in hits:
        remote = hit["path"]
        if kind == KIND_DOCUMENTS and not remote.lower().endswith(".md"):
            continue
        item = _item(call, remote, source_id=source_id, cli=cli,
                     resource_id=resource_id, cache=cache, want_body=want_body)
        item["score"] = hit.get("score")
        if want_body:
            item["chunk"] = hit.get("chunk")
        items.append(item)
    return (STATUS_OK, items, {"recall": "semantic"})


def _walk(call: Invoke, root: str, listed: dict, *, kind: str, cli, resource_id
          ) -> tuple:
    """从 `root` 往下找匹配的文件。返回 `(文件路径列表, 是否被上限截断)`。

    **当层没有匹配文件才往下走。** 素材那种「目录里直接放 md」的照旧一次调用；
    成品埋在 `<合集>/<作品名>/正文.md` 底下，才付 N+1 的代价。

    单层 `list` 是云盘 CLI 的限制，不是设计选择——不往下走的话，
    映射指到 `<APP_ID>` 会返回 `ok` + 0 条，而查重据此得出
    「这个号没发过任何文章」。**静默，且结论完全相反。**
    """
    calls = 1
    truncated = False
    frontier = [(root, listed, 0)]
    found: list[str] = []
    while frontier:
        here, payload, depth = frontier.pop(0)
        matched = [f for f in payload["files"]
                   if kind != KIND_DOCUMENTS or f.lower().endswith(".md")]
        if matched:
            found.extend(matched)
            continue                       # 这一层有货就不再往下
        if depth >= MAX_WALK_DEPTH:
            truncated = truncated or bool(payload["dirs"])
            continue
        for child in payload["dirs"]:
            if calls >= MAX_WALK_CALLS:
                truncated = True
                break
            calls += 1
            frontier.append((child, _list(call, child, cli=cli,
                                          resource_id=resource_id), depth + 1))
    return found, truncated


def _list(call: Invoke, path: str, *, cli, resource_id) -> dict:
    """列一层目录。**形状由适配层归一**，这里不碰对方的原始字段名。

    旧实现读的是 `payload["files"]` 与 `payload["dirs"]`，
    而真实返回是扁平的 `items` + `type`——两个键恒空，于是取材恒 0 条、
    乐观验证误判成 `MAPPING_STALE`。**云盘线从上线起就没通过。**
    """
    payload = call(["list", "--directory-path", path], cli=cli, resource_id=resource_id)
    return normalise_list(payload)


def _explain_empty(call: Invoke, path: str, *, cli, resource_id) -> str:
    """空结果：是目录没了，还是目录真的是空的？

    只在空结果时才问这一次。非空时多问一次父目录，是每条映射路径白搭一个网络往返。
    """
    parent = str(PurePosixPath(path).parent)
    if parent == path:
        return ""
    listed = _list(call, parent, cli=cli, resource_id=resource_id)
    # **只问名字，不问类型。** 按 `dirs` 判的话，`type` 的词一旦对不上，
    # 存在的目录会被判成「已不存在」——线上报「8 个目录全不存在」就是这么来的。
    leaf = PurePosixPath(path.rstrip("/")).name
    if leaf in listed["names"] or any(_same_path(d, path) for d in listed["dirs"]):
        return ""  # 目录在，只是空的——这是「查过了，确实没有」
    siblings = "、".join(listed["names"]) or "（父目录下是空的）"
    return (f"映射指向的 {path} 已不存在，{parent} 下现有：{siblings}。"
            f"请更新 /.user_settings 下的映射，或确认新位置。")


def _same_path(a: str, b: str) -> bool:
    return a.rstrip("/") == b.rstrip("/")


def _cache_dir(session_root: str | None) -> Path | None:
    if not session_root:
        return None
    return Path(str(session_root)) / RETRIEVAL_CACHE


#: `--operation fetch` 放行的扩展名。**按路径取时不该再按 `.md` 过滤**——
#: 路径是调用方明确给的，二次过滤只会把 `.json`、`.txt` 这类挡在外面。
#: 实测踩过：账号画像是 `.json`，被 `.md` 那条挡住，调用方为它绕了六轮，
#: 而报错还让它「换 kind」——**那个参数根本不存在**。
#:
#: 仍然拒二进制：正文是 `raw.decode("utf-8", errors="replace")` 出来的，
#: PDF、图片解出来是一堆替换字符，**看起来像内容，其实是垃圾**。
FETCHABLE_SUFFIXES = frozenset({
    ".md", ".markdown", ".txt", ".json", ".yaml", ".yml",
    ".csv", ".tsv", ".html", ".htm", ".xml", ".log",
})


def _under_roots(remote: str, roots: list[str]) -> bool:
    r = "/" + remote.strip("/")
    return any(r == "/" + root.strip("/") or r.startswith("/" + root.strip("/") + "/")
               for root in roots)


def _fetch_paths(call: Invoke, urls: list[str], *, roots: list[str], kind: str,
                 cli, resource_id, cache: Path | None, source_id: str,
                 manifest_only: bool = False) -> tuple:
    """按**云盘绝对路径**直接取文件，不走语义检索。

    **为什么必须有这条路**：地图、账号档案、术语表这些是**结构化参照物**——
    路径固定、每次必读、`metadata-search` 已经把路径给出来了。
    没有这条路时只能拿语义检索去撞，实测撞了三次才中
    （「地图」这个词被术语表抢走），一个路径明确的文件读了六轮。

    ⚠️ 以前 `--operation fetch --url` 对云盘域是**静默无效**的：
    `--url` 只有 web 源在读，云盘这边从没看过它，于是退化成枚举整个域根，
    报出来的错跟路径八竿子打不着——调用方据此推断出的原因必然是错的。
    **一个不干活也不报错的开关，比没有这个开关更糟。**
    """
    items, bad = [], []
    for remote in urls:
        if not remote.startswith("/"):
            bad.append(f"{remote}（不是绝对路径）")
            continue
        if not _under_roots(remote, roots):
            bad.append(f"{remote}（不在本域范围内）")
            continue
        suffix = PurePosixPath(remote).suffix.lower()
        if suffix not in FETCHABLE_SUFFIXES:
            bad.append(
                f"{remote}（`{suffix or '无扩展名'}` 取不了正文：只能取文本类型 "
                f"{'、'.join(sorted(FETCHABLE_SUFFIXES))}。"
                "二进制解成 UTF-8 是一堆替换字符，**看着像内容其实是垃圾**）")
            continue
        try:
            if manifest_only:
                # **落盘，但正文不回上下文。** 批量取一百多篇时，正文全带回来
                # 会把上下文撑爆，而其中绝大多数当次根本不读。
                raw = _fetch(call, remote, cli=cli, resource_id=resource_id, cache=cache)
                local = cache / remote.lstrip("/") if cache else None
                items.append({
                    "source": source_id, "path": remote,
                    "title": resolve_title(PurePosixPath(remote), raw),
                    "local": str(local) if local else None,
                    "bytes": len(raw),
                    "sha256": hashlib.sha256(raw).hexdigest(),
                })
            else:
                items.append(_item(call, remote, source_id=source_id, cli=cli,
                                   resource_id=resource_id, cache=cache, want_body=True))
        except CloudError as exc:
            bad.append(f"{remote}（[{exc.code}] {exc}）")

    extra: dict[str, Any] = {"recall": "path"}
    if manifest_only:
        extra["manifest_only"] = True
        extra["hint"] = (f"{len(items)} 篇已落盘，**正文没有回到上下文**——"
                         "按 items[].local 本地读你真正要看的那几篇。")
    if bad:
        # **取不到要说出来，不能只返回取到的那几条。**
        extra["failed"] = bad
        extra["hint"] = ("这些路径取不到：" + "；".join(bad)
                         + f"。本域根目录是：{'、'.join(roots)}。"
                         "路径可用 metadata-search 的 filePath 取，不要自己拼。")
    if not items:
        return (STATUS_UNSUPPORTED, [], extra)
    return (STATUS_OK, items, extra)


def _item(call: Invoke, remote: str, *, source_id: str, cli, resource_id,
          cache: Path | None, want_body: bool) -> dict[str, Any]:
    path = PurePosixPath(remote)
    item: dict[str, Any] = {
        "source": source_id,
        "path": remote,
        "title": _title(path),
        # 不下载就没有内容，也就没有哈希。**去重要能处理 None**——
        # 按 None 去重会把整批枚举结果折叠成一条。
        "sha256": None,
        "chunk": None,
        "score": None,
    }
    if want_body:
        raw = _fetch(call, remote, cli=cli, resource_id=resource_id, cache=cache)
        item["sha256"] = hashlib.sha256(raw).hexdigest()
        item["content"] = raw.decode("utf-8", errors="replace")
        # 有正文了就用 H1：目录名被剥过非法字符（`本体江湖：五大门派…` →
        # `本体江湖五大门派…`），H1 才是原文。
        item["title"] = resolve_title(path, raw)
    return item


def _fetch(call: Invoke, remote: str, *, cli, resource_id, cache: Path | None) -> bytes:
    """先落盘，再进上下文；同一份素材一次创作只下载一次。"""
    if cache is None:
        raise CloudError(
            "取正文需要 --session-root：内容必须先落盘再进上下文。",
            code="SESSION_ROOT_MISSING")
    local = cache / remote.lstrip("/")
    if local.is_file():
        return local.read_bytes()
    local.parent.mkdir(parents=True, exist_ok=True)
    call(["download", "--file-path", remote, "--output", str(local)],
         cli=cli, resource_id=resource_id)
    if not local.is_file():
        # `download` 对不存在的路径**报成功、返回空包**——「路径不存在」与
        # 「内容为空」在这个接口上长得一模一样。不显式拦一下的话，下一行
        # `read_bytes()` 抛的是裸 FileNotFoundError，**上层会把它当成
        # 「文件不存在」写进文案**，而真实原因（多半是 resource_id 指错库）
        # 一个字都不会出现。实测里这一条让三方各查了一轮才发现资源用错。
        raise CloudError(
            f"资源 {resource_id} 上 download {remote} 报成功，但没有落下文件。"
            "**这个接口对「路径不存在」和「内容为空」返回同一个结果**，"
            f"所以先确认 {resource_id} 是不是**项目云盘**的 cloudResourceId"
            "（`project-context basic --project-id <id>` 取，**不要猜**）——"
            "本体库、其它知识库的 ID 在这里不会报错，只会静默返回空。",
            code="CLOUD_DOWNLOAD_EMPTY")
    return local.read_bytes()


def _title(path: PurePosixPath) -> str:
    """枚举阶段的标题：文件名够用就用文件名，不够用就取父目录名。

    **不为了标题去下载**：那正是 `include_body` 要避免的事。取了正文之后
    改用 `resolve_title`（会读 H1），两者共用同一份 `UNINFORMATIVE_STEMS`——
    分成两份迟早只改一处。
    """
    stem = path.stem
    if stem.lower() not in UNINFORMATIVE_STEMS:
        return stem
    return path.parent.name or stem


def make_reader(call: Invoke | None = None, *, cli, resource_id, cache=None):
    """给 `mapping.load_mapping` 用的读取器：把云盘上的一个文本文件读成字符串。

    映射文件也在云盘上（`/.user_settings/`），但**它是配置，不是素材**，
    所以不走素材那条缓存：

    * **不落会话目录。** `.runtime/retrieval` 是「这次创作读了哪些素材」的账，
      配置混进去就数不准了；线上看到的 `.runtime/retrieval/.user_settings/`
      就是这么来的。
    * **每次都重新读。** 素材缓存命中本地就直接返回，映射跟着被缓存一整个会话——
      于是「报 `MAPPING_STALE` → 让人去改映射 → 同一会话重试」这条路走不通：
      读到的还是那份旧的。**我们让人去修的东西，修完却读不到**，
      而人会以为自己没改对，回头再改一遍本来已经正确的映射。

    `cache` 保留只为兼容旧调用（`__main__` 一直传着会话缓存进来），**收到也不用**。
    """
    invoke = call or run_cloud

    def _read(path: str) -> str:
        import tempfile

        try:
            # 每次一个新的临时目录：既不留痕，也拿不到上一次的结果。
            with tempfile.TemporaryDirectory() as tmp:
                raw = _fetch(invoke, path, cli=cli, resource_id=resource_id,
                             cache=Path(tmp))
        except CloudError as exc:
            # **resource_id 必须进消息。** 少了它，上层只能报「云盘上没有 X」，
            # 而读的人无从判断「是文件真没有」还是「查错了库」。
            raise FileNotFoundError(
                "资源 {} 上取不到 {}：[{}] {}".format(
                    resource_id, path, exc.code, exc)) from exc
        return raw.decode("utf-8", errors="replace")

    return _read



__all__ = ["CloudDriver", "STATUS_MAPPING_STALE", "RETRIEVAL_CACHE",
           "MAX_WALK_DEPTH", "MAX_WALK_CALLS", "MAX_WHERE_LEAVES", "make_reader"]
