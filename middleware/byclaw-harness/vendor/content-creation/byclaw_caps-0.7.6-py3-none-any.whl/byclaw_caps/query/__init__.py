#!/usr/bin/env python3
"""数据查询：一个读接口，三种数据组织方式。

七项能力中**唯一必须面向多后端设计**的一项。本地文件夹、本体对象 API、知识库 API，
另加联网检索一路。当前已实现本地、DataCloud（本体对象与知识库）和 Web 三种 Driver；
Skill 仍只依赖统一接口，部署更换数据组织方式不改调用方。

全部关键在一条：**Skill 声明要什么知识域，不声明去哪拿。** 每个源在配置里自报「本源如何
理解这些知识域」，谁挂什么源就从哪拿，Skill 一行不改。这也是同一套 Skill 能在纯本地、
纯 API、混合三种部署下都工作的原因。

**能力缺失一律报出，不静默降级。** 四种状态码各有所指，其中 ``NO_SOURCE_FOR_DOMAIN``
最要紧：不报出来，Skill 会以为「确实没有这类素材」而继续，实际是没配。而把本地关键词匹配
伪装成语义召回比报错更糟——会给出看似有结果实则漏检的答案。
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

VERSION = "1.0.0"

# ── 知识域：受控词表 ───────────────────────────────────────────────────────
# 必须受控。Skill 写「素材.产品」、配置写「产品知识」就对不上。
# 这与关系名可自由命名相反：关系名是给人看的标签，知识域是机器路由的键。
#
# `领域` **只有父域，不开子域**。各领域（数据本体论、CRM…）是同构的——都是「一份地图 +
# 一份术语表」，分不分域取回来的形状一样。开子域的代价是每加一个领域都要改这里和公共映射，
# 忘了就是 NO_SOURCE_FOR_DOMAIN；而那按约定「不算故障」，助理会得出「没有这个领域」接着写。
# 要限定到某个领域用**路径前缀**，不要用 `领域.数据本体论` 这种域名。
#
# 判据：子目录之间**性质不同、查询时要分开**（如 `素材.产品` vs `素材.事件`）才各自注册；
# **同构、只是实例不同**（各领域、各账号、各合集）一律只注册父域。`成品` 底下的合集同理。
#
# `渠道` 与 `渠道.账号档案` 必须分开。旧设计靠 PARTIALLY_SCOPED_DOMAINS + `--scope`
# 在一个域里分「共享的渠道规范、受众库」与「按号的账号档案」两层；`--scope` 随账号维度
# 进路径而废除，两层就得分成两个域。**混成一条，读错号会按错误的读者画像写，且不报错。**
# `素材.实体` 是 `/KnowledgeEntity`——从素材抽出来的实体，一个概念一个文件。
# 域名带 `素材.` 前缀是为了让读到它的人知道**出处是素材**，因而
# **引文不能出自这里**（`## 实体定义与边界` 是多篇文档综合改写的，不是原话）。
# 目录名叫 KnowledgeEntity 而域名叫 素材.实体——两者本来就不必同名。
DOMAINS: frozenset[str] = frozenset(
    {
        "素材", "素材.产品", "素材.事件", "素材.会议纪要", "素材.实体",
        "写法", "写法.模板", "写法.资产", "写法.参考",
        "领域",
        "选题", "渠道", "渠道.账号档案", "成品", "运营",
    }
)

# ── 请求形态 ──────────────────────────────────────────────────────────────
KIND_OBJECTS = "objects"      # 按对象查，仅本体对象 API 支持
KIND_DOCUMENTS = "documents"  # 按内容召回文档或片段
KIND_FILE = "file"            # 按标识取具体文件
KINDS = frozenset({KIND_OBJECTS, KIND_DOCUMENTS, KIND_FILE})

# ── 逐源状态 ──────────────────────────────────────────────────────────────
STATUS_OK = "ok"
STATUS_UNSUPPORTED = "UNSUPPORTED_BY_SOURCE"
STATUS_NO_SOURCE = "NO_SOURCE_FOR_DOMAIN"
STATUS_UNREACHABLE = "UNREACHABLE"

#: 「该源不服务这个域」是**常态不是故障**。
#:
#: 源与知识域是多对多：素材可以来自本地、知识库或联网检索；而成品、渠道、写法是用户
#: 自己的东西，联网检索不可能有，通用知识库也未必有。若把"不适用"计为失败，只要挂上
#: 联网源，每一次查成品都会失败——用户为了让流程别停就只能把联网源摘掉，于是被逼回
#: 全本地或全远端，正是多源架构要避免的局面。
#:
#: 三分：不适用（不计成败）／服务了（计入）／该服务却没服务（结果不完整，必须说）。
_SERVED = {STATUS_OK}
_INAPPLICABLE = {STATUS_NO_SOURCE}

DEFAULT_LIMIT = 10


class QueryError(ValueError):
    """知识域未知、源未配置，或请求形态非法。"""


#: 文件名是**类型标记**而非标题的那几种。
#:
#: 通则「标题即文件名」对 `素材/事件`（`2023-12-31_数据要素…`，日期前缀有价值）
#: 与 `写法/模板` 都成立，不该动。但 `成品` 的约定是 `<标题>/index.md`——
#: 十篇文章的 title 全是 `index`，而选题的词面查重吃的正是这个字段，
#: **于是查重从来没命中过任何东西，且不报错**。
#:
#: 只在文件名不携带信息时才另找标题；找 H1 而不是取父目录名，因为目录名被
#: 剥掉了非法字符（`本体江湖：五大门派…` → `本体江湖五大门派…`），H1 才是原文。
#: 云盘上成品的约定是 `<日期>-<标题>/正文.md`，于是 `正文` 与 `index` 同病：
#: 十篇文章的 title 全叫「正文」，而选题查重吃的正是这个字段。
# 角色名，不是内容名。每个领域 / 每个号都有一份叫「地图」「术语表」
# 「账号档案」的文件——拿文件名当标题，多领域一上来就全重名了，
# 而当下只有一个领域，看不出来。落到 H1 或父目录名才分得开。
UNINFORMATIVE_STEMS = frozenset({
    "index", "collection", "正文", "readme",
    "地图", "术语表", "账号档案", "索引_合集",
})

_H1 = re.compile(r"^#\s+(.+?)\s*$", re.M)


def resolve_title(path: Path, raw: bytes) -> str:
    """文件名够用就用文件名；不够用才读首个一级标题，再退到父目录名。

    `raw` 由调用方传入——驱动本来就要读全文算 sha256，这里不额外开销一次 IO。
    """
    stem = path.stem
    if stem.lower() not in UNINFORMATIVE_STEMS:
        return stem
    match = _H1.search(raw.decode("utf-8", errors="replace"))
    if match:
        return match.group(1)
    return path.parent.name or stem


# ── 驱动 ──────────────────────────────────────────────────────────────────
#
# **账号维度整段删除。** `SCOPED_DOMAINS`、`PARTIALLY_SCOPED_DOMAINS`、
# `discover_accounts`、`classify_path`、`parse_scope` 与 `--scope` 一起废除：
# 账号进了云盘路径（`/成品/<channel>/<APP_ID>/…`），过滤由映射完成，
# 不再需要一道运行期校验。**留着不生效比删掉更坏**——调用方会以为它还在保护什么。
#
# 「共享 vs 按号」那一层没有丢，改由两个知识域承担：`渠道` 是项目公共，
# `渠道.账号档案` 随号走（见 DOMAINS 处的说明）。
#
# **本地驱动同时删除。** 项目空间作废，素材只在云盘上；留一个连不到任何数据的
# 驱动，只会让「本地够用就不打远端」这类旧写法看起来还能跑。

DRIVERS: dict[str, Any] = {}


def _register_optional_drivers() -> None:
    """DataCloud 驱动**延迟注册**：它 import 本模块的常量，模块级 import 会成环。

    注册失败不影响本地驱动——本地能独立跑是这套架构的要点之一。
    """
    try:
        from byclaw_caps.query.datacloud import DataCloudDriver
    except ImportError:
        pass
    else:
        DRIVERS.setdefault("datacloud", DataCloudDriver)
    try:
        from byclaw_caps.query.web import WebDriver
    except ImportError:
        pass
    else:
        DRIVERS.setdefault("web", WebDriver)
    try:
        from byclaw_caps.query.cloud import CloudDriver
    except ImportError:
        pass
    else:
        DRIVERS.setdefault("cloud", CloudDriver)


# ── 配置 ──────────────────────────────────────────────────────────────────


def load_sources(path: str | Path) -> dict[str, Any]:
    """读取源配置。

    配置分两级：用户级 ``~/by/sources.yaml`` 作基底，项目级覆盖。纯 API 部署没有项目空间，
    配置无处安放，故基底不能依赖项目。
    """
    from byclaw_caps.query.source_config import load_sources_file

    return load_sources_file(path, valid_domains=DOMAINS)


def resolve_sources(
    config: Mapping[str, Any], *, request: Mapping[str, Any]
) -> list[dict[str, Any]]:
    """三种写法：不写用默认挂载；``extra_sources`` 追加；``sources`` 完全覆盖。

    用追加而非覆盖作默认，是因为覆盖太容易误伤——写成 ``sources: ["corp-kb"]`` 就把本地
    关掉了，而用户的本意通常是「**再**查一下」。
    """
    known = {s["id"]: s for s in config["sources"]}

    def pick(names: Iterable[str]) -> list[dict[str, Any]]:
        chosen = []
        for name in names:
            if name not in known:
                raise QueryError(
                    f"未配置的源：{name}。可用：{'、'.join(known)}。"
                    "外部源的凭据不能在会话里现给，须先在配置中登记。"
                )
            chosen.append(known[name])
        return chosen

    if request.get("sources"):
        return pick(request["sources"])
    picked = [s for s in config["sources"] if s.get("default_mount")]
    return picked + pick(request.get("extra_sources") or [])


# ── 入口 ──────────────────────────────────────────────────────────────────


def run_query(
    request: Mapping[str, Any], *, sources: Sequence[Mapping[str, Any]]
) -> dict[str, Any]:
    """按知识域路由到各源，合并结果，逐源报状态。"""
    domain = str(request.get("domain") or "").strip()
    if domain not in DOMAINS:
        # 在任何 IO 之前拒绝：词表受控，拼错就静默查不到东西
        raise QueryError(
            f"未知知识域 {domain!r}。可用：{'、'.join(sorted(DOMAINS))}。"
        )
    kind = request.get("kind") or KIND_DOCUMENTS
    if kind not in KINDS:
        raise QueryError(f"未知 kind {kind!r}。可用：{'、'.join(sorted(KINDS))}。")

    request = dict(request)

    per_source = request.get("per_source_limit")
    limit = int(request.get("limit") or DEFAULT_LIMIT)

    report: dict[str, Any] = {}
    merged: list[dict[str, Any]] = []
    seen: dict[tuple[str, Any], dict[str, Any]] = {}

    for source in sources:
        driver = DRIVERS.get(source.get("backend"))
        if driver is None:
            report[source["id"]] = {
                "status": STATUS_UNREACHABLE,
                "count": 0,
                "hint": (f"未注册的后端 {source.get('backend')}。"
                         f"可用：{'、'.join(sorted(DRIVERS)) or '（一个都没注册）'}。"),
            }
            continue

        status, items, extra = driver.query(source, request)
        if per_source is not None:
            items = items[: int(per_source)]

        kept = 0
        for item in items:
            # 去重键含账号归属。**只按内容哈希去重会把跨号的同一篇折叠成一条**，
            # 而先到者留下——若留下的是别人那份，本号自己发过的这篇就从「阻断」
            # 降级成了「提示」，查重失效且无人察觉。
            # 两个号各发过一次同一篇内容，是两件事实，不是一件。
            # **没有 sha256 时退回按路径去重。** 云盘枚举阶段不下载内容，
            # 整批条目的 sha256 都是 None；以 None 作键会把十篇文章折叠成一篇，
            # 而且不报错——枚举的结果看起来只是「素材比想象中少」。
            digest = item["sha256"] or ("path:" + str(item.get("path")))
            if digest in seen:
                # 路径会变，内容不变才是同一份——与封面缓存键同源。
                # 先到者留下，源按配置顺序排列，项目空间在前故优先。
                seen[digest].setdefault("also_in", []).append(item["source"])
                continue
            seen[digest] = item
            merged.append(item)
            kept += 1

        entry = {"status": status, "count": kept}
        entry.update(extra)
        report[source["id"]] = entry

    served = [i for i, e in report.items() if e["status"] in _SERVED]
    incomplete = [i for i, e in report.items()
                  if e["status"] not in _SERVED and e["status"] not in _INAPPLICABLE]
    if not served:
        # 一个源都没服务：这个问题没有任何途径能回答，是真问题。
        status = STATUS_NO_SOURCE if not incomplete else "PARTIAL"
    elif incomplete:
        status = "PARTIAL"
    else:
        status = STATUS_OK

    return {
        "ok": status == STATUS_OK,
        "status": status,
        "incomplete": incomplete,
        # 逐源状态码。**算完就扔等于 SKILL.md 那张处置表形同虚设**——
        # 调用方只看到「联网检索 不完整」，看不出该去修部署、补素材，还是换检索方式。
        "per_source": report,
        "domain": domain,
        "kind": kind,
        "items": merged[:limit],
        "sources": report,
    }


def run_metadata_query(
    request: Mapping[str, Any], *, sources: Sequence[Mapping[str, Any]]
) -> dict[str, Any]:
    """按结构化条件枚举云盘文件，返回分页结果。

    只路由到 cloud 后端；非云盘源（web、datacloud）不支持该操作，
    报 UNSUPPORTED_BY_SOURCE，不算失败（与 run_query 的约定一致）。

    **不合并多源结果**：多个云盘源时逐源返回独立分页；单源时结果直接展开到顶层。
    """
    domain = str(request.get("domain") or "").strip()
    if domain not in DOMAINS:
        raise QueryError(
            f"未知知识域 {domain!r}。可用：{'、'.join(sorted(DOMAINS))}。"
        )

    per_source: dict[str, Any] = {}
    for source in sources:
        backend = source.get("backend")
        if backend != "cloud":
            per_source[source["id"]] = {
                "status": STATUS_UNSUPPORTED,
                "hint": f"{backend} 后端不支持 metadata-search，只有云盘后端支持。",
            }
            continue
        driver = DRIVERS.get("cloud")
        if driver is None:
            per_source[source["id"]] = {
                "status": STATUS_UNREACHABLE,
                "hint": "云盘驱动未注册。",
            }
            continue
        status, result = driver.metadata_query(source, request)
        per_source[source["id"]] = {"status": status, **result}

    served = [sid for sid, e in per_source.items() if e["status"] == STATUS_OK]
    ok = bool(served)
    return {
        "ok": ok,
        "domain": domain,
        "per_source": per_source,
        **(per_source[served[0]] if len(served) == 1 else {}),
    }


__all__ = [
    "VERSION",
    "DOMAINS",
    "KINDS",
    "KIND_OBJECTS",
    "KIND_DOCUMENTS",
    "KIND_FILE",
    "STATUS_OK",
    "STATUS_UNSUPPORTED",
    "STATUS_NO_SOURCE",
    "STATUS_UNREACHABLE",
    "QueryError",
    "DRIVERS",
    "load_sources",
    "resolve_sources",
    "resolve_title",
    "run_query",
    "run_metadata_query",
]


_register_optional_drivers()
