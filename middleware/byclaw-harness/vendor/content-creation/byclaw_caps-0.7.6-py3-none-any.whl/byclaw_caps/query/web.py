"""联网检索驱动。

`web-research-enhauce`（750 行 + vendor 了 20MB searxng）**退役**，这里只留薄适配。

按方案的入选判据三问——输出可验证吗、失败可诊断吗、凭据要隔离吗——检索结果本就是自然
语言，第一条就不成立。它做数据查询的第 4 路驱动就够了，不必是独立能力。

**只服务素材域。** 联网检索不可能有用户自己的成品、渠道设定或写法资产；查这些域时报
`NO_SOURCE_FOR_DOMAIN` 并**不拖累整体成败**。这是这路驱动能挂上来的前提——先前
`ok = all(逐源都成功)` 的算法会让「挂了联网源之后每次查成品都失败」，用户只能把它摘掉。

**取回的内容落 `.runtime/retrieval/`。** 它是素材不是产物：落进阶段目录，人打开
`10-topic/` 会看到一堆外部原文，误以为是本次产出。

**内容逐字落盘，不做概括。** 原句门禁要在本地文件里逐字定位引文；概括过的内容过不了那道门。
实测一个 Next.js 页面可完整抓回 678KB markdown，是字段搬运不是概括，所以这条前提成立。
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping

from byclaw_caps.query import (
    KIND_DOCUMENTS,
    STATUS_NO_SOURCE,
    STATUS_OK,
    STATUS_UNREACHABLE,
    STATUS_UNSUPPORTED,
)

RETRIEVAL_SUBDIR = Path(".runtime") / "retrieval" / "web"

#: 只有素材类的域走联网。其余是用户私有数据，外面不可能有。
WEB_DOMAINS = frozenset({"素材", "素材.产品", "素材.事件", "素材.会议纪要", "写法.参考"})

Search = Callable[..., List[Dict[str, Any]]]
Fetch = Callable[..., List[Dict[str, Any]]]


def retrieval_dir(session_root: Path | str) -> Path:
    return Path(session_root) / RETRIEVAL_SUBDIR


def default_search(query: str, *, limit: int, source: Mapping[str, Any],
                   filters: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """按 `sources.yaml` 的 `web_search.provider` 构建真实后端。"""
    from byclaw_caps.query.web_backend import make_web_backend

    return make_web_backend(source.get("integration") or {}).search(
        query, limit=limit, filters=filters)


def _land(root: Path, item: Mapping[str, Any]) -> Path:
    """把原文写进 `.runtime/retrieval/`，返回落盘路径。

    文件名按 URL 哈希，**内容逐字写入不做加工**——原句门禁要逐字定位。
    """
    directory = retrieval_dir(root)
    directory.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(str(item.get("url") or "").encode("utf-8")).hexdigest()[:16]
    target = directory / f"{digest}.md"
    title = str(item.get("title") or "").strip()
    url = str(item.get("url") or "").strip()
    header = f"# {title}\n\n> 来源：{url}\n\n" if (title or url) else ""
    target.write_text(header + str(item.get("content") or ""), encoding="utf-8")
    return target


class WebDriver:
    """联网检索。"""

    backend = "web"
    CAPABILITIES: dict[str, Any] = {
        "kinds": frozenset({KIND_DOCUMENTS}),
        "filters": frozenset({"category", "language", "time_range", "safesearch"}),
        # 没有枚举——枚举整个互联网没有意义。
        "recall": frozenset({"semantic"}),
        "write": "none",
    }

    @classmethod
    def query(cls, source: Mapping[str, Any], request: Mapping[str, Any],
              *, search: Search | None = None, fetch: Fetch | None = None
              ) -> tuple[str, list[dict[str, Any]], dict[str, Any]]:
        domain = request["domain"]
        configured_domains = frozenset(source.get("domains") or WEB_DOMAINS)
        if domain not in WEB_DOMAINS or domain not in configured_domains:
            return (
                STATUS_NO_SOURCE, [],
                {"hint": (f"联网检索不服务 {domain}——那是你的私有数据，外面不可能有。"
                          f"可服务的域：{'、'.join(sorted(WEB_DOMAINS))}。")},
            )

        operation = str(request.get("operation") or (
            "legacy" if request.get("include_body") else "search"))
        limit = int(request.get("limit") or 10)
        session_root = str(request.get("session_root") or source.get("root") or "").strip()
        filters = request.get("filters") or {}
        items: list[dict[str, Any]] = []
        try:
            if operation == "fetch":
                urls = [str(url).strip() for url in (request.get("urls") or []) if str(url).strip()]
                if not urls:
                    return STATUS_UNSUPPORTED, [], {"hint": "operation=fetch 必须提供 urls/--url"}
                if not session_root:
                    return STATUS_UNSUPPORTED, [], {
                        "hint": "抓取原文必须提供 Session Root；不会回退到项目目录或当前目录。"}
                if fetch is not None:
                    fetched = fetch(urls, timeout=float(request.get("fetch_timeout") or 30))
                else:
                    from byclaw_caps.query.web_backend import make_web_backend
                    fetched = make_web_backend(source.get("integration") or {}).fetch(
                        urls, timeout=float(request.get("fetch_timeout") or 30))
                failures: list[str] = []
                for hit in fetched:
                    if hit.get("error"):
                        failures.append(str(hit.get("url") or ""))
                        continue
                    content = str(hit.get("content") or "")
                    if not content:
                        failures.append(str(hit.get("url") or ""))
                        continue
                    landed = _land(Path(session_root), hit)
                    items.append({
                        "source": source["id"], "source_kind": "web_search",
                        "path": str(landed), "title": str(hit.get("title") or ""),
                        "sha256": hashlib.sha256(landed.read_bytes()).hexdigest(),
                        "digest_basis": "content", "chunk": None, "score": None,
                        "url": str(hit.get("url") or ""),
                        "fetch_mode": str(hit.get("fetch_mode") or "simple"),
                        "fetched_at": datetime.now(timezone.utc).isoformat(),
                    })
                return ("PARTIAL" if failures and items else STATUS_OK), items[:limit], {
                    "failed_urls": failures,
                }

            queries = [str(q) for q in (request.get("queries") or []) if str(q).strip()]
            if request.get("query"):
                queries.append(str(request["query"]))
            if not queries:
                return (STATUS_UNSUPPORTED, [], {
                    "hint": "联网检索必须给检索词（--query 或 queries）；本驱动不支持枚举。"})
            for query in queries:
                if search is not None:
                    hits = search(query, limit=limit)
                else:
                    hits = default_search(query, limit=limit, source=source, filters=filters)
                for hit in hits:
                    content = str(hit.get("content") or "") if operation == "legacy" else ""
                    landed = None
                    if operation == "legacy" and content:
                        if not session_root:
                            return STATUS_UNSUPPORTED, [], {
                                "hint": "落盘联网原文必须提供 Session Root。"}
                        landed = _land(Path(session_root), hit)
                    url = str(hit.get("url") or "")
                    basis = content if content else url
                    digest = (hashlib.sha256(landed.read_bytes()).hexdigest()
                              if landed else hashlib.sha256(basis.encode("utf-8")).hexdigest())
                    items.append({
                        "source": source["id"], "source_kind": "web_search",
                        "path": str(landed) if landed else url,
                        "title": str(hit.get("title") or ""),
                        "sha256": digest,
                        "digest_basis": "content" if content else "identity",
                        "chunk": str(hit.get("snippet") or "") or None,
                        "score": hit.get("score"), "url": url,
                        "engine": hit.get("engine"),
                        "published_at": hit.get("published_at"),
                    })
                    if len(items) >= limit:
                        break
                if len(items) >= limit:
                    break
        except (FileNotFoundError, OSError) as exc:
            # 工具不在 ≠ 没搜到。说成后者，人会去换检索词，换多少次都没用。
            return (STATUS_UNREACHABLE, [],
                    {"hint": f"联网检索后端不可用：{exc}"})
        except Exception as exc:  # noqa: BLE001
            return (STATUS_UNREACHABLE, [],
                    {"hint": f"联网检索失败：{type(exc).__name__}: {exc}"})
        return STATUS_OK, items[:limit], {"result_count": len(items[:limit])}
