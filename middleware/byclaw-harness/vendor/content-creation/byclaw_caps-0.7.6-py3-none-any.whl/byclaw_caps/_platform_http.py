"""平台内网调用：服务发现 + Beyond-Token。

**两个能力共用**：`query` 的 DataCloud 驱动与 `credentials` 的凭据解析，
服务名靠 `post_json(service_name=...)` 区分。放在 `query/` 下面时，
`credentials` 要用就得 import 另一个能力的私有模块。

原名 `query/_datacloud_transport.py`。环境变量仍叫 `DATACLOUD_*`——
它们是既有部署配置，改名等于要求所有环境同步改。

由 `datacloud-knowledge-retrieval/scripts/client.py` 与 `auth.py` 移植。**逐字保留调用方式**
——这些不是可以照直觉重写的东西：

- **Redis 单例必须始终在同一个事件循环里用。** 所以有那个进程级后台循环，而不是每次
  `asyncio.run()`。换成后者，`by_framework` 的全局 Redis 客户端会跨循环使用，报出的错
  与真实原因毫无关系。
- **超时要能从服务发现的异常链里认出来。** 平台把它包了好几层，只看最外层类型会把超时
  当成普通失败重试，白等两轮。
- **`user_code → real_user_id` 的回退分支。** 映射键缺失时按 USER_CODE 直接查 auth 哈希，
  与 `byclaw_data.worker` 保持一致。

本模块**只在具备平台运行时的环境里可用**。缺 `by_framework` 时抛 `ModuleNotFoundError`，
由驱动翻译成 `UNREACHABLE` 并说清缺的是运行时——不是网络，也不是没数据。
"""

from __future__ import annotations

import asyncio
import os
import threading
from concurrent.futures import TimeoutError as FutureTimeoutError
from typing import Any

QUERY_SERVICE_ENV = "DATACLOUD_DOMAINNAME"
QUERY_SERVICE_FALLBACK = "byclaw-datacloud"
DEFAULT_REQUEST_TIMEOUT_SECONDS = 100
DEFAULT_HTTP_TIMEOUT_SECONDS = 90.0
DEFAULT_RETRY_ATTEMPTS = 1

_loop: asyncio.AbstractEventLoop | None = None
_loop_thread: threading.Thread | None = None
_loop_ready: threading.Event | None = None
_loop_lock = threading.Lock()


class DataCloudAuthError(RuntimeError):
    """当前用户的 Redis 认证不可用。"""


def _env_first(*names: str, default: str = "") -> str:
    for name in names:
        value = os.getenv(name, "").strip()
        if value:
            return value
    return default


def _text(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace").strip()
    return str(value or "").strip()


def init_auth_redis() -> None:
    from by_framework.common.redis_client import init_redis  # type: ignore[import-untyped]

    try:
        port = int(_env_first("REDIS_PORT", "DATACLOUD_GATEWAY_REDIS_PORT", default="6379"))
        database = int(_env_first(
            "REDIS_DATABASE", "REDIS_DB",
            "DATACLOUD_GATEWAY_REDIS_DATABASE", "DATACLOUD_GATEWAY_REDIS_DB",
            default="0",
        ))
    except ValueError as exc:
        raise DataCloudAuthError("Redis 端口或数据库编号配置无效") from exc

    init_redis(
        host=_env_first("REDIS_HOST", "DATACLOUD_GATEWAY_REDIS_HOST", default="localhost"),
        port=port,
        db=database,
        password=_env_first("REDIS_PASSWORD", "DATACLOUD_GATEWAY_REDIS_PASSWORD") or None,
        username=_env_first("REDIS_USERNAME", "DATACLOUD_GATEWAY_REDIS_USERNAME") or None,
    )


async def resolve_beyond_token(user_code: str | None = None) -> str:
    """经平台 Redis 取当前用户的 Beyond-Token。

    与 `byclaw_data.worker` 一致：USER_CODE 经 ``SHARE_BFM_USER_CODE_{code}`` 映射到真实
    用户 ID，再读 ``user:{id}:login:auth``。**不接受环境变量里的陈旧 token。**
    """
    resolved = _text(user_code) or os.getenv("USER_CODE", "").strip()
    if not resolved:
        raise DataCloudAuthError("USER_CODE 未配置")

    init_auth_redis()
    from by_framework.common.redis_client import get_redis  # type: ignore[import-untyped]

    redis = get_redis()
    real_user_id = _text(await redis.get(f"SHARE_BFM_USER_CODE_{resolved}"))
    # 映射键缺失时按 USER_CODE 直接查 auth 哈希——与 worker 保持同一条回退路径。
    auth = await redis.hgetall(f"user:{real_user_id or resolved}:login:auth")
    token = _text(auth.get("Beyond-Token")) or _text(auth.get(b"Beyond-Token"))
    if not token:
        raise DataCloudAuthError("Redis 中未找到当前用户的 Beyond-Token")
    return token


def _loop_worker(loop: asyncio.AbstractEventLoop, ready: threading.Event) -> None:
    asyncio.set_event_loop(loop)
    loop.call_soon(ready.set)
    loop.run_forever()


def _background_loop() -> asyncio.AbstractEventLoop:
    """进程级单一事件循环。

    `by_framework` 的 Redis 客户端是全局单例，**必须始终在同一个循环里使用**。
    改成每次 `asyncio.run()` 会让它跨循环，报出的错与真实原因毫无关系。
    """
    global _loop, _loop_thread, _loop_ready
    with _loop_lock:
        if _loop is None or _loop.is_closed():
            loop = asyncio.new_event_loop()
            ready = threading.Event()
            thread = threading.Thread(
                target=_loop_worker, args=(loop, ready),
                name="byclaw-caps-datacloud-asyncio", daemon=True,
            )
            _loop, _loop_ready, _loop_thread = loop, ready, thread
            thread.start()
        loop, ready = _loop, _loop_ready
    if ready is None or not ready.wait(timeout=5):
        raise RuntimeError("后台事件循环启动超时")
    return loop


def _int_env(name: str, default: int, low: int, high: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} 必须是整数") from exc
    if value < low or value > high:
        raise ValueError(f"{name} 必须在 {low} 到 {high} 之间")
    return value


def _is_timeout(exc: BaseException) -> bool:
    """从服务发现的异常链里认出超时。

    平台把它包了好几层；只看最外层类型会把超时当成普通失败去重试，白等两轮。
    """
    seen = set()
    current: BaseException | None = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, (TimeoutError, asyncio.TimeoutError)):
            return True
        if "timeout" in type(current).__name__.lower():
            return True
        if "timeout" in str(current).lower():
            return True
        current = current.__cause__ or current.__context__
    return False


def _raise_for_error(response: Any, body: dict[str, Any], path: str) -> None:
    if not response.is_success:
        raise ValueError(f"HTTP {response.status_code} {path}: {body}")
    if body.get("success") is False:
        raise ValueError(str(body.get("message") or body))
    if "code" in body and str(body["code"]) not in {"0", "200"}:
        raise ValueError(str(body.get("message") or body.get("msg") or body))
    if "resultCode" in body and str(body["resultCode"]) != "0":
        raise ValueError(str(body.get("resultMsg") or body))


async def _post_via_discovery(service: str, path: str, payload: dict[str, Any]) -> Any:
    from by_framework.core.discovery import DiscoveryClient  # type: ignore[import-untyped]
    from by_framework.util.discovery_http_client import DiscoveryHttpClient  # type: ignore[import-untyped]
    from by_framework.util.http_client import ByHttpClient, RetryConfig  # type: ignore[import-untyped]

    token = await resolve_beyond_token()
    discovery = DiscoveryClient(cache_interval=5)
    http_timeout = float(_int_env("DATACLOUD_HTTP_TIMEOUT_SECONDS",
                                  int(DEFAULT_HTTP_TIMEOUT_SECONDS), 5, 120))
    retry = RetryConfig(
        max_attempts=_int_env("DATACLOUD_RETRY_ATTEMPTS", DEFAULT_RETRY_ATTEMPTS, 1, 5),
        retry_on_status_codes={502, 503, 504},
    )
    http_client = ByHttpClient(base_url="", timeout=http_timeout,
                              retry_config=RetryConfig.no_retry())
    headers = {"Content-Type": "application/json", "Beyond-Token": token}
    try:
        async with http_client:
            async with DiscoveryHttpClient(discovery, http_client=http_client,
                                           retry_config=retry) as client:
                started = asyncio.get_running_loop().time()
                try:
                    return await client.post(service, path, headers=headers, json=payload)
                except Exception as exc:
                    elapsed = asyncio.get_running_loop().time() - started
                    if _is_timeout(exc) or elapsed >= http_timeout * 0.9:
                        error = TimeoutError(
                            f"DataCloud HTTP request exceeded {http_timeout:g} seconds")
                        error.code = "DATACLOUD_REQUEST_TIMEOUT"  # type: ignore[attr-defined]
                        raise error from exc
                    raise
    finally:
        await discovery.close()


def post_json(path: str, payload: dict[str, Any],
              service_name: str | None = None) -> dict[str, Any]:
    """同步入口。驱动只认这一个函数。"""
    service = (service_name or "").strip() or (
        os.environ.get(QUERY_SERVICE_ENV, "").strip() or QUERY_SERVICE_FALLBACK)
    loop = _background_loop()
    try:
        if asyncio.get_running_loop() is loop:
            raise RuntimeError("不能在服务发现后台事件循环中同步等待自身")
    except RuntimeError as exc:
        if "后台事件循环" in str(exc):
            raise
    future = asyncio.run_coroutine_threadsafe(
        _post_via_discovery(service, path, payload), loop)
    timeout = _int_env("DATACLOUD_REQUEST_TIMEOUT_SECONDS",
                       DEFAULT_REQUEST_TIMEOUT_SECONDS, 5, 120)
    try:
        response = future.result(timeout=timeout)
    except FutureTimeoutError as exc:
        future.cancel()
        error = TimeoutError(f"DataCloud request exceeded {timeout} seconds")
        error.code = "DATACLOUD_REQUEST_TIMEOUT"  # type: ignore[attr-defined]
        raise error from exc
    body = response.data
    if not isinstance(body, dict):
        raise ValueError(f"接口未返回 JSON 对象: {path}")
    _raise_for_error(response, body, path)
    return body
