#!/usr/bin/env python3
"""风格档 CLI。

**这项能力此前只有库函数，没有 CLI 也没有 SKILL.md**——于是
`build_image_prompt` 只被自己的测试调用过，三个出图的 Skill 一个都没提它。
和当初 `prereqs` 那次一样：能力在，但 agent 发现不了、也没有命令可跑。

退出码：`0` 成功 / `1` 业务失败 / `2` 用法错误或环境不具备。
未知风格档、场景描述不合格都是 **2**——那是调用方写错了参数，
改参数就能过，不是内容问题。
"""
from __future__ import annotations

import argparse

from byclaw_caps._cli import add_common, dispatch
from byclaw_caps.style import (
    PACKS, StyleError, build_image_prompt, check_pack_contrast, get_pack,
)


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="byclaw_caps.style", description="风格档：配色与生图提示词的单一来源")
    sub = parser.add_subparsers(dest="command", required=True)

    packs = sub.add_parser("packs", help="列出可用风格档")

    show = sub.add_parser("show", help="打印一个风格档的全部角色色值")
    show.add_argument("--pack", required=True)

    # **出图前走这条，不要自己拼提示词。** 骨架逐字固定、只有 scene 可变，
    # 是让「同一批图同调」成为机制而不是运气。
    prompt = sub.add_parser("prompt", help="由风格档生成生图提示词")
    prompt.add_argument("--pack", required=True)
    prompt.add_argument(
        "--scene", required=True,
        help="英文场景描述：机位与焦段、主体在画面何处、光从哪来打在什么上、"
             "有哪些使用痕迹、整体情绪。一句话撑不起一张图")

    check = sub.add_parser("check", help="校验正文与底色的亮度差")
    check.add_argument("--pack", required=True)

    for one in (packs, show, prompt, check):
        add_common(one)
    return parser


def handle(args: argparse.Namespace):
    if args.command == "packs":
        return {"ok": True, "packs": sorted(PACKS)}, 0
    if args.command == "show":
        return {"ok": True, "pack_id": args.pack, "pack": get_pack(args.pack)}, 0
    if args.command == "prompt":
        return {"ok": True, "pack_id": args.pack,
                "prompt": build_image_prompt(args.pack, scene=args.scene)}, 0
    issues = check_pack_contrast(get_pack(args.pack))
    # 对比度不足是**配置问题**：渲染会成功但字看不见，比渲染失败难发现。
    return {"ok": not issues, "pack_id": args.pack, "issues": issues}, 0


def main() -> int:
    return dispatch(build(), handle, usage_errors=(StyleError,))


if __name__ == "__main__":
    raise SystemExit(main())
