#!/usr/bin/env python3
"""视觉风格档：一条视频里三条素材来源共用的同一套色与骨架。

## 为什么是参数化的 pack，而不是又一篇规范

用户看到的问题是「一会素白信息图、一会全黑生图」。根因不是路由错了——
路由只回答「这一镜的图由谁生成」，**没回答「生成出来长什么样」**。

而三处颜色是**写死在代码里的常量**：

    REQUIRED_THEME = "hand-drawn"              # infographic 校验器
    VISUAL_DNA = "Pure white background..."    # 小黑提示词
    NORMALIZE_PAD_COLOR = "white"              # 视频归一化补边

再写一篇暗色规范，这三处照样按白底走：规范和代码各说一套，而**代码赢**。
所以要有一个 pack，让三条来源都从它取色。

## 默认一律不动

文章配图与图文卡片链路还在用 hand-drawn 白底。改默认会连带打坏那两条线，
所以新增的是**参数**，不是新的默认。

## 只锁颜色不够

同为暗色，一镜可能是 3D 科技渲染、一镜写实照片、一镜霓虹插画。
上一批四张恰好同调，是同一次会话里同一段提示词的运气，不是机制。
所以 pack 连 provider、模型、材质、光照、负面约束一起锁，
且**同一 pack 的提示词骨架逐字固定**——只有场景描述可变。
"""

from __future__ import annotations

import re

from typing import Any

VERSION = "1.0.0"

#: 一个 pack 必须给全的角色。缺一个就会有人就地编一个颜色出来。
REQUIRED_ROLES: tuple[str, ...] = (
    "background", "surface", "text", "muted", "accent", "sequence_accent", "border",
)

#: 正文与底色的最小亮度差（0–255）。低于此值渲染成功但字看不见——
#: 引擎的 dark 主题正是只改了 colorBg、正文色不跟着走。
MIN_TEXT_GAP = 90

#: 场景描述的最少词数。
#:
#: 旧版的场景描述是一句中文——「一个空旷的机房，一台机柜亮着」。
#: 614 字的提示词里，真正描述画面的只有这一句，其余全是配色和禁令。
#: 对照实验里把它扩到六句英文，同一个模型就出了走廊纵深、地面反光和体积感。
MIN_SCENE_WORDS = 25


class StyleError(RuntimeError):
    """未知风格档，或档内自身对比度不足。"""


PACKS: dict[str, dict[str, Any]] = {
    "technical-dark-v1": {
        "background": "#0f1115",
        "surface": "#171b22",
        "text": "#f0f2f5",
        "muted": "#949dab",
        "accent": "#b0563f",
        "sequence_accent": "#c8956c",
        "border": "rgba(214,235,251,.16)",
        "infographic_theme": "dark",
        "pad_color": "#0f1115",
        # 生图侧：连供应商与模型一并锁定，否则换个模型风格就飘了。
        "image_provider": "volcengine",
        "image_model": "doubao-seedream-5-0-260128",
        "medium": ("Cinematic technical illustration, photoreal render with matte "
                   "surfaces and fine micro-texture"),
        # 镜头语言。旧版只有配色和禁令，出来的是「一堆东西堆在那」——
        # 对照实验证明补上这一层，同一个模型就有了纵深与体积感。
        "camera": ("Prefer a decisive camera: state the angle (low / eye level / "
                   "overhead), a focal length (24mm wide, 50mm normal, 85mm compressed) "
                   "and depth of field. One clear focal subject, everything else "
                   "falling away"),
        # 材质与使用痕迹是「真实感」的主要来源，比配色更管用。
        "surface_detail": ("Real surfaces: brushed metal, matte plastic, polished concrete. "
                    "Show wear — settled dust, faint scuffs, a slightly ajar door. "
                    "Avoid showroom-clean perfection"),
        "lighting": ("Single directional key light plus faint ambient fill, soft "
                     "falloff, one luminous coral source, no lens flare"),
        "composition": ("16:9 wide, strong grid, generous negative space, "
                        "one subject against an otherwise neutral scene"),
        "negative": ("no text, no letters, no numbers, no captions, no watermarks, "
                     "no UI labels, no neon rainbow, no indiscriminate glow, "
                     "no dashboard tiles, no stock-photo people"),
    },
    "editorial-light-v1": {
        "background": "#ffffff",
        "surface": "#faf6f2",
        "text": "#1a1a1a",
        "muted": "#5a5a5a",
        "accent": "#b0563f",
        "sequence_accent": "#c8956c",
        "border": "#d8c4b6",
        "infographic_theme": "light",
        "pad_color": "white",
        "image_provider": "volcengine",
        "image_model": "doubao-seedream-5-0-260128",
        "medium": ("Clean editorial illustration, flat shapes with subtle paper "
                   "grain, no gradients"),
        "camera": ("Prefer a decisive viewpoint: state the angle and how much of the "
                   "scene is in frame. One clear focal subject, generous air around it"),
        "surface_detail": ("Paper-like surfaces with subtle grain and soft edge shadows. "
                    "A little imperfection — uneven edges, slight misalignment — "
                    "rather than vector-perfect shapes"),
        "lighting": "Even diffuse light, no dramatic shadows",
        "composition": ("16:9 wide, airy layout, generous white space, "
                        "one subject clearly dominant"),
        "negative": ("no text, no letters, no numbers, no captions, no watermarks, "
                     "no UI labels, no neon, no 3D render look"),
    },
}


def _luma(color: str) -> float:
    value = str(color or "").strip().lstrip("#")
    if len(value) == 3:
        value = "".join(ch * 2 for ch in value)
    if len(value) != 6:
        raise StyleError(f"颜色 {color!r} 不是 #rrggbb —— 猜一个会让对比度检查失去意义")
    r, g, b = (int(value[i:i + 2], 16) for i in (0, 2, 4))
    return 0.299 * r + 0.587 * g + 0.114 * b


def get_pack(pack_id: str) -> dict[str, Any]:
    """取风格档。

    **未知 id 直接报错，不回落默认。** 悄悄回到白底的话，
    「全片统一暗色」写了等于没写，而画面上要到成片才看得出来。
    """
    pack = PACKS.get(str(pack_id))
    if pack is None:
        raise StyleError(
            f"未知风格档 {pack_id!r}。可用：{'、'.join(sorted(PACKS))}。")
    return dict(pack)


def check_pack_contrast(pack) -> list[str]:
    """档内自洽：正文与次要文字压在底色上必须看得见。

    这条是照着一次真实失败写的：引擎的 dark 主题只改了 ``colorBg``，
    正文色不跟着走，于是标题深灰压近黑——**渲染成功、退出码 0，只是看不见**。
    """
    data = get_pack(pack) if isinstance(pack, str) else dict(pack or {})
    issues: list[str] = []
    background = data.get("background")
    for role in ("text", "muted"):
        try:
            gap = abs(_luma(data.get(role)) - _luma(background))
        except StyleError as exc:
            issues.append(str(exc))
            continue
        if gap < MIN_TEXT_GAP:
            issues.append(
                f"{role} {data.get(role)} 压在 background {background} 上亮度差只有 "
                f"{gap:.0f}（需 ≥ {MIN_TEXT_GAP}）——会渲染成功但看不见")
    return issues


def build_image_prompt(pack_id: str, *, scene: str) -> str:
    """由风格档生成生图提示词。

    **骨架逐字固定，只有 scene 可变。** 上一批四张恰好同调是运气；
    要成为机制，除场景外的每一个字都必须来自 pack。

    对场景描述有两条硬要求，都来自一次对照实验——同一模型、同一场景，
    只换提示词：旧版只有配色和一句中文场景，出来是「一堆东西堆在那」；
    新版补了机位、材质、光的落点，同一个模型就有了纵深与体积感。
    """
    pack = get_pack(pack_id)
    body = str(scene or "").strip()
    if not body:
        raise StyleError("scene 不能为空——没有场景描述，生成的是随机图")
    if len(body.split()) < MIN_SCENE_WORDS:
        raise StyleError(
            f"场景描述只有 {len(body.split())} 个词，少于 {MIN_SCENE_WORDS}——"
            "一句话撑不起一张图。写清楚：机位与焦段、主体在画面何处、"
            "光从哪来打在什么上、有哪些使用痕迹、整体情绪")
    if re.search(r"[\u4e00-\u9fff]", body):
        raise StyleError(
            "场景描述里有中文。骨架是英文，混语言会降低指令遵循度——请整段用英文写")
    return "\n".join([
        pack["medium"] + ".",
        "Camera: " + pack["camera"] + ".",
        f"Palette: background {pack['background']}, surface {pack['surface']}, "
        f"accent {pack['accent']} used as the single accent colour.",
        "Lighting: " + pack["lighting"] + ".",
        "Surfaces: " + pack["surface_detail"] + ".",
        "Composition: " + pack["composition"] + ".",
        # 文字一律交给确定性图层：AI 渲中文会出错字、糊字、少笔画，且不报错。
        "Constraints: " + pack["negative"] + ".",
        "",
        "Scene:",
        body,
    ])


__all__ = [
    "VERSION", "REQUIRED_ROLES", "MIN_TEXT_GAP", "StyleError", "PACKS",
    "get_pack", "check_pack_contrast", "build_image_prompt",
]
