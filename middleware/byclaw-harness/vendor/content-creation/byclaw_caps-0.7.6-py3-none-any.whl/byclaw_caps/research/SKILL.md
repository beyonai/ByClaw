---
name: research-contracts
description: 调研请求与证据包的契约校验。素材采集助理与选题／创作助理之间靠两个文件交接——写请求的用 check-request 自查，写证据包的用 check-pack 自查（带 --request 时一并查覆盖度）。当需要确认「这份请求提得对不对」「这份证据包交代全了没有」时使用。strength 词表的唯一定义也在这里。
---

# 调研契约

## 为什么要有它

助理之间**不互相调用**，靠两个文件交接：

```
2 号／3 号 → 1 号   .runtime/retrieval/research-request-<run_id>.yaml
1 号 → 2 号／3 号   .runtime/retrieval/evidence-pack-<run_id>.yaml
```

组长只搬路径、不看内容，**所以没有人在中间兜底**——契约错了没人发现，
下一棒拿着半份数据往下走，而且它不知道自己拿的是半份。

## 调用

```bash
python3 -m byclaw_caps.research check-request --input <请求文件>
python3 -m byclaw_caps.research check-pack --input <证据包> [--request <请求文件>]
python3 -m byclaw_caps.research vocabulary
```

退出码：`0` 通过／`1` 契约不合（回去改文件）／`2` 文件读不了。

**契约不合是业务失败不是用法错误。** 判成 `2` 的话，提示词教 agent
「退出码 2 的第一动作是报告不是重试」，它会去查命令怎么写，
而该改的是那个 YAML。

## 三条硬规则

### 一、请求里 `if_found` / `if_not_found` 必填，且不能相同

它同时干两件事：

- **让提问方先想清楚这条值不值得查**——写不出「查到／查不到分别导致什么判断」，
  说明它不影响决策，**查了是白花钱**；
- **让调研方知道该花多少预算**——两种结果差别越大，越值得用满 3 轮。

两者写成同一句会被拦下。那不是格式问题，**是这条问题本身没有意义**。

### 二、证据包的 `gaps` 必填

空数组可以，**缺字段不行**——缺了就分不清「没缺口」和「没想过缺口」。

「3 轮到顶仍不够」必须显式传下去，否则下游会**拿不确定的东西当确定的写**。
这一条堵的是 hallucination。

### 三、每个问题都要有交代

带 `--request` 时会查覆盖度：请求里每个 `question.id`，在 `findings`
或 `gaps` 里至少出现一次。

**问了没答也没标缺口是最坏的一种**——下一棒会默认「没查到相关的」，
而其实是漏查了。

反过来，`answers` 指向请求里没有的 id 也会被拦：
**多查的东西没人验证过必要性，而它花的是同一份预算。**

## `strength` 词表的唯一定义在这里

```bash
python3 -m byclaw_caps.research vocabulary
```

| 值 | 什么时候用 |
|---|---|
| `official_fact` | 官方直接来源明确陈述 |
| `source_synthesis` | 多个来源综合得出 |
| `author_inference` | 推断，来源不直接支持 |
| `metaphor` | 比喻，不是事实主张 |
| `roadmap` | 路线图，尚未交付 |

**与 ContentBrief 的 `claim_type` 是同一套词**，下游直接抄进
`evidence_pack.external_refs`，不必翻译也不该重新判定——
它们没看过原文，改不出更准的。

这套词原先**只写在散文里**（选题 Skill 与 content-brief-contract 各一份），
没有任何代码在守。现在定义在 `byclaw_caps.research.STRENGTHS`，
散文那几份由 `tests/skills/test_claim_type_vocabulary.py` 比对。

## 与其它能力的关系

检索本身走 `byclaw_caps.query --only-sources 联网检索`；
预算计数走 `byclaw_caps.workflow budget`。**这项能力只管契约，不发请求、不记账。**
