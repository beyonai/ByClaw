#!/usr/bin/env python3
"""调研契约校验 CLI。

**契约不合是业务失败（退出码 1），不是用法错误（2）。** 分错的后果很具体：
提示词教 agent「退出码 2 是环境不具备，第一动作是报告不是重试」，
而契约不合的正确动作恰恰是回去把文件改对。
"""
from __future__ import annotations

import argparse

from byclaw_caps._cli import add_common, business, dispatch
from byclaw_caps.research import (
    MODES, STRENGTHS, ResearchError, validate_evidence_pack,
    validate_research_request,
)


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="byclaw_caps.research", description="调研请求与证据包的契约校验")
    sub = parser.add_subparsers(dest="command", required=True)

    request = sub.add_parser(
        "check-request", help="校验调研请求（2 号／3 号 → 1 号）")
    request.add_argument("--input", required=True)

    pack = sub.add_parser(
        "check-pack", help="校验证据包（1 号 → 2 号／3 号）")
    pack.add_argument("--input", required=True)
    pack.add_argument("--request",
                      help="对应的调研请求；给了就一并查覆盖度——"
                           "问了没答也没标缺口是最坏的一种")

    vocab = sub.add_parser("vocabulary", help="打印 strength 与 mode 的封闭取值")

    for one in (request, pack, vocab):
        add_common(one)
    return parser


def handle(args: argparse.Namespace):
    if args.command == "vocabulary":
        return {"ok": True, "strengths": sorted(STRENGTHS), "modes": sorted(MODES)}, 0
    if args.command == "check-request":
        found = validate_research_request(args.input)
    else:
        found = validate_evidence_pack(args.input, request_path=args.request)
    return business({**found, "ok": found["status"] == "pass",
                     "input": args.input})


def main() -> int:
    return dispatch(build(), handle, usage_errors=(ResearchError,))


if __name__ == "__main__":
    raise SystemExit(main())
