#!/usr/bin/env python3
"""调研请求与证据包：两个助理之间的唯一依赖形态。

文章选题助理与素材调研助理**不互相调用**，靠两个文件交接：

    2 号／3 号 → 1 号   .runtime/retrieval/research-request-<run_id>.yaml
    1 号 → 2 号／3 号   .runtime/retrieval/evidence-pack-<run_id>.yaml

组长只搬路径、不看内容，所以**没有人在中间兜底**——契约错了没人发现，
下一棒拿着半份数据往下走，而且它不知道自己拿的是半份。

## 三条硬规则，各堵一种具体的坏结果

**一、请求里 `if_found` / `if_not_found` 必填，且两者不能一样。**
它让提问方先想清楚这条值不值得查——两种结果导向同一个判断的问题，
说明它不影响决策，查了是白花钱；也让调研方知道该在它身上花多少预算。

**二、证据包里 `gaps` 必填（可以是空数组，不能缺）。**
「3 轮到顶仍不够」必须显式传下去，否则文章创作助理会拿不确定的东西当确定的写。
缺字段和空数组是两件事：前者分不清「没缺口」和「没想过缺口」。

**三、请求里的每个问题，在证据包里必须有交代**——要么在 `findings`，
要么在 `gaps`。**问了没答也没标缺口是最坏的一种**：下一棒会默认
「没查到相关的」，而其实是漏查了。

## strength 词表的归属

`findings[].strength` 用的是 ContentBrief `claim_type` 那套词。
这套词原先**只写在散文里**（`discover-writing-topics/SKILL.md` 与
`content-brief-contract.md` 各一份），没有任何代码在守它——
于是它是这个仓库最典型的那类漂移风险：两份副本靠没人改过维持一致。

现在**唯一定义在这里**，散文那两份由 `tests/skills/` 的一条测试比对。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

VERSION = "1.0.0"

#: 主张强度。**唯一定义在这里**，散文里的两份由测试比对。
#:
#: 与 ContentBrief 的 `claim_type` 同一套词，下游不必翻译——
#: 证据包里的 `official_fact` 直接抄进 ArticlePlan 就是对的。
STRENGTHS: frozenset[str] = frozenset({
    "official_fact",      # 官方直接来源明确陈述
    "source_synthesis",   # 多个来源综合得出
    "author_inference",   # 作者推断，来源不直接支持
    "metaphor",           # 比喻，不是事实主张
    "roadmap",            # 路线图，尚未交付
})

#: 检索模式。两份 reference 互斥，一次只读一个。
MODES: frozenset[str] = frozenset({"storm", "deep"})

#: `raw_pages` 是路径不是内容。塞正文进去，等于把上下文污染又搬回来了。
RAW_PAGES_MAX = 200


class ResearchError(ValueError):
    """文件读不了或参数说不通——用法错误，不是内容不合格。"""


def _load(path: Path | str) -> dict[str, Any]:
    import yaml

    target = Path(path)
    if not target.is_file():
        raise ResearchError(f"文件不存在：{target}")
    try:
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ResearchError(f"{target} 不是合法 YAML：{exc}") from None
    if not isinstance(data, dict):
        raise ResearchError(f"{target} 的根节点必须是对象")
    return data


def _text(node: Any, key: str) -> str:
    return str((node or {}).get(key) or "").strip() if isinstance(node, dict) else ""


def validate_research_request(path: Path | str) -> dict[str, Any]:
    """校验调研请求。返回失败清单，不抛异常——内容不合格是业务结果。"""
    data = _load(path)
    failures: list[str] = []

    if not _text(data, "run_id"):
        failures.append("run_id 不能为空——证据包要靠它对上是哪一次请求")

    mode = _text(data, "mode_hint")
    if mode and mode not in MODES:
        failures.append(f"mode_hint 必须为 {'|'.join(sorted(MODES))}，实际 {mode}")

    questions = data.get("questions")
    if not isinstance(questions, list) or not questions:
        failures.append("questions 不能为空——报「要调研」却不说查什么，对方无从下手")
        questions = []

    seen: set[str] = set()
    for index, item in enumerate(questions, 1):
        if not isinstance(item, dict):
            failures.append(f"questions[{index}] 必须是对象")
            continue
        qid = _text(item, "id") or f"questions[{index}]"
        if not _text(item, "id"):
            failures.append(f"{qid}.id 不能为空——证据包的 answers 要引用它")
        elif qid in seen:
            # id 重了，证据包的 answers 就指不明白是哪一条。
            failures.append(f"{qid} 重复：问题 id 必须唯一")
        seen.add(qid)

        if not _text(item, "question"):
            failures.append(f"{qid}.question 不能为空")
        found, not_found = _text(item, "if_found"), _text(item, "if_not_found")
        for field, value in (("if_found", found), ("if_not_found", not_found)):
            if not value:
                failures.append(
                    f"{qid}.{field} 不能为空——写不出「这条查到／查不到分别导致什么判断」，"
                    "说明它不影响决策，查了是白花钱")
        if found and not_found and found == not_found:
            failures.append(
                f"{qid} 的 if_found 与 if_not_found 相同：两种结果导向同一个判断，"
                "这条不影响决策，不该提")

    return {"status": "fail" if failures else "pass", "failures": failures,
            "question_ids": sorted(seen)}


def validate_evidence_pack(path: Path | str, *,
                           request_path: Path | str | None = None) -> dict[str, Any]:
    """校验证据包。给了 `request_path` 就一并查覆盖度。"""
    data = _load(path)
    failures: list[str] = []

    if not _text(data, "run_id"):
        failures.append("run_id 不能为空")
    mode = _text(data, "mode")
    if mode not in MODES:
        failures.append(f"mode 必须为 {'|'.join(sorted(MODES))}，实际 {mode or '空'}")
    if not _text(data, "retrieved_at"):
        failures.append("retrieved_at 不能为空——时效内容要标「信息检索于」")

    # **必填，可以是空数组。** 缺字段分不清「没缺口」和「没想过缺口」。
    if "gaps" not in data:
        failures.append(
            "缺少 gaps 字段——「3 轮到顶仍不够」必须显式传下去，"
            "否则下一棒会拿不确定的东西当确定的写。没有缺口就写空数组")
    elif not isinstance(data.get("gaps"), list):
        failures.append("gaps 必须是数组")

    raw = str(data.get("raw_pages") or "")
    if len(raw) > RAW_PAGES_MAX or "\n" in raw:
        failures.append(
            "raw_pages 必须是路径不是内容——把网页正文塞进证据包，"
            "等于把上下文污染又搬回来了")

    answered: set[str] = set()
    findings = data.get("findings")
    if findings is not None and not isinstance(findings, list):
        failures.append("findings 必须是数组")
        findings = []
    for index, item in enumerate(findings or [], 1):
        if not isinstance(item, dict):
            failures.append(f"findings[{index}] 必须是对象")
            continue
        label = _text(item, "answers") or f"findings[{index}]"
        answered.add(_text(item, "answers"))
        if not _text(item, "claim"):
            failures.append(f"{label}.claim 不能为空")
        strength = _text(item, "strength")
        if strength not in STRENGTHS:
            failures.append(
                f"{label}.strength 必须为 {'|'.join(sorted(STRENGTHS))}，"
                f"实际 {strength or '空'}")
        sources = item.get("sources")
        if not isinstance(sources, list) or not sources:
            # 没有来源的 finding 就是模型记忆，那正是这套东西要堵的。
            failures.append(f"{label}.sources 不能为空——没有来源的结论就是模型记忆")
            continue
        for order, source in enumerate(sources, 1):
            if not _text(source, "url"):
                failures.append(f"{label}.sources[{order}].url 不能为空")

    for index, item in enumerate(data.get("gaps") or [], 1):
        if isinstance(item, dict):
            answered.add(_text(item, "answers"))
            if not _text(item, "reason"):
                failures.append(f"gaps[{index}].reason 不能为空——"
                                "说不清为什么查不到，下一棒无从判断要不要另找路子")
    answered.discard("")

    if request_path is not None:
        request = validate_research_request(request_path)
        asked = set(request["question_ids"])
        missing = sorted(asked - answered)
        if missing:
            # 比缺 gaps 更坏：下一棒会默认「没查到相关的」，而其实是漏查了。
            failures.append(
                f"这些问题在证据包里没有交代：{'、'.join(missing)}——"
                "查到了写 findings，查不到写 gaps，两者都没有等于漏查")
        extra = sorted(answered - asked)
        if extra:
            failures.append(
                f"这些 answers 不在请求里：{'、'.join(extra)}——"
                "多查的东西没人验证过必要性，而它花的是同一份预算")

    return {"status": "fail" if failures else "pass", "failures": failures,
            "answered": sorted(answered)}


__all__ = [
    "STRENGTHS", "MODES", "RAW_PAGES_MAX", "VERSION",
    "ResearchError", "validate_research_request", "validate_evidence_pack",
]
