"""Small deterministic I/O helpers; no service imports or secret logging."""
from __future__ import annotations
import hashlib, html, importlib.util, json, math, os, re, time
from contextlib import contextmanager
from pathlib import Path

def read_json(path, default=None):
    p=Path(path)
    return json.loads(p.read_text(encoding="utf-8-sig")) if p.is_file() else default

def dumps(obj):
    return json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)+"\n"

def digest(value):
    if not isinstance(value, bytes): value=dumps(value).encode("utf-8")
    return hashlib.sha256(value).hexdigest()

def atomic(path, text):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    temp=p.with_name(p.name+".tmp")
    temp.write_text(text, encoding="utf-8", newline="")
    temp.replace(p)

def load_module(name, path):
    spec=importlib.util.spec_from_file_location(name, path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def stamp(path, content=False):
    p=Path(path)
    if not p.is_file(): return {"path":str(p.resolve()),"exists":False}
    s=p.stat()
    r={"path":str(p.resolve()),"exists":True,"size":s.st_size,"mtime_ns":s.st_mtime_ns}
    if content: r["sha256"]=digest(p.read_bytes())
    return r

def plain(text):
    return re.sub(r"([\\*_\[\]|])", r"\\\1", html.escape(str(text if text is not None else ""),quote=False).replace("\n"," ")).replace(chr(96),"&#96;")

def link(label, path):
    if not path: return "未提供"
    p=Path(path)
    if not p.is_file(): return plain(label)+"（不可访问）"
    target=p.resolve().as_posix().replace("%","%25").replace("#","%23").replace("<","%3C").replace(">","%3E")
    return f"[{plain(label)}](<{target}>)"

def number(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)

def schema_check(value, schema):
    try: import jsonschema
    except ImportError as exc: raise RuntimeError("需要 jsonschema；请选择已安装它的Python运行入口") from exc
    jsonschema.Draft202012Validator(read_json(schema)).validate(value)

def verify_managed(root):
    root=Path(root); m=read_json(root/".machine/manifest.json",{})
    for name, expected in m.get("output_sha256",{}).items():
        p=root/name
        if not p.is_file() or (digest(p.read_bytes())!=expected and digest(p.read_bytes().replace(b"\r\n",b"\n"))!=expected):
            raise RuntimeError("检测到人工修改或文件缺失，拒绝覆盖："+str(p))
    return m

def write_bundle(root, files, metadata):
    root=Path(root); previous=verify_managed(root)
    for name, text in files.items():
        p=root/name
        if p.is_file() and name not in previous.get("output_sha256",{}) and p.read_bytes()!=text.encode("utf-8"):
            raise RuntimeError("已有未受管文件，拒绝覆盖："+str(p))
    if previous and previous.get("input_fingerprint")!=metadata.get("input_fingerprint"):
        archive=root/".machine/history"/str(time.time_ns())
        for name in previous.get("output_sha256",{}):
            p=root/name
            if p.is_file(): atomic(archive/name,p.read_text(encoding="utf-8"))
        atomic(archive/"manifest.json",dumps(previous))
    stale=set(previous.get("output_sha256",{}))-set(files)
    if stale: raise RuntimeError("输出集合缩小，请使用新目录保留旧审核结果："+",".join(sorted(stale)))
    for name,text in files.items(): atomic(root/name,text)
    meta=dict(metadata,output_sha256={n:digest(t.encode("utf-8")) for n,t in files.items()})
    atomic(root/".machine/manifest.json",dumps(meta))
    return meta

@contextmanager
def lock(root):
    p=Path(root)/".machine/run.lock"; p.parent.mkdir(parents=True,exist_ok=True)
    try: fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError as exc: raise RuntimeError("分析包正在执行或上次中断；核查后处理run.lock") from exc
    os.close(fd)
    try: yield
    finally: p.unlink(missing_ok=True)
