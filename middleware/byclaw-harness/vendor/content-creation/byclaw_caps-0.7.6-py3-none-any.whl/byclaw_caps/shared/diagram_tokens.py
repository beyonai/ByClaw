#!/usr/bin/env python3
"""文章配图的设计令牌：层级色板、语义色、中性阶、字阶、画幅档位。

本文件要被整份注入进 illustrate-article 的 `scripts/`（见 `build_skill_zips.py`
的 `SHARED_LIBS`），故**不能 import byclaw_caps**，只能是纯标准库。
与 `channel_specs.py` 同一条通道、同一条约束。

## 为什么令牌要从代码下发，而不是写在参考档里让模型抄

`compile_article_visual_plan.py` 原先下发的是 `palette: []` 与 `typography: ""`。
空令牌的后果不是"没有风格"，是**每张图现场发明一套配色**——
同一篇文章里第一层在图 1 是紫的、到图 3 变成绿的，而这种不一致
机器查不出来，人也要把五张图并排摆开才看得见。

参考档（`references/article-visual/diagram-design-system.md`）讲的是**怎么用**，
本文件是**用什么**。两处的色值必须一致，由 `tests/test_diagram_tokens.py` 强制——
不是靠写的人记得两边一起改。
"""

from __future__ import annotations

# ── 层级色：色 = 语义 ───────────────────────────────────────────────
# 每层三档：deep 用于描边与标题，solid 用于实心块与图标，soft 用于填充底。
#
# **`tier-N` 是"第 N 类"，不预设谁在上谁在下。** 分层图把最上面配 tier-1
# 或把基础层配 tier-1 都合理——唯一的硬要求是**同一篇文章里同一个实体永远同一个令牌**。
# 让每张图自己挑颜色，挑出来的必然是每张都合理、放在一起不成套。
TIER_PALETTE: dict[str, dict[str, str]] = {
    "tier-1": {"deep": "#5B21B6", "solid": "#7C3AED", "soft": "#F3E8FF", "role": "第一类（调度者／根节点／最上层）"},
    "tier-2": {"deep": "#1E40AF", "solid": "#3B82F6", "soft": "#EFF6FF", "role": "第二类（中间层／路由）"},
    "tier-3": {"deep": "#166534", "solid": "#22C55E", "soft": "#F0FDF4", "role": "第三类（执行单元／叶子／基础层）"},
    "tier-4": {"deep": "#9A3412", "solid": "#F97316", "soft": "#FFF7ED", "role": "第四类（外部系统／旁路）"},
}

# ── 语义色：编码方向与状态，不编码层级 ────────────────────────────────
SEMANTIC_COLORS: dict[str, str] = {
    "flow_out": "#EA580C",      # 下行 / 调用 / 请求
    "flow_back": "#2563EB",     # 上行 / 返回 / 响应
    "negated": "#94A3B8",       # 不存在的连接：灰虚线 + ×
    "highlight_bg": "#FEF08A",  # 正文内嵌高亮词条
    "highlight_ink": "#854D0E",
}

# ── 中性阶：偏冷，与层级色协调。深色不用纯黑，浅色不用纯灰 ──────────────
NEUTRALS: dict[str, str] = {
    "ink": "#0F172A",       # 图内主标题
    "ink_2": "#334155",     # 节点主名、面板标题
    "ink_3": "#64748B",     # 说明文字、代码标识
    "ink_4": "#94A3B8",     # 次要标注
    "line": "#E2E8F0",      # 分割线、次要描边
    "canvas": "#F7F8FA",    # 画布底
    "surface": "#FFFFFF",   # 节点底、面板底
}

FONT_STACK_SANS = (
    '"PingFang SC","Microsoft YaHei","Noto Sans CJK SC",'
    '"Source Han Sans SC",-apple-system,sans-serif'
)
FONT_STACK_MONO = (
    '"JetBrains Mono","SFMono-Regular",Consolas,'
    '"Noto Sans Mono CJK SC",monospace'
)

# ── 字阶 ──────────────────────────────────────────────────────────
# 按 1280px 宽设计，落地系数见 `render_scale`。
# **第三列（落地字号）才是判断"看不看得清"的那个数**，设计字号不是。

#: 图片在读者屏幕上的实际显示宽度，缺省值。
#:
#: ⛔ **这是缺省，不是事实。** 真实显示宽度取决于读者的视口与正文的左右留白：
#: 420px 手机视口、正文两侧各留 28px 时，图片只有约 364px 宽——
#: 按 677 算出来的落地字号会**系统性高估 1.86 倍**。
#:
#: 实测过高估的后果：一张图内刻度 16px、行名 21px、数值 23px，
#: 按 677 判是「通过」，读者那边的等效字号只有 4.6 / 6.0 / 6.5px，必须放大才看得清。
#:
#: 所以凡是知道真实宽度的调用方**都应当传进来**（`inspect_visual(display_width=…)`）。
#: 这个常量只在「确实不知道显示多宽」时兜底。
DEFAULT_DISPLAY_WIDTH = 677

#: 旧名。保留是因为外部可能已经在引用，新代码用 `DEFAULT_DISPLAY_WIDTH`。
WECHAT_BODY_DISPLAY_WIDTH = DEFAULT_DISPLAY_WIDTH
TYPE_SCALE: dict[str, dict[str, object]] = {
    "figure_title": {"size": 44, "weight": 700, "use": "整图标题，一张图至多一个"},
    "panel_title": {"size": 30, "weight": 700, "use": "复合图里每个面板的小标题"},
    "node_name":   {"size": 28, "weight": 600, "use": "方块里的中文主名"},
    "prose":       {"size": 20, "weight": 400, "use": "面板里的成句说明"},
    "identifier":  {"size": 18, "weight": 400, "use": "代码标识，等宽", "mono": True},
    "edge_label":  {"size": 18, "weight": 500, "use": "连线上的『调用』『返回』"},
    "tag":         {"size": 16, "weight": 500, "use": "芯片、角标"},
}

#: 设计稿上的字号下限。**它不是「看不看得清」的判据**——
#: 同一份设计稿放大一倍出 PNG，这个数不变，而字在页面上占多宽也不变。
#: 判读者看不看得清用 `MIN_LANDING_FONT_PX`。
MIN_FONT_PX = 16
#: 承担论证的文字（不只是标签）的设计字号下限。
MIN_ARGUMENT_FONT_PX = 18

#: **落地字号的硬下限**，低于此拒绝出图。
#:
#: 取 8.0 是为了与改判据之前的实际行为对齐：旧代码筛「设计字号 < 16」，
#: 在 677 显示宽下等价于落地 8.46px。**这一步只把判据换对，不顺手收紧**——
#: 收紧要另外做，而且要先拿一批历史图校准（现存三张图的最小落地字号全是 8.5，
#: 一改就会集体判红，那不是校准出来的结论）。
#:
#: 真正的改善来自把**真实显示宽度**传进来：同样这三张图，677 宽下落地 8.5px
#: 勉强过线，塞进 364px 的手机正文里只有 4.5px——那时它们会红，而且该红。
MIN_LANDING_FONT_PX = 8.0

#: 落地字号的**舒适线**。低于此只告警，不阻断。
#:
#: 8px 是「勉强能认」，不是「读得舒服」。正文是 16px，图里承载数值的文字
#: 掉到它的一半以下，读者就得放大——而放大过的图基本不会再被读第二遍。
COMFORTABLE_LANDING_FONT_PX = 12.0

# ── 尺寸的三个量 ──────────────────────────────────────────────────
# "尺寸"一个词原先同时指三件事，于是必然打架：`raster` 默认 2 倍出图，
# 而 `image verify` 与 `finalize-assets` 都要求像素严格等于计划里的宽高。
# 2026-09-11 实测中助理据此把图重渲成 1 倍——**为了过门禁而降了清晰度**，
# 而且它在日志里把这个矛盾说清楚了，只是无从选择。
#
# 三个量各有各的名字，不再共用"尺寸"：
#
#   layout     HTML 的 CSS 画布，如 1280×800。骨架按它排版，字号换算按它做。
#   scale      渲染倍率，`raster --scale`。
#   delivered  实际交付的 PNG 像素 = layout × scale。清单与校验按它比。
#
#: 确定性渲染的交付倍率。公众号正文图按约 677px 宽显示，1 倍在高分屏上偏软。
DELIVERY_SCALE = 2
#: 这些生成方式的产物尺寸由渲染器决定，倍率恒为 1：
#: `ai_image` 按请求尺寸出图，`cover_composite` 由 compose_cover 精确合成到 900×383，
#: `source_asset` 是既有截图。给它们乘 2 只会让校验拿错的期望值去比真实文件。
UNSCALED_METHODS = frozenset({"ai_image", "cover_composite", "source_asset"})


def delivery_scale_for(generation_method: object) -> int:
    """按生成方式定交付倍率。**不是让调用方随便填的数。**"""
    return 1 if str(generation_method or "") in UNSCALED_METHODS else DELIVERY_SCALE


def delivered_size(layout_width: int, layout_height: int, scale: int) -> tuple[int, int]:
    """layout × scale → 交付像素。清单、`verify`、`finalize` 三处共用这一个换算。"""
    if layout_width <= 0 or layout_height <= 0:
        raise ValueError("layout 宽高必须为正")
    if scale <= 0:
        raise ValueError("scale 必须为正")
    return layout_width * scale, layout_height * scale


def render_scale(design_width: int,
                 display_width: int | None = None) -> float:
    """设计宽度 → 读者眼里的缩放系数。**不舍入。**

    1280 设计宽落到 677 显示宽是 0.5289；落到手机上的 364 宽只有 0.2844。

    ⛔ **不要用 `landing_px(1.0, w)` 当缩放系数。** 那个函数会把结果舍到
    一位小数，`0.5289` 出来就是 `0.5`——系数本身先掉了 5.5%，
    再拿去乘每一处字号，误差一路带进统计。要系数就用这个函数。
    """
    if design_width <= 0:
        raise ValueError("design_width 必须为正")
    width = DEFAULT_DISPLAY_WIDTH if display_width is None else int(display_width)
    if width <= 0:
        raise ValueError("display_width 必须为正")
    return width / design_width


def landing_px(design_px: float, design_width: int = 1280,
               display_width: int | None = None) -> float:
    """设计字号 → 落地字号。判断"看不看得清"用这个数。

    **返回值是给人看的**（保留一位小数）；要拿它做后续计算，用 `render_scale`。
    """
    return round(design_px * render_scale(design_width, display_width), 1)


def global_style(style_id: str = "editorial") -> dict[str, object]:
    """下发给渲染环节的 `VisualPlan.global_style`。

    **不再下发空 palette。** 空令牌不等于"没有风格"，等于"每张图自己发明一套"。
    """
    return {
        "style_id": style_id,
        "palette": [
            {"token": token, "role": spec["role"],
             "deep": spec["deep"], "solid": spec["solid"], "soft": spec["soft"]}
            for token, spec in TIER_PALETTE.items()
        ],
        "semantic_colors": dict(SEMANTIC_COLORS),
        "neutrals": dict(NEUTRALS),
        "typography": {
            "sans": FONT_STACK_SANS,
            "mono": FONT_STACK_MONO,
            "scale": {k: dict(v) for k, v in TYPE_SCALE.items()},
            "min_font_px": MIN_FONT_PX,
            "min_argument_font_px": MIN_ARGUMENT_FONT_PX,
            "wechat_body_display_width": WECHAT_BODY_DISPLAY_WIDTH,
        },
        # layout → 骨架。**`paired` 与 `matrix` 原先都指向 layered**，
        # 而 layered 是层级拓扑，拿它做左右对照南辕北辙；2026-09-11 那篇要的
        # 正是 3 张对照 + 1 张矩阵，一张都套不上，于是只能从零手写。
        "skeletons": {
            "layered": "references/article-visual/skeletons/layered.html",
            "comparison": "references/article-visual/skeletons/comparison.html",
            "matrix": "references/article-visual/skeletons/matrix.html",
            "nested": "references/article-visual/skeletons/nested.html",
            "composite": "references/article-visual/skeletons/composite.html",
        },
        "consistency_rules": [
            "事实结构图使用确定性渲染",
            "不添加 evidence_refs 之外的产品能力、数据或结论",
            "同一作品的颜色、字体、圆角和线条保持一致",
            "实体 → 颜色的映射全篇统一：同一个实体在每张图里都是同一个 tier token",
            "不引入 palette 与 semantic_colors 之外的颜色，图标与图表同此",
            f"所有文字设计字号不低于 {MIN_FONT_PX}px，承担论证的不低于 {MIN_ARGUMENT_FONT_PX}px",
            "图标一律内联 SVG + currentColor，禁用 emoji",
        ],
    }


# 允许的色值全集，供 `image inspect` 的色板合规检查取用。
def allowed_colors() -> frozenset[str]:
    values: set[str] = set()
    for spec in TIER_PALETTE.values():
        values.update({spec["deep"], spec["solid"], spec["soft"]})
    values.update(SEMANTIC_COLORS.values())
    values.update(NEUTRALS.values())
    return frozenset(v.upper() for v in values)


__all__ = [
    "TIER_PALETTE", "SEMANTIC_COLORS", "NEUTRALS",
    "FONT_STACK_SANS", "FONT_STACK_MONO", "TYPE_SCALE",
    "MIN_FONT_PX", "MIN_ARGUMENT_FONT_PX", "WECHAT_BODY_DISPLAY_WIDTH",
    "DELIVERY_SCALE", "UNSCALED_METHODS", "delivery_scale_for", "delivered_size",
    "render_scale", "landing_px", "global_style", "allowed_colors",
]
