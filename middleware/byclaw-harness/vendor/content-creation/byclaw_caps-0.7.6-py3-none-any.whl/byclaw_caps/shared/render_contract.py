"""呈现阶段的公共契约：两层指纹与失配阻断。

配图与排版共用。方案见 `docs/创作优化方案3/临时方案/配图语义规划方案.md` §三。

**为什么是两层，而不是一个指纹。**

一个指纹办不了两件事：

- 「渠道包与预览用的是不是同一套输入」——要**跨产物比**，所以里面不能有
  两份产物本来就该不同的东西（地址、角色）；
- 「这一份产物自己有没有过期」——要**各自与当前输入比**，而恰恰是地址
  这类东西最容易悄悄改掉。

把二者压成一个指纹，会同时得到误拦（渠道包 `channel` 与预览 `preview` 永远
不相等，正常交付被拦）和漏检（为了让两份地址可以不同而把地址整个排除出比较，
于是映射从 A 改成 B、旧 HTML 仍指向 A，没有任何东西会报）。两处都真实发生过。

所以：

| 层 | 结构 | 比法 |
|---|---|---|
| 一 | `render_input` | 渠道包 ≟ 预览，**必须相同** |
| 二 | `consumption` | **各自**与当前输入、与自己的 HTML 比 |

资产身份 `(id, sha256)` 是两层的分界线，**只存在于第一层**。第二层按 `id`
关联，不重记 `sha256`——存两处就会漂，而漂的正好是判定基准。
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

#: 契约结构版本。字段有增减即视为不兼容——**不做"多一个字段就忽略"的宽容解析**，
#: 那会让新旧两版产物互相认为对方合法。
SCHEMA_VERSION = "1.0"

#: 一份产物是渠道包还是预览。**整份产物的属性，不是逐张图的属性**，
#: 所以在 `consumption` 顶层而不在 `consumption.assets` 里。
ROLE_CHANNEL = "channel"
ROLE_PREVIEW = "preview"
SRC_ROLES = (ROLE_CHANNEL, ROLE_PREVIEW)

#: 地址与源资产的绑定证据强度。
#: `declared` **不得用于渠道包**——渠道包一旦群发不可撤回，人工声明不是证据。
BINDING_UPLOAD_RECORD = "upload_record"
BINDING_CONTENT_VERIFIED = "content_verified"
BINDING_DECLARED = "declared"
#: 还没上传，地址就是本地文件。**这是排版阶段的正常状态**——
#: 上传发生在发布阶段，排版产出的渠道包本来就引用本地图。
#: 把它当成"缺映射"拦下来，等于要求排版去做发布阶段的事。
BINDING_LOCAL_FILE = "local_file"
BINDING_TYPES = (BINDING_UPLOAD_RECORD, BINDING_CONTENT_VERIFIED,
                 BINDING_DECLARED, BINDING_LOCAL_FILE)

#: 渠道包接受的绑定强度。
#:
#: `local_file` 在这里：排版阶段的渠道包引用本地图是正常的，
#: 它的正确性由"文件在不在、哈希对不对"保证，而不是由上传回执保证——
#: **那两件事由 `_verify_local_file` 当场去磁盘上查**。
#: 光把 `local_file` 列进来而不查，等于给本地图发了一张免检证：
#: 实测过，编译验收之后把 PNG 删掉、或同名换一张，门禁都放行。
#: 发布阶段把本地引用换成 CDN 链接时，那一步要出 `upload_record`。
CHANNEL_BINDING_TYPES = (BINDING_UPLOAD_RECORD, BINDING_CONTENT_VERIFIED,
                         BINDING_LOCAL_FILE)

# ── 错误码 ────────────────────────────────────────────────────────────────
#
# 按「差在哪一环」分，不合并成一个笼统的失败。
# 合并之后调用方只知道"不一致"，得自己去猜是正文改了、计划改了还是图换了——
# 而这三件事的修法完全不同。

INPUT_FINGERPRINT_MISMATCH = "INPUT_FINGERPRINT_MISMATCH"
PLAN_FINGERPRINT_MISMATCH = "PLAN_FINGERPRINT_MISMATCH"
ASSET_VERSION_MISMATCH = "ASSET_VERSION_MISMATCH"
#: 本地图对不上：文件没了，或同名换了一张。
#:
#: **与 `ASSET_VERSION_MISMATCH` 分开。** 那个说的是"记录之间对不上"，
#: 修法是重新编译；这个说的是"磁盘上的图不是验收过的那张",
#: 重新编译只会把坏的那张重新编一遍。
LOCAL_ASSET_MISSING = "LOCAL_ASSET_MISSING"
RENDER_INPUT_MISMATCH = "RENDER_INPUT_MISMATCH"
REVIEW_STALE = "REVIEW_STALE"

ERROR_CODES = (
    INPUT_FINGERPRINT_MISMATCH,
    PLAN_FINGERPRINT_MISMATCH,
    ASSET_VERSION_MISMATCH,
    LOCAL_ASSET_MISSING,
    RENDER_INPUT_MISMATCH,
    REVIEW_STALE,
)


class ContractError(ValueError):
    """契约失配。**带错误码和差在哪**，不是一句"校验失败"。"""

    def __init__(self, code: str, message: str, **detail: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.detail = detail

    def as_dict(self) -> dict:
        return {"ok": False, "code": self.code, "message": self.message,
                **self.detail}


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_file(path: str | Path) -> str:
    """文件内容哈希。

    **统一小写十六进制。** 曾经因为一侧大写、一侧小写，把每一张合法资产都判成
    失配——大小写不是"格式细节"，它决定了比较结果。
    """
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json(payload: Mapping[str, Any]) -> str:
    """规范化序列化：键按字典序、无多余空白、不转义非 ASCII。

    指纹必须对**内容**敏感、对**书写方式**不敏感。缩进或键序变一下就换一个
    指纹，等于每次重新序列化都报失配。
    """
    return json.dumps(payload, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False)


# ── 第一层：两份产物的共同指纹 ────────────────────────────────────────────


def build_render_input(
    *,
    content_sha256: str,
    plan_sha256: str,
    assets: Sequence[Mapping[str, Any]],
    theme: str,
    layout_profile: str,
    reading_profile: str = "default",
    article_plan_sha256: str = "",
    component_plan_sha256: str = "",
    theme_file_sha256: str = "",
    renderer_sha256: str = "",
    image_fit: str,
    glossary_sha256: str = "",
    compiler_version: str,
) -> dict:
    """组装第一层对象。

    `assets` 只取 `id` 与 `sha256`——**多给的字段一律丢掉**，不是为了整洁：
    `src` 或 `src_role` 漏进来，两份产物的指纹就再也不可能相等。
    """
    normalized = []
    for asset in assets:
        asset_id = str(asset["id"])
        digest = str(asset["sha256"]).lower()
        normalized.append({"id": asset_id, "sha256": digest})
    normalized.sort(key=lambda item: item["id"])
    result = {
        "schema_version": SCHEMA_VERSION,
        "content_sha256": str(content_sha256).lower(),
        "plan_sha256": str(plan_sha256).lower(),
        "assets": normalized,
        "theme": theme,
        "layout_profile": layout_profile,
        "image_fit": image_fit,
        "glossary_sha256": str(glossary_sha256 or "").lower(),
        "compiler_version": compiler_version,
    }
    # 缺省与历史契约完全相同；只有改变渲染的故事预设才扩展指纹。
    if reading_profile != "default":
        result["reading_profile"] = reading_profile
    if article_plan_sha256:
        result["article_plan_sha256"] = str(article_plan_sha256).lower()
    if component_plan_sha256:
        result["component_plan_sha256"] = component_plan_sha256.lower()
    if theme_file_sha256:
        result["theme_file_sha256"] = theme_file_sha256.lower()
    if renderer_sha256:
        result["renderer_sha256"] = renderer_sha256.lower()
    return result


#: 历史字段必需；两个后加字段缺省等价于 default / 未提供 ArticlePlan。
RENDER_INPUT_KEYS = frozenset({
    "schema_version", "content_sha256", "plan_sha256", "assets",
    "theme", "layout_profile", "image_fit", "glossary_sha256",
    "compiler_version", "reading_profile", "article_plan_sha256",
    "component_plan_sha256", "theme_file_sha256", "renderer_sha256",
})

#: **永远不许出现在第一层的键。** 单独列出来是因为放进去不会报错，
#: 只会让两份产物永不相等——那种失败看起来像"数据不一致"，查很久才发现是结构错了。
FORBIDDEN_IN_RENDER_INPUT = frozenset({"src", "src_role", "src_binding",
                                       "image_map_sha256"})


def render_input_sha256(render_input: Mapping[str, Any]) -> str:
    """第一层指纹 = 整个对象的规范化序列化。

    **没有"排除某字段"这一说**：该对象里本来就不含 `src` / `src_role`，
    所以"序列化整个对象"就等于"全部字段参与"。一旦需要排除规则，
    说明有东西放错了层。
    """
    _assert_render_input_shape(render_input)
    normalized = dict(render_input)
    if normalized.get("reading_profile") == "default":
        normalized.pop("reading_profile")
    if normalized.get("article_plan_sha256") == "":
        normalized.pop("article_plan_sha256")
    for optional in ("component_plan_sha256", "theme_file_sha256", "renderer_sha256"):
        if normalized.get(optional) == "":
            normalized.pop(optional)
    return _sha256_text(canonical_json(normalized))


def _assert_render_input_shape(render_input: Mapping[str, Any]) -> None:
    keys = set(render_input)
    unknown = keys - RENDER_INPUT_KEYS
    if unknown:
        leaked = sorted(unknown & FORBIDDEN_IN_RENDER_INPUT)
        hint = ("地址与角色属于第二层 `consumption`，放进来两份产物永远不相等"
                if leaked else "字段有增减即视为不兼容")
        raise ContractError(
            RENDER_INPUT_MISMATCH,
            "render_input 出现非法字段：%s（%s）" % (sorted(unknown), hint),
            unknown=sorted(unknown), leaked=leaked)
    missing = RENDER_INPUT_KEYS - {"reading_profile", "article_plan_sha256", "component_plan_sha256", "theme_file_sha256", "renderer_sha256"} - keys
    if missing:
        raise ContractError(
            RENDER_INPUT_MISMATCH,
            "render_input 缺字段：%s" % sorted(missing), missing=sorted(missing))
    for asset in render_input.get("assets") or ():
        extra = set(asset) - {"id", "sha256"}
        if extra:
            raise ContractError(
                RENDER_INPUT_MISMATCH,
                "render_input.assets 只放资产身份 (id, sha256)，"
                "多出：%s" % sorted(extra), unknown=sorted(extra))


# ── 第二层：每份产物各自的消费绑定 ────────────────────────────────────────


def build_consumption(
    *,
    src_role: str,
    image_map_sha256: str,
    assets: Sequence[Mapping[str, Any]],
) -> dict:
    """组装第二层对象。

    `assets` 里**没有 `sha256`**，`id` 作关联键；资产身份一律去第一层取。
    """
    if src_role not in SRC_ROLES:
        raise ContractError(RENDER_INPUT_MISMATCH,
                            "未知 src_role：%s" % src_role, known=list(SRC_ROLES))
    normalized = []
    for asset in assets:
        entry = {"id": str(asset["id"]), "src": str(asset["src"])}
        binding = asset.get("src_binding")
        if binding is not None:
            entry["src_binding"] = dict(binding)
        normalized.append(entry)
    normalized.sort(key=lambda item: item["id"])
    return {
        "schema_version": SCHEMA_VERSION,
        "src_role": src_role,
        "image_map_sha256": str(image_map_sha256 or "").lower(),
        "assets": normalized,
    }


def compare_render_inputs(channel: Mapping[str, Any],
                          preview: Mapping[str, Any]) -> None:
    """第一层比较：渠道包 ≟ 预览。

    资产版本差异单独报 `ASSET_VERSION_MISMATCH`——它和"主题不一样"是两回事，
    合并成一个码，调用方就得自己去 diff 才知道要重出图还是改参数。
    """
    channel_assets = {a["id"]: a["sha256"] for a in channel.get("assets") or ()}
    preview_assets = {a["id"]: a["sha256"] for a in preview.get("assets") or ()}
    for asset_id in sorted(set(channel_assets) | set(preview_assets)):
        left = channel_assets.get(asset_id)
        right = preview_assets.get(asset_id)
        if left != right:
            raise ContractError(
                ASSET_VERSION_MISMATCH,
                "资产 %s 在渠道包与预览里不是同一份：%s ≠ %s"
                % (asset_id, left or "（缺）", right or "（缺）"),
                asset_id=asset_id, channel=left, preview=right)

    left_fp = render_input_sha256(channel)
    right_fp = render_input_sha256(preview)
    if left_fp != right_fp:
        differing = sorted(
            key for key in RENDER_INPUT_KEYS
            if channel.get(key) != preview.get(key))
        raise ContractError(
            RENDER_INPUT_MISMATCH,
            "渠道包与预览的渲染输入不一致，差在：%s" % differing,
            fields=differing, channel=left_fp, preview=right_fp)


#: HTML 里的图片地址。取 `src="…"`，不做完整 HTML 解析——
#: 这里只需要"实际写出去的地址是什么"，多余的解析只会多一个出错的地方。
_SRC_RE = re.compile(r'<img\b[^>]*?\bsrc="([^"]*)"', re.IGNORECASE)


def srcs_in_html(html: str) -> list[str]:
    return _SRC_RE.findall(html)


@dataclass
class ConsumptionFinding:
    code: str
    message: str
    detail: dict = field(default_factory=dict)


def verify_consumption(
    consumption: Mapping[str, Any],
    *,
    render_input: Mapping[str, Any],
    html: str,
    current_image_map_sha256: str,
    base_dir: Path | str | None,
) -> list[ConsumptionFinding]:
    """第二层核对：这一份产物自己有没有过期。

    **四项各自独立，任一项失配即阻断，不要求同时失配。**

    这条约束是硬的。最常见的那个场景——只改了映射文件，HTML 与消费记录都没动——
    此时记录里的 `src` 与 HTML 里的 `src` **仍然彼此一致**（两边都是旧地址），
    失配的只有 `image_map_sha256` 一项。若把"两项同时失败"写进判据，
    这个真实场景反而测成通过。

    返回全部 finding 而不是遇到第一个就抛：一次跑完能看到所有问题，
    否则修一个跑一次，映射里有五张图就要跑五轮。

    `base_dir` 是**这份 HTML 所在的目录**，用来把记录里的相对地址还原成磁盘路径。
    **它是必填的、没有默认值**：`local_file` 绑定的全部证据就是"那个文件在、
    而且还是那一份"，给个默认就等于允许调用方在不查的情况下拿到"通过"。
    确实无从解析时传 `None`，本函数会**明说这一项没查**（`LOCAL_ASSET_MISSING`），
    而不是悄悄跳过——查不到与没变是两件事。
    """
    findings: list[ConsumptionFinding] = []

    role = consumption.get("src_role")
    if role not in SRC_ROLES:
        findings.append(ConsumptionFinding(
            RENDER_INPUT_MISMATCH, "未知 src_role：%s" % role))

    recorded_map = str(consumption.get("image_map_sha256") or "").lower()
    current_map = str(current_image_map_sha256 or "").lower()
    if recorded_map != current_map:
        findings.append(ConsumptionFinding(
            RENDER_INPUT_MISMATCH,
            "映射已改、产物没跟上：记录 %s，当前 %s"
            % (recorded_map or "（无）", current_map or "（无）"),
            {"recorded": recorded_map, "current": current_map}))

    identity = {a["id"]: a["sha256"] for a in render_input.get("assets") or ()}
    consumed = {a["id"]: a for a in consumption.get("assets") or ()}

    for asset_id in sorted(identity):
        if asset_id not in consumed:
            findings.append(ConsumptionFinding(
                ASSET_VERSION_MISMATCH,
                "资产 %s 没有映射记录——缺映射时编译器会原样保留本地路径，"
                "草稿里就是坏图" % asset_id, {"asset_id": asset_id}))
    for asset_id in sorted(set(consumed) - set(identity)):
        findings.append(ConsumptionFinding(
            ASSET_VERSION_MISMATCH,
            "消费记录里的 %s 不在资产身份表中" % asset_id,
            {"asset_id": asset_id}))

    actual = srcs_in_html(html)
    actual_set = set(actual)
    for asset_id, entry in sorted(consumed.items()):
        src = entry.get("src") or ""
        if src not in actual_set:
            findings.append(ConsumptionFinding(
                RENDER_INPUT_MISMATCH,
                "资产 %s 记录的地址没有出现在这份 HTML 里：%s"
                % (asset_id, src), {"asset_id": asset_id, "src": src,
                                    "html_srcs": actual}))
        findings.extend(_verify_binding(asset_id, entry, identity.get(asset_id),
                                        role, base_dir))
    return findings


def _verify_binding(asset_id: str, entry: Mapping[str, Any],
                    identity_sha256: str | None,
                    role: Any,
                    base_dir: Path | str | None) -> list[ConsumptionFinding]:
    """绑定证据核对。

    「记了源 PNG 的哈希」和「这个地址确实是那张 PNG」是**两项证据**，不是一项。
    本地哈希对远端地址指向什么一个字都没说，所以要有上传记录或回取核验；
    而既然证据里带了 `source_sha256`，就必须校验它与计入指纹的那份相等——
    否则"上传时串了一张图"在整条链上仍然无人可查。
    """
    findings: list[ConsumptionFinding] = []
    binding = entry.get("src_binding")
    if not binding:
        findings.append(ConsumptionFinding(
            ASSET_VERSION_MISMATCH,
            "资产 %s 缺 src_binding：无法证明这个地址对应那份源文件" % asset_id,
            {"asset_id": asset_id}))
        return findings

    binding_type = binding.get("type")
    if binding_type not in BINDING_TYPES:
        findings.append(ConsumptionFinding(
            ASSET_VERSION_MISMATCH,
            "资产 %s 的 src_binding.type 未知：%s" % (asset_id, binding_type),
            {"asset_id": asset_id, "known": list(BINDING_TYPES)}))
        return findings

    if role == ROLE_CHANNEL and binding_type not in CHANNEL_BINDING_TYPES:
        findings.append(ConsumptionFinding(
            ASSET_VERSION_MISMATCH,
            "渠道包不接受 %s 级绑定（资产 %s）——草稿群发不可撤回，"
            "人工声明不是证据" % (binding_type, asset_id),
            {"asset_id": asset_id, "type": binding_type,
             "accepted": list(CHANNEL_BINDING_TYPES)}))

    source = str(binding.get("source_sha256") or "").lower()
    if not source and binding_type in (BINDING_UPLOAD_RECORD,
                                       BINDING_CONTENT_VERIFIED):
        # **回执不完整就是没有回执。** 缺 `source_sha256` 时不得拿当前本地文件
        # 的哈希顶上——那是用"现在的文件"冒充"当时上传了什么"，
        # 上传串了一张的情况恰好就查不出来了。
        findings.append(ConsumptionFinding(
            ASSET_VERSION_MISMATCH,
            "资产 %s 的 %s 没有 source_sha256：回执不完整，"
            "证明不了这个地址对应哪一份源文件" % (asset_id, binding_type),
            {"asset_id": asset_id, "type": binding_type}))
    if source and identity_sha256 and source != str(identity_sha256).lower():
        findings.append(ConsumptionFinding(
            ASSET_VERSION_MISMATCH,
            "资产 %s 上传的与计入指纹的不是同一份：%s ≠ %s"
            % (asset_id, source, identity_sha256),
            {"asset_id": asset_id, "uploaded": source,
             "fingerprinted": identity_sha256}))
    if binding_type == BINDING_LOCAL_FILE:
        findings.extend(_verify_local_file(asset_id, entry, source, base_dir))
    return findings


def _verify_local_file(asset_id: str, entry: Mapping[str, Any],
                       recorded_sha256: str,
                       base_dir: Path | str | None) -> list[ConsumptionFinding]:
    """本地图的证据只有一条：**那个文件现在还在，而且还是那一份**。

    上传回执是"当时发生过什么"的凭据，写下来就不会变；本地引用没有这种凭据，
    HTML 里只有一个路径，它指向什么完全取决于磁盘此刻的状态。所以这一项
    必须当场去读文件，**不能靠记录自洽推出来**——记录里那个 `source_sha256`
    正是编译时算的，拿它跟自己比永远相等。

    实测过不查的后果：编译并验收之后把 PNG 删掉，或者同名换一张，
    门禁都放行。前者草稿里是坏图，后者发出去的是另一张图——
    **而且两者都不改动 HTML 一个字节**，上面那三项检查全都通过。
    """
    src = str(entry.get("src") or "")
    if base_dir is None:
        return [ConsumptionFinding(
            LOCAL_ASSET_MISSING,
            "资产 %s 是本地引用，但没给出 HTML 所在目录，无法核对文件是否还在。"
            "**这不等于通过**——本地引用的全部证据就是那个文件本身。" % asset_id,
            {"asset_id": asset_id, "src": src})]

    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", src):
        # 远程地址不该带 local_file 绑定；这是记录本身写错了。
        return [ConsumptionFinding(
            LOCAL_ASSET_MISSING,
            "资产 %s 的地址是 %s，却记成 local_file 绑定——"
            "远程地址要有上传回执" % (asset_id, src),
            {"asset_id": asset_id, "src": src})]

    local = Path(src) if Path(src).is_absolute() else Path(base_dir) / src
    if not local.is_file():
        return [ConsumptionFinding(
            LOCAL_ASSET_MISSING,
            "资产 %s 引用的本地文件不在：%s。"
            "渠道包里就是一张坏图——发布阶段扫本地路径上传时会扑空。"
            % (asset_id, local),
            {"asset_id": asset_id, "src": src, "resolved": str(local)})]

    if recorded_sha256:
        actual = sha256_file(local)
        if actual != recorded_sha256:
            return [ConsumptionFinding(
                LOCAL_ASSET_MISSING,
                "资产 %s 同名换了一张图：记录 %s，磁盘 %s。"
                "**HTML 一个字节没改，发出去的却是另一张图。**"
                % (asset_id, recorded_sha256, actual),
                {"asset_id": asset_id, "src": src,
                 "recorded": recorded_sha256, "actual": actual})]
    return []


# ── 失效判定：按 visual_id 粒度 ───────────────────────────────────────────


def stale_visuals(record: Mapping[str, Any],
                  current: Mapping[str, Any]) -> list[str]:
    """哪些图的计划与复核失效了。

    **按 `visual_id` 逐张判，不看全文指纹。** 只记一个全文哈希时，改第 5 节会让
    第 1 节的图也失配——PNG 文件确实还在，但它的计划和复核都进不了门禁，
    等于仍然要重做，"局部复用"名存实亡。

    `record["document"]` 下的全文指纹**只作追溯**（这一版是在哪一版正文下做的），
    不参与本判定。

    `current` 形如 ``{"sections": {id: sha256}, "evidence": {ref: sha256}}``。
    """
    stale: list[str] = []
    sections = {k: str(v).lower() for k, v in (current.get("sections") or {}).items()}
    evidence = {k: str(v).lower() for k, v in (current.get("evidence") or {}).items()}
    for visual_id, entry in sorted((record.get("visuals") or {}).items()):
        depends = entry.get("depends_on") or {}
        changed = False
        for item in depends.get("sections") or ():
            now = sections.get(item["id"])
            if now is None or now != str(item["sha256"]).lower():
                changed = True
        for item in depends.get("evidence") or ():
            now = evidence.get(item["ref"])
            if now is None or now != str(item["sha256"]).lower():
                changed = True
        if changed:
            stale.append(visual_id)
    return stale


__all__ = [
    "SCHEMA_VERSION", "ROLE_CHANNEL", "ROLE_PREVIEW", "SRC_ROLES",
    "BINDING_UPLOAD_RECORD", "BINDING_CONTENT_VERIFIED", "BINDING_DECLARED",
    "BINDING_LOCAL_FILE", "BINDING_TYPES", "CHANNEL_BINDING_TYPES",
    "INPUT_FINGERPRINT_MISMATCH", "PLAN_FINGERPRINT_MISMATCH",
    "ASSET_VERSION_MISMATCH", "RENDER_INPUT_MISMATCH", "REVIEW_STALE",
    "ERROR_CODES", "ContractError", "ConsumptionFinding",
    "sha256_file", "canonical_json",
    "build_render_input", "render_input_sha256", "compare_render_inputs",
    "build_consumption", "verify_consumption", "srcs_in_html",
    "LOCAL_ASSET_MISSING",
    "stale_visuals", "normalize_digest", "digests_match",
    "DigestFormatError",
    "RENDER_INPUT_KEYS", "FORBIDDEN_IN_RENDER_INPUT",
]


# ── 摘要的规范化：同一个摘要不因写法不同而失配 ────────────────────────────

_HEX64 = re.compile(r"\A[0-9a-fA-F]{64}\Z")


class DigestFormatError(ValueError):
    """摘要格式不对。**与"内容变了"分开报**——两者的修法完全不同：
    前者是记录写坏了，后者是东西真的换了。"""


def normalize_digest(value: Any, *, field: str = "sha256") -> str:
    """把一个 sha256 摘要归一成小写十六进制。

    **这个仓库里同时存在两种写法。** `image.manifest.file_sha256` 返回大写，
    `shared.render_contract.sha256_file` 返回小写——于是"同一个文件"在
    两侧算出的字符串不相等，而比较处又是裸 `!=`：

        记录小写 vs 磁盘大写  → REVIEW_STALE（文件一个字节都没动）

    这一条 2026-09-11 在资产登记那里犯过一次，当时是逐处改调用；
    这次换成在**比较边界**归一，两侧各自的输出格式不动
    （改 `file_sha256` 会波及所有既有清单）。

    格式不合法时抛 `DigestFormatError`，不返回空串也不当成"不相等"——
    空串会悄悄变成"内容变了"，把一个写坏的记录报成一件没发生的事。
    """
    text = str(value or "").strip()
    if not _HEX64.match(text):
        raise DigestFormatError(
            "%s 不是合法的 sha256（应为 64 位十六进制），实际：%r" % (field, value))
    return text.lower()


def digests_match(left: Any, right: Any, *, field: str = "sha256") -> bool:
    """两个摘要指的是不是同一份内容。**大小写不算差异，格式错要报。**"""
    return normalize_digest(left, field=field) == normalize_digest(right, field=field)
