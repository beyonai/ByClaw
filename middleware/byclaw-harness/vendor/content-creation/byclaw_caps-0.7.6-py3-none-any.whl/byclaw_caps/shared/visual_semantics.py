# -*- coding: utf-8 -*-
"""配图语义层：来源快照、`must_cover` / `form_hint` 拆分、按图粒度的依赖。

方案《配图语义规划方案.md》§3.2、§4、§5。

**这个模块只做一件事：把「这张图凭什么这么画」变成可核验的输入。**
在此之前，出图助理拿到的是 `must_include` 一串字符串，里面混着事实要求
（「三层各自的判据」）和形式指令（「三行 × 四个维度」）；而 `evidence_refs`
是一串裸 ID（`['ev-001']`），下发的 `context_digest` 八个键里没有任何字段
能把 `ev-001` 解回原文——「锚定 evidence_refs 原文」这句要求当时根本写不出来。
"""

from __future__ import annotations

import hashlib
import re
from typing import Any, Iterable, Mapping

#: 一条 `must_include` 是在说形式，不是在说事实。
#:
#: 命中不等于自动搬走——**自动拆会把「必须呈现这些事实」悄悄放宽成「大意即可」**，
#: 那是这条改动最大的风险。命中的条目只标 `form_hint_candidate` 交人确认。
_FORM_WORDS = (
    "矩阵", "流程图", "象限", "时间轴", "环形", "金字塔",
    "左右", "上下", "并列", "对照表", "表格", "双栏", "分栏",
)

#: 形式词要带数量才算数，而且**「层」不在里面**。
#:
#: 「三层各自的判据」「第 2 层依赖第 1 层」里的「层」说的是事实结构，
#: 「三行（三层）× 四个维度」里的「行」与「×」才是在规定画法。
#: 把「层」也算进来，这两条真实的事实要求都会被标成形式候选——
#: 而误判的代价不对称：标错了会让人把一条必须呈现的事实移进"可换"那一栏。
_FORM_SHAPE = re.compile(
    r"[0-9一二三四五六七八九十两]+\s*[行列栏]|[×]\s*[0-9一二三四五六七八九十]")


def looks_like_form(text: str) -> bool:
    """这条要求是在规定形式吗。

    只用来**提示人工确认**，不用来自动改写。判断错了的代价不对称：
    把事实误判成形式 → 那条事实从"必须呈现"降级成"可换"，图里可以没有它；
    把形式误判成事实 → 至多多一条冗余约束。所以宁可少判。
    """
    if _FORM_SHAPE.search(text):
        return True
    return any(word in text for word in _FORM_WORDS)


def split_must_include(must_include: Iterable[str]) -> dict[str, list[str]]:
    """`must_include` → `must_cover` + `form_hint_candidate`。

    **保守迁移**：存量条目一律先落 `must_cover`（不放宽），
    其中明显描述形式的另外标一份候选，提示人工确认，**不自动搬**。

    只改称呼是不够的——1548 那轮的第一条 `must_include` 就是
    「三行（三层）× 四个维度（判断 / 能力 / 价值 / 判据）」，
    它本身已经指定了矩阵。就算解释成"至少包含这些"，
    助理选流程图仍与原要求冲突。
    """
    cover: list[str] = []
    candidates: list[str] = []
    for raw in must_include:
        text = str(raw).strip()
        if not text:
            continue
        cover.append(text)
        if looks_like_form(text):
            candidates.append(text)
    return {"must_cover": cover, "form_hint_candidate": candidates}


def sha256_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def section_sha256(body: str) -> str:
    """一节正文的语义哈希。

    **与 `content_sha256` 用同一条归一化规则，只是范围是一节。**
    两处规则必须一致：写依据时归一化、判依据变没变时不归一化，
    等于每次替换占位都报一次"来源改了"。
    """
    return sha256_text(normalize_content(body))


def evidence_index(article_plan: Mapping[str, Any]) -> dict[str, dict]:
    """`ev-001` → 它的原文与出处。

    没有这一步，`evidence_refs` 只是一串裸 ID：复核者拿到 `['ev-001']`，
    既读不到它说了什么，也就无从判断图上那句话是不是它支持的。
    """
    index: dict[str, dict] = {}
    for item in (article_plan.get("evidence_pool") or []):
        if not isinstance(item, Mapping):
            continue
        ref = str(item.get("evidence_id") or "").strip()
        if not ref:
            continue
        text = str(item.get("claim") or "").strip()
        index[ref] = {
            "ref": ref,
            "text": text,
            "origin": str(item.get("origin") or "").strip(),
            "source": str(item.get("source") or "").strip(),
            "strength": str(item.get("strength") or "").strip(),
            "sha256": sha256_text(text),
        }
    return index


def build_sources(
    *,
    section_id: str,
    section_excerpt: str,
    section_heading: str = "",
    evidence_refs: Iterable[str],
    evidence_lookup: Mapping[str, dict],
    content_sha256: str,
) -> dict:
    """这张图的来源快照。

    `depends_on` 按**这一张图实际读了什么**记，不记全文——
    只记一个全文哈希时，改第 5 节会让第 1 节的图也失配：PNG 文件确实还在，
    但它的计划和复核都进不了门禁，等于仍然要重做。

    `content_sha256` 放在 `document` 下，**只作追溯**（这一版是在哪一版正文下做的），
    不参与失效判定。
    """
    evidence: list[dict] = []
    missing: list[str] = []
    for ref in evidence_refs:
        entry = evidence_lookup.get(str(ref))
        if entry is None:
            missing.append(str(ref))
            continue
        evidence.append(entry)
    snapshot = {
        "document": {"content_sha256": content_sha256},
        "depends_on": {
            # `id` 给人看（它是 ArticlePlan 里的 section_id），
            # `heading` 给判定用——失效判定只能按标题在正文里查得到这一节。
            "sections": [{"id": section_id,
                          "heading": normalise_heading(section_heading or ""),
                          "sha256": section_sha256(section_excerpt)}]
            if section_id else [],
            "evidence": [{"ref": item["ref"], "sha256": item["sha256"]}
                         for item in evidence],
        },
        "section_excerpt": section_excerpt,
        "evidence": evidence,
    }
    if missing:
        # 引了但解不出原文的 ID **必须说出来**。静默丢掉的话，
        # 复核者会以为这张图没有证据依赖，而它其实有、只是没下发。
        snapshot["unresolved_evidence_refs"] = missing
    return snapshot


def normalize_content(markdown: str, visual_ids: Iterable[str] | None = None) -> str:
    """语义内容归一化：占位与图片引用统一成带身份的槽位标记。

    配图交付本身会改正文字节——`SKILL.md` 第 363 行「你替换占位改了它的字节」。
    语义依据若绑正文文件哈希，**图刚嵌进去就失效了**。

    **归成带 `visual_id` 的标记，不是归成空。** `validate_article.py` 的
    `clean_prose` 把占位与图片引用都 `sub("")` 掉，照抄那一条会把
    「把 A 图换到 B 槽」也一起抹掉，而那是真变化。

    归一化管不到 alt 文案与 PNG 内容——那两件事分别归嵌入映射校验与资产哈希
    （§3.2）。把 PNG 哈希塞回这里会重建"依据取决于产物"的循环，绕一圈还是循环。
    """
    text = markdown
    text = re.sub(r"!\[[^\]]*\]\(([^)]*?)([A-Za-z0-9_-]*visual-(\d+))\.png\)",
                  lambda m: "⟦VISUAL:visual-%s⟧" % m.group(3), text)
    text = re.sub(r">\s*\*\*配图占位\s*(\d+)[^\n]*\*\*",
                  lambda m: "⟦VISUAL:visual-%03d⟧" % int(m.group(1)), text)
    return text


def content_sha256(markdown: str) -> str:
    return sha256_text(normalize_content(markdown))


_HEADING = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
#: 标题里的装饰与编号：比对时一律剥掉。大纲里写「三个真实项目」，
#: 正文里可能是「## 二、三个真实项目」——按原样比对一个都对不上。
_HEADING_NOISE = re.compile(r"[\s0-9０-９一二三四五六七八九十、．.。\-—－:：|｜*_`#]+")


def normalise_heading(text: str) -> str:
    return _HEADING_NOISE.sub("", str(text or ""))


def article_sections(markdown: str) -> dict[str, str]:
    """正文 Markdown → {归一化标题: 该节正文}。

    **生成依据和判断依据变没变，必须用同一份实现。** 分节规则各写一份的话，
    两边切出的节边界稍有出入，哈希就永远对不上——症状是"每次都报来源变了"，
    而正文其实一个字没改。
    """
    sections: dict[str, str] = {}
    current: str | None = None
    buffer: list[str] = []
    in_fence = False
    for line in markdown.splitlines():
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
        match = None if in_fence else _HEADING.match(line)
        if match:
            if current:
                sections[current] = "\n".join(buffer).strip()
            current = normalise_heading(match.group(2))
            buffer = []
            continue
        if current:
            buffer.append(line)
    if current:
        sections[current] = "\n".join(buffer).strip()
    return sections


def current_fingerprints(markdown: str,
                         evidence_lookup: Mapping[str, dict] | None = None) -> dict:
    """当前正文与证据的指纹，按 `stale_visuals` 要的形状给。

    节的 key 用**归一化标题**，与 `build_sources` 写进 `depends_on` 时用的是
    同一个 `section_id`——一编把 `section_id` 和标题对应起来，这里只能按标题查，
    所以两处都存：`depends_on.sections[].id` 记 `section_id`，
    而 `sections[].heading` 记归一化标题。
    """
    # **按归一化后的节正文算。** 不归一化的话，配图交付把占位替换成图片引用之后，
    # 这一节的字节就变了——而全文语义哈希明明不变。于是"正常替换占位"
    # 会被判成"来源改了"，反例 4 在按节粒度这一层重新失效了一次。
    sections = {heading: section_sha256(body)
                for heading, body in article_sections(markdown).items()}
    evidence = {ref: entry.get("sha256") or sha256_text(entry.get("text") or "")
                for ref, entry in (evidence_lookup or {}).items()}
    return {"sections": sections, "evidence": evidence,
            "content_sha256": content_sha256(markdown)}


def stale_visuals(record: Mapping[str, Any], current: Mapping[str, Any]) -> list[str]:
    """哪些图的依据变了。

    **按 `visual_id` 逐张判，不看全文指纹。** 只记一个全文哈希时，改第 5 节会让
    第 1 节的图也失配——PNG 文件确实还在，但它的计划和复核都进不了门禁，
    等于仍然要重做，"局部复用"名存实亡。

    `record["document"]` 下的全文指纹**只作追溯**，不参与本判定。
    """
    stale: list[str] = []
    sections = {k: str(v).lower() for k, v in (current.get("sections") or {}).items()}
    evidence = {k: str(v).lower() for k, v in (current.get("evidence") or {}).items()}
    for visual_id, entry in sorted((record.get("visuals") or {}).items()):
        depends = entry.get("depends_on") or {}
        changed = False
        for item in depends.get("sections") or ():
            # 按归一化标题查；一编写入时把它一并记下（`heading` 字段）。
            key = str(item.get("heading") or item.get("id") or "")
            now = sections.get(key)
            if now is None or now != str(item.get("sha256") or "").lower():
                changed = True
        for item in depends.get("evidence") or ():
            now = evidence.get(str(item.get("ref") or ""))
            if now is None or now != str(item.get("sha256") or "").lower():
                changed = True
        if changed:
            stale.append(visual_id)
    return stale


# ── 复核输入包 ────────────────────────────────────────────────────────────
#
# **放在共享层，因为有三个地方要用同一份实现**：二编要预先算出它的哈希写进计划，
# skill 脚本要把包生成给复核者，登记门禁要拿它核对报告绑的是不是这一版。
# 三处各写一份的话，哈希永远对不上——症状是"每次复核都说过期"。


def build_review_input(*, visual_id: str, sources: Mapping[str, Any],
                       plan_item: Mapping[str, Any],
                       design: Mapping[str, Any]) -> dict:
    """复核输入包：**屏蔽理由，不屏蔽待核查的内容**。

    只给来源和图，复核者做不了那张清单——它不知道哪些是 `must_cover`、
    哪些是 `must_avoid`、画面上哪个断言是设计里声明过的、`derived` 声称的
    推导是什么。「未声明的新断言」这一项，没有声明清单就无从谈起。

    屏蔽 `rationale` 是防止复核者顺着设计者的论证走；
    屏蔽断言清单则是直接取消了复核能力。**这是两件事。**
    """
    assertions: list[dict] = []
    for node in (design.get("nodes") or []):
        if isinstance(node, Mapping):
            assertions.append({"where": "node", "id": node.get("id"),
                               "text": node.get("label") or node.get("text"),
                               "anchor": node.get("anchor"),
                               "relation": node.get("relation")})
    for relation in (design.get("relations") or []):
        if isinstance(relation, Mapping):
            assertions.append({"where": "relation", "kind": relation.get("kind"),
                               "text": relation.get("label"),
                               "support": relation.get("support"),
                               "visual_convention": relation.get("visual_convention")})
    return {
        "visual_id": visual_id,
        "section_excerpt": sources.get("section_excerpt") or "",
        "evidence": sources.get("evidence") or [],
        "assertions": assertions,
        "must_cover": list(plan_item.get("must_cover") or []),
        "must_avoid": list(plan_item.get("must_avoid") or []),
        "structure": plan_item.get("structure") or {},
        # **数值也是断言。** 不进复核输入的话，改一个数字而旧复核不失效——
        # 那正是"5.3× 与四根柱对不上"那类错误能一路走到交付的原因。
        "numeric": plan_item.get("numeric"),
        # `rationale` 故意不在这里。
    }


def review_input_sha256(review_input: Mapping[str, Any]) -> str:
    import json as _json

    return sha256_text(_json.dumps(review_input, sort_keys=True,
                                   ensure_ascii=False, separators=(",", ":")))


__all__ = ["looks_like_form", "split_must_include", "evidence_index",
           "build_sources", "normalize_content", "content_sha256",
           "sha256_text", "section_sha256", "normalise_heading", "article_sections",
           "current_fingerprints", "stale_visuals",
           "build_review_input", "review_input_sha256"]
