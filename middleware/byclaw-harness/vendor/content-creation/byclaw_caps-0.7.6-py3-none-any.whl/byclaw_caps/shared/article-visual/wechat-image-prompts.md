# 公众号配图 · 提示词与图表模板

> 从 [wechat-image-spec.md](wechat-image-spec.md) 拆出。
> **按需加载**：只在实际要生成对应类型的图时读本文件；查尺寸、目录、质检口径读 spec，不必读这里。

### 4.3 提示词模板（至少 5 个）

提示词统一采用「中英文双语」，结构为：主体 + 风格 + 构图 + 配色 + 细节，并附参数与负向提示词。

---

#### 模板 1 · 技术深度稿封面

适用场景：技术架构拆解、源码解析、工程实践类深度文章。

风格：深色科技底，等宽代码质感，冷色调，专业克制。

提示词：

```
中文：一张科技感封面图，深色背景（近黑 #0D1117），主体是由发光绿色线条构成的分层系统架构轮廓，
悬浮在画面中央偏右，左侧留白区域用于放置主标题文字。点缀细小的代码符号与节点光点，
整体冷静、专业、有工程感。扁平化矢量风格，无写实照片。

English: A tech-style cover image, dark background (near-black #0D1117), the main subject is a layered
system architecture outline made of glowing green lines, floating center-right. Left area reserved as
negative space for the headline text. Small code symbols and node light points as accents. Calm,
professional, engineering feel. Flat vector style, no photorealism.
```

参数：
- 尺寸：900x383
- 比例：2.35:1
- 风格：扁平矢量 / 暗色科技

负向提示词：照片写实、人物肖像、杂乱渐变、花哨装饰、低对比度、模糊文字。

---

#### 模板 2 · 业务场景稿封面

适用场景：客户案例、落地场景、业务价值叙事类文章。

风格：明亮商务风，场景化构图，蓝绿主色，可信赖感。

提示词：

```
中文：一张商务场景封面图，浅色背景（#F5F7FF），主体是抽象的业务闭环流程图示——几个圆角卡片
通过发光连线串联成环，象征业务流转。画面右侧有向上箭头与增长曲线暗示价值。整体明亮、专业、
有增长感。扁平插画风格，无人物写实。

English: A business-scene cover, light background (#F5F7FF), main subject is an abstract business loop
diagram — rounded cards linked by glowing lines into a ring, symbolizing workflow. Right side has an
upward arrow and growth curve implying value. Bright, professional, sense of growth. Flat illustration,
no realistic figures.
```

参数：
- 尺寸：900x383
- 比例：2.35:1
- 风格：扁平插画 / 明亮商务

负向提示词：暗黑背景、夸张特效、人物照片、刺眼高饱和、杂乱线条。

---

#### 模板 3 · 产品评测稿封面

适用场景：产品功能对比、上手实测、评测打分类文章。

风格：产品质感特写，对比构图，干净留白，科技蓝。

提示词：

```
中文：一张产品评测封面图，浅灰渐变背景，主体是两个并列的抽象设备/界面卡片，中间一道分隔线，
左侧标注优、右侧标注待改进，形成对比暗示。卡片有细腻高光与阴影，像产品渲染图。整体干净、
聚焦、可信。3D 等距风格。

English: A product-review cover, light gray gradient background, main subject is two side-by-side
abstract device/UI cards split by a center line — left marked strength, right marked to-improve,
implying comparison. Cards have subtle highlights and shadows like product renders. Clean, focused,
trustworthy. 3D isometric style.
```

参数：
- 尺寸：900x383
- 比例：2.35:1
- 风格：3D 等距 / 产品渲染

负向提示词：模糊、低质截图、花哨背景、文字重叠、过度饱和。

---

#### 模板 4 · 行业洞察稿封面

适用场景：趋势判断、方法论、行业数据解读类文章。

风格：宏观俯视视角，数据可视化元素，蓝紫渐变，理性克制。

提示词：

```
中文：一张行业洞察封面图，深蓝紫渐变背景，主体是从中心向外发散的网状节点结构，象征行业生态
与连接关系，局部节点放大为高亮数据点。构图大气、俯视、有格局感。点缀细线网格暗示数据维度。
扁平矢量 + 轻微发光。

English: An industry-insight cover, deep blue-purple gradient background, main subject is a node network
radiating from center, symbolizing industry ecosystem and connections; some nodes enlarged as highlighted
data points. Grand, top-down, strategic feel. Thin grid lines hint data dimensions. Flat vector with
slight glow.
```

参数：
- 尺寸：900x383
- 比例：2.35:1
- 风格：扁平矢量 / 蓝紫渐变

负向提示词：具象人物、写实照片、杂乱配色、低对比、廉价感。

---

#### 模板 5 · 通用科技感封面

适用场景：不限定具体类型、需要统一科技调性的品牌型文章。

风格：抽象几何 + 光线，中性蓝青配色，未来感。

提示词：

```
中文：一张通用科技感封面图，深空蓝背景，主体是流动的抽象光线与几何网格交织，形成向前延伸的
隧道感，中心偏左留白给主标题。点缀微小粒子光点。未来、专业、有速度感。3D 抽象风格。

English: A universal tech-feel cover, deep-space blue background, main subject is flowing abstract light
and geometric grid interweaving into a forward-extending tunnel; center-left reserved for headline. Tiny
particle lights. Futuristic, professional, sense of speed. 3D abstract style.
```

参数：
- 尺寸：900x383
- 比例：2.35:1
- 风格：3D 抽象 / 光线隧道

负向提示词：具象物体、文字混乱、高饱和撞色、模糊、廉价素材感。

---

### 5.3 提示词模板（至少 5 个）

---

#### 模板 1 · 技术架构示意图

适用场景：解释系统由哪些组件构成、如何分层。

提示词：

```
中文：一张扁平化技术架构示意图，浅色背景，主体为三层堆叠的模块组（接入层、逻辑层、数据层），
每层用同色系圆角矩形表示组件，组件间用细箭头连接表示调用方向。无人物、无照片，纯矢量图标感。
宽度约 1280px 的横版构图。

English: A flat technical architecture diagram, light background, three stacked module groups (access /
logic / data layer), each layer uses same-hue rounded rectangles as components, thin arrows show call
direction. No figures, no photos, pure vector icon feel. Horizontal layout ~1280px wide.
```

参数：尺寸 1280x720，风格 扁平矢量。

负向提示词：写实照片、人物、渐变杂乱、文字不清、重叠。

---

#### 模板 2 · 数据流程图

适用场景：展示数据从源头到落库的完整链路。

提示词：

```
中文：一张数据流向示意图，从左到右展示：数据源 → 采集 → 清洗 → 存储 → 分析 → 应用，
每个环节是一个圆角卡片，卡片间用带箭头的发光连线串联，关键节点用不同颜色区分。浅色背景，
扁平插画风，横版。

English: A data-flow diagram, left to right: source → ingest → clean → store → analyze → apply.
Each stage a rounded card, linked by glowing arrows; key nodes color-coded. Light background, flat
illustration, horizontal.
```

参数：尺寸 1280x640，风格 扁平插画。

负向提示词：照片、人物、3D 写实、文字重叠。

---

#### 模板 3 · 场景示意图

适用场景：把抽象业务场景具象化（如「客服接入智能体」）。

提示词：

```
中文：一张业务场景示意图，扁平插画风，画面左侧是一个用户向对话框输入问题，中间是一个智能体
中枢（圆形芯片图标）在处理，右侧输出答案并连接多个业务系统图标。整体明亮、易懂，浅色背景，
带轻微投影区分前后景。

English: A business scene illustration, flat style. Left: a user typing into a chat box. Center: an agent
hub (circular chip icon) processing. Right: answer output connecting to multiple business-system icons.
Bright, easy to understand, light background, subtle shadows for depth.
```

参数：尺寸 1280x720，风格 扁平插画。

负向提示词：暗黑、写实照片、人物写实、杂乱。

---

#### 模板 4 · 对比展示图

适用场景：方案 A vs 方案 B、改造前 vs 改造后。

提示词：

```
中文：一张左右对比示意图，中间一条竖直分隔线。左侧是「传统方式」：手工、多步骤、灰色调；
右侧是「智能方式」：自动化、少步骤、蓝色调高亮。两侧用相同的图标语言保证可比性。扁平风，
浅背景。

English: A left-right comparison diagram with a vertical divider. Left "traditional": manual, many steps,
gray tone. Right "smart": automated, few steps, blue highlighted. Same icon language both sides for
comparability. Flat, light background.
```

参数：尺寸 1280x720，风格 扁平对比。

负向提示词：不对称、配色混乱、文字重叠。

---

#### 模板 5 · 概念插画

适用场景：文章开头引出抽象概念，增加吸引力。

提示词：

```
中文：一张抽象概念插画，表现「知识被智能体连接」的主题：大脑轮廓中伸出发光丝线，连接周围的
书籍、数据库、对话气泡图标。蓝紫渐变背景，发光元素，未来感但克制。3D 轻微等距。

English: An abstract concept illustration on "knowledge connected by agents": a brain outline sends
glowing threads linking books, databases, chat-bubble icons around it. Blue-purple gradient background,
glowing elements, futuristic but restrained. Slight 3D isometric.
```

参数：尺寸 1280x800，风格 3D 等距 / 概念。

负向提示词：具象人物、文字、低质、撞色。

---

### 6.3 Mermaid 模板（至少 4 个）

---

#### 模板 1 · 技术架构图（Mermaid）

适用场景：展示系统模块分层与调用关系。

```mermaid
graph LR
  subgraph 接入层
    A[API 网关]
    B[Web 前端]
  end
  subgraph 逻辑层
    C[业务服务]
    D[智能体编排]
  end
  subgraph 数据层
    E[(向量库)]
    F[(关系库)]
  end
  A --> C
  B --> C
  C --> D
  D --> E
  D --> F
```

配色说明：接入层蓝 `#3B82F6`、逻辑层紫 `#8B5CF6`、数据层绿 `#10B981`；连线实线表示同步调用。

---

#### 模板 2 · 数据流程图（Mermaid）

适用场景：展示数据从源头到应用的链路。

```mermaid
flowchart LR
  S[数据源] --> I[采集]
  I --> C[清洗]
  C --> ST[(存储)]
  ST --> A[分析]
  A --> V[可视化]
  A -.-> M[模型训练]
  M -.-> A
```

配色说明：处理节点灰 `#94A3B8`、存储节点绿 `#10B981`、异步连线用虚线 `--.->` 表示离线/批处理。

---

#### 模板 3 · 业务流程图（Mermaid）

适用场景：展示带判断分支的业务流转。

```mermaid
flowchart TD
  U[用户提交需求] --> Q{需求合规?}
  Q -->|是| R[进入处理队列]
  Q -->|否| B[返回修改]
  B --> U
  R --> P[智能体执行]
  P --> D{执行成功?}
  D -->|是| O[交付结果]
  D -->|否| H[人工兜底]
  H --> O
```

配色说明：用户节点蓝 `#3B82F6`、判断菱形橙 `#F59E0B`、成功绿 `#10B981`、兜底红 `#EF4444`。

---

#### 模板 4 · Agent 决策流程图（Mermaid）

适用场景：展示智能体的规划—执行—反思循环。

```mermaid
flowchart TD
  I[用户指令] --> P[任务规划]
  P --> T{工具调用?}
  T -->|需要| C[调用工具]
  C --> O[观察结果]
  O --> R[反思]
  R --> T
  T -->|不需要| A[生成回答]
  A --> E[结束]
```

配色说明：规划/反思紫 `#8B5CF6`、工具调用蓝 `#3B82F6`、判断菱形橙 `#F59E0B`；循环用回边表示迭代。

---

### 7.3 Mermaid 模板（至少 3 个）

---

#### 模板 1 · 系统分层架构（Mermaid）

适用场景：展示企业级应用的分层结构。

```mermaid
flowchart TB
  subgraph 应用层
    A1[Web 门户]
    A2[开放 API]
  end
  subgraph 服务层
    B1[业务微服务]
    B2[智能体服务]
  end
  subgraph 数据层
    C1[(主数据库)]
    C2[(向量库)]
  end
  subgraph 基础设施层
    D1[容器平台]
    D2[对象存储]
  end
  A1 --> B1
  A2 --> B1
  B1 --> B2
  B1 --> C1
  B2 --> C2
  B1 --> D1
  C1 --> D2
```

配色说明：应用层蓝、服务层紫、数据层绿、基础设施层灰；自顶向下分层，连线表示依赖方向。

---

#### 模板 2 · 微服务部署架构（Mermaid）

适用场景：展示服务在云上的部署与调用拓扑。

```mermaid
flowchart LR
  GW[API 网关] --> S1[服务 A 实例x3]
  GW --> S2[服务 B 实例x2]
  GW --> S3[智能体服务x2]
  S1 --> R[(Redis 缓存)]
  S2 --> DB[(主库)]
  S3 --> V[(向量库)]
  S1 -.-> MQ[[消息队列]]
  S2 -.-> MQ
```

配色说明：网关橙 `#F59E0B`、服务蓝 `#3B82F6`、存储绿 `#10B981`、消息队列紫 `#8B5CF6`；虚线表示异步消息。

---

#### 模板 3 · 数据流架构（Mermaid）

适用场景：展示端到端数据链路与存储分层。

```mermaid
flowchart LR
  src[业务系统] --> kfk[[消息队列]]
  kfk --> etl[ETL 作业]
  etl --> ods[(ODS 原始层)]
  ods --> dw[(数仓明细层)]
  dw --> ads[(应用层)]
  ads --> bi[BI 看板]
  ads --> feat[特征服务]
  feat --> ml[模型推理]
```

配色说明：源蓝 `#3B82F6`、管道紫 `#8B5CF6`、存储绿 `#10B981`、应用橙 `#F59E0B`；分层用 subgraph 收口。

---

### 7.4 AI 生图提示词模板（至少 2 个）

#### 模板 A · 系统架构概念图

适用场景：文章首屏用一张「概念级」架构全景，不求精确、求气势。

提示词：

```
中文：一张系统架构概念图，深色背景，主体是悬浮的模块化立方体群，按接入、逻辑、数据、基础设施
四层错落排列，层间有发光数据流连接，整体像一座发光的数据城市。未来感、专业、有体量。3D 渲染。

English: A system-architecture concept image, dark background, floating modular cubes arranged in four
layers (access, logic, data, infra), glowing data streams linking layers, like a glowing data city.
Futuristic, professional, massive. 3D render.
```

参数：尺寸 1200x900，风格 3D 概念。

负向提示词：文字标注、写实照片、杂乱、低对比。

---

#### 模板 B · 技术栈全景图

适用场景：展示「我们用了哪些技术」的鸟瞰。

提示词：

```
中文：一张技术栈全景概念图，浅色背景，主体是围绕中心内核向外辐射的多圈层技术环（语言、框架、
中间件、平台），每个环用不同色系区分，节点为发光圆点代表技术组件。结构清晰、信息密度高但不乱。
扁平矢量 + 轻微发光。

English: A tech-stack panorama concept, light background, concentric tech rings radiating from a center
core (languages, frameworks, middleware, platforms), each ring a different hue, nodes are glowing dots
representing components. Clear structure, high info density but orderly. Flat vector with slight glow.
```

参数：尺寸 1200x1200，风格 扁平矢量。

负向提示词：具象图标堆砌、照片、文字混乱。

---

### 8.3 Markdown 脑图模板（至少 3 个）

#### 模板 1 · 技术知识体系脑图

```markdown
# RAG 技术体系
### 8.4 Mermaid mindmap 模板（至少 2 个）

#### 模板 1 · 技术知识体系（Mermaid mindmap）

```mermaid
mindmap
  root((RAG 技术体系))
    检索
      向量检索
      混合检索
      重排序
    生成
      提示词工程
      上下文压缩
      引用溯源
    工程
      文档解析
      分块策略
      评估体系
    进阶
      Agentic RAG
      多模态 RAG
```

配色说明：Mermaid 默认按层级自动配色；如需分主分支配色，可在渲染后通过 CSS 类覆盖。

---

#### 模板 2 · 产品功能矩阵（Mermaid mindmap）

```mermaid
mindmap
  root((智能体平台))
    编排能力
      可视化画布
      多智能体协作
      工具调用
    知识能力
      文档入库
      向量检索
      权限控制
    集成能力
      API 开放
      企业微信
      Webhook
    运营能力
      对话日志
      效果评估
      用量统计
```

配色说明：root 用主色填充，四个一级分支自动区分色相，保持子节点同色系。

---

