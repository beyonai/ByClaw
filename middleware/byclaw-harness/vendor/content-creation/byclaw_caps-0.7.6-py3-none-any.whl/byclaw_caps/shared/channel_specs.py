#!/usr/bin/env python3
"""渠道画幅的单一事实来源。

画幅由 **渠道 × 媒介** 两维决定，只按渠道查表是不成立的：同一个「微信公众号」，
正文配图是 16:9 横版（嵌在文章里随正文宽度走），独立贴图是 3:4 竖版（读者竖屏逐张滑动）。

原缺陷是四层叠加、每层都静默：

1. 画幅表只有渠道一维，且缺贴图条目；
2. 键用连字符而 schema 用下划线，查表永远 miss；
3. miss 之后**静默回落**到正文配图的 1280×720 横版，不报错；
4. 校验器完全不看尺寸，横版图当竖版贴图一路走到发布。

因此本模块坚持两条：**媒介必填**（没有默认媒介，默认值正是那个缺陷的核心），
**未登记组合硬失败**。
"""

from __future__ import annotations

from math import gcd

VERSION = "2.2.0"

# 这两个值与生图能力的 BUSINESS_SIZES 是同一份契约（video_landscape 与 card）。
# 本文件要被整份复制进各 Skill 的 scripts/，不能 import byclaw_caps，故只能字面重复；
# 一致性由 tests/test_shared_libs.py 强制——不是靠人记得两处一起改。
# 16:9 横版：嵌在文章正文里的配图，随正文宽度走。
LANDSCAPE_SIZE = (1280, 720)
# 3:4 竖版：独立图文作品，读者在手机上竖屏逐张滑动。**这一档正是平台原生生图会降级的那个。**
PORTRAIT_SIZE = (1080, 1440)
# 2.35:1 超宽：公众号信息流首图。它与正文配图的 16:9 只差一点，但差的这一点就是上下各
# 被裁掉约 15%——封面文案正好压在这两条被裁的带上。原先封面没有自己的媒介，
# 一律按 article_body 拿 16:9，属于本模块开头列的同一类静默缺陷，只是漏掉的第三档。
COVER_SIZE = (900, 383)

# ── 正文配图的三个档位 ────────────────────────────────────────────────
# `LANDSCAPE_SIZE` 仍是缺省档，但**它不再是唯一档**。
#
# 原先所有正文配图一律 16:9，这一条反过来压制了图的深度：三层结构 + 批注层
# 在 720px 高里放不下，模型只能砍掉第二个信息寄存器和批注，产出"一排方块加箭头"。
# 三张达标样图的实际比例是 1.84 / 1.60 / 1.50，**没有一张是 16:9**。
#
# 档位由 `VisualPlan` 的 `body_size_tier` 指定，不是随便填的数：登记成枚举
# 是为了跨图一致，也为了 `image inspect` 能按档校验。
BODY_SIZE_TIERS: dict[str, tuple[int, int]] = {
    "body_wide": (1280, 720),   # 1.78 线性流程、单层对比（缺省）
    "body_std": (1280, 800),    # 1.60 多层结构、嵌套
    "body_tall": (1440, 960),   # 1.50 复合版式，一图一节
}
DEFAULT_BODY_TIER = "body_wide"


def resolve_body_size(tier: object) -> tuple[int, int]:
    """正文配图档位 → 画幅。空值落到缺省档，未登记档位硬失败。

    **不接受任意自定尺寸。** 允许现填宽高等于放弃跨图一致，且 `inspect`
    的字号换算要按设计宽度做，宽度随意就没有可比的基准了。
    """
    key = _normalise(tier) or DEFAULT_BODY_TIER
    size = BODY_SIZE_TIERS.get(key)
    if size is None:
        raise ChannelSpecError(
            f"未登记的正文配图档位：{tier}。必须是 "
            f"{'、'.join(BODY_SIZE_TIERS)} 之一。"
            "复合版式（layout=composite）必须用 body_tall；"
            "三层以上的层级结构不得用 body_wide。"
        )
    return size

MEDIUM_ARTICLE_BODY = "article_body"
MEDIUM_ARTICLE_COVER = "article_cover"
MEDIUM_IMAGE_TEXT_POST = "image_text_post"
MEDIUMS = frozenset({MEDIUM_ARTICLE_BODY, MEDIUM_ARTICLE_COVER, MEDIUM_IMAGE_TEXT_POST})

# 渠道别名 → 规范渠道键。历史产物用连字符，也有把上下文当渠道用的旧键。
CHANNEL_ALIASES: dict[str, str] = {
    "wechat_public_account": "wechat_public_account",
    "wechat_official_account": "wechat_public_account",
    "wechat_body": "wechat_public_account",
    "article_body": "wechat_public_account",
    "xiaohongshu": "xiaohongshu",
}

# （规范渠道, 媒介）→ 画幅。
CHANNEL_SIZES: dict[tuple[str, str], tuple[int, int]] = {
    ("wechat_public_account", MEDIUM_ARTICLE_BODY): LANDSCAPE_SIZE,
    ("wechat_public_account", MEDIUM_ARTICLE_COVER): COVER_SIZE,
    ("wechat_public_account", MEDIUM_IMAGE_TEXT_POST): PORTRAIT_SIZE,
    ("xiaohongshu", MEDIUM_ARTICLE_BODY): LANDSCAPE_SIZE,
    ("xiaohongshu", MEDIUM_IMAGE_TEXT_POST): PORTRAIT_SIZE,
    # 小红书刻意不登记 article_cover：它没有独立封面位，首图即封面，走 image_text_post。
    # 未登记组合硬失败，比给一个看似合理的默认值安全。
}

# 竖版媒介：独立作品一律竖版。
PORTRAIT_MEDIUMS = frozenset({MEDIUM_IMAGE_TEXT_POST})


class ChannelSpecError(ValueError):
    """渠道或媒介缺失、未登记；不提供默认画幅。"""


def _normalise(value: object) -> str:
    return str(value or "").strip().lower().replace("-", "_")


def canonical_channel(channel_ref: object) -> str:
    key = _normalise(channel_ref)
    if not key:
        raise ChannelSpecError(
            "channel_ref 为空，无法确定画幅。"
            f"已登记渠道：{'、'.join(sorted(set(CHANNEL_ALIASES.values())))}"
        )
    canonical = CHANNEL_ALIASES.get(key)
    if canonical is None:
        raise ChannelSpecError(
            f"未登记的 channel_ref：{channel_ref}。"
            f"已登记渠道：{'、'.join(sorted(CHANNEL_ALIASES))}。"
            "新增渠道必须显式登记画幅，不得沿用其它渠道的默认值。"
        )
    return canonical


def resolve_channel_size(channel_ref: object, medium: object) -> tuple[int, int]:
    """返回该渠道该媒介的目标画幅。

    `medium` **必填**，取值 `article_body`、`article_cover` 或 `image_text_post`。不设默认媒介：
    默认值会让贴图静默拿到正文配图的横版画幅，那正是本模块要根治的缺陷。
    """
    canonical = canonical_channel(channel_ref)
    medium_key = _normalise(medium)
    if not medium_key:
        raise ChannelSpecError(
            f"medium 为空，无法确定画幅。必须显式给出 {'、'.join(sorted(MEDIUMS))} 之一——"
            "同一渠道的正文配图与独立贴图画幅不同。"
        )
    if medium_key not in MEDIUMS:
        raise ChannelSpecError(
            f"未登记的 medium：{medium}。必须是 {'、'.join(sorted(MEDIUMS))} 之一。"
        )
    size = CHANNEL_SIZES.get((canonical, medium_key))
    if size is None:
        raise ChannelSpecError(
            f"渠道 {canonical} 与媒介 {medium_key} 的组合未登记画幅，必须显式登记。"
        )
    return size


def is_portrait(medium: object) -> bool:
    return _normalise(medium) in PORTRAIT_MEDIUMS


def aspect_ratio(width: int, height: int) -> str:
    """由真实画幅约分得出比例。

    原先写死「竖版就是 3:4，否则 16:9」，加进封面这一档后那句话直接是错的
    （900x383 既不是 3:4 也不是 16:9）。比例是画幅的函数，不该另存一份判断。
    """
    divisor = gcd(width, height)
    return "%d:%d" % (width // divisor, height // divisor)


def describe(channel_ref: object, medium: object) -> dict[str, object]:
    width, height = resolve_channel_size(channel_ref, medium)
    return {
        "channel_ref": canonical_channel(channel_ref),
        "medium": _normalise(medium),
        "width": width,
        "height": height,
        "orientation": "portrait" if is_portrait(medium) else "landscape",
        "aspect_ratio": aspect_ratio(width, height),
    }
