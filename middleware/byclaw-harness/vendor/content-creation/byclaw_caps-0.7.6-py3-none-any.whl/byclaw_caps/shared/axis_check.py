# -*- coding: utf-8 -*-
"""数值图的几何校验：刻度、量尺与倍数标注必须自洽。

方案《配图语义规划方案.md》§4.1 的机器可判部分。

## 为什么需要它

0913 那轮交付的 `visual-004` 是一张对数轴图。四个刻度（小时/天/周/季/年）
落在一条干净的对数尺上——按 `x = a + k·ln(v)` 回归，四段算出的 k 分别是
73.6 / 73.5 / 73.6 / 74.3，一致得很好。

而图上画了两根倍数量尺：

| 标注 | 几何长度 | 按该尺度实际代表的倍数 |
|---|---:|---:|
| `≈1000×` | 669px | **8698×** |
| `5.3×` | 122px | 5.23×（对） |

小时到年本来就是 8760 倍，标成「≈1000×」差了近一个数量级。

**两道门禁都放行了**：`inspect` 查的是溢出、字号、术语、文字占比——
它不知道 669px 在这张图上意味着什么；语义复核读的是断言与来源，
而「≈1000×」这个数字在正文里找不到对应的原句可比。

这类错误有个共同点：**它不在文字里，在几何里**。文字说 1000，
像素说 8698，而没有任何一层同时看这两样。这个模块就是那一层。

## 它不做什么

不判断「这张图该不该这么画」，也不替代语义复核。它只回答一个确定性问题：
**图上标出来的倍数，和画出来的长度，是不是同一回事。**
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

#: 对数轴上，两点间距离与 ln(值之比) 成正比。回归出的 k 若在各段之间
#: 相差超过这个比例，说明它压根不是一条对数轴——那时不做倍数校验，
#: 只报"轴本身对不上"，避免拿一个错误的尺度去算出更离谱的结论。
AXIS_FIT_TOLERANCE = 0.05

#: 倍数标注允许的相对误差。标「≈1000×」而实际 1030× 是可接受的取整，
#: 8698× 不是。**放宽到能容下取整，但容不下一个数量级。**
DEFAULT_RATIO_TOLERANCE = 0.15


class AxisError(ValueError):
    def __init__(self, code: str, message: str, **detail) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.detail = detail


@dataclass(frozen=True)
class Finding:
    code: str
    message: str
    detail: dict


def fit_log_axis(ticks: Sequence[Mapping[str, float]]) -> tuple[float, float]:
    """从刻度反推 `x = a + k·ln(v)`，返回 `(a, k)`。

    `ticks` 是 `[{"px": 51, "value": 1}, …]`，`value` 必须为正
    ——**对数轴上不存在 0 与负数**，落上去的点没有意义，不能靠裁剪蒙混过去。
    """
    points = [(float(t["px"]), float(t["value"])) for t in ticks]
    if len(points) < 2:
        raise AxisError("AXIS_TOO_FEW_TICKS",
                        "对数轴至少要两个刻度才能定出尺度，实际 %d 个" % len(points))
    bad = [v for _, v in points if v <= 0]
    if bad:
        raise AxisError(
            "AXIS_NONPOSITIVE_VALUE",
            "对数轴上出现非正值：%s。ln 对它们无定义——"
            "这类值要么换线性轴，要么显式说明截断口径。" % bad, values=bad)

    slopes = []
    for (x1, v1), (x2, v2) in zip(points, points[1:]):
        span = math.log(v2) - math.log(v1)
        if abs(span) < 1e-12:
            raise AxisError("AXIS_DUPLICATE_VALUE",
                            "相邻刻度的值相同（%g），定不出尺度" % v1)
        slopes.append((x2 - x1) / span)
    k = sum(slopes) / len(slopes)
    if k == 0:
        raise AxisError("AXIS_DEGENERATE", "刻度算出的尺度为 0")
    spread = (max(slopes) - min(slopes)) / abs(k)
    if spread > AXIS_FIT_TOLERANCE:
        raise AxisError(
            "AXIS_NOT_LOGARITHMIC",
            "这些刻度不在同一条对数尺上：各段尺度 %s，相差 %.1f%%。"
            "**先把轴本身弄对**，否则拿它去校验倍数只会算出更离谱的结论。"
            % ([round(s, 1) for s in slopes], spread * 100),
            slopes=slopes)
    a = points[0][0] - k * math.log(points[0][1])
    return a, k


def ratio_for_span(px: float, k: float) -> float:
    """在尺度 k 的对数轴上，长度 px 代表的倍数。"""
    return math.exp(px / k)


def check_log_axis_annotations(
    ticks: Sequence[Mapping[str, float]],
    annotations: Iterable[Mapping[str, object]],
    *,
    tolerance: float = DEFAULT_RATIO_TOLERANCE,
) -> list[Finding]:
    """量尺标的倍数，和它画出来的长度，对得上吗。

    `annotations` 是 `[{"label": "≈1000×", "ratio": 1000, "px": 669}, …]`：
    `ratio` 是图上写的那个数，`px` 是那根量尺的几何长度。

    返回全部不一致项——**一次说完**，否则改一根量一次，四根就要四轮。
    """
    a, k = fit_log_axis(ticks)
    findings: list[Finding] = []
    for one in annotations:
        label = str(one.get("label") or "")
        px = float(one.get("px") or 0)
        declared = float(one.get("ratio") or 0)
        if declared <= 0:
            findings.append(Finding(
                "ANNOTATION_NONPOSITIVE_RATIO",
                "量尺「%s」声明的倍数不是正数：%g" % (label, declared),
                {"label": label}))
            continue
        actual = ratio_for_span(px, k)
        drift = abs(actual - declared) / declared
        if drift > tolerance:
            findings.append(Finding(
                "ANNOTATION_RATIO_MISMATCH",
                "量尺「%s」标的是 %g×，而它在这条轴上画出来是 %.4g×"
                "（相差 %.0f%%）。**文字说一个数、像素说另一个数**——"
                "两者必须来自同一份数据。"
                % (label, declared, actual, drift * 100),
                {"label": label, "declared": declared,
                 "actual": actual, "px": px}))
    return findings


def check_axis_covers(ticks: Sequence[Mapping[str, float]],
                      *, claimed_span: float | None = None,
                      tolerance: float = DEFAULT_RATIO_TOLERANCE) -> list[Finding]:
    """整条轴的跨度，与图上宣称的总跨度一致吗。

    0913 那张图两头是小时与年——8760 倍，而图上写「≈1000×」。
    **端点是公开可算的**，这一条不需要任何额外声明就能查。
    """
    if claimed_span is None:
        return []
    values = [float(t["value"]) for t in ticks]
    actual = max(values) / min(values)
    drift = abs(actual - claimed_span) / claimed_span
    if drift <= tolerance:
        return []
    return [Finding(
        "AXIS_SPAN_MISMATCH",
        "轴两端是 %g 与 %g，跨度 %.4g×，而图上宣称 %g×（相差 %.0f%%）。"
        % (min(values), max(values), actual, claimed_span, drift * 100),
        {"actual": actual, "claimed": claimed_span})]


__all__ = ["AxisError", "Finding", "AXIS_FIT_TOLERANCE",
           "DEFAULT_RATIO_TOLERANCE", "fit_log_axis", "ratio_for_span",
           "check_log_axis_annotations", "check_axis_covers"]
