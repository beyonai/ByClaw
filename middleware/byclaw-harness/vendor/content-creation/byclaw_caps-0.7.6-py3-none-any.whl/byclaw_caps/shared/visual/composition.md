# Composition

## Establish the frame

- Treat the requested pixel dimensions as a fixed poster, not a responsive webpage.
- Reserve 5–7% of width as safe-area padding and 5–8% of height as safe-area padding.
- Choose one reading direction: left-to-right, top-to-bottom, center-out, or staged depth.
- Give one element dominant weight. Secondary elements must support it rather than compete.
- Use a 4px or 8px spacing base and align major edges to a visible grid.

## Allocate density

- Keep 15–30% of the frame as meaningful negative space.
- Prefer 3–7 primary nodes. Group larger systems into labeled regions instead of shrinking everything.
- Keep body labels concise. Move explanations into captions or callouts.
- Avoid placing essential labels or arrowheads within 32px of a canvas edge.

## Connectors

- Draw connectors in one full-canvas inline SVG layer behind or between node layers.
- Derive paths from stable grid positions. Avoid visually crossing labels.
- Use orthogonal paths for technical architecture and gentle curves for conceptual relationships.
- Use one line weight family: 1.5–2px primary, 1px secondary.
- Add arrowheads only when direction matters. Do not decorate every line.

## Text hierarchy

- Use at most 6–8 sizes in the whole visual and at most 3 above the fold.
- Keep display headings short. Keep explanatory text around 45–70 characters per line.
- Use monospace for identifiers, code, ports, coordinates, and sequence numbers—not general prose.
