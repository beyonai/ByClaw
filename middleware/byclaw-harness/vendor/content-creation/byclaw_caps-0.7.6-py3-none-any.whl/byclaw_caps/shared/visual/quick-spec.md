# 公众号配图快速规范

## Default Asset Set

| Article Type | Required | Optional |
| --- | --- | --- |
| 技术深度稿 | cover, architecture, flowchart | mindmap, code illustration |
| 业务场景稿 | cover, scenario diagram, flowchart | comparison card, mindmap |
| 产品评测稿 | cover, comparison chart, data chart | UI screenshot, recommendation card |
| 行业洞察稿 | cover, data chart, mindmap | concept illustration, quote card |

## Dimensions

| Asset | Size |
| --- | --- |
| WeChat cover | 900x383 |
| Square share cover | 200x200 |
| Body visual | 1280x720 / 1280x800 / 1280x640 |
| Diagram | 900-1200px wide, or 1280x720 |
| Mindmap | within 1200x1200 |
| Xiaohongshu | 1080x1440 |
| Video account | 1080x1920 |

## Manifest Fields

Each generated asset must be listed in `manifest.md`:

| File | Type | Dimensions | Method | Article Position | Alt Text | Verification |
| --- | --- | --- | --- | --- | --- | --- |

## Prompt Pattern

Use bilingual prompts for AI image generation:

```text
中文：主体 + 风格 + 构图 + 配色 + 细节 + 留白/文字区说明。

English: subject + style + composition + palette + details + reserved text area.

Size: WIDTHxHEIGHT
Negative prompt: malformed text, unreadable labels, cluttered layout, low contrast, photorealistic people unless required, copyright logos.
```

## Rendering Pattern

文字密集的图先写 HTML，再走图像栅格化能力渲染：

```bash
python3 -m byclaw_caps.raster html source.html output.png --width 1280 --height 720 --scale 2
```

> 这一条原先写的是 `python scripts/render_html_to_image.py`。**该脚本不存在**，
> 全仓库无此文件——照着它写调用会直接撞墙。同一份文件下面那段批注讲的正是
> 这类失效路径（`finalize_assets.py` 的旧写法），**同一个毛病在同一份文件里长了两次**，
> 这回是在渲染那一步。渲染只有一个出口：`byclaw_caps.raster`。

独立 `.svg` 源文件（`generation_method=svg_file`）走 `raster svg` 子命令，不走上面的
`raster html`——后者按视口渲染整页，而 SVG 的画布应由根节点 `viewBox` 决定：

```bash
python3 -m byclaw_caps.raster svg source.svg output.png --scale 2
```

**公众号不显示 SVG**，正文里直接放 `.svg` 会整张不出图，必须先转成 PNG 再入渠道包。
默认 2 倍出图：公众号正文图按约 677px 宽显示，1 倍在高分屏上会糊。

图片全部生成并打开检查后，**不要手工编辑 manifest**：

```bash
python3 -m byclaw_caps.image finalize-assets --plan visual-plan.json \
  --asset visual-001=visual-001.png --asset visual-002=visual-002.png --reviewed-all
python3 -m byclaw_caps.image validate-assets --plan visual-plan.json
```

两份 `image-asset-manifest.{json,yaml}` 落在**图片所在目录**，不是 `.meta/`——
发布前的联合校验按图片目录去找它们。

> 这两条原先写的是 `python scripts/finalize_assets.py`，还跟着一段
> `invoke-content-*.ps1` 的 Windows 包装写法。**那些路径和脚本都已经不存在。**
> 唯一提到这三个模块的地方指向失效路径，等于没提——2026-08-28 实测里
> 配图助理因此手拼了 manifest，再读源码反推 schema。

**`--selector` 与 `--full-page` 当前不可用。** 二者需要 Patchright 或 Playwright 及其
配套 Chromium，而本环境未安装；Chrome CLI 路径遇到它们会直接硬失败。照这两个选项写调用
会撞墙，故不要用。

需要只截页面一部分时，改在 HTML 里做：把不想入镜的辅助内容移出，或用容器宽高把捕获区域
框成整个视口。这样走的仍是确定性渲染，不必引入额外运行时。
