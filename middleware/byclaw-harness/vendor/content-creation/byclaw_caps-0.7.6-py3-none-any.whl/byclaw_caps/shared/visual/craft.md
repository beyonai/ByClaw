# Craft rules

These rules are adapted from Open Design's brand-agnostic craft references.

## Typography

- Use no more than two typeface families and three weights.
- Use `line-height: 1–1.2` for display text and `1.45–1.65` for body text.
- Apply `letter-spacing: -0.01em` to `-0.03em` to headings 32px and larger.
- Apply at least `0.06em` positive tracking to all-caps labels.
- Keep body text left-aligned; do not justify text.
- Always include local system fallback families.

## Color

- Allocate 70–90% of pixels to neutral surfaces and text.
- Use one accent color and no more than two visible accent moments per frame.
- Maintain at least 4.5:1 contrast for normal text and 3:1 for large text and UI boundaries.
- Name CSS variables by purpose, such as `--accent` and `--muted`, not by hue.
- Avoid hardcoded Tailwind indigo (`#6366f1`, `#4f46e5`, `#7c3aed`) unless explicitly required.

## Avoid generic AI styling

- Do not use purple-to-blue, blue-to-cyan, or indigo-to-pink decorative gradients.
- Never use emoji as icons. Every icon must be inline SVG with `currentColor`; emoji render inconsistently across platforms and break the style system.
- Do not combine rounded cards with colored left borders.
- Do not add decorative blobs, waves, glass effects, or glows without semantic purpose.
- Do not repeat identical cards merely to fill space.
- Do not use placeholder text, invented metrics, or unverified claims.

## Polish

- Use approximately 80% proven structure and 20% distinctive visual choice.
- Add one memorable move: an intentional type contrast, proportion, annotation system, or motion cue.
- Check optical alignment, not only mathematical centering.
- Make borders, shadows, and radii consistent with the selected style profile.
