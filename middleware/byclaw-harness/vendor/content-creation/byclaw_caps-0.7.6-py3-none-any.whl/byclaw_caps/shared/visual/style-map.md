# 公众号 HTML 模板与配图风格映射

Use this file before generating article images. Match the image system to the selected `html-template-skill` template ID.

| Template ID | Visual Direction | Palette | Best Assets |
| --- | --- | --- | --- |
| `tech` | dark tech, code texture, layered systems, node links | near-black, blue, cyan, green | cover, architecture, data flow, code concept |
| `biz` | bright business, workflow loop, growth metrics, cards | white, navy, trust blue, green, orange highlights | cover, flowchart, scenario diagram, KPI cards |
| `review` | neutral comparison, objective evidence, red/green states | gray, white, green, red/orange, blue accent | comparison chart, score card, feature matrix |
| `insight` | editorial, strategic, high-contrast, restrained accent | black, white, gray, deep red, muted gold | cover, data chart, framework mindmap, quote card |
| `lifestyle` | soft, emotional, airy, image-led | oatmeal, beige-gray, muted brown, soft green | mood cover, body illustration, quote card |
| `news` | compact briefing, modular, scan-friendly | black, white, gray, one bright accent | roundup card, timeline, list graphic |
| `story` | narrative, interview, documentary, quote-led | charcoal, warm gray, subdued gold | portrait card, quote card, story timeline |
| `tutorial` | operational, stepwise, checklist-oriented | green, blue, white, light gray | step diagram, checklist image, process card |
| `ecommerce` | product launch, conversion, visual emphasis | rose/red, white, high-contrast accent | product hero, offer card, comparison image |
| `education` | structured knowledge, course-like, trustworthy | sky blue, white, navy, soft gray | knowledge map, framework card, teaching diagram |
| `event` | invitation, agenda, location and time clarity | violet, white, refined accent | event poster, agenda card, registration card |
| `humor` | conversational, meme-like, light interaction | yellow, warm neutrals, simple comic accents | dialogue card, reaction graphic |
| `architecture` | layered blocks, system modules, data movement | blue, purple, green, gray | architecture diagrams |
| `flowchart` | node path, decision branches, outcomes | blue, orange, green, red, gray | process diagrams |
| `mindmap` | root/branch/leaf knowledge tree | branch colors with light background | mindmaps |
| `funnel` | stages, conversion, drop-off | blue, indigo, red/orange drop-off | funnel charts |
| `svg-chart` | precise charting, readable labels | match article palette | bar/line/chart visuals |
| `svg-icon` | feature icons and capability grids | match article palette | icon grids |
| `card-design` | premium quote, profile, and data cards | match article palette | inline cards |

## Illustration Style Profiles

按画面性质选风格档，加载 `references/styles/<style>.md`：

| 风格档 | 适用 | 执行 |
|---|---|---|
| `ian-xiaohei` | **隐喻类**：判断、转折、状态、抽象机制 | `scripts/build_xiaohei_prompt.py` 拼装提示词 → `python3 -m byclaw_caps.image` |
| `technical-dark` | 技术产品氛围图 | `python3 -m byclaw_caps.image` |
| `editorial` | 编辑部、观点类氛围图 | `python3 -m byclaw_caps.image` |
| `sketch` | 低保真线框、探索稿 | `python3 -m byclaw_caps.image` |

事实类结构图不选风格档——改用 `infographic` 或 `html_svg` 确定性渲染。

## Route Selection

- Use HTML/SVG rendering for all text-heavy visuals.
- Use HTML/SVG rendering for charts, architecture, flowcharts, funnels, mindmaps, and cards.
- Use AI image generation for abstract covers and atmosphere illustrations.
- If an AI image needs title text, generate the background first, then overlay text with HTML/SVG.

## Cross-Asset Consistency

- Reuse the cover's primary color in all body visuals.
- Keep icon stroke width, card radius, shadow depth, and line style consistent across a single article.
- Do not mix more than one illustration language in a single article.
- For technical and business articles, prioritize clarity over decoration.
