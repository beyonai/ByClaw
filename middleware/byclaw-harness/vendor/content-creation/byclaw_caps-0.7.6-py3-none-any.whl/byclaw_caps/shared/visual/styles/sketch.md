# Sketch style

Adapted from Open Design's wireframe-sketch template.

- Mood: exploratory, human, low-fidelity, legible.
- Canvas: warm white or pale graph paper; graphite ink; one yellow, coral, or blue highlighter.
- Background: 20–28px graph grid drawn with low-opacity CSS linear gradients.
- Typography: sturdy serif or sans for titles, system sans for labels, monospace for notes. Do not depend on remote handwriting fonts.
- Shapes: dashed borders, hatched SVG fills, checkboxes, sticky notes, and slight rotations between `-0.8deg` and `0.8deg`.
- Composition: present 1–4 variants or one annotated screen. Keep the main idea readable despite looseness.
- Signature move: one taped note, highlighter swipe, or hand-drawn callout.
- Avoid: excessive randomness, illegible faux handwriting, polished production UI, and animation that makes geometry drift.
