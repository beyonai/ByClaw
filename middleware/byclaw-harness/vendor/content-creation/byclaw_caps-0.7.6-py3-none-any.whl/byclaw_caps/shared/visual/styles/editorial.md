# Editorial style

Adapted from Open Design's Atelier Zero and magazine-poster systems.

- Mood: intelligent, tactile, restrained, magazine-like.
- Canvas: warm paper around `#efe7d2`; ink around `#15140f`; muted ink around `#5a5448`.
- Accent: one coral around `#ed6f5c`; use it for one mark, keyword, or critical route.
- Typography: compressed bold sans for structural headings, italic serif for one emotional phrase, readable sans or serif for body, monospace for annotations.
- Composition: asymmetric, top-biased, generous negative space, hairline rules, numbered sections, small metadata.
- Texture: optional subtle inline SVG paper noise below 7% opacity. Do not let texture reduce legibility.
- Components: flat paper surfaces, thin ink rules, limited radii, no glassmorphism.
- Signature move: mix one italic serif phrase into a bold display heading or use editorial plate annotations.
- Avoid: generic SaaS cards, cool gray surfaces, multiple hot colors, large soft shadows.
