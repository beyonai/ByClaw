# Technical dark style

Adapted from Open Design's Resend and HUD systems.

- Mood: precise, cinematic, technical, calm.
- Canvas: near-black `#0f1115`; surface `#171b22`; text `#f0f2f5`; muted `#949dab`.
- Structure: use blue-tinted white borders around `rgba(214,235,251,.16)` instead of heavy shadows.
- Accent: choose one coral, amber, cyan, or green based on meaning. Never mix accent families in one diagram.
- Typography: neutral sans for labels, deliberate display face for titles, monospace for code, ports, events, and identifiers.
- Composition: strong grid, labeled system boundaries, compact legends, generous gaps between runtime regions.
- Components: 8–16px radii, 1px frost borders, subtle ring shadows only.
- Signature move: one luminous route, selected node, or protocol marker against an otherwise neutral system.
- Avoid: pure-white panels, neon rainbow accents, indiscriminate glow, dashboard tile repetition.
