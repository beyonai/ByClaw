# Infographic DSL 约定

`generation_method=infographic` 的图由 AntV Infographic 渲染。模型只写 DSL，版式与配色由引擎保证。

DSL 写好后**先运行本地校验**，通过再交给渲染：

```bash
python3 scripts/validate_infographic_dsl.py --input path/to/source.ifgc
```

退出码 0 通过，2 不通过。校验的是本项目约定，语法正确性由渲染侧的 `validate.mjs` 负责，两者都要过。


## 选它之前先确认可用

**`antv-infographic-creator` 必须已安装且可调用。** 未安装时它产出不了图，而计划里仍会引用
那个不存在的文件——渲染出来是有标题有说明、中间整块空白的坏图，**且不报错**。

事实类结构图不是只有这一条路：`html_svg` 与 `svg_file` 同属确定性渲染，数值只来自输入、
由代码绘制。确认不了可用性就用它们，**不要退到 AI 生图**——生图模型会编造数字。

**默认路线是 `html_svg`，不是本文件。** `html_svg` 有可直接填充的骨架库与设计令牌，
见 `references/article-visual/diagram-design-system.md`；`infographic` 只在
「`antv-infographic-creator` 确认可调用」且图形正好落在下表某个模板族里时才更省事。
本文件按需加载——没打算走这条路就不必读下去。

## 一、必须声明手绘主题

```
theme
  name hand-drawn
  palette #1f2933 #f97316 #c4513b
```

不写 `theme` 块会回落到默认 `light` 主题——规整商务风。同一篇内容里事实类信息图是商务风、隐喻类小黑图是手绘风，成片和图文都会明显割裂。

`palette` 必须显式给出品牌色，不依赖引擎默认值。色值用十六进制。

## 二、图标必须用固定 ID

```
icon mingcute/search-line        ✅ 固定 ID
icon rocket launch               ❌ 语义关键词
```

语义关键词要走蚂蚁的公网检索接口 `www.weavefox.cn`。该接口在服务端可能不通，而且 **SSR 通道下图标失败是静默的**——不报错、不告警，出图后才发现少了图标。固定 ID 绕开检索这一跳。

不需要图标时直接不写 `icon` 行。

## 三、模板族决定数据字段

| 模板族 | 数据字段 | 典型用途 |
|---|---|---|
| `list-*` | `lists` | 并列要点、网格 |
| `sequence-*` | `sequences` | 步骤、时间轴、漏斗、路线图 |
| `hierarchy-*` | `root` | 树、思维导图、组织架构 |
| `compare-*` | `compares` | 双方对比、SWOT |
| `relation-*` | `nodes` | DAG 流程图、网络图、环形关系 |
| `chart-*` | `values` | 折线、柱状、饼图 |
| `quadrant-*` | `quadrants` | 四象限 |

写错字段是 AI 生成 DSL 最常见的错误，且渲染出的图会缺内容而不报错。

## 四、渲染必须走浏览器

Infographic 把**所有正文文字放在 `<foreignObject>` 里**，没有 `<text>` 降级路径。resvg、librsvg、sharp、cairosvg 都不支持 `foreignObject`——用它们光栅化会得到一张只有色块、**一个中文都没有**的图，而且不报错。

所以 PNG 必须由 Chromium / Chrome / Edge 光栅化。`antv-infographic-creator` 的 `render.mjs` 已经这么做，不要改成轻量链路。

## 五、画幅不可指定

`width` / `height` 参数会被内容包围盒覆盖，输出恒为内容自适应尺寸，宽高比不固定。

归一化由调用方负责：等比缩放 + 居中 + 白底补边到目标画幅。视频链路统一归一化到 1920×1080，图文链路按渠道规范。

## 六、出图后必须校验文字非空

因为中文丢失时引擎不报错，只判断"PNG 生成成功"是不够的。

校验方式是 **DOM 断言**：在 Chromium 出图前读取页面里 `foreignObject` 的文本节点，与 DSL 的 `title` / `label` 逐项比对。比 OCR 准确、快，且能指出是哪个字段丢了。

## 示例

```
infographic sequence-timeline-simple
data
  title 知识库生长机制
  sequences
    - label 发现
      desc 素材自动认亲
      icon mingcute/search-line
    - label 完善
      desc 沿线取料
      icon mingcute/edit-line
    - label 加固
      desc 补薄弱环节
      icon mingcute/shield-line
theme
  name hand-drawn
  palette #1f2933 #f97316 #c4513b
```

## 内容规则

- 一张图只讲一个核心结构。
- 主要条目 3–7 项。少于 3 项版面空，多于 7 项拥挤。
- 标题直接，条目标签短，描述一句话说完。
- 数字用 `value` 数值字段，单位写在标签或描述里。
- 竖向时间轴、树、长列表增加画布高度；对比、泳道、左右关系增加宽度。**先缩短文案，再调字号。**
