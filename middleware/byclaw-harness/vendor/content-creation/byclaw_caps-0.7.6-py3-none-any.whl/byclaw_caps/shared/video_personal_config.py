"""Personal parameter injection; report presence only, never credential values."""
import argparse
import json
import os
from pathlib import Path
from urllib.parse import urlsplit


def keys(purpose):
    prefix = "VIDEO_" + purpose.upper()
    return tuple(prefix + suffix for suffix in ("_API_KEY", "_BASE_URL", "_MODEL"))


def values():
    return dict(os.environ)


def require_tencent():
    data = values()
    names = ("TENCENTCLOUD_SECRET_ID", "TENCENTCLOUD_SECRET_KEY")
    invalid = [key for key in names if not data.get(key, "").strip()
               or data[key].strip().startswith("REPLACE_ME_")]
    if invalid:
        raise ValueError("请到头像→设置→个人参数配置填写：" + ", ".join(invalid))
    return {key: data[key] for key in names}


def resolve(purpose):
    data = values()
    required = keys(purpose)
    # Use an explicit complete purpose-specific group; never mix with legacy keys.
    missing = [key for key in required if not data.get(key, "").strip()]
    if missing:
        raise ValueError("个人参数缺失：" + ", ".join(missing))
    placeholders = [key for key in required if data[key].strip().startswith("REPLACE_ME_")]
    if placeholders:
        raise ValueError("个人参数仍为占位值：" + ", ".join(placeholders))
    token, base, model = [data[key].strip() for key in required]
    url = urlsplit(base)
    if url.scheme != "https" or not url.hostname or url.username or url.password or url.query or url.fragment:
        raise ValueError(required[1] + " 必须为不含认证信息、查询串的HTTPS API基础地址")
    if url.path.rstrip("/").endswith("/chat/completions"):
        raise ValueError(required[1] + " 请填API基础地址，不含/chat/completions")
    return {"token": token, "url": base.rstrip("/"), "model": model}


def status(purpose):
    data = values()
    required = keys(purpose)
    missing = [key for key in required if not data.get(key, "").strip()]
    placeholders = [key for key in required if data.get(key, "").strip().startswith("REPLACE_ME_")]
    issue = "placeholder_values" if placeholders else None
    if not missing and not placeholders:
        try:
            resolve(purpose)
        except ValueError:
            issue = "invalid_base_url"
    return {"purpose": purpose, "configured": {key: key not in missing for key in required},
            "missing": missing, "placeholders": placeholders, "issue": issue, "configuration_ready": not missing and issue is None,
            "authentication_verified": False, "capability_verified": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--purpose", choices=["vision", "analysis"], required=True)
    args = parser.parse_args()
    try:
        result = status(args.purpose)
        if args.purpose == "vision":
            data = values()
            result["tencent_configured"] = {key: bool(data.get(key, "").strip()) and not data[key].strip().startswith("REPLACE_ME_") for key in
                ("TENCENTCLOUD_SECRET_ID", "TENCENTCLOUD_SECRET_KEY")}
            result["configuration_ready"] &= all(result["tencent_configured"].values())
        print(json.dumps(result, ensure_ascii=False))
        raise SystemExit(0 if result["configuration_ready"] else 1)
    except (ValueError, OSError) as exc:
        print(json.dumps({"status": "configuration_error", "error_type": type(exc).__name__}))
        raise SystemExit(1)
