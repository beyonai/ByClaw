#!/usr/bin/env python3
"""按叙事段合成：一段音频里气脉连续，再按词级时间戳切回逐镜。

## 为什么改

16 段各自独立合成，每段从静默起、到静默止——拼起来就是 **16 条播报**，
每段重新起调。真人讲一段话是一条气脉，这是「一听就知道是 AI」的一大来源。

全片旁白 603 字，单次上限 10000 字，放得下。官方 OpenAPI 还明写
「段落切换用换行符标记」——段内用换行拼接，模型自己会处理段间气口。

## 为什么不整片合成

整片合成后改一句，**整条音频重生成**，全部镜头的时长与字幕轴一起作废：
合成是不确定的，同请求体极差 11%。逐镜合成时改一句只影响一镜。

折中是**按叙事段**：段内气脉连续，改动影响面限于一组。

## 切分怎么保证对

合成的文本就是各镜旁白用换行拼起来的，字符序列是确定的。
拿词级时间戳的字符流去**对齐**每一镜的起止——不是按时长平分。
对不上就报错：硬切成等长会让画面与话音全片错位，而且不报错。

## 一条标定上的教训

语速标定必须用**裸句**。拿含停顿标记与语气词的段落去测，
测到的是「含气口的整体节奏」而不是语速——阅历姐姐因此被误判成
3.85 字/秒，实际裸句是 5.13。
"""

from __future__ import annotations

import re

from . import TtsError

VERSION = "1.0.0"

#: 一组的字数上限。太长时改一句的代价太大，也逼近单次字数上限。
MAX_SEGMENT_CHARS = 400

#: 叙事段。相邻同段的镜头合成一组。
_SECTION_OF = {
    "title": "开场", "hook": "开场",
    "context": "铺垫", "problem": "铺垫",
    "turn": "转折",
    "mechanism": "机制",
    "payoff": "兑现", "closing": "收尾",
}

#: 不发音的行内标记：停顿与语气词。它们不出现在词级时间戳里。
_MARKERS = re.compile(r"<#\d+(?:\.\d{1,2})?#>|\([a-z-]+\)")
#: 标点。对齐时两边都要去掉。
_PUNCT = re.compile(r"[\s，。：；？！、（）()「」“”\"'—…·,.!?:;]+")


def strip_markers(text: str) -> str:
    """去掉停顿标记与语气词。它们不发音，也不进词流。"""
    return _MARKERS.sub("", str(text or ""))


def _spoken(text: str) -> str:
    return _PUNCT.sub("", strip_markers(text))


def spoken_length(text: str) -> int:
    """一段旁白里**真正发出声音**的字数：去掉标记、语气词与标点。

    语速门禁按它计数。手工数最容易把 ``<#0.3#>`` 与 ``(breath)`` 算进去，
    把语速算低——于是门禁报「太慢」，作者去加内容，结果真的超上限。
    """
    return len(_spoken(str(text or "")))


def plan_segments(shots) -> list[dict]:
    """把镜头按叙事段分组。相邻同段合成一组，超长再拆。"""
    items = list(shots or [])
    if not items:
        raise TtsError("没有镜头可分组——空脚本不该走到配音这一步")
    groups: list[dict] = []
    for shot in items:
        section = _SECTION_OF.get(str(shot.get("narrative_role") or ""), "其他")
        length = len(_spoken(str((shot.get("narration") or {}).get("text") or "")))
        if groups and groups[-1]["section"] == section:
            current = sum(len(_spoken(str((s.get("narration") or {}).get("text") or "")))
                          for s in groups[-1]["shots"])
            if current + length <= MAX_SEGMENT_CHARS:
                groups[-1]["shots"].append(shot)
                continue
        groups.append({"id": f"SEG{len(groups) + 1:02d}",
                       "section": section, "shots": [shot]})
    return groups


def segment_text(shots, *, decorate=None) -> str:
    """把一组镜头的旁白拼成一次请求的文本。

    **用换行分隔**——OpenAPI 明写换行是段落切换标记，模型据此安排段间气口。
    """
    parts = []
    for shot in shots or []:
        text = str((shot.get("narration") or {}).get("text") or "")
        if decorate is not None:
            text = decorate(text, shot)
        parts.append(text)
    return "\n".join(parts)


def locate_shots(words, texts) -> list[dict]:
    """在一段音频里定位每一镜的起止秒。

    Args:
        words: :func:`byclaw_caps.tts.timestamps.parse_words` 的产出。
        texts: 这一组各镜的旁白原文（可含停顿标记与语气词，会被剥掉）。

    Raises:
        TtsError: 有一镜在词流里对不上。**不退回等长切分**——
            那会让画面与话音全片错位，而且不报错。
    """
    stream, owners = [], []
    for index, word in enumerate(words or []):
        for char in _spoken(word.get("text", "")).casefold():
            stream.append(char)
            owners.append(index)
    joined = "".join(stream)
    if not joined:
        raise TtsError("词级时间戳里没有可用的字符，无法定位镜头")

    spans, cursor = [], 0
    for text in texts:
        target = _spoken(text).casefold()
        if not target:
            raise TtsError("有一镜的旁白为空，无法定位")
        at = joined.find(target, cursor)
        if at < 0:
            raise TtsError(
                f"在这一段的词流里找不到「{target[:12]}…」——"
                "合成文本与脚本对不上。等长切分会让画面与话音全片错位，所以报错")
        start = float(words[owners[at]]["start"])
        end = float(words[owners[at + len(target) - 1]]["end"])
        spans.append({"start": start, "end": end})
        cursor = at + len(target)

    # 相邻镜首尾相接：留空隙会丢话音，重叠会重复。
    for previous, current in zip(spans, spans[1:]):
        previous["end"] = current["start"]
    spans[-1]["end"] = float(words[-1]["end"])
    for span in spans:
        if span["end"] <= span["start"]:
            raise TtsError(f"定位出非正时长的镜头：{span}")
    return spans


__all__ = ["VERSION", "MAX_SEGMENT_CHARS", "strip_markers", "spoken_length",
           "plan_segments",
           "segment_text", "locate_shots"]
