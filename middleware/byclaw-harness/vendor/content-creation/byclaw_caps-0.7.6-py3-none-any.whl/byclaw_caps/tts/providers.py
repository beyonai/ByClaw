"""Resolve a bound TTS credential to the matching provider driver."""

from __future__ import annotations

import hashlib
import json
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from . import TtsError
from .timestamps import parse_words


@dataclass(frozen=True)
class BoundTtsRequest:
    text: str
    delivery: str
    provider: str
    model_id: str
    model_code: str
    voice: str
    input_fingerprint: str
    credential: dict[str, Any] = field(repr=False, compare=False)


@dataclass(frozen=True)
class BoundTtsModel:
    provider: str
    model_id: str
    model_code: str
    voice: str
    credential: dict[str, Any] = field(repr=False, compare=False)

    def prepare(self, text: str, delivery: str) -> BoundTtsRequest:
        body_text = str(text or "").strip()
        fingerprint_input = {
            "provider": self.provider,
            "model_id": self.model_id,
            "model_code": self.model_code,
            "voice": self.voice,
            "delivery": str(delivery),
            "text": body_text,
        }
        if self.provider == "volcengine":
            from .volcengine import VERSION as volcengine_request_version
            fingerprint_input["request_version"] = volcengine_request_version
        fingerprint = hashlib.sha256(json.dumps(
            fingerprint_input, ensure_ascii=False, sort_keys=True,
        ).encode("utf-8")).hexdigest()
        return BoundTtsRequest(
            text=body_text,
            delivery=str(delivery),
            provider=self.provider,
            model_id=self.model_id,
            model_code=self.model_code,
            voice=self.voice,
            input_fingerprint=fingerprint,
            credential=self.credential,
        )

    @property
    def receipt(self) -> dict[str, str]:
        return {
            "provider": self.provider,
            "model_id": self.model_id,
            "model_code": self.model_code,
            "voice": self.voice,
        }


def resolve_bound_model(
    agent_id: str,
    *,
    session_root: str | Path | None = None,
    voice: str = "",
    refresh: bool = False,
) -> BoundTtsModel:
    from byclaw_caps.credentials.resolve import resolve_credentials
    from .minimax import DEFAULT_VOICE

    credential = resolve_credentials(
        agent_id, kind="tts", session_root=session_root, refresh=refresh,
    )
    provider = str(credential.get("providerName") or "").strip().lower()
    if provider == "volcengine":
        chosen_voice = str(credential.get("voiceId") or "").strip()
        if not chosen_voice:
            raise TtsError(
                "火山语音模型配置缺少 extendParam.speaker；"
                "speaker 跟随模型配置，不能从调用参数传入"
            )
    else:
        chosen_voice = str(voice or DEFAULT_VOICE).strip()
    return BoundTtsModel(
        provider=provider,
        model_id=str(credential.get("modelId") or ""),
        model_code=str(credential.get("modelCode") or ""),
        voice=chosen_voice,
        credential=credential,
    )


def _download(url: str) -> bytes:
    if not url:
        raise TtsError("配音结果没有词级字幕地址")
    with urllib.request.urlopen(url, timeout=120) as response:
        return response.read()


def _portable_timestamps(words: list[dict[str, Any]]) -> bytes:
    payload = {"words": [{
        "word": str(item["text"]),
        "time_begin": round(float(item["start"]) * 1000, 3),
        "time_end": round(float(item["end"]) * 1000, 3),
    } for item in words]}
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


def synthesize_resolved(
    text: str,
    output,
    *,
    credential: dict[str, Any],
    delivery: str,
    voice: str = "",
    model: str = "",
    subtitles: bool = False,
    http: Callable[..., Any] | None = None,
    sleep: Callable[[float], None] | None = None,
) -> dict[str, Any]:
    provider = str(credential.get("providerName") or "").strip().lower()
    token = str(credential.get("apiToken") or "").strip()
    endpoint = str(credential.get("apiEndpoint") or "").strip()
    chosen_model = str(model or credential.get("modelCode") or "").strip()
    if not token:
        raise TtsError("配音凭据里没有 apiToken")
    if not endpoint:
        raise TtsError("配音凭据里没有 apiEndpoint")
    if not chosen_model:
        raise TtsError("配音凭据里没有 modelCode，也没有显式 model")

    if provider == "minimax":
        from .minimax import DEFAULT_VOICE, synthesize

        chosen_voice = str(voice or DEFAULT_VOICE).strip()
        result = synthesize(
            text, output, voice=chosen_voice, delivery=delivery,
            api_key=token, endpoint=endpoint, model=chosen_model,
            subtitles=subtitles, http=http, sleep=sleep,
        )
    elif provider == "volcengine":
        from .volcengine import synthesize

        chosen_voice = str(credential.get("voiceId") or "").strip()
        result = synthesize(
            text, output, voice=chosen_voice, delivery=delivery, api_key=token,
            endpoint=endpoint, resource_id=chosen_model, subtitles=subtitles,
            http=http, sleep=sleep,
        )
    else:
        raise TtsError(
            f"配音不支持供应商 {credential.get('providerName')!r}。"
            "支持：MINIMAX、VOLCENGINE"
        )
    result.setdefault("provider", provider)
    return result


def synthesize_bound(
    request: BoundTtsRequest,
    output,
    *,
    require_word_timestamps: bool = False,
    http: Callable[..., Any] | None = None,
    sleep: Callable[[float], None] | None = None,
) -> dict[str, Any]:
    """Synthesize through a provider-neutral bound-model contract."""
    result = synthesize_resolved(
        request.text,
        output,
        credential=request.credential,
        delivery=request.delivery,
        voice=request.voice,
        subtitles=require_word_timestamps,
        http=http,
        sleep=sleep,
    )
    words: list[dict[str, Any]] = []
    timestamp_bytes = b""
    if require_word_timestamps:
        payload = result.get("word_timestamps")
        if payload is None:
            payload = _download(str(result.get("subtitle_file") or ""))
        words = parse_words(payload)
        timestamp_bytes = _portable_timestamps(words)
    return {
        "audio_path": str(result.get("path") or output),
        "bytes": int(result.get("bytes") or 0),
        "words": words,
        "word_timestamps": timestamp_bytes,
        "input_fingerprint": request.input_fingerprint,
        "trace_id": str(result.get("trace_id") or ""),
        "attempts": int(result.get("attempts") or 1),
        "receipt": {
            "provider": request.provider,
            "model_id": request.model_id,
            "model_code": request.model_code,
            "voice": request.voice,
        },
    }


__all__ = [
    "BoundTtsModel", "BoundTtsRequest", "resolve_bound_model",
    "synthesize_bound", "synthesize_resolved",
]
