#!/usr/bin/env python3
"""MiniMax T2A v2 配音驱动。

## 为什么不是 edge-tts

edge-tts 把整段文本包进**一个** ``<prosody>``（读过它的 ``mkssml``），一句话一个语速
一个音高——**结构上就给不了句内起伏**。用户反馈的「机械」由此而来，不是选错音色。

MiniMax 给了三样它没有的：文本内嵌停顿 ``<#x#>``、语气词标签（仅 2.8 系）、``emotion``。

## 合成是**不确定的**——这条决定了本模块的形状

完全相同的请求体连打 5 次，得到 5 个不同的 sha256，时长 3.49–3.88 秒，**极差 11%**。

- ``speed`` 是风格旋钮，**不是时长旋钮**。想让某镜正好 8 秒，只能改文案长度。
- 「时长只测不算」再进一步：**连「上次同参数测出来是 3.5 秒」也不能复用。**
- **最险的是重试**：一次失败后重试成功，拿到的是**另一条时长不同的音频**。
  所以任何重新生成——包括失败重试——之后必须重测时长、重建字幕轴。

因此本模块**不返回任何时长**，哪怕 ``extra_info.audio_length`` 就在返回体里。
时长只能来自 :func:`byclaw_caps.tts.measure_durations` 对落地文件的实测。

指纹的语义也随之写死：**指纹相同 = 可以复用已落地的那个文件，
不等于「重新生成会得到同样的东西」。指纹没变时就复用文件，绝不重新生成。**

## 契约来自官方 OpenAPI

第一版曾据搜索到的二手来源起草，四处是错的：域名写成 ``api.minimaxi.chat``、
声称国内需要 ``GroupId``、说音频是 base64、把中性情感写成 ``neutral``。
第三条最危险——**拿 base64 解 hex 不抛异常**，会写出一个大小合理、内容是垃圾的
mp3，播放才发现，又一个「退出码 0 的坏产物」。
"""

from __future__ import annotations

import hashlib
import json
import re
import time
import urllib.request
from pathlib import Path
from typing import Any, Callable

from . import TtsError

VERSION = "1.0.0"

#: 官方 OpenAPI 的地址。二手来源写的 ``api.minimaxi.chat`` 是错的。
ENDPOINT = "https://api.minimaxi.com/v1/t2a_v2"
#: 备用地址。主地址不可达时由调用方显式切换，**不自动切**——
#: 自动切会掩盖网络问题，而两个地址的可用性可能反映不同的故障。
ENDPOINT_BACKUP = "https://api-bj.minimaxi.com/v1/t2a_v2"

#: 成片用 2.8 系：**只有它支持语气词标签**。退到 2.6 必须同时剥掉标签，
#: 否则 ``(breath)`` 会被当普通文本念成「左括号 breath 右括号」。
DEFAULT_MODEL = "speech-2.8-hd"
#: 默认音色。原先在 `integrations.yaml` 的 `tts.voice`，随那个文件一起废除。
#: **凭据链不给音色**——它不是凭据。没有默认值的话，删掉配置文件就等于
#: 把「说话用哪个嗓子」变成每次必填。
DEFAULT_VOICE = "Chinese (Mandarin)_News_Anchor"

#: 情感枚举。中性是 ``calm``——写 ``neutral`` 会被 2013 拒掉。
EMOTIONS = frozenset({
    "happy", "sad", "angry", "fearful", "disgusted", "surprised",
    "calm", "fluent", "whisper",
})

#: 停顿标记的合法秒数区间（OpenAPI）。
PAUSE_MIN, PAUSE_MAX = 0.01, 99.99

_PAUSE_RE = re.compile(r"<#\d+(?:\.\d{1,2})?#>")

#: 五种表达 → 参数。
#:
#: **speed 只取两个拉得开的值。** 原打算在基准上下各摆 ±0.08，那只有 9% 的差，
#: **小于合成本身 11% 的抖动**——听众听的是某一次渲染而不是均值，
#: 9% 的标称差会被抖动淹没，五档听起来还是一个样。
#: 细的差别交给停顿和 vol/pitch，**这两者是确定性的，不抖**。
#:
#: 基准 1.2 来自新闻女声实测（4.86 字/秒，舒适区 4.5–5.5）。speed 1.0 只有 4.06。
#: **换音色必须重新标定**：同样 speed 1.0，电台男主播是 4.87 字/秒。
DELIVERY_PRESETS: dict[str, dict[str, Any]] = {
    "opening":   {"speed": 1.10, "vol": 1.00, "pitch":  0, "emotion": "calm"},
    "narration": {"speed": 1.20, "vol": 1.00, "pitch":  0, "emotion": None},
    "contrast":  {"speed": 1.20, "vol": 1.05, "pitch":  1, "emotion": "fluent"},
    "question":  {"speed": 1.20, "vol": 1.05, "pitch":  1, "emotion": "fluent"},
    "emphasis":  {"speed": 1.10, "vol": 1.10, "pitch": -1, "emotion": "calm"},
}

#: ``base_resp.status_code`` → 类别。
_ERROR_CATEGORIES: dict[int, str] = {
    0: "ok",
    1000: "unknown_error",
    1001: "timeout",
    1002: "rate_limited",
    1004: "authentication_failed",
    1039: "token_rate_limited",
    1042: "illegal_characters",
    2013: "invalid_parameter",
}

#: 可重试的码。**1042 与 2013 刻意不在其中**——重试同一段文本，
#: 非法字符还是非法字符，只会重试到配额耗尽。本仓库在微信投递上踩过同型的坑：
#: ``ip_not_allowed`` 被归进 ``authentication_failed``，人反复换凭据，换多少次都没用。
_RETRYABLE = frozenset({1000, 1001, 1002, 1039})


def categorize_api_error(code: int) -> tuple[str, bool]:
    """返回 ``(类别, 是否可重试)``。"""
    code = int(code)
    return _ERROR_CATEGORIES.get(code, "minimax_api_error"), code in _RETRYABLE


def pause(seconds: float) -> str:
    """构造停顿标记。**最多两位小数**（OpenAPI），超范围直接报错。"""
    value = float(seconds)
    if not (PAUSE_MIN <= value <= PAUSE_MAX):
        raise TtsError(
            f"停顿 {value:g} 秒超出 [{PAUSE_MIN}, {PAUSE_MAX}]——"
            "API 会以 2013 拒绝，不如在本地就拦下")
    return f"<#{value:.2f}#>"


def check_pauses(text: str) -> None:
    """停顿标记必须夹在两段可发音文本之间，且不可连用（OpenAPI 明写）。

    在本地拦，是为了不把一次调用浪费在 API 那边报 1042/2013 上——
    而且那两个码不可重试，等于白花一次往返才知道文案写错了。
    """
    stripped = text.strip()
    if _PAUSE_RE.match(stripped):
        raise TtsError("停顿标记不能在开头——它前面必须有可发音的文本")
    for match in _PAUSE_RE.finditer(stripped):
        if match.end() == len(stripped):
            raise TtsError("停顿标记不能在结尾——它后面必须有可发音的文本")
        rest = stripped[match.end():]
        if _PAUSE_RE.match(rest):
            raise TtsError("两个停顿标记不能相连——中间必须有可发音的文本")


def resolve_delivery(delivery: str) -> dict[str, Any]:
    """取表演预设。

    **未知表达直接报错，不回退到中性**——默默回退的话，五种表达就形同虚设：
    写错一个词，整段变平铺直叙，而没有任何提示。
    """
    preset = DELIVERY_PRESETS.get(str(delivery))
    if preset is None:
        raise TtsError(
            f"未知表达 {delivery!r}。可用：{'、'.join(DELIVERY_PRESETS)}。")
    return dict(preset)


def build_request(text: str, *, voice: str, delivery: str,
                  model: str = DEFAULT_MODEL, subtitles: bool = False) -> dict[str, Any]:
    """拼装请求体。必填只有 ``model`` 与 ``text``，其余给全是为了可复现。"""
    body_text = str(text or "").strip()
    if not body_text:
        raise TtsError("配音文本为空——空音频不会报错，只会让那个镜头变哑")
    check_pauses(body_text)
    preset = resolve_delivery(delivery)
    voice_setting: dict[str, Any] = {
        "voice_id": str(voice), "speed": preset["speed"],
        "vol": preset["vol"], "pitch": preset["pitch"],
    }
    # emotion 为 None 时**不传**：OpenAPI 说「模型会根据输入文本自动匹配合适的情绪，
    # 一般无需手动指定」。硬塞一个值反而把模型的判断关掉了。
    if preset.get("emotion") is not None:
        voice_setting["emotion"] = preset["emotion"]
    body = {
        "model": model,
        "text": body_text,
        "stream": False,
        # hex 虽是默认值也显式写——默认值会变，而解码方式跟着它。
        "output_format": "hex",
        "language_boost": "Chinese",
        "text_normalization": True,
        "voice_setting": voice_setting,
        "audio_setting": {"sample_rate": 32000, "bitrate": 128000,
                          "format": "mp3", "channel": 1},
    }
    if subtitles:
        body["subtitle_enable"] = True
        body["subtitle_type"] = "word"
    return body


def default_http(url: str, *, payload: dict[str, Any], headers: dict[str, str],
                 timeout: int = 180) -> dict[str, Any]:
    """默认传输。测试与重放时注入替代实现——不可注入就没法在无凭据、无网络时测。"""
    request = urllib.request.Request(
        url, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        method="POST", headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def synthesize(text: str, output, *, voice: str, delivery: str, api_key: str,
               model: str = DEFAULT_MODEL, subtitles: bool = False,
               endpoint: str = ENDPOINT, attempts: int = 4,
               http: Callable[..., dict[str, Any]] | None = None,
               sleep: Callable[[float], None] | None = None) -> dict[str, Any]:
    """合成一段配音并落地。

    **不返回时长。** ``extra_info.audio_length`` 就在返回体里，但不采信——
    合成不确定，同参数每次时长都不同；provider 报的那个数一旦被当成实测值，
    字幕轴就会和真正播放的那个文件对不上。时长走 :func:`~byclaw_caps.tts.measure_durations`。

    Returns:
        落地信息（路径、字节数、指纹、trace_id），**不含时长，也不含密钥**。
    """
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    body = build_request(text, voice=voice, delivery=delivery,
                         model=model, subtitles=subtitles)
    send = http or default_http
    wait = sleep if sleep is not None else time.sleep
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    last = ""
    for attempt in range(max(1, int(attempts))):
        try:
            payload = send(endpoint, payload=body, headers=headers) or {}
        except Exception as exc:      # noqa: BLE001
            # **传输异常与超时码同等对待。** 这条链路走代理，SSL 断连撞过多次；
            # 原来传输异常直接抛出，一次抖动就让整批配音前功尽弃。
            last = f"传输失败：{type(exc).__name__}: {exc}"
            if attempt < attempts - 1:
                wait(2 * (attempt + 1))
                continue
            raise TtsError(f"MiniMax 配音重试 {attempts} 次仍失败，最后一次：{last}") from exc
        code = int((payload.get("base_resp") or {}).get("status_code", -1))
        category, retryable = categorize_api_error(code)
        if code == 0:
            data = payload.get("data")
            # OpenAPI 明写 data 可能为 null。不判空的话 TypeError 会出现在很远的地方。
            if not data or not data.get("audio"):
                raise TtsError(
                    f"MiniMax 返回 status_code=0 但没有音频（trace_id="
                    f"{payload.get('trace_id')}）——成功码配空音频，下游会得到一个哑镜头")
            # **hex，不是 base64。** 拿 base64 解 hex 不抛异常，会写出一个
            # 大小合理、内容是垃圾的 mp3，播放才发现。
            target.write_bytes(bytes.fromhex(data["audio"]))
            return {
                "ok": True,
                "path": str(target),
                "bytes": target.stat().st_size,
                "voice_id": voice,
                "delivery": delivery,
                "model": model,
                "fingerprint": voice_fingerprint(voice, delivery, model=model,
                                                 text=body["text"]),
                "subtitle_file": data.get("subtitle_file"),
                "trace_id": payload.get("trace_id"),
                "attempts": attempt + 1,
            }
        last = f"{code} {category}: {(payload.get('base_resp') or {}).get('status_msg') or ''}".strip()
        if not retryable:
            raise TtsError(f"MiniMax 配音失败，{last}——该错误重试无用")
        if attempt < attempts - 1:
            wait(2 * (attempt + 1))
    raise TtsError(f"MiniMax 配音重试 {attempts} 次仍失败，最后一次：{last}")


def synthesize_resolved(text: str, output, *, credential: dict[str, Any],
                        delivery: str, voice: str = "", model: str = "",
                        http: Callable[..., dict[str, Any]] | None = None,
                        sleep: Callable[[float], None] | None = None) -> dict[str, Any]:
    """按 `credentials resolve --kind tts` 解出来的凭据合成。

    这是 Skill/CLI 应使用的公开入口；``synthesize`` 只保留为供应商内部传输函数。

    **音色与模型不是凭据。** 它们原先在 `integrations.yaml` 里，随那个文件一起废除；
    凭据链只给端点、令牌、供应商，**不给音色**。所以它们在这里落成带默认值的参数——
    不给默认值的话，删掉配置文件等于把「说话用哪个嗓子」变成每次必填。
    """
    provider = str(credential.get("providerName") or "").strip().lower()
    if provider != "minimax":
        raise TtsError(
            f"配音只支持 MiniMax，凭据给的是 {credential.get('providerName')!r}。"
            "**不回落**：用 MiniMax 的协议打别家的地址，报出来的是 400 或鉴权失败，"
            "与真正的原因隔了两层。")
    token = str(credential.get("apiToken") or "").strip()
    if not token:
        raise TtsError("凭据里没有 apiToken。先跑 credentials resolve --kind tts 看它报什么。")
    # **原样用，不拼路径、不回落到模块里那个 ENDPOINT 常量。**
    # 平台存的就是完整地址（`https://api.minimaxi.com/v1/t2a_v2`）。
    # 回落的坏处与型号那条一样：后台把地址改了，这里照样打旧的，而且不报错。
    endpoint = str(credential.get("apiEndpoint") or "").strip()
    if not endpoint:
        raise TtsError(
            "凭据里没有 apiEndpoint。先跑 credentials resolve --kind tts 看它报什么。")
    chosen = str(model or credential.get("modelCode") or "").strip()
    if not chosen:
        # **不回落到 DEFAULT_MODEL。** 回落的话，后台把模型换成别的型号之后
        # 这里照样用旧的合成，**而且不报错**——听上去只是「音色好像不太一样」。
        raise TtsError(
            "没有模型型号：凭据里的 modelCode 是空的，也没有显式 --model。"
            "先跑 credentials resolve --kind tts 看它报什么。")
    return synthesize(
        text, output, voice=str(voice or DEFAULT_VOICE), delivery=delivery,
        api_key=token, endpoint=endpoint, model=chosen,
        http=http, sleep=sleep,
    )


def voice_fingerprint(voice: str, delivery: str, *, model: str = DEFAULT_MODEL,
                      text: str = "") -> str:
    """音色 + 表达 + 模型 + 文本，**四项全参与**。

    最容易漏的是 ``text``：停顿标记和语气词就藏在里面，它们**改时长但不改音色**，
    听上去差不多。指纹不含它，就会出现「音频换了、字幕轴还是旧的」——
    字幕从那一段起整体漂移，而且没有任何报错。

    ``model`` 也必须进：2.8 换 2.6 会让 ``(breath)`` 从换气变成
    **念出「左括号 breath 右括号」**，时长和内容一起变。

    注意这个指纹**只保证「参数没变」**，不保证「重新生成会得到同样的音频」——
    合成是不确定的（同请求体极差 11%）。所以用法是：**指纹没变就复用已落地的文件，
    绝不重新生成。**
    """
    preset = resolve_delivery(delivery)
    payload = "\x00".join([
        str(voice), str(delivery), str(model), str(text),
        f"{preset['speed']:g}", f"{preset['vol']:g}", f"{preset['pitch']:g}",
        str(preset.get("emotion")),
    ])
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


__all__ = [
    "VERSION", "ENDPOINT", "ENDPOINT_BACKUP", "DEFAULT_MODEL", "EMOTIONS",
    "DELIVERY_PRESETS", "categorize_api_error", "pause", "check_pauses",
    "resolve_delivery", "build_request", "default_http", "synthesize",
    "synthesize_resolved",
    "voice_fingerprint",
]
