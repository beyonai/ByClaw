---
name: voice-over
description: 当需要配音并据此生成字幕时使用。逐句时长只测不算——曾出现字幕只覆盖 30% 旁白，根因是拿按字数估算的时长当实测。字幕时间轴在类型上就拒绝接收裸浮点数，只接受 measure 产出的实测对象，从结构上堵死"估算冒充实测"。声音克隆需要双授权（本人授权＋平台授权），预设音色不需要；模式识别不出时按需要双授权处理。
---

# 配音与字幕时间轴

## 调用

```bash
# 按 agentId 解析配音凭据并生成音频。
# CLI 不接受 api-key 参数：端点与令牌由 credentials 按 agent 绑定的模型查出来。
python3 -m byclaw_caps.tts synthesize --agent-id <agentId> \
    --text-file <旁白.txt> --output <旁白.wav> \
    [--delivery narration] [--voice <音色>] [--session-root <会话根>]

# 逐句实测音频时长
python3 -m byclaw_caps.tts measure <音频1> <音频2> ...

# 由实测时长生成字幕时间轴
python3 -m byclaw_caps.tts timeline <音频1> <音频2> ... [--gap 0.0]

# 按叙事段分组：段内一次合成，段间才断
python3 -m byclaw_caps.tts segments <分镜脚本.json>

# 判断该音色模式是否需要双授权
python3 -m byclaw_caps.tts auth --mode preset|clone
```

退出码：`0` 成功，`1` 业务失败，`2` 用法错误。

## 凭据按 agentId 解析

`MINIMAX_API_KEY` 与 `integrations.yaml` 都已废除。`--agent-id` 传进来之后，
`credentials resolve --kind tts` 查出 `apiEndpoint` / `apiToken` / `providerName`，
会话内按 agentId 缓存——十几段配音共用一次解析。

**该 agent 没绑配音模型时报「未配置文生语音模型」**，不是凭据错误：
去后台绑一个，不是去查密钥。

供应商由绑定模型的 `providerName` 决定，支持 `MINIMAX` 与 `VOLCENGINE`，不做失败后
自动回落。MiniMax 的 `modelCode` 是请求体 `model`；火山语音的 `modelCode` 是
`X-Api-Resource-Id`（如 `seed-tts-2.0`、`seed-icl-2.0`）。

MiniMax 音色可由 `--voice` 输入，未提供时使用 `Chinese (Mandarin)_News_Anchor`。
火山语音的 `speaker` 跟随绑定模型，从模型详情的 `extendParam.speaker` 读取，不能由
命令行、脚本或 production plan 覆盖；配置缺失时直接失败。`--model` 不给时使用绑定
模型的 `modelCode`。

火山语音请求固定使用 `speech_rate=23` 作为当前默认口播速度。该值属于供应商请求契约，
不向 CLI、production plan 或调用方暴露调整参数；契约版本进入配音输入指纹，默认速度变化
时必须重新生成音频和词级时间轴，不能复用旧缓存。

不要在对话或命令行提供 Token。

## 时长只测不算——这条是结构性的

字幕曾只覆盖 30% 旁白：时间轴按"字数 ÷ 语速"估算，而实际语速逐句浮动。

因此 `timeline` **在类型上拒绝裸浮点数**，只收 `measure` 产出的实测对象。想传估算值
进去，代码根本写不出来——不是靠注释提醒，是靠结构堵死。

同理，**不提供"按音频播放位置反推时长"的接口**。SAPI 报告的播放位置与实际时长有约 4%
偏差，一分钟旁白就是两秒半的错位，足以让字幕整体漂移。该接口存在但永远抛错，就是为了
让人别再找这条路。

## 按段合成，不逐句合成

逐句合成时每一句都**从静默起、到静默止**——16 句拼起来是 16 条播报，每句重新起调。
这是「一听就知道是 AI」的主要来源，比音色本身更明显。

`segments` 把相邻同叙事段的镜头分成一组，一组一次请求，段内用**换行**分隔——
官方 OpenAPI 明写换行是段落切换标记，模型据此安排段间气口。

不整片合成，是因为**合成不确定**：同一请求体连发五次得到五个不同的 sha256，
时长极差 11%。整片合成时改一句，全片时长、字幕轴、词级时间戳一起作废。
按段是折中：段内气脉连续，改动影响面限于一组。

### 切回逐镜靠字符对齐

合成文本就是各镜旁白拼起来的，字符序列是确定的。拿词级时间戳的字符流去
**对齐**每一镜的起止，对不上就报错。

**不退回等长切分。** 按时长平分会让画面与话音全片错位，而且不报错——
这正是最难发现的一类失败。

### 一条标定上的教训

换音色后重新标定语速必须用**裸句**。拿含停顿标记与语气词的段落去测，
测到的是「含气口的整体节奏」而不是语速——阅历姐姐因此被误判成 3.85 字/秒，
裸句实测 5.13，本来在band内，差点为此白改一轮参数。

## 双授权

| 模式 | 是否需要双授权 |
| --- | --- |
| `preset` 预设音色 | 否 |
| `clone` 声音克隆 | **是**——需本人授权＋平台授权 |
| 识别不出的模式 | **按需要处理** |

未知模式按"需要"处理是刻意的：漏判一次克隆授权是法律风险，多问一次只是麻烦。

## 与视频合成的衔接

`timeline` 的产出直接喂给 `video-compose` 烧录字幕。两端共用同一份实测时长，
不存在"配音一份时长、字幕另一份时长"的分叉。

## 五种表达

```bash
python3 -m byclaw_caps.tts delivery            # 列出全部预设
python3 -m byclaw_caps.tts delivery emphasis   # 取某一种及其指纹
```

同一音色下按语义换表演，不是"生硬"与"平平无奇"的二选一：
`opening` `narration` `contrast` `question` `emphasis`。

`narration` 是**中性基线**——它不加料，其余四种才听得出差别。

**未知表达直接报错，不回退到中性。** 默默回退的话五种表达形同虚设：写错一个词，
整段变成平铺直叙而没有任何提示。

## 四项参数全部纳入指纹

`speed` / `pitch` / `volume` / `pause_after_ms` 任一项变了，就要**重生成该段并重建时间轴**。

最容易漏的是 `pause_after_ms`：它不改音色只改尾部静音，听上去差不多，**但时长变了**。
指纹不含它会出现「音频换了、字幕轴还是旧的」——字幕从那段起整体漂移，且无任何报错。

**停顿写进 WAV 尾部**，不靠字幕空白代替。它是实测时长的一部分。
