#!/usr/bin/env python3
"""Volcengine/ByteDance unidirectional streaming TTS driver."""

from __future__ import annotations

import base64
import hashlib
import json
import time
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from . import TtsError

VERSION = "1.1.0"
ENDPOINT = "https://openspeech.bytedance.com/api/v3/tts/unidirectional"
DEFAULT_SPEECH_RATE = 23

DELIVERY_CONTEXTS = {
    "opening": "使用清晰自然、稍有吸引力的开场语气",
    "narration": "使用自然、连贯的讲述语气",
    "contrast": "突出前后反差，但保持自然和克制",
    "question": "使用自然的提问语气",
    "emphasis": "清晰强调关键信息，但不要喊叫",
}


def resolve_delivery(delivery: str) -> str:
    try:
        return DELIVERY_CONTEXTS[str(delivery)]
    except KeyError:
        raise TtsError(
            f"未知表达 {delivery!r}。可用：{'、'.join(DELIVERY_CONTEXTS)}。"
        ) from None


def build_request(text: str, *, voice: str, delivery: str) -> dict[str, Any]:
    body_text = str(text or "").strip()
    if not body_text:
        raise TtsError("配音文本为空——空音频会让镜头变哑")
    speaker = str(voice or "").strip()
    if not speaker:
        raise TtsError(
            "火山语音模型配置缺少 extendParam.speaker；"
            "speaker 跟随绑定模型配置，不能从调用参数或 production plan 传入"
        )
    additions = {
        "disable_markdown_filter": True,
        "disable_emoji_filter": True,
        "enable_latex_tn": True,
        "context_texts": [resolve_delivery(delivery)],
    }
    return {
        "req_params": {
            "text": body_text,
            "speaker": speaker,
            "additions": json.dumps(additions, ensure_ascii=False),
            "audio_params": {
                "format": "mp3",
                "sample_rate": 24000,
                "enable_subtitle": True,
                "speech_rate": DEFAULT_SPEECH_RATE,
            },
        }
    }


def build_headers(*, api_key: str, resource_id: str,
                  request_id: str | None = None) -> dict[str, str]:
    token = str(api_key or "").strip()
    model = str(resource_id or "").strip()
    if not token:
        raise TtsError("火山语音凭据里没有 apiToken")
    if not model:
        raise TtsError("火山语音凭据里没有 modelCode，无法设置 X-Api-Resource-Id")
    return {
        "X-Api-Key": token,
        "X-Api-Resource-Id": model,
        "X-Api-Request-Id": str(request_id or uuid.uuid4()),
        "X-Control-Require-Usage-Tokens-Return": "*",
        "Content-Type": "application/json",
        "Connection": "keep-alive",
    }


def default_http(url: str, *, payload: dict[str, Any], headers: dict[str, str],
                 timeout: int = 180) -> tuple[list[dict[str, Any]], Mapping[str, str]]:
    request = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers=headers,
    )
    events: list[dict[str, Any]] = []
    with urllib.request.urlopen(request, timeout=timeout) as response:
        for raw_line in response:
            line = raw_line.strip()
            if not line:
                continue
            events.append(json.loads(line.decode("utf-8")))
        response_headers = dict(response.headers.items())
    return events, response_headers


def _response_parts(value: Any) -> tuple[Iterable[dict[str, Any]], Mapping[str, str]]:
    if isinstance(value, tuple) and len(value) == 2:
        return value[0], value[1]
    return value, {}


def synthesize(
    text: str,
    output,
    *,
    voice: str,
    delivery: str,
    api_key: str,
    resource_id: str,
    endpoint: str = ENDPOINT,
    subtitles: bool = False,
    attempts: int = 4,
    http: Callable[..., Any] | None = None,
    sleep: Callable[[float], None] | None = None,
) -> dict[str, Any]:
    """Synthesize one segment and normalize Volcengine word timestamps."""
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    body = build_request(text, voice=voice, delivery=delivery)
    send = http or default_http
    wait = sleep if sleep is not None else time.sleep
    last = ""

    for attempt in range(max(1, int(attempts))):
        headers = build_headers(api_key=api_key, resource_id=resource_id)
        try:
            events, response_headers = _response_parts(
                send(endpoint, payload=body, headers=headers)
            )
            audio = bytearray()
            words: list[dict[str, Any]] = []
            seen_words: set[tuple[str, float, float]] = set()
            for event in events:
                if not isinstance(event, Mapping):
                    continue
                code = int(event.get("code", 0))
                if code == 20000000:
                    break
                if code != 0:
                    message = str(event.get("message") or "")
                    raise TtsError(f"火山语音合成失败，{code}: {message}".rstrip())
                encoded = event.get("data")
                if encoded:
                    audio.extend(base64.b64decode(str(encoded), validate=True))
                sentence = event.get("sentence") or {}
                for item in sentence.get("words") or []:
                    word = str(item.get("word") or "")
                    start = float(item.get("startTime", 0.0))
                    end = float(item.get("endTime", start))
                    key = (word, start, end)
                    if word and key not in seen_words:
                        seen_words.add(key)
                        words.append({
                            "word": word,
                            "time_begin": round(start * 1000, 3),
                            "time_end": round(end * 1000, 3),
                        })
            if not audio:
                raise TtsError("火山语音返回成功但没有音频数据")
            if subtitles and not words:
                raise TtsError(
                    "火山语音没有返回字级时间戳；视频字幕和动效不能退回按时长均分"
                )
            target.write_bytes(bytes(audio))
            log_id = ""
            for key, value in response_headers.items():
                if str(key).lower() == "x-tt-logid":
                    log_id = str(value)
                    break
            fingerprint = hashlib.sha256("\x00".join([
                "volcengine", VERSION, str(resource_id), str(voice),
                str(delivery), str(text),
            ]).encode("utf-8")).hexdigest()
            return {
                "ok": True,
                "path": str(target),
                "bytes": target.stat().st_size,
                "provider": "volcengine",
                "voice_id": voice,
                "delivery": delivery,
                "model": resource_id,
                "fingerprint": fingerprint,
                "word_timestamps": {"words": words},
                "trace_id": log_id,
                "attempts": attempt + 1,
            }
        except TtsError:
            raise
        except Exception as exc:  # noqa: BLE001
            last = f"{type(exc).__name__}: {exc}"
            if attempt < attempts - 1:
                wait(2 * (attempt + 1))
                continue
            raise TtsError(
                f"火山语音传输重试 {attempts} 次仍失败，最后一次：{last}"
            ) from exc
    raise TtsError(f"火山语音合成失败：{last}")


__all__ = [
    "VERSION", "ENDPOINT", "DEFAULT_SPEECH_RATE", "DELIVERY_CONTEXTS",
    "build_request",
    "build_headers", "default_http", "synthesize",
]
