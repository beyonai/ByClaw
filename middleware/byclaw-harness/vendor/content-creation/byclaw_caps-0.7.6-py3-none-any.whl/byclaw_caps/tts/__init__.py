#!/usr/bin/env python3
"""配音：逐句时长实测与字幕时间轴。

两处不可让步，都来自真实事故：

一、**逐句时长必须实测，不得按文本比例换算。** 曾出现字幕只覆盖 30% 旁白（204 字对
   669 字），根因正是拿估算当实测。现有 ``tts_batch.py`` 里两套并存——``audio_duration()``
   读帧数是实测，``spoken_units()`` 按字符加权是估算。估算目前只用于算平均语速，
   **没踩坑，但没有任何机制拦着它被误用**。

   本模块把这道分界做成**结构性**的：:func:`subtitle_timeline` 只接受
   :class:`Measured`，而 :class:`Measured` 只能由 :func:`measure_durations` 产出。
   估算值在类型上就喂不进去。靠纪律记住「别用错」，迟早会用错。

二、**不得用 SAPI 的 ``AudioPosition`` 推算真实时长。** 实测其与真实时长的比值离散度
   达 4%，线性换算不成立。:func:`from_audio_position` 存在的唯一目的是把这条写进代码
   并硬失败，而不是留给下一个人重新踩。

另有一条：**预置音色是默认路径**，双授权只作用于音色克隆。此前把双授权加在了全部 TTS 上，
导致用户不指定音色时也被拦。
"""

from __future__ import annotations

import subprocess
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

VERSION = "1.0.0"

#: 需要双授权的音色模式。预置音色不在其列。
_PRESET = "preset"


class TtsError(RuntimeError):
    """音频不可读，或把估算值当实测用。"""


@dataclass(frozen=True)
class Measured:
    """实测时长。**只能由 measure_durations 产出**，这是它存在的全部意义。

    做成独立类型而非裸 ``list[float]``，是为了让「估算喂进字幕时间轴」在类型上不可能，
    而不是靠调用方记得区分。
    """

    seconds: tuple[float, ...]
    source: str = "ffprobe|wave"


def _probe(path: Path) -> float:
    try:
        with wave.open(str(path), "rb") as handle:
            rate = handle.getframerate()
            if not rate:
                raise wave.Error("采样率为零")
            # 采样率必须读，不能假设：曾按 16kHz 估算而实际是 22.05kHz，时长算错三成
            return handle.getnframes() / float(rate)
    except (wave.Error, OSError):
        pass
    try:
        done = subprocess.run(
            [
                "ffprobe", "-v", "quiet", "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1", str(path),
            ],
            capture_output=True, text=True, timeout=30, check=True,
        )
        return float(done.stdout.strip())
    except Exception as exc:  # noqa: BLE001
        raise TtsError(f"无法测量时长：{path}（{exc}）") from None


def measure_durations(paths: Iterable[str | Path]) -> Measured:
    """逐句实测。每句一次探测，不做任何插值或分摊。"""
    values: list[float] = []
    for item in paths:
        target = Path(item)
        if not target.is_file():
            raise TtsError(f"音频不存在：{target}")
        values.append(round(_probe(target), 4))
    if not values:
        raise TtsError("没有可测量的音频")
    return Measured(seconds=tuple(values))


def estimate_units(text: str) -> float:
    """口播单位估算，**仅用于算平均语速，不得用于字幕对齐**。

    返回裸 ``float`` 而非 :class:`Measured`，因此在类型上就进不了字幕时间轴。
    """
    import re

    total = 0.0
    for token in re.findall(
        r"[一-鿿]|[A-Za-z]+|\d+(?:\.\d+)?|[%％]|[，。！？；：、,.!?;:]",
        str(text or ""),
    ):
        if re.fullmatch(r"[一-鿿]", token):
            total += 1.0
        elif re.fullmatch(r"[A-Za-z]+", token):
            total += max(1.0, -(-len(token) // 4))
        elif re.fullmatch(r"\d+(?:\.\d+)?", token):
            total += len(re.sub(r"\D", "", token))
        elif token in {"%", "％"}:
            total += 2.0
        elif token in {"。", "！", "？", ".", "!", "?"}:
            total += 1.2
        else:
            total += 0.6
    return total


def from_audio_position(positions: Sequence[float]) -> Measured:
    """**永远抛错。** 存在的唯一目的是把这条教训写进代码。

    SAPI 的 ``AudioPosition`` 与真实时长的比值离散度实测达 4%，线性换算不成立。
    """
    raise TtsError(
        "不得用 SAPI AudioPosition 推算真实时长：实测其与真实时长的比值离散度达 4%，"
        "线性换算不成立。请对每句音频调用 measure_durations() 实测。"
    )


def subtitle_timeline(
    measured: Measured | Sequence[float], *, gap: float = 0.0
) -> list[tuple[float, float]]:
    """由实测时长生成字幕时间轴。

    **只接受 Measured。** 传入裸数字一律拒绝——那通常意味着值来自估算或按文本比例分摊，
    而那正是「字幕只覆盖 30% 旁白」的成因。
    """
    if not isinstance(measured, Measured):
        raise TtsError(
            "字幕时间轴只接受 measure_durations() 的实测结果。"
            "收到的是裸数值，通常意味着按文本比例换算或估算得来——"
            "曾因此导致字幕只覆盖 30% 旁白（204 字对 669 字）。"
            "请对每句音频实测后再生成时间轴。"
        )
    cues: list[tuple[float, float]] = []
    cursor = 0.0
    for value in measured.seconds:
        cues.append((round(cursor, 4), round(cursor + value, 4)))
        cursor += value + gap
    return cues


def requires_dual_auth(request: Mapping[str, Any] | None = None) -> bool:
    """双授权只作用于音色克隆；预置音色是默认路径，不受其限。

    模式无法识别时按更严的一侧走——授权漏判的代价远大于多问一次。
    """
    mode = str((request or {}).get("mode") or _PRESET).strip().lower()
    return mode != _PRESET


__all__ = [
    "VERSION",
    "Measured",
    "TtsError",
    "measure_durations",
    "estimate_units",
    "from_audio_position",
    "subtitle_timeline",
    "requires_dual_auth",
]


# ── 批处理内核（A4）────────────────────────────────────────────────────────
#
# 由 `preset-voice-tts/scripts/tts_batch.py` 迁入。合成本身仍需凭据与网络；
# 这里是它周围**不需要网络就能定的那部分**：切分、拼接、指纹复用。

import hashlib as _hashlib
import math as _math
import re as _re
import shutil as _shutil
import subprocess as _subprocess
import wave as _wave
from pathlib import Path as _Path

_TOKEN = _re.compile(r"[一-鿿]|[A-Za-z]+|\d+(?:\.\d+)?|[%％]|[，。！？；：、,.!?;:]")


def normalize_text(value) -> str:
    return " ".join(str(value or "").split())


def spoken_units(text: str) -> float:
    """口播单位，用于**估算语速**。

    **不得用于字幕时间轴**——时间轴只能来自 `measure_durations` 的实测值。
    曾出现字幕只覆盖 30% 旁白，根因正是拿估算当实测。保留估算是为了在合成**之前**
    判断分段是否合理。
    """
    total = 0.0
    for token in _TOKEN.findall(normalize_text(text)):
        if _re.fullmatch(r"[一-鿿]", token):
            total += 1.0
        elif _re.fullmatch(r"[A-Za-z]+", token):
            total += max(1.0, _math.ceil(len(token) / 3.5))
        elif _re.fullmatch(r"\d+(?:\.\d+)?", token):
            total += len(_re.sub(r"\D", "", token))
        elif token in {"%", "％"}:
            total += 2.0          # 「百分之三十」念出来比一个字长得多
        elif token in {"。", "！", "？", ".", "!", "?"}:
            total += 1.2          # 句末停顿
        else:
            total += 0.6
    return total


def split_text(text: str, max_chars: int) -> list[str]:
    """按句切分到平台单次请求上限以内。

    **先按句读符号切，句子本身超限才硬切。** 直接按字数硬切会切断句子，
    合成出来两段之间语调断裂，听起来像两个人接力。
    """
    text = normalize_text(text)
    if len(text) <= max_chars:
        return [text]
    parts: list[str] = []
    current = ""
    for sentence in _re.findall(r"[^。！？!?；;]+[。！？!?；;]?", text):
        sentence = sentence.strip()
        while len(sentence) > max_chars:
            if current:
                parts.append(current)
                current = ""
            parts.append(sentence[:max_chars])
            sentence = sentence[max_chars:]
        if not sentence:
            continue
        if current and len(current) + len(sentence) > max_chars:
            parts.append(current)
            current = sentence
        else:
            current += sentence
    if current:
        parts.append(current)
    return parts or [text]


def text_fingerprint(text: str) -> str:
    return _hashlib.sha256(normalize_text(text).encode("utf-8")).hexdigest()


def voice_fingerprint(provider: str, model: str, voice: str,
                      speed: float, sample_rate: int) -> str:
    """音色参数**必须参与指纹**。

    换了音色或语速还复用旧音频，成片里会中途换人声——而文件都在、时长也对，
    只有听到那一刻才发现。
    """
    payload = f"{provider}\x00{model}\x00{voice}\x00{speed:g}\x00{sample_rate}"
    return _hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _concat_pcm(inputs, output: _Path) -> None:
    expected = None
    with _wave.open(str(output), "wb") as dst:
        for path in inputs:
            with _wave.open(str(path), "rb") as src:
                current = (src.getnchannels(), src.getsampwidth(),
                           src.getframerate(), src.getcomptype())
                if current[3] != "NONE":
                    raise TtsError(f"{_Path(path).name} 不是未压缩 PCM WAV")
                if expected is None:
                    expected = current
                    dst.setnchannels(current[0])
                    dst.setsampwidth(current[1])
                    dst.setframerate(current[2])
                    dst.setcomptype("NONE", "not compressed")
                elif current != expected:
                    raise TtsError(
                        f"{_Path(path).name} 的声道、位深或采样率与其他片段不一致")
                while True:
                    frames = src.readframes(65536)
                    if not frames:
                        break
                    dst.writeframesraw(frames)


def concat_audio(inputs, output, work_dir, *, allow_reencode: bool = True):
    """拼接音频。**先无损拼 PCM，失败才退到 ffmpeg。**

    顺序不能反。先走 ffmpeg 就把「两段参数不一致」悄悄抹平了：产出能播，
    音质却在中间某处变了，而没有任何提示。直接拼 PCM 遇到不一致会**明确报错**。
    """
    inputs = [_Path(p) for p in inputs]
    output, work_dir = _Path(output), _Path(work_dir)
    if not inputs:
        raise TtsError("没有可拼接的音频片段")
    output.parent.mkdir(parents=True, exist_ok=True)
    if len(inputs) == 1:
        _shutil.copy2(str(inputs[0]), str(output))
        return output
    try:
        _concat_pcm(inputs, output)
        return output
    except (TtsError, _wave.Error, OSError) as exc:
        output.unlink(missing_ok=True)
        ffmpeg = _shutil.which("ffmpeg")
        if not allow_reencode:
            raise TtsError(f"片段参数不一致，且未允许重编码：{exc}") from exc
        if not ffmpeg:
            raise TtsError(f"片段参数不一致，且系统未安装 ffmpeg：{exc}") from exc
    listing = work_dir / "concat.txt"
    listing.write_text("".join(f"file '{p.name}'\n" for p in inputs), encoding="utf-8")
    done = _subprocess.run(
        [ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(listing),
         "-c:a", "pcm_s16le", str(output)],
        cwd=str(work_dir), capture_output=True, text=True)
    listing.unlink(missing_ok=True)
    if done.returncode != 0 or not output.is_file():
        raise TtsError(f"ffmpeg 合并失败：{(done.stderr or '')[-400:]}")
    return output


# ── 五种表达预设 ──────────────────────────────────────────────────────────
#
# 同一音色下按语义换表演，不是"生硬"与"平平无奇"的二选一。

#: `narration` 是中性基线——它不加料，其余四种才听得出差别。
DELIVERY_PRESETS: dict[str, dict] = {
    "opening":   {"speed": 0.86, "pitch": -1, "volume": 1.04, "pause_after_ms": 350},
    "narration": {"speed": 0.94, "pitch":  0, "volume": 1.00, "pause_after_ms": 140},
    "contrast":  {"speed": 0.90, "pitch":  1, "volume": 1.02, "pause_after_ms": 260},
    "question":  {"speed": 0.88, "pitch":  1, "volume": 1.03, "pause_after_ms": 320},
    "emphasis":  {"speed": 0.84, "pitch": -1, "volume": 1.07, "pause_after_ms": 360},
}


def resolve_delivery(delivery: str, override: dict | None = None) -> dict:
    """取预设并叠加微调。

    未知表达**直接报错，不回退到中性**——默默回退的话，五种表达就形同虚设：
    写错一个词，整段变成平铺直叙，而没有任何提示。
    """
    preset = DELIVERY_PRESETS.get(str(delivery))
    if preset is None:
        raise TtsError(
            f"未知表达 {delivery!r}。可用：{'、'.join(DELIVERY_PRESETS)}。")
    merged = dict(preset)
    merged.update(override or {})
    return merged


def delivery_fingerprint(delivery: str, override: dict | None = None) -> str:
    """四项参数**全部参与**。

    最容易漏的是 `pause_after_ms`：它不改音色只改尾部静音，听上去差不多，
    但**时长变了**。指纹不含它，就会出现「音频换了、字幕轴还是旧的」——
    字幕从那一段起整体漂移，而且没有任何报错。
    """
    p = resolve_delivery(delivery, override)
    payload = (f"{delivery}\x00{p['speed']:g}\x00{p['pitch']:g}"
               f"\x00{p['volume']:g}\x00{int(p['pause_after_ms'])}")
    return _hashlib.sha256(payload.encode("utf-8")).hexdigest()
