#!/usr/bin/env python3
"""配音能力 CLI。

逐句时长只测不算：曾出现字幕只覆盖 30% 旁白，根因是拿估算当实测。
"""
from __future__ import annotations

import argparse
import pathlib

from byclaw_caps._cli import add_common, dispatch
from byclaw_caps.tts import (
    TtsError, concat_audio, measure_durations, requires_dual_auth,
    split_text, spoken_units, subtitle_timeline,
    DELIVERY_PRESETS, delivery_fingerprint, resolve_delivery,
)
from byclaw_caps.tts.segments import plan_segments, segment_text
from byclaw_caps.credentials import ConfigurationError
from byclaw_caps.tts.providers import synthesize_resolved


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="byclaw_caps.tts", description="配音")
    sub = parser.add_subparsers(dest="command", required=True)
    measure = sub.add_parser("measure", help="逐句实测时长")
    measure.add_argument("paths", nargs="+")
    timeline = sub.add_parser("timeline", help="由实测时长生成字幕时间轴")
    timeline.add_argument("paths", nargs="+")
    timeline.add_argument("--gap", type=float, default=0.0)
    auth = sub.add_parser("auth", help="判断该音色模式是否需要双授权")
    auth.add_argument("--mode", default="preset")
    split = sub.add_parser("split", help="按句切分到平台单次请求上限内")
    split.add_argument("text")
    split.add_argument("--max-chars", type=int, default=500)

    units = sub.add_parser("units", help="估算口播单位（**不得用于字幕时间轴**）")
    units.add_argument("text")

    join = sub.add_parser("concat", help="拼接音频片段：先无损拼 PCM，失败才退 ffmpeg")
    join.add_argument("output")
    join.add_argument("inputs", nargs="+")
    join.add_argument("--no-reencode", action="store_true",
                      help="不允许退到 ffmpeg 重编码：参数不一致时明确报错，"
                           "而不是悄悄抹平")

    seg = sub.add_parser("segments", help="按叙事段分组：段内一次合成，气脉连续")
    seg.add_argument("script", help="含 shots 的分镜脚本 JSON")

    dlv = sub.add_parser("delivery", help="取表演预设与指纹")
    dlv.add_argument("name", nargs="?", choices=sorted(DELIVERY_PRESETS))

    synth = sub.add_parser("synthesize", help="按 agentId 解析配音凭据并合成")
    synth.add_argument("--agent-id", required=True, help="agent 运行上下文里的 agentId")
    synth.add_argument("--session-root", help="凭据缓存落点；不给则每次重新解析")
    synth.add_argument("--model", default="", help="覆盖凭据里的 modelCode（模型型号）")
    text_group = synth.add_mutually_exclusive_group(required=True)
    text_group.add_argument("--text")
    text_group.add_argument("--text-file")
    synth.add_argument("--output", required=True)
    synth.add_argument(
        "--voice", default="",
        help=("MiniMax 音色，未传时使用默认值。火山语音 speaker 跟随绑定模型的"
              "instanceParam.extendParam，不接受此参数覆盖"),
    )
    synth.add_argument("--delivery", default="narration", choices=sorted(DELIVERY_PRESETS))

    for one in (measure, timeline, auth, split, units, join, dlv, seg, synth):
        add_common(one)
    return parser


def handle(args: argparse.Namespace):
    if args.command == "synthesize":
        text = args.text
        if args.text_file:
            text = pathlib.Path(args.text_file).read_text(encoding="utf-8")
        from byclaw_caps.credentials.resolve import resolve_credentials

        credential = resolve_credentials(
            args.agent_id, kind="tts", session_root=args.session_root)
        return synthesize_resolved(
            text, args.output, credential=credential, delivery=args.delivery,
            voice=args.voice, model=args.model), 0
    if args.command == "delivery":
        if not args.name:
            return {"ok": True, "presets": DELIVERY_PRESETS}, 0
        return {"ok": True, "name": args.name,
                "preset": resolve_delivery(args.name),
                "fingerprint": delivery_fingerprint(args.name)}, 0
    if args.command == "segments":
        import json

        data = json.loads(pathlib.Path(args.script).read_text(encoding="utf-8"))
        # 空脚本是「输入合法但结果不合约」——退 1 让 agent 去改脚本，
        # 不是退 2 让它去改命令行参数。
        try:
            groups = plan_segments(data.get("shots"))
        except TtsError as exc:
            return {"ok": False, "error": str(exc)}, 1
        return {"ok": True, "count": len(groups), "segments": [
            {"id": g["id"], "section": g["section"],
             "shots": [s["id"] for s in g["shots"]],
             "text": segment_text(g["shots"])} for g in groups]}, 0
    if args.command == "split":
        parts = split_text(args.text, args.max_chars)
        return {"ok": True, "parts": parts, "count": len(parts)}, 0
    if args.command == "units":
        return {"ok": True, "units": spoken_units(args.text),
                "note": "估算值，不得用于字幕时间轴——时间轴只能来自 measure 实测"}, 0
    if args.command == "concat":
        import tempfile
        out = concat_audio(args.inputs, args.output, tempfile.mkdtemp(),
                           allow_reencode=not args.no_reencode)
        return {"ok": True, "output": str(out), "segments": len(args.inputs)}, 0
    if args.command == "auth":
        return {"ok": True, "mode": args.mode, "dual_auth": requires_dual_auth({"mode": args.mode})}, 0
    measured = measure_durations(args.paths)
    if args.command == "measure":
        return {"ok": True, "seconds": list(measured.seconds), "source": measured.source}, 0
    cues = subtitle_timeline(measured, gap=args.gap)
    return {"ok": True, "cues": [list(cue) for cue in cues]}, 0


def main() -> int:
    """控制台入口点。

    `python -m byclaw_caps.<能力>` 与安装后的 `byclaw-<能力>` 走同一条路——
    两条路行为分叉的话，文档里写的那条迟早是错的。
    """
    return dispatch(build(), handle, usage_errors=(TtsError, ConfigurationError))


if __name__ == "__main__":
    raise SystemExit(main())
