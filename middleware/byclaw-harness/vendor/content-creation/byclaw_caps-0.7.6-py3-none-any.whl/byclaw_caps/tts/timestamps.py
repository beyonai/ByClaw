#!/usr/bin/env python3
"""词级时间戳：让画面元素在「讲到它」的那一刻出现。

## 为什么需要它

用户说动画「毫无逻辑」，举的例子是 PPT——「配合演示讲解，按顺序先显示 A，再显示 B」。
把镜头时长均分给 N 个元素做不到这件事，那还是机械的。
只有拿到「旁白讲到第一个月是在第几秒」，才谈得上配合讲解。

## 之前只拿到了地址

``synthesize`` 早就请求了 ``subtitle_enable`` + ``subtitle_type: word``，
返回体里的 ``subtitle_file`` 也带出来了——**但仅止于此**。

## 指纹绑定不能省

MiniMax 合成是**不确定的**：同一个请求体连打 5 次，5 个不同的 sha256，
时长极差 11%。音频一旦重生成（包括失败重试），旧的时间戳就全部作废——
而画面上看不出来，只表现为「元素比话音早了半秒或晚了半秒」。
所以时间戳落盘时必须带上音频指纹，读取时必须核对。

## 匹配失败硬失败

第一版方案写的是「退回均分并告警」。**告警不够**——告警之后照样出片，
交付的仍是用户指出的那种机械动画。要均分，必须由脚本显式选 ``even``。
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from . import TtsError

VERSION = "1.0.0"

#: 最后一个图层出现后至少要留的秒数。
#: 若它在 9.4 秒镜头的第 9.2 秒才冒出来，只有 0.2 秒露脸——一闪而过等于白做。
MIN_LAST_DWELL = 1.2

#: 匹配时忽略的标点。旁白里的顿号句号不该阻断匹配。
_PUNCT = re.compile(r"[\s，。：；？！、（）()「」“”\"'—…·,.!?:;]+")


def _normalise(text: str) -> str:
    return _PUNCT.sub("", str(text or "")).casefold()


def restore_authored_spelling(words, authored_text: str) -> list[dict]:
    """Restore authored Latin spelling without changing provider timings.

    Some TTS providers return word timestamps with normalized Latin text, for
    example ``ERP`` as ``e r p`` or ``供应商A`` as ``供应商a``.  The timestamps
    remain authoritative, while the request text remains authoritative for
    spelling.  Reconcile the two only when their complete alphanumeric streams
    are equal case-insensitively; any real wording difference is left intact so
    the normal alignment checks can still fail closed.
    """
    restored = [{**word, "text": str(word.get("text") or "")}
                for word in (words or [])]
    provider_chars: list[tuple[int, int, int, str]] = []
    provider_semantic: list[tuple[int, int, int, str]] = []
    linear = 0
    for word_index, word in enumerate(restored):
        for char_index, char in enumerate(word["text"]):
            item = (word_index, char_index, linear, char)
            provider_chars.append(item)
            if char.isalnum():
                provider_semantic.append(item)
            linear += 1

    authored_chars = list(str(authored_text or ""))
    authored_semantic = [
        (index, char) for index, char in enumerate(authored_chars)
        if char.isalnum()
    ]
    if (
        not provider_semantic
        or [item[3].casefold() for item in provider_semantic]
        != [char.casefold() for _, char in authored_semantic]
    ):
        return restored

    mutable = [list(word["text"]) for word in restored]
    removed: set[tuple[int, int]] = set()
    for provider, authored in zip(provider_semantic, authored_semantic):
        word_index, char_index, _, provider_char = provider
        _, authored_char = authored
        if provider_char.isascii() and provider_char.isalpha():
            mutable[word_index][char_index] = authored_char

    for (left_provider, left_authored), (right_provider, right_authored) in zip(
        zip(provider_semantic, authored_semantic),
        zip(provider_semantic[1:], authored_semantic[1:]),
    ):
        left_char, right_char = left_authored[1], right_authored[1]
        if not (
            left_char.isascii() and left_char.isalpha()
            and right_char.isascii() and right_char.isalpha()
        ):
            continue
        authored_gap = authored_chars[left_authored[0] + 1:right_authored[0]]
        if any(char.isspace() for char in authored_gap):
            continue
        for word_index, char_index, position, char in provider_chars:
            between = left_provider[2] < position < right_provider[2]
            if between and char.isspace():
                removed.add((word_index, char_index))

    output = []
    for word_index, word in enumerate(restored):
        text = "".join(
            char for char_index, char in enumerate(mutable[word_index])
            if (word_index, char_index) not in removed
        )
        if text:
            output.append({**word, "text": text})
    return output


def parse_words(payload) -> list[dict]:
    """解析 MiniMax 的词级字幕。

    返回 ``[{"text", "start", "end"}]``，秒为单位。

    **空字幕必须报错。** 当成「没有时间戳」静默继续的话，就会退回机械动画，
    而那正是这套东西要解决的问题。
    """
    if isinstance(payload, (str, bytes)):
        try:
            data = json.loads(payload)
        except (ValueError, TypeError) as exc:
            raise TtsError(f"词级字幕不是合法 JSON：{exc}") from None
    else:
        data = payload

    if isinstance(data, dict):
        for key in ("words", "subtitles", "data", "result"):
            if isinstance(data.get(key), list):
                data = data[key]
                break
    if not isinstance(data, list) or not data:
        raise TtsError(
            "词级字幕为空——没有时间戳就无法按讲解顺序出元素。"
            "静默继续会退回按时长均分，也就是用户说的那种机械动画")

    # 真实结构：顶层是**分段**数组，逐词时间在 `timestamped_words` 里。
    # 段本身也带 time_begin／time_end，但那是整段的——拿它做 cue 等于没有词级。
    items = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        if isinstance(entry.get("timestamped_words"), list):
            items.extend(entry["timestamped_words"])
            continue
        # 段级条目却没有逐词时间：当成一个粗粒度的「词」会让**所有元素同时出现**，
        # 而画面上看起来只是「动画没生效」。宁可报错。
        #
        # 判别靠键名：词级条目用 `word`，段级用 `text`。
        # 一开始拿 `is_final_segment` 当判据是错的——那个字段不一定出现。
        if "word" not in entry:
            raise TtsError(
                "字幕分段里没有 timestamped_words——只有整段时间而无逐词时间。"
                "当成一个词用会让所有元素在同一刻出现，"
                "请确认请求带了 subtitle_type: word")
        items.append(entry)

    words: list[dict] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        text = str(item.get("word") or item.get("text") or "")
        begin = item.get("time_begin", item.get("begin_time",
                 item.get("start_time", item.get("start"))))
        end = item.get("time_end", item.get("end_time", item.get("end")))
        if begin is None or not text:
            continue
        # 毫秒。数值再小也按毫秒——一段旁白不会只有 1 秒。
        words.append({"text": text,
                      "start": float(begin) / 1000.0,
                      "end": float(end if end is not None else begin) / 1000.0})
    if not words:
        raise TtsError(
            "词级字幕里没有可用的时间项——只有整段时间而无逐词时间，"
            "做不了「讲到哪个亮哪个」")
    return words


def find_cue(words, phrase: str, *, occurrence: int = 1) -> float:
    """找出短语**开始被讲到**的时刻。

    按标准化后的**连续字符**匹配，不假定分词粒度——
    「第一个月」在返回里可能是「第一」+「个月」两个 token。

    Raises:
        TtsError: 找不到，或出现次数不足。**不返回兜底值**。
    """
    target = _normalise(phrase)
    if not target:
        raise TtsError("cue 短语为空")

    # 拼成连续字符串，同时记下每个字符来自哪个 token，以便回推起始时刻。
    joined, owners = [], []
    for index, word in enumerate(words or []):
        for char in _normalise(word["text"]):
            joined.append(char)
            owners.append(index)
    text = "".join(joined)

    hits, cursor = [], 0
    while True:
        at = text.find(target, cursor)
        if at < 0:
            break
        hits.append(at)
        cursor = at + 1
    if not hits:
        raise TtsError(
            f"旁白里找不到 cue {phrase!r}——by_narration 匹配失败**不退回均分**："
            "告警之后照样出片，交付的仍是机械动画。"
            "请改 cue、或显式改用 even / at_ms")
    if occurrence < 1 or occurrence > len(hits):
        raise TtsError(
            f"cue {phrase!r} 只出现 {len(hits)} 次，取不到第 {occurrence} 次")
    return float(words[owners[hits[occurrence - 1]]]["start"])


def save_timestamps(path, *, words, audio_fingerprint: str, shot_id: str) -> Path:
    """落盘为阶段产出，**与音频指纹绑定**。"""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    parsed = parse_words(words)
    target.write_text(json.dumps(
        {"shot_id": shot_id, "audio_fingerprint": audio_fingerprint,
         "words": parsed}, ensure_ascii=False, indent=1), encoding="utf-8")
    return target


def load_timestamps(path, *, audio_fingerprint: str) -> list[dict]:
    """读回时间戳，**核对指纹**。

    音频重生成过而时间戳没跟着更新，是最容易悄悄发生的一种——
    合成不确定，重试一次就是另一条时长不同的音频。
    """
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    saved = str(data.get("audio_fingerprint") or "")
    if saved != str(audio_fingerprint):
        raise TtsError(
            f"词级时间戳与音频不匹配（存的是 {saved[:12]}…，当前是 "
            f"{str(audio_fingerprint)[:12]}…）——音频重生成过，时间戳已作废。"
            "合成不确定，同参数每次时长都不同，必须重新下载")
    return list(data.get("words") or [])


def build_layer_timeline(layers, *, mode: str, words, duration: float) -> list[dict]:
    """算出每个图层的出现时刻。

    ``lead_ms`` 让视觉**略微领先**于语音——同步反而显得慢半拍。
    """
    items = list(layers or [])
    if not items:
        raise TtsError("没有图层——空的分步等于没有分步，而画面看不出差别")

    if mode == "by_narration":
        if not words:
            raise TtsError(
                "by_narration 需要词级时间戳，但没有拿到——"
                "**不退回均分**：要均分请在脚本里显式写 mode: even")
        times = []
        for layer in items:
            anchor = layer.get("anchor") or {}
            at = find_cue(words, anchor.get("text"),
                          occurrence=int(anchor.get("occurrence") or 1))
            lead = float((layer.get("enter") or {}).get("lead_ms") or 0) / 1000.0
            times.append({"id": layer.get("id"), "at": max(0.0, at - lead)})
    elif mode == "even":
        step = float(duration) / (len(items) + 1)
        times = [{"id": layer.get("id"), "at": step * (i + 1)}
                 for i, layer in enumerate(items)]
    elif mode == "at_ms":
        times = [{"id": layer.get("id"),
                  "at": float(layer.get("at_ms") or 0) / 1000.0} for layer in items]
    else:
        raise TtsError(f"未知 build.mode {mode!r}")

    ats = [t["at"] for t in times]
    if ats != sorted(ats):
        raise TtsError(
            f"图层出现时刻乱序：{[round(a, 2) for a in ats]}——"
            "cue 顺序写错了，叠出来会「讲第一点、亮第三个」")
    tail = float(duration) - ats[-1]
    if tail < MIN_LAST_DWELL:
        raise TtsError(
            f"最后一个图层在第 {ats[-1]:.2f} 秒才出现，镜头只有 {duration:.2f} 秒，"
            f"仅剩 {tail:.2f} 秒露脸（需 ≥ {MIN_LAST_DWELL}）——"
            "一闪而过等于白做，请加长镜头或前移 cue")
    return times


__all__ = [
    "VERSION", "MIN_LAST_DWELL", "parse_words", "restore_authored_spelling",
    "find_cue", "save_timestamps", "load_timestamps", "build_layer_timeline",
]
