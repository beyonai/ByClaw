> 由 `preset-voice-tts/references/providers/minimax.md` 迁入——该 Skill 已退役，配音归本能力。

# provider: minimax — MiniMax T2A v2

> 本文所有数值均为 2026-08-20 实测结果，非文档摘抄。
> 驱动实现见 `scripts/providers/minimax.py`；契约见 `scripts/providers/__init__.py` 顶部。

## 端点

| 用途 | 方法 | 路径 |
|---|---|---|
| 语音合成 | POST | `https://api.minimax.chat/v1/t2a_v2` |
| 查询音色 | POST | `https://api.minimax.chat/v1/get_voice` |

`https://api.minimaxi.com` 为等效备用域名，实测返回一致。`api.minimax.io` 不可解析。

鉴权：`Authorization: Bearer <TTS_MINIMAX_TOKEN>`，`Content-Type: application/json`。实测不需要额外传 GroupId。

## 合成请求

```json
{
  "model": "speech-02-hd",
  "text": "要合成的文本",
  "stream": false,
  "voice_setting": {"voice_id": "Chinese (Mandarin)_Male_Announcer", "speed": 0.92, "vol": 1.0, "pitch": 0},
  "audio_setting": {"sample_rate": 32000, "bitrate": 128000, "format": "wav", "channel": 1}
}
```

## 合成响应

```json
{
  "data": {"audio": "<十六进制字符串>", "status": 2},
  "extra_info": {"audio_length": 15092, "word_count": 67, "audio_sample_rate": 32000},
  "base_resp": {"status_code": 0, "status_msg": "success"}
}
```

- 音频以**十六进制字符串**返回，`bytes.fromhex()` 解码后即完整文件字节，不是 base64。
- `format: "wav"` 时解码结果以 `RIFF` 开头，实测为 `pcm_s16le` / 32000 Hz / 单声道 / 16 bit——未压缩 PCM，Python `wave` 模块可直接读写合并。
- `extra_info.audio_length` 单位为毫秒，与本地 `ffprobe` 实测一致。
- 业务错误通过 `base_resp.status_code != 0` 表达，HTTP 状态仍可能是 200。**必须检查 `base_resp`，不能只看 HTTP 码。**

## 实测性能

绕开本地代理后，从 Windows 开发机测得：

| 场景 | 文本 | 音频时长 | 墙钟 |
|---|---|---|---|
| `speech-02-hd` | 67 字 | 15.09 s | 2.80 s |
| `speech-2.5-hd-preview` | 67 字 | 15.57 s | 3.84 s |
| `speech-01-turbo` | 67 字 | 13.61 s | 1.94 s |
| `speech-02-hd` 长文本 | 603 字 | 132.18 s | 5.01 s |

三页真实项目端到端 4.76 秒；全部命中指纹复用时 0.22 秒且零联网。

**603 字单次调用成功，未触发长度限制**——与有道那条链路必须按 500 字分段不同，多数页面不需要分段。脚本仍保留 `--max-chars`（默认 2000）作为保险。

## 音色

`POST /v1/get_voice` body `{"voice_type": "all"}`，响应 `system_voice[]` 每项含 `voice_id`、`voice_name`。

实测共 **303 个**系统预置音色，其中中文命名 **64 个**（含普通话与粤语）。用 `--list-voices` 查看。

## 语速与渠道规范

| 音色 | speed | 实测语速（口播单位/分钟） |
|---|---|---|
| `Chinese (Mandarin)_Male_Announcer` | 1.00 | 约 266–274 |
| `Chinese (Mandarin)_Male_Announcer` | 0.92 | 254.7 |
| `Chinese (Mandarin)_Radio_Host` | 0.92 | 290.6 – 293.2 |

`DEFAULT_SPEED = 0.92` 是按播报男声标定的。**换音色必须重新标定**——电台男主播在同一 speed 下快 15%。

`speed` 生效可验证：同一文本 1.0 → 15.09 s，1.15 → 12.49 s。

## 非幂等

同一文本两次调用返回的音频不逐字节相同。实测第 13 页两次生成分别为 34.11 s 与 34.71 s，整片总时长 384.53 s → 388.10 s。因此任何触发重生成的改动都会作废下游字幕与成片。

## 已知环境坑

Windows 上 Python `urllib` 会读注册表做代理探测。本机 `getproxies()` 返回 `http://127.0.0.1:7897`（本地代理客户端），该代理对此域名不通，导致**每个请求固定卡约 20 秒**：

```
默认 opener                    20912 ms
ProxyHandler({}) 禁代理探测        375 ms
```

同一请求用 curl 只需 1.01 秒，说明不是网络本身的问题。脚本提供 `--no-proxy` 开关绕过。Linux 沙箱只读环境变量，通常不受影响；沙箱确实需要走代理时不要加该开关。

同类问题也存在于 `generate-content-images/scripts/llm_image.py`——它同样用 `urllib.request`，在同样的 Windows 环境下会有同样的固定延迟。
