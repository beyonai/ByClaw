#!/usr/bin/env python3
"""能力 CLI 的共用骨架。

七项能力**以 CLI 形态交付**，因为调用方是 agent 不是代码：今天 15 个 Skill 零处跨 Skill
import，协作全靠 agent 编排。agent 擅长执行命令，不擅长现写 Python。

各能力参数名不同，但**传入传出的形状一致**——否则 agent 要为每个能力记一套规矩。

退出码分三档，**业务失败与用法错误必须分开**：agent 据此判断该改输入还是该改参数。

    0  成功
    1  业务失败（输入合法，结果不合约，如画幅降级、踩了平台红线）
    2  用法错误（参数缺失或非法、源文件不存在、环境不具备）
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Callable

EXIT_OK = 0
EXIT_BUSINESS = 1
EXIT_USAGE = 2


def add_common(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """所有能力共用的开关。"""
    parser.add_argument(
        "--result-file",
        help="把结果 JSON 同时写到此路径。留痕是重放的前提——"
             "会话目录的 .meta/ 与 .runtime/validation/ 正靠它。",
    )
    return parser


WORKSPACE_MARKER = "/by/.openclaw/workspace-"


class UsageError(RuntimeError):
    """用法错误。带 `exit_code`，由 `dispatch` 映射成退出码 2。"""

    exit_code = EXIT_USAGE


def check_result_file(result_file: str | None) -> Path | None:
    """结果文件不得落在工作区。

    工作区会随回收而丢失，也无法在同一会话的多个数字员工之间交接——写进去的东西过一会儿
    就没了，**而且不报错**。原先这道守卫由两个 Skill 各自实现（它们的 `--result-file`
    不经运行时分配、直接落盘，绕过了运行时拦截，只能自己拦）；能力层接手时漏了。
    """
    if not result_file:
        return None
    raw = str(result_file).replace("\\", "/")
    # **先解析再判，不能只查字符串。** 相对路径按 cwd 解析，而 cwd
    # **常常就是工作区**——只比字符串的话，`--result-file out.json` 里没有
    # workspace 标记，守卫放行，文件却落进了工作区。实测踩过：写完找不到，
    # `ls` 加 `find /` 找了一圈，最后靠 `cd` + `mv` 绕过去。
    # **静默落错地方，比报错难查得多。**
    resolved = Path(raw) if Path(raw).is_absolute() else (Path.cwd() / raw)
    normalized = str(resolved).replace("\\", "/")
    if WORKSPACE_MARKER in normalized:
        where = ("解析到 " + normalized) if not Path(raw).is_absolute() else normalized
        raise UsageError(
            f"--result-file 落在工作区（{where}）。产物不得写入工作区："
            "该目录会随工作区回收而丢失，也无法在数字员工之间交接。"
            + ("**相对路径按当前目录解析，而当前目录就是工作区**——"
               "请给会话根下的绝对路径，例如 "
               "/by/.sessions/<数字ID>/.runtime/xxx.json。"
               if not Path(raw).is_absolute() else
               "请改写到会话根之下（/by/.sessions/<数字ID>/）。")
        )
    return resolved


def write_stdout(text: str) -> None:
    """把一行文本按 **UTF-8** 写到 stdout。

    ⛔ **不要退回 `print`。**

    Windows 上 stdout 接管道时用的是系统 ANSI 代码页（这台机器是 GBK），
    而载荷里到处是中文。于是同一份 JSON：写进 `--result-file` 的是 UTF-8，
    走 stdout 的是 GBK——**两处内容一样，字节不一样**。

    实测后果：调用方按 UTF-8 读 stdout 直接 `UnicodeDecodeError`，
    `subprocess.run(..., encoding="utf-8")` 把 `stdout` 交成 `None`，
    于是"这次到底成没成"从一份结构化载荷退化成一个空值。
    技能里的 agent 读到的则是一屏乱码——错误码、下一步全糊了。

    stdout 已经是 UTF-8（Linux、或调用方设了 `PYTHONIOENCODING`）时照常走
    `print`；拿不到底层字节流时（pytest 的捕获流就没有 `buffer`）也照常走——
    那些情况下本来就没有这个问题。
    """
    encoding = (getattr(sys.stdout, "encoding", "") or "").lower()
    buffer = getattr(sys.stdout, "buffer", None)
    if buffer is None or encoding.replace("-", "") in ("utf8", "utf8sig"):
        print(text)
        return
    sys.stdout.flush()
    buffer.write((text + "\n").encode("utf-8"))
    buffer.flush()


def emit(payload: dict[str, Any], *, result_file: str | None, code: int) -> int:
    """输出 JSON 并按需落盘。stdout 永远是 JSON，便于记录、重放与比对。

    落点非法时**只跳过落盘，不再抛**——校验已在 `dispatch` 入口做过并给出了错误载荷；
    这里再抛一次会盖掉那个载荷，把「路径不合法」变成一串 traceback。
    """
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    write_stdout(text)
    try:
        target = check_result_file(result_file)
    except UsageError:
        return code
    if target is not None:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    return code


def error_payload(exc: BaseException) -> dict[str, Any]:
    """保留异常自带的结构化信息。

    两份数字员工提示词都写着「同一错误码连续出现 2 次即停」。那条规则要成立，错误码就得
    真的出现在输出里——只渲染一句中文，agent 无从判断这次和上次是不是同一个错。
    """
    payload: dict[str, Any] = {}
    if hasattr(exc, "as_dict"):
        payload.update(exc.as_dict())
    payload.setdefault("ok", False)
    payload.setdefault("error", str(exc))
    payload.setdefault("error_type", type(exc).__name__)
    return payload


def dispatch(
    parser: argparse.ArgumentParser,
    handler: Callable[[argparse.Namespace], tuple[dict[str, Any], int]],
    *,
    usage_errors: tuple[type[BaseException], ...] = (),
) -> int:
    """统一异常到退出码的映射。

    ``usage_errors`` 里的异常归入用法错误（2）；其余未预期异常同样按 2 处理并带上类型名——
    不静默吞掉，也不让 agent 面对裸堆栈。
    """
    args = parser.parse_args()
    try:
        # 在跑业务之前先校验落点：跑完再报错，副作用已经发生了。
        check_result_file(getattr(args, "result_file", None))
    except UsageError as exc:
        return emit(error_payload(exc), result_file=None, code=EXIT_USAGE)
    try:
        payload, code = handler(args)
    except usage_errors as exc:
        # 异常自带 exit_code 时按它走：并发冲突这类"重读一次就能继续"的失败是业务失败，
        # 判成用法错误会让 agent 按"环境不具备"处理，动作正好反了。
        return emit(
            error_payload(exc),
            result_file=getattr(args, "result_file", None),
            code=getattr(exc, "exit_code", EXIT_USAGE),
        )
    except Exception as exc:  # noqa: BLE001
        return emit(
            error_payload(exc),
            result_file=getattr(args, "result_file", None),
            code=EXIT_USAGE,
        )
    return emit(payload, result_file=getattr(args, "result_file", None), code=code)


def business(payload: dict[str, Any]) -> tuple[dict[str, Any], int]:
    """按 ``ok`` 字段决定 0 或 1。"""
    return payload, EXIT_OK if payload.get("ok") else EXIT_BUSINESS


__all__ = [
    "EXIT_OK", "EXIT_BUSINESS", "EXIT_USAGE",
    "add_common", "emit", "write_stdout", "dispatch", "business",
]
