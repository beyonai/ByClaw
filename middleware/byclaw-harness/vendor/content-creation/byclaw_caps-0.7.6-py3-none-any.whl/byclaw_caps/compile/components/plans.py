"""Source-bound, versioned component plans. Highlights keep their old contract."""
from __future__ import annotations

import json
import re
from pathlib import Path

from .. import CompileError, presentation_profile, validate_reading_profile
from .catalog import CATALOG, CHANNELS, RECIPES, source_variants, variant

_DEFAULT = {
    "heading": "section.heading", "subheading": "section.subheading",
    "paragraph": "content.paragraph", "conclusion": "content.paragraph",
    "quote": "content.quote", "ordered_list": "content.list.ordered",
    "unordered_list": "content.list.unordered", "table": "content.table",
    "image": "media.image", "code": "code.block",
    "divider": "section.divider", "scene_break": "section.divider",
}


def make_plan(document: dict, *, channel="wechat.public_article", theme="gzh-red-white",
              layout="balanced", reading_profile="default", recipe="auto") -> dict:
    blocks = document["blocks"]
    if recipe == "auto":
        recipe = ("essay" if reading_profile != "default" else
                  "tutorial" if any(b["kind"] == "code" for b in blocks) else "analysis")
    if recipe not in RECIPES:
        raise CompileError("UNKNOWN_RECIPE", "未知文章配方", recipe=recipe)
    entries = []
    first_content = True
    skip = set()
    for index, block in enumerate(blocks):
        kind = block["kind"]
        if kind == "title" or block["block_id"] in skip:
            continue
        component = _DEFAULT[kind]
        refs = [block["block_id"]]
        # The opening quote is an authored lead. Ordinary first paragraphs
        # remain prose; full-bold sentences are not automatically summary cards.
        if kind == "quote" and first_content and recipe != "essay":
            component = RECIPES[recipe]["intro"]
        if (kind in {"paragraph", "conclusion"} and
                re.sub(r"[*\s]", "", block["data"].get("text", "")) in {"本文看点", "本文脉络", "目录"} and
                index + 1 < len(blocks) and blocks[index+1]["kind"] in {"ordered_list", "unordered_list"}):
            component = "article.toc"
            refs.append(blocks[index+1]["block_id"])
            skip.add(refs[-1])
        if kind == "ordered_list" and reading_profile == "default":
            component = RECIPES[recipe]["ordered"]
        if kind == "quote":
            text = block["data"]["text"]
            if text.startswith(("注意", "警告", "风险")):
                component = "content.callout.warning"
        if reading_profile != "default":
            if kind == "conclusion":
                component = "content.paragraph"
        if kind == "image" and block["data"]["src"].lower().split("?")[0].endswith(".gif"):
            component = "media.gif"
        entries.append({"instance_id": "c-" + block["block_id"],
                        "component_id": component, "variant_id": "default",
                        "source_refs": refs})
        first_content = False
    result = {key: document[key] for key in ("schema_version", "article_sha256", "block_set_sha256")}
    result.update(channel=channel, theme=theme, layout=layout,
                  reading_profile=reading_profile, recipe=recipe, components=entries)
    from .structures import fingerprint
    result["render_binding"] = fingerprint(theme)
    result["review"] = {"status": "draft"}
    validate(result, document)
    return result


def load(path: str | Path) -> dict:
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (json.JSONDecodeError, UnicodeError) as error:
        raise CompileError("INVALID_COMPONENT_PLAN", "组件计划须为有效 JSON") from error
    if not isinstance(payload, dict):
        raise CompileError("INVALID_COMPONENT_PLAN", "组件计划必须为对象")
    return payload


def validate(plan: dict, document: dict) -> dict:
    def fail(code, message, **detail):
        raise CompileError(code, message, **detail)

    allowed = {"schema_version", "article_sha256", "block_set_sha256", "channel",
               "theme", "layout", "reading_profile", "recipe", "components", "render_binding", "review"}
    if set(plan) - allowed:
        fail("INVALID_COMPONENT_PLAN", "组件计划含未知字段", fields=sorted(set(plan) - allowed))
    if plan.get("schema_version") != "1.0":
        fail("COMPONENT_SCHEMA_VERSION", "不支持的组件计划版本")
    for key in ("article_sha256", "block_set_sha256"):
        if plan.get(key) != document[key]:
            fail("COMPONENT_PLAN_STALE", "原文或解析结果变化，须重新生成组件计划", field=key)
    if plan.get("channel") not in CHANNELS:
        fail("UNKNOWN_CHANNEL", "未支持该渠道", channel=plan.get("channel"))
    if not isinstance(plan.get('recipe'),str) or plan.get("recipe") not in RECIPES:
        fail("UNKNOWN_RECIPE", "未支持该文章配方")
    presentation_profile(plan.get("layout"), plan.get("theme"))
    validate_reading_profile(plan.get("reading_profile"))
    if "render_binding" in plan:
        from .structures import fingerprint
        if plan["render_binding"] != fingerprint(plan["theme"]):
            fail("COMPONENT_RENDERER_STALE", "主题或渲染实现变化，须重建计划并重新验收")
    review = plan.get("review", {"status": "draft"})
    if not isinstance(review, dict) or review.get("status") not in {"draft", "reviewed"}:
        fail("INVALID_COMPONENT_REVIEW", "组件计划复核状态无效")
    if review["status"] == "reviewed" and review.get("plan_sha256") != plan_digest(plan):
        fail("COMPONENT_REVIEW_STALE", "计划已改变，须重新复核组件选用")
    if not isinstance(plan.get("components"), list):
        fail("INVALID_COMPONENT_PLAN", "components 必须为数组")
    lookup = {b["block_id"]: b for b in document["blocks"]}
    order = {b["block_id"]: i for i, b in enumerate(document["blocks"])}
    consumed, instance_ids = set(), set()
    previous = -1
    variants = source_variants()
    for entry in plan["components"]:
        if not isinstance(entry, dict):
            fail("INVALID_COMPONENT_PLAN", "组件实例必须为对象")
        extra = set(entry) - {"instance_id", "component_id", "variant_id",
                              "source_refs", "fields", "fallback", "derived", "marks"}
        if extra:
            fail("INVALID_COMPONENT_PLAN", "组件实例含未知字段", fields=sorted(extra))
        ident = entry.get("instance_id")
        if not isinstance(ident, str) or not ident or ident in instance_ids:
            fail("DUPLICATE_COMPONENT_ID", "实例 ID 不能为空或重复")
        instance_ids.add(ident)
        cid = entry.get("component_id")
        if not isinstance(cid,str) or cid not in CATALOG:
            fail("UNKNOWN_COMPONENT", "组件未注册", component_id=cid)
        vid = entry.get("variant_id", "default")
        try:
            variant(vid)
        except (ValueError, TypeError):
            fail("UNKNOWN_COMPONENT_VARIANT", "组件变体未注册", variant_id=vid)
        if vid in variants and variants[vid]["component_id"] != cid:
            fail("COMPONENT_VARIANT_MISMATCH", "源变体与组件语义不符", variant_id=vid)
        refs = entry.get("source_refs")
        if not isinstance(refs, list) or not refs or any(not isinstance(r, str) for r in refs):
            fail("INVALID_COMPONENT_REFS", "组件必须引用非空源块列表")
        if len(set(refs)) != len(refs) or any(r not in lookup for r in refs):
            fail("INVALID_COMPONENT_REFS", "源块重复或不存在")
        if any(lookup[r]["kind"] == "title" for r in refs):
            fail("COMPONENT_TITLE_FIELD", "文章标题由渠道标题字段承载，不能重复当正文")
        if not isinstance(entry.get("derived", False), bool):
            fail("INVALID_COMPONENT_PLAN", "derived 必须为布尔值")
        if entry.get("derived"):
            if cid != "article.toc":
                fail("INVALID_DERIVED_COMPONENT", "只允许目录按原文标题派生")
            if any(lookup[r]["kind"] not in {"heading", "subheading"} for r in refs):
                fail("INVALID_DERIVED_COMPONENT", "派生目录仅引用原文标题")
            if [order[r] for r in refs] != sorted(order[r] for r in refs):
                fail("COMPONENT_ORDER", "目录引用须保持原文标题顺序")
        else:
            if any(r in consumed for r in refs):
                fail("COMPONENT_OVERLAP", "同一正文块不能重复消费")
            positions = [order[r] for r in refs]
            if positions != list(range(positions[0], positions[0] + len(refs))) or positions[0] <= previous:
                fail("COMPONENT_ORDER", "组件引用须保持连续的原文顺序")
            previous = positions[-1]
            consumed.update(refs)
        kinds = CATALOG[cid]["source_kinds"]
        if kinds is None:
            fail("NON_CONTENT_COMPONENT", "容器和内部元数据不能替换正文")
        if any(lookup[r]["kind"] not in kinds for r in refs):
            fail("COMPONENT_KIND_MISMATCH", "原文类型与组件不符", component_id=cid)
        marks = entry.get("marks", [])
        if not isinstance(marks, list) or len(marks) > 3 * len(refs):
            fail("INVALID_COMPONENT_MARK", "强调标记须为列表，每源块不超过3处")
        counts = {}
        for mark in marks:
            if not isinstance(mark, dict) or set(mark) != {"source_ref", "text", "occurrence", "kind"}:
                fail("INVALID_COMPONENT_MARK", "强调仅指定来源、原文短语、出现序号和类型")
            ref, phrase, occurrence = mark['source_ref'], mark['text'], mark['occurrence']
            if (ref not in refs or lookup[ref]['kind'] not in {'paragraph','conclusion','quote'} or
                    not isinstance(phrase,str) or not 1 <= len(phrase) <= 40 or
                    not isinstance(occurrence,int) or isinstance(occurrence,bool) or occurrence < 0 or
                    not isinstance(mark['kind'],str) or mark['kind'] not in {'underline','highlight','tag'} or
                    lookup[ref]['data'].get('text','').count(phrase) <= occurrence):
                fail("INVALID_COMPONENT_MARK", "强调必须定位到对应源文中的已有短语")
            counts[ref] = counts.get(ref, 0) + 1
            if counts[ref] > 3:
                fail("INVALID_COMPONENT_MARK", "每个源块最多3处显式强调")
        fields = entry.get("fields", {})
        if not isinstance(fields, dict) or set(fields) - set(CATALOG[cid]["fields"]):
            fail("INVALID_COMPONENT_FIELDS", "展示字段不接受新的正文、数据或 HTML")
        if any(not isinstance(v, str) or len(v) > 40 for v in fields.values()):
            fail("INVALID_COMPONENT_FIELDS", "展示字段须为不超过 40 字的文字")
        fallback = entry.get("fallback")
        if fallback and (not isinstance(fallback,str) or fallback not in CATALOG):
            fail("UNKNOWN_COMPONENT", "降级组件未注册", component_id=fallback)
    return plan


def plan_digest(plan):
    from .semantic import digest
    return digest({k: v for k, v in plan.items() if k != "review"})


def review_plan(plan, document, note):
    """Agent attestation after semantic inspection, separate from visual QA."""
    validate(plan, document)
    if not isinstance(note, str) or not note.strip():
        raise CompileError("REVIEW_NOTE_REQUIRED", "请记录实际复核的组件选择及调整")
    plan["review"] = {"status": "reviewed", "plan_sha256": plan_digest(plan), "note": note.strip()}
    return plan
