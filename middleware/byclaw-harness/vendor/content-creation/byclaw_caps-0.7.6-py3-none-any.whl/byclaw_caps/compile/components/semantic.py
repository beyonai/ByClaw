"""Observe the public compiler's blocks rather than parsing Markdown twice."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .. import markdown_to_html


def digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":")).encode("utf-8")).hexdigest()


def scan(markdown: str, *, article_sha256: str = "") -> dict:
    blocks = []

    def observe(fragment, kind, data):
        blocks.append({"block_id": f"b{len(blocks) + 1:04d}", "kind": kind, "data": data})
        return fragment

    markdown_to_html(markdown, {}, block_sink=observe)
    return {"schema_version": "1.0",
            "article_sha256": article_sha256 or hashlib.sha256(markdown.encode("utf-8")).hexdigest(),
            "block_set_sha256": digest(blocks), "blocks": blocks}


def scan_file(path: str | Path) -> dict:
    source = Path(path)
    return scan(source.read_text(encoding="utf-8-sig"),
                article_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
