"""Additional commands wired into byclaw_caps.compile's existing CLI."""
from __future__ import annotations

import json
from pathlib import Path

from .catalog import CHANNELS, RECIPES, catalog, source_variants
from .plans import make_plan
from .semantic import scan_file

COMMANDS = {"components","blocks","component-plan","component-review","component-gallery","channel","theme-create"}


def add_parsers(sub):
    parsers = []
    listing = sub.add_parser("components",help="组件契约、渠道与配方")
    listing.add_argument("--channel",choices=CHANNELS)
    listing.add_argument("--sources",action="store_true",help="同时返回完整源项映射")
    parsers.append(listing)
    blocks = sub.add_parser("blocks",help="按既有编译器解析正文语义块")
    blocks.add_argument("source")
    blocks.add_argument("--out")
    parsers.append(blocks)
    plan = sub.add_parser("component-plan",help="生成源文哈希绑定的组件计划")
    plan.add_argument("source")
    plan.add_argument("output")
    plan.add_argument("--channel",choices=CHANNELS,default="wechat.public_article")
    plan.add_argument("--recipe",choices=["auto",*RECIPES],default="auto")
    plan.add_argument("--theme",default="gzh-red-white")
    plan.add_argument("--layout",default="balanced")
    plan.add_argument("--reading-profile",default="default")
    plan.add_argument("--theme-file")
    parsers.append(plan)
    review = sub.add_parser("component-review", help="记录 Agent 对组件计划的语义复核；不等于视觉通过")
    review.add_argument("source")
    review.add_argument("plan")
    review.add_argument("--note", required=True)
    review.add_argument("--theme-file")
    parsers.append(review)
    gallery = sub.add_parser("component-gallery",help="实际渲染组件和源变体画廊")
    gallery.add_argument("output")
    gallery.add_argument("--theme",default="gzh-red-white")
    gallery.add_argument("--theme-file")
    gallery.add_argument("--all-sources",action="store_true")
    parsers.append(gallery)
    channel = sub.add_parser("channel",help="按渠道导出富文本、配文或卡片；不联网发布")
    channel.add_argument("source")
    channel.add_argument("output")
    channel.add_argument("--channel",choices=CHANNELS,required=True)
    channel.add_argument("--component-plan")
    channel.add_argument("--theme")
    channel.add_argument("--theme-file")
    channel.add_argument("--recipe",choices=["auto",*RECIPES],default="auto")
    channel.add_argument("--layout")
    channel.add_argument("--reading-profile")
    channel.add_argument("--image-map")
    channel.add_argument("--render-images",action="store_true")
    channel.add_argument("--browser")
    parsers.append(channel)
    theme = sub.add_parser("theme-create",help="由偏好生成任务主题、组件预览；不改安装包")
    theme.add_argument("spec")
    theme.add_argument("output")
    parsers.append(theme)
    return parsers


def handle(args):
    if getattr(args,"theme_file",None):
        from .themes import register
        args.theme = register(args.theme_file)
    if args.command == "components":
        result = {"ok":True,**catalog(args.channel)}
        if args.sources:
            result["source_variants"] = source_variants()
    elif args.command == "component-review":
        from .plans import load, review_plan
        payload = review_plan(load(args.plan), scan_file(args.source), args.note)
        Path(args.plan).write_text(json.dumps(payload, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        result = {"ok": True, "plan": args.plan, "review": payload["review"], "visual_status": "pending"}
    elif args.command in ("blocks","component-plan"):
        document = scan_file(args.source)
        payload = (document if args.command == "blocks" else
                   make_plan(document,channel=args.channel,theme=args.theme,layout=args.layout,
                             recipe=args.recipe,reading_profile=args.reading_profile))
        path = getattr(args,"out",None) if args.command == "blocks" else args.output
        if path:
            path = Path(path)
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
            result = {"ok":True,"output":str(path),"blocks":len(document["blocks"])}
        else:
            result = {"ok":True,**payload}
    elif args.command == "component-gallery":
        from .gallery import build
        result = build(args.output,theme=args.theme,all_sources=args.all_sources)
    elif args.command == "channel":
        from ..channels import export
        from .._records import read_image_map
        result = export(args.source,args.output,channel=args.channel,plan_path=args.component_plan,
                        theme=args.theme,recipe=args.recipe,image_map=read_image_map(args.image_map)[0],
                        render_images=args.render_images,browser=args.browser,
                        layout=args.layout,reading_profile=args.reading_profile,theme_file=args.theme_file)
    else:
        from .themes import create
        result = create(args.spec,args.output)
    return result,0
