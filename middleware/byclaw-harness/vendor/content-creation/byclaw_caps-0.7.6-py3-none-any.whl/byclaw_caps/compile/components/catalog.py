"""Channel-independent component contracts. Kept in the capability wheel."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

SCHEMA_VERSION = "1.0"
DATA = Path(__file__).with_name("data")
CHANNELS = ("wechat.public_article", "wechat.image_text",
            "xiaohongshu.note", "toutiao.article")
RECIPES = {
    "analysis": {"label": "观点与分析", "intro": "article.hero", "ordered": "content.list.ordered"},
    "tutorial": {"label": "教程", "intro": "article.intro", "ordered": "content.steps"},
    "roundup": {"label": "工具盘点", "intro": "article.intro", "ordered": "content.item-card"},
    "report": {"label": "数据报告", "intro": "article.intro", "ordered": "content.list.ordered"},
    "case": {"label": "案例复盘", "intro": "article.intro", "ordered": "content.timeline"},
    "interview": {"label": "访谈", "intro": "article.intro", "ordered": "content.list.ordered"},
    "faq": {"label": "知识问答", "intro": "article.intro", "ordered": "content.faq"},
    "essay": {"label": "故事与随笔", "intro": "content.paragraph", "ordered": "content.list.ordered"},
}

# kind controls selection; renderer controls composition. Visual variation is
# data, never a second semantic component named after a theme.
_SPECS = [
    ("layout.container", "文章容器", "container", None),
    ("layout.section", "章节卡片容器", "section-card", ["heading", "subheading", "paragraph", "conclusion", "quote", "ordered_list", "unordered_list", "table", "image", "code", "divider"]),
    ("article.hero", "开篇观点/头图区", "hero", ["paragraph", "conclusion", "quote", "image"]),
    ("article.intro", "导语", "intro", ["paragraph", "quote", "conclusion"]),
    ("article.masthead", "刊头与期号", "masthead", ["paragraph", "heading", "subheading"]),
    ("article.toc", "看点与目录", "toc", ["heading", "subheading", "paragraph", "conclusion", "ordered_list", "unordered_list"]),
    ("section.heading", "章节标题", "heading", ["heading"]),
    ("section.subheading", "小节标题", "subheading", ["subheading", "heading", "conclusion"]),
    ("section.kicker", "前导词标题", "kicker", ["heading", "subheading"]),
    ("section.step-heading", "步骤标题", "step-heading", ["heading", "subheading"]),
    ("section.divider", "分隔线", "divider", ["divider", "scene_break"]),
    ("content.paragraph", "正文", "paragraph", ["paragraph", "conclusion"]),
    ("content.richtext", "富文本段落", "paragraph", ["paragraph", "conclusion"]),
    ("content.dropcap", "首字下沉", "dropcap", ["paragraph"]),
    ("content.emphasis", "行内强调", "emphasis", ["paragraph", "conclusion"]),
    ("content.quote", "引用", "quote", ["quote", "paragraph", "conclusion"]),
    ("content.quote.center", "居中金句", "quote-center", ["quote", "paragraph", "conclusion"]),
    ("content.quote.note", "编者按与旁注", "note", ["quote", "paragraph"]),
    ("content.callout.info", "信息", "callout", ["quote", "paragraph", "conclusion"]),
    ("content.callout.success", "结果", "callout", ["quote", "paragraph", "conclusion"]),
    ("content.callout.warning", "警示", "callout", ["quote", "paragraph", "conclusion"]),
    ("content.callout.tip", "提示", "callout", ["quote", "paragraph", "conclusion"]),
    ("content.callout.pitfall", "踩坑提醒", "callout", ["quote", "paragraph", "conclusion"]),
    ("content.label", "内容与主题标签", "label", ["paragraph", "heading", "subheading", "unordered_list"]),
    ("content.list.ordered", "有序列表", "ordered", ["ordered_list"]),
    ("content.list.unordered", "无序列表", "unordered", ["unordered_list"]),
    ("content.list.pill", "胶囊列表", "pill", ["ordered_list", "unordered_list"]),
    ("content.checklist", "任务清单", "checklist", ["ordered_list", "unordered_list"]),
    ("content.steps", "步骤", "steps", ["ordered_list"]),
    ("content.flow", "流程", "flow", ["ordered_list", "unordered_list"]),
    ("content.timeline", "时间线", "timeline", ["ordered_list", "unordered_list"]),
    ("content.comparison", "多项对照", "comparison", ["table", "ordered_list", "unordered_list", "paragraph"]),
    ("content.before-after", "新旧对照", "comparison", ["table", "paragraph", "ordered_list", "unordered_list"]),
    ("content.item-card", "条目卡", "item-card", ["ordered_list", "unordered_list", "paragraph"]),
    ("content.tool-card", "工具说明", "tool-card", ["paragraph", "ordered_list", "unordered_list"]),
    ("content.faq", "问答", "faq", ["paragraph", "quote", "ordered_list", "unordered_list"]),
    ("content.data-card", "数据卡", "data-card", ["paragraph", "table", "ordered_list", "unordered_list"]),
    ("content.data-grid", "多列数据卡", "data-grid", ["table", "ordered_list", "unordered_list"]),
    ("content.table", "数据表格", "table", ["table"]),
    ("content.progress", "进度", "progress", ["paragraph", "ordered_list", "unordered_list"]),
    ("content.trust-wall", "信任墙", "trust-wall", ["image", "unordered_list", "paragraph"]),
    ("content.summary", "摘要", "summary", ["paragraph", "conclusion", "unordered_list"]),
    ("content.roadmap", "路线", "roadmap", ["ordered_list", "unordered_list"]),
    ("media.image", "图片", "image", ["image"]),
    ("media.image-card", "图片卡", "image-card", ["image"]),
    ("media.full-bleed-image", "通栏图片", "image-full", ["image"]),
    ("media.image-pair", "双图", "image-pair", ["image"]),
    ("media.caption", "图片说明", "caption", ["paragraph"]),
    ("media.gif", "GIF", "image", ["image"]),
    ("media.video", "视频/录屏素材位", "placeholder", ["paragraph", "image"]),
    ("media.chart", "图表素材位", "placeholder", ["paragraph", "image"]),
    ("media.placeholder", "待补素材", "placeholder", ["paragraph"]),
    ("code.block", "代码块", "code", ["code"]),
    ("code.command", "命令", "code", ["code", "paragraph"]),
    ("code.prompt", "提示词", "prompt", ["code", "quote", "paragraph"]),
    ("code.inline", "行内代码", "emphasis", ["paragraph"]),
    ("article.ending", "结尾", "ending", ["paragraph", "conclusion", "quote"]),
    ("article.cta", "行动与互动", "cta", ["paragraph", "unordered_list"]),
    ("article.end-mark", "结束标记", "end-mark", ["divider", "paragraph"]),
    ("author.signature", "作者署名", "signature", ["paragraph"]),
    ("resources.links", "延伸阅读与资源", "resources", ["paragraph", "ordered_list", "unordered_list"]),
    ("metadata.marker", "内部元数据", "metadata", None),
]

VARIANTS = {
    "default": {}, "plain": {"surface": "none", "edge": "none"},
    "left-rule": {"edge": "left"},
    "outline": {"surface": "none", "edge": "outline"},
    "filled": {"surface": "soft"}, "dark": {"surface": "dark"},
    "center": {"align": "center"}, "large": {"scale": "large"},
    "numbered": {"numbered": True}, "watermark": {"numbered": True, "scale": "large"},
    "ticket": {"shape": "ticket", "edge": "dashed"},
    "magazine": {"edge": "top", "scale": "large"},
    "two-column": {"columns": 2}, "three-column": {"columns": 3},
    "dots": {"divider": "dots"}, "short": {"divider": "short"},
    "bold": {"emphasis": "bold"}, "highlight": {"emphasis": "highlight"},
    "underline": {"emphasis": "underline"}, "strike": {"emphasis": "strike"},
    "inline-code": {"emphasis": "code"}, "brand": {"emphasis": "brand"},
    "label": {"emphasis": "label"}, "light": {"surface": "soft"},
}

CATALOG = {
    cid: {
        "component_id": cid, "label": label, "renderer": renderer,
        "source_kinds": kinds, "required": ["source_refs"],
        "optional": ["variant_id", "fields", "fallback", "derived", "marks"],
        "fields": ["label", "number", "kicker"],
        "trigger": label + "的源文语义已存在，或用户明确要求该结构",
        "forbidden": "不得增加源文没有的事实、身份、引文或广告",
        "quality": ["content_fidelity", "resources", "render"],
        "channels": {
            channel: ("native" if channel == "wechat.public_article"
                      else "image" if channel in ("wechat.image_text", "xiaohongshu.note")
                      else "native" if renderer in (
                          "paragraph", "heading", "subheading", "ordered", "unordered",
                          "table", "quote", "image", "code", "divider") else "fallback")
            for channel in CHANNELS
        },
    }
    for cid, label, renderer, kinds in _SPECS
}


@lru_cache(maxsize=1)
def source_variants() -> dict:
    path = DATA / "source-variants.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}


def variant(identity: str) -> dict:
    if identity in VARIANTS:
        return dict(VARIANTS[identity])
    entry = source_variants().get(identity)
    if entry:
        return dict(entry["style"])
    raise ValueError("未知组件变体：" + identity)


def catalog(channel: str | None = None) -> dict:
    if channel and channel not in CHANNELS:
        raise ValueError("未知渠道：" + channel)
    return {
        "schema_version": SCHEMA_VERSION,
        "components": list(CATALOG.values()), "variants": VARIANTS,
        "recipes": RECIPES, "channels": CHANNELS,
        "source_variant_count": len(source_variants()),
    }
