"""Copyable rich text is the exact channel fragment, separate from UI chrome."""
from html import escape


def copy_preview(fragment: str, title: str) -> str:
    return (
        '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>{escape(title)} · 复制预览</title>'
        '<style>body{margin:0;background:#f3f3f3;font-family:system-ui,sans-serif}'
        'main{max-width:677px;margin:20px auto;padding:22px;background:white;box-sizing:border-box}'
        'header{max-width:677px;margin:16px auto;padding:0 22px;box-sizing:border-box}'
        'button{padding:10px 18px;cursor:pointer}small{display:block;margin-top:8px;color:#666}</style>'
        '</head><body><header><button id="copy-button">复制公众号正文</button>'
        '<small id="copy-status">复制后粘贴到公众号编辑器，并核对图片与样式。</small>'
        f'</header><main><article id="copy-content">{fragment}</article></main>'
        '<script>document.getElementById("copy-button").onclick=async function(){'
        'const node=document.getElementById("copy-content");'
        'const status=document.getElementById("copy-status");'
        'try{if(navigator.clipboard&&window.ClipboardItem){'
        'await navigator.clipboard.write([new ClipboardItem({'
        '"text/html":new Blob([node.innerHTML],{type:"text/html"}),'
        '"text/plain":new Blob([node.innerText],{type:"text/plain"})})]);'
        '}else{throw new Error("fallback");}'
        'status.textContent="正文已复制，请粘贴并检查图片和格式。";'
        '}catch(e){const range=document.createRange();range.selectNodeContents(node);'
        'const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);'
        'const ok=document.execCommand("copy");'
        'status.textContent=ok?"正文已复制，请粘贴并检查图片和格式。":"正文已选中，请按 Ctrl+C 或 Command+C 复制。";}'
        '};</script></body></html>\n'
    )
