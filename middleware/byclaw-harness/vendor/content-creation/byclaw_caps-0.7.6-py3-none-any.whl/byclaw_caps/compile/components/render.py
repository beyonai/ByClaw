"""Deterministic semantic composition over the existing compiler's fragments."""
from __future__ import annotations

from html import escape
import re

from .. import CompileError, markdown_to_html, presentation_profile
from ..themes import THEME_PRESETS, style_tag
from .catalog import CATALOG, variant
from .htmltree import parse
from .plans import validate


def _tag(name, body, style=""):
    return f'<{name} style="{escape(style, quote=True)}">{body}</{name}>'


def _clean(fragment):
    """Retain inline semantics; reset inherited block chrome inside a component."""
    tree = parse(fragment)
    for node in tree.find("p", "blockquote", "section"):
        node.attrs["style"] = ("margin:0;line-height:inherit;font-size:inherit;color:inherit;"
                               "background:none;border:0;padding:0;text-indent:0;"
                               "box-sizing:border-box;")
    return tree.html()


def _inner(fragment, kind):
    tree = parse(fragment)
    tags = {"paragraph": ("p",), "conclusion": ("p",), "quote": ("blockquote",),
            "heading": ("h2",), "subheading": ("h3",)}
    matches = tree.find(*tags.get(kind, ()))
    return matches[0].inner() if matches else _clean(fragment)


def _items(fragments):
    result = []
    def visit(node):
        if node.tag == 'li':
            result.append(node.inner())
            return
        for child in node.children:
            if not isinstance(child, str):
                visit(child)
    for fragment in fragments:
        visit(parse(fragment))
    return result


def _shell(body, theme, style, **overrides):
    values = {"margin": "22px 0", "padding": "20px", "border-radius": "8px",
              "font-size": "16px", "line-height": "1.85", "color": theme["text"],
              "box-sizing": "border-box", "max-width": "100%",
              "overflow-wrap": "anywhere"}
    values.update(style)
    values.update(overrides)
    return _tag("section", body, ";".join(f"{k}:{v}" for k, v in values.items()) + ";")


def component(entry, blocks, fragments, *, theme_id, layout="balanced", channel="wechat.public_article", reading_profile="default"):
    """All prose comes from compiled source fragments, never generated fields."""
    cid = entry["component_id"]
    spec = CATALOG[cid]
    role = spec["renderer"]
    style = variant(entry.get("variant_id", "default"))
    _, theme = presentation_profile(layout, theme_id)
    tokens = THEME_PRESETS.get(theme_id, {}).get("components", {})
    fields = entry.get("fields", {})
    status = "native"
    if channel == "toutiao.article" and spec["channels"][channel] == "fallback":
        return "".join(fragments), {"status": "fallback", "reason": "头条使用标准富文本保留全文",
                                   "component_id": cid, "instance_id": entry["instance_id"]}
    from .structures import themed_component
    # Explicit non-default variants retain their existing contract. Reading
    # profiles also retain the dedicated prose renderer's rhythm.
    if channel == "wechat.public_article" and reading_profile == "default" and entry.get("variant_id", "default") == "default":
        adapted = themed_component(role, blocks, fragments, identity=theme_id,
                                   layout=layout, fields=fields)
        if adapted:
            result, provenance = adapted
            return result, {"status": "native", "component_id": cid,
                            "instance_id": entry["instance_id"], "variant_id": "default",
                            "source_refs": entry["source_refs"], **provenance}
    body = "".join(_clean(f) for f in fragments)
    inners = [_inner(f, b["kind"]) for f, b in zip(fragments, blocks)]
    content = "<br>".join(inners)
    radius = tokens.get("radius", "8px")
    outer = {"border-radius": radius}
    if style.get("surface") == "dark":
        outer.update({"background": theme["surface_dark"], "color": theme["on_dark"]})
        # Original inline emphasis must inherit contrast on a dark component.
        for tag in ("strong", "em", "a", "span", "code"):
            content = style_tag(content, {"color": "inherit", "background": "none"},
                                tag=tag, all_matches=True)
    elif style.get("surface") == "soft":
        outer["background"] = theme["surface"]
    if style.get("align"):
        outer["text-align"] = style["align"]
    edge = style.get("edge", "")
    if edge == "left":
        outer["border-left"] = f'4px solid {theme["primary"]}'
    elif edge in ("outline", "dashed"):
        outer["border"] = f'1px {"dashed" if edge == "dashed" else "solid"} {theme["border"]}'
    elif edge == "top":
        outer["border-top"] = f'3px solid {theme["primary"]}'
    label = escape(fields.get("label", ""))
    kicker = escape(fields.get("kicker", ""))
    prefix = _tag("p", kicker or label, f'font-size:12px;letter-spacing:0.1em;color:{theme["primary"]};margin:0 0 10px;') if kicker or label else ""

    def box(value, **css):
        combined = dict(outer)
        combined.update(css)
        return _shell(value, theme, combined)

    if role == "section-card":
        result = box(body, **{"border": f'1px solid {theme["border"]}', "background": theme["surface"]})
    elif role in ("paragraph",):
        result = "".join(fragments)
    elif role in ("hero", "intro", "masthead"):
        design = style.get("shape", tokens.get("hero", "editorial"))
        decoration = f'border-top:3px solid {theme["primary"]};border-bottom:1px solid {theme["border"]};'
        if design == "ticket":
            decoration = f'border:1px dashed {theme["primary"]};'
        if role == "masthead":
            result = box(prefix + content, **{"padding": "12px 16px",
                         "border-top": f'2px solid {theme["primary"]}',
                         "border-bottom": f'1px solid {theme["border"]}', "font-size": "14px"})
        else:
            heading = _tag("section", content, "font-size:24px;line-height:1.55;font-weight:700;" if role == "hero" else "font-size:17px;line-height:1.9;")
            result = box(prefix + heading, **{"padding": "26px 22px",
                         "background": theme["surface"], "border-radius": radius})
            result = style_tag(result, dict(x.split(":", 1) for x in decoration.strip(";").split(";")))
            if role == "hero" and design in ("breaking", "journal"):
                background = theme["primary_dark"] if design == "breaking" else theme["surface_dark"]
                result = style_tag(result, {"background": background, "color": theme["on_dark"],
                                            "border": "0", "border-radius": radius})
                for tag in ("p", "span", "strong", "em", "a"):
                    result = style_tag(result, {"color": "inherit", "background": "none"},
                                       tag=tag, all_matches=True)
            elif role == "hero" and design == "quiet":
                result = style_tag(result, {"background": "none", "border": "0",
                                            "text-align": "center", "padding": "40px 16px",
                                            "margin": "32px 0"})
    elif role in ("heading", "subheading", "kicker", "step-heading"):
        number = escape(fields.get("number", ""))
        number_html = _tag("span", number, f'display:inline-block;padding:2px 10px;margin-right:10px;'
                           f'background:{theme["primary"]};color:#fff;border-radius:3px;font-size:15px;') if number else ""
        tag = "h2" if role == "heading" else "h3"
        if not number and role == "heading" and (
                style.get("numbered") or tokens.get("heading") == "numbered"):
            match = re.match(r"(?:第\s*)?([一二三四五六七八九十\d]+)", parse(content).text())
            if match:
                marker = str({c:i+1 for i,c in enumerate('一二三四五六七八九十')}.get(match[1],match[1]))
                if marker.isdigit():
                    marker = marker.zfill(2)
                number_html = _tag("span", escape(marker),
                    f'display:block;margin:0 0 8px;font-size:36px;line-height:1.2;color:{theme["primary"]};font-weight:800;')
        heading = _tag(tag, number_html + content,
                       f'margin:0;font-size:{"24" if role == "heading" else "19"}px;line-height:1.55;'
                       f'font-weight:750;color:{theme["primary_dark"]};overflow-wrap:anywhere;')
        default_border = f'3px solid {theme["primary"]}'
        result = box(prefix + heading, **{"padding": "12px 0 12px 14px", "margin": "34px 0 18px",
                                         "border-left": default_border, "border-radius": "0"})
        if tokens.get("heading") == "minimal" or edge == "top":
            result = style_tag(result, {"border-left": "0", "padding-left": "0",
                                        "border-bottom": f'1px solid {theme["border"]}'})
    elif role in ("quote", "quote-center", "note", "callout", "summary"):
        label_map = {"content.callout.warning": "注意", "content.callout.pitfall": "边界",
                     "content.callout.info": "信息", "content.callout.tip": "提示",
                     "content.callout.success": "结果"}
        label = label or label_map.get(cid, "")
        prefix = (_tag("p", label, f'margin:0 0 9px;font-size:12px;font-weight:700;color:{theme["primary"]};')
                  if label and not parse(content).text().lstrip().startswith(label) else "")
        settings = {"background": theme["surface"], "border-left": f'3px solid {theme["primary"]}',
                    "padding": "18px 20px"}
        if role == "quote-center" or style.get("align") == "center":
            settings.update({"text-align": "center", "border-left": "0", "font-size": "21px"})
        if role == "note":
            settings.update({"background": "none", "font-size": "15px", "color": theme["muted"]})
        settings.update(outer)
        if role in ("summary", "quote-center"):
            settings["font-weight"] = "700"
        result = box(prefix + content, **settings)
    elif role == "toc":
        items = _items(fragments)
        if items:
            label_nodes = [parse(f).text().strip() for f, b in zip(fragments, blocks)
                           if b["kind"] in {"paragraph", "conclusion"}]
            result = box(_tag("p", escape(label_nodes[0]) if label_nodes else label or "本文看点", "margin:0 0 12px;font-weight:700;") +
                         "".join(_tag("p", value, "margin:8px 0;font-size:14px;") for value in items),
                         **{"border": f'1px solid {theme["border"]}', "background": theme["surface"]})
        else:
            result = box(_tag("p", label or "本文看点", "margin:0 0 12px;font-weight:700;") +
                     "".join(_tag("p", value, f'margin:8px 0;font-size:14px;color:{theme["primary_dark"]};')
                             for value in inners),
                     **{"border": f'1px solid {theme["border"]}', "background": theme["surface"]})
    elif role in ("ordered", "unordered", "pill", "checklist", "steps", "flow", "timeline",
                  "item-card", "tool-card", "roadmap", "comparison", "data-grid", "data-card", "trust-wall", "faq"):
        items = _items(fragments)
        if not items and any(b["kind"] == "table" for b in blocks):
            for fragment in fragments:
                for row in parse(fragment).find("tr"):
                    # Keep header and every cell in their original order.
                    items.append(" · ".join(n.inner() for n in row.find("th", "td")))
        if not items:
            items = inners
        if role in ("ordered", "unordered", "checklist"):
            # Retain nesting, start offsets and authored markers from the parser.
            result = "".join(fragments)
        elif role in ("flow", "comparison", "data-grid", "trust-wall"):
            children = []
            columns = style.get("columns", 2)
            basis = "calc(50% - 10px)" if columns == 2 else "calc(33.333% - 10px)"
            for value in items:
                children.append(_tag("section", value,
                    f'flex:1 1 {basis};min-width:130px;max-width:100%;padding:14px;'
                    f'border:1px solid {theme["border"]};background:{theme["surface"]};'
                    f'border-radius:{radius};box-sizing:border-box;line-height:1.75;overflow-wrap:anywhere;'))
            result = box(_tag("section", "".join(children), "display:flex;flex-wrap:wrap;gap:10px;"),
                         **{"padding": "0", "background": "none", "border": "0"})
        else:
            children = []
            for index, value in enumerate(items):
                numeral = (f'{index + 1:02d}' if role in ("steps", "timeline", "roadmap") else "")
                badge = _tag("span", numeral, f'display:inline-block;margin-right:10px;font-weight:800;color:{theme["primary"]};') if numeral else ""
                children.append(_tag("section", badge + value,
                    f'padding:14px 16px;margin:8px 0;background:{theme["surface"]};'
                    f'border-left:{"2px" if role == "timeline" else "0"} solid {theme["primary"]};'
                    f'border-radius:{radius};line-height:1.8;box-sizing:border-box;'))
            result = box(prefix + "".join(children), **{"padding": "0", "border": "0", "background": "none"})
    elif role == "table":
        result = "".join(fragments)
    elif role in ("image", "image-card", "image-full", "image-pair"):
        result = "".join(fragments)
        if role == "image-card":
            result = box(result, **{"border": f'1px solid {theme["border"]}', "padding": "8px"})
        elif role == "image-pair":
            result = box("".join(_tag("section", f, "flex:1 1 220px;min-width:0;") for f in fragments),
                         **{"display": "flex", "flex-wrap": "wrap", "gap": "12px", "padding": "0"})
        elif role == "image-full":
            result = style_tag(result, {"border-radius": "0", "margin-left": "0", "margin-right": "0"})
    elif role == "placeholder":
        if all(b["kind"] == "image" for b in blocks):
            result = "".join(fragments)
        else:
            status = "pending_material"
            result = box(prefix + content, **{"text-align": "center", "padding": "32px 20px",
                         "background": theme["surface"], "border": f'1px dashed {theme["border"]}'})
    elif role in ("code", "prompt"):
        if any(b["kind"] == "code" for b in blocks):
            result = "".join(fragments)
            if style.get("surface") != "soft":
                result = style_tag(result, {"background": theme["surface_dark"], "color": theme["on_dark"]})
            else:
                result = style_tag(result, {"background": theme["surface"], "color": theme["text"]})
                result = style_tag(result, {"color": theme["text"]}, tag="pre", all_matches=True)
            languages = [b["data"].get("language", "") for b in blocks if b["kind"] == "code"]
            if any(languages):
                result = box(_tag("p", escape(" / ".join(languages)),
                                 "margin:0 0 8px;font:12px monospace;") + result,
                             **{"padding": "0"})
        else:
            result = box(content, **{"font-family": "Consolas,monospace", "background": theme["surface"]})
    elif role == "emphasis":
        emphasis = style.get("emphasis", "code" if cid == "code.inline" else "bold")
        css = {"font-weight": "700"}
        if emphasis in ("highlight", "label"):
            css["background"] = theme["surface_strong"]
        elif emphasis == "underline":
            css["border-bottom"] = f'2px solid {theme["primary"]}'
        elif emphasis == "strike":
            css["text-decoration"] = "line-through"
        elif emphasis == "code":
            css.update({"font-family": "Consolas,monospace", "background": theme["surface"]})
        value = _tag("span", content, ";".join(k + ":" + v for k, v in css.items()))
        result = box(value, **{"padding": "0", "margin": "18px 0"})
    elif role == "dropcap":
        # Keep inline nodes and characters intact; size only the first text leaf.
        tree = parse(content)
        done = False
        def visit(node):
            nonlocal done
            for i, child in enumerate(node.children):
                if done:
                    break
                if isinstance(child, str) and child.strip():
                    from .htmltree import Node
                    first = len(child) - len(child.lstrip())
                    node.children[i:i + 1] = [child[:first], Node("span", {"style":
                        f'font-size:30px;font-weight:700;color:{theme["primary"]};'}, [child[first]]), child[first + 1:]]
                    done = True
                elif not isinstance(child, str):
                    visit(child)
        visit(tree)
        result = box(tree.html(), **{"padding": "0"})
    elif role == "progress":
        match = re.search(r"(?<!\d)(\d+(?:\.\d+)?)\s*%", parse(content).text())
        if match and 0 <= float(match[1]) <= 100:
            bar = _tag("section", "", f'height:7px;width:{float(match[1]):g}%;background:{theme["primary"]};')
            result = box(content + _tag("section", bar,
                         f'margin-top:12px;background:{theme["surface_strong"]};height:7px;'))
        else:
            result, status = "".join(fragments), "fallback"
    elif role in ("divider", "end-mark"):
        if role == "end-mark" and any(b["kind"] == "paragraph" for b in blocks):
            result = box(content, **{"text-align": "center", "color": theme["muted"]})
        elif style.get("divider") == "dots":
            result = box("· · ·", **{"text-align": "center", "padding": "0", "color": theme["muted"]})
        else:
            result = box("", **{"padding": "0", "height": "1px",
                         "width": "35%" if style.get("divider") == "short" else "100%",
                         "background": theme["border"], "margin": "30px auto"})
    elif role in ("ending", "cta", "signature", "resources", "caption", "label"):
        result = box(prefix + body, **{"border-top": f'1px solid {theme["border"]}',
                     "font-size": "13px" if role in ("signature", "caption") else "15px",
                     "color": theme["muted"] if role in ("signature", "caption") else theme["text"]})
    else:
        raise CompileError("UNIMPLEMENTED_COMPONENT", "没有组件实现", component_id=cid)
    # Explicit standard variants override component defaults at the outer shell.
    overrides = {}
    if style.get("surface") == "none":
        overrides.update({"background": "none"})
    elif style.get("surface") == "dark":
        overrides.update({"background": theme["surface_dark"], "color": theme["on_dark"]})
        for tag in ("p", "h2", "h3", "blockquote", "strong", "em", "span", "code", "pre"):
            result = style_tag(result, {"color": "inherit"}, tag=tag, all_matches=True)
    if style.get("align"):
        overrides["text-align"] = style["align"]
    if style.get('scale') == 'large':
        overrides['font-size'] = '22px'
    if edge == "none":
        overrides["border"] = "0"
    if style.get("shape") == "ticket":
        overrides.update({"border": f'1px dashed {theme["primary"]}', "border-radius": "0"})
    if overrides:
        result = style_tag(result, overrides)
    return result, {"status": status, "component_id": cid, "instance_id": entry["instance_id"],
                    "variant_id": entry.get("variant_id", "default"), "source_refs": entry["source_refs"],
                    "mapping_status": "merged", "render_status": "pass", "visual_status": "pending",
                    "structure_role": "shared-" + role,
                    "reason": "使用公共组件或显式变体；不声明上游独立结构已复刻"}


def render(plan, document, markdown, image_map, *, source_path=None, output_path=None,
           image_fit="contain", terms=()):
    validate(plan, document)
    captured = []
    def collect(fragment, kind, data):
        captured.append((fragment, kind))
        return ""
    shell = markdown_to_html(markdown, image_map, layout_profile=plan["layout"],
                             theme_profile=plan["theme"], reading_profile=plan["reading_profile"],
                             image_fit=image_fit, source_path=source_path, output_path=output_path,
                             terms=terms, block_sink=collect)
    if [kind for _, kind in captured] != [b["kind"] for b in document["blocks"]]:
        raise CompileError("COMPONENT_PARSE_MISMATCH", "高亮处理改变了正文块结构")
    fragments = {b["block_id"]: item[0] for b, item in zip(document["blocks"], captured)}
    lookup = {b["block_id"]: b for b in document["blocks"]}
    start, consumed, derived = {}, set(), {}
    for entry in plan["components"]:
        refs = entry["source_refs"]
        if entry.get("derived"):
            derived.setdefault(refs[0], []).append(entry)
        else:
            start[refs[0]] = entry
            consumed.update(refs)
    output, reports = [], []
    def produce(entry):
        from .structures import mark_fragment
        entry_fragments = []
        for ref in entry['source_refs']:
            marks = [m for m in entry.get('marks', []) if m['source_ref'] == ref]
            entry_fragments.append(mark_fragment(fragments[ref], marks, plan['theme'], entry['component_id']) if marks else fragments[ref])
        value, report = component(entry, [lookup[r] for r in entry["source_refs"]],
                                  entry_fragments,
                                  theme_id=plan["theme"], layout=plan["layout"], channel=plan["channel"],
                                  reading_profile=plan["reading_profile"])
        output.append(value)
        report["root_nodes"] = len([n for n in parse(value).children if not isinstance(n, str)])
        reports.append(report)
    for block in document["blocks"]:
        ident = block["block_id"]
        for entry in derived.get(ident, ()):
            produce(entry)
        if ident in start:
            produce(start[ident])
        elif ident not in consumed:
            output.append(fragments[ident])
    html = shell[:shell.index(">") + 1] + "\n" + "\n".join(output) + "\n</section>\n"
    if plan["channel"] == "wechat.public_article" and plan["reading_profile"] == "default":
        from .structures import wrap
        html = wrap("\n".join(output), plan["theme"]) or html
    # Every non-decorative source character must survive in order. No source is
    # retyped by the plan; this catches a renderer dropping a cell, list or image.
    expected = re.sub(r"\s+", "", parse("".join(f for f, _ in captured)).text())
    actual = re.sub(r"\s+", "", parse(html).text())
    position = 0
    for char in expected:
        position = actual.find(char, position)
        if position < 0:
            raise CompileError("COMPONENT_CONTENT_LOSS", "组件渲染丢失或改变了源文文字")
        position += 1
    source_images = [n.attrs.get("src") for f, _ in captured for n in parse(f).find("img")]
    result_images = [n.attrs.get("src") for n in parse(html).find("img")]
    if source_images != result_images:
        raise CompileError("COMPONENT_IMAGE_LOSS", "组件渲染改变了图片数量、顺序或地址")
    from .structures import fingerprint
    from .plans import plan_digest
    return html, {"ok": True, "component_count": len(reports), "blocks": len(document["blocks"]),
                  "content_fidelity": "pass", "images": len(result_images), "components": reports,
                  "render_binding": fingerprint(plan["theme"]), "plan_sha256": plan_digest(plan),
                  "plan_review": plan.get("review", {"status": "legacy_unreviewed"}),
                  "visual_status": "pending",
                  "editor_paste": "pending"}
