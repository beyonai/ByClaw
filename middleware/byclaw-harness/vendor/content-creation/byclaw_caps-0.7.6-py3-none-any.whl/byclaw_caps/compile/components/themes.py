"""Task-local custom themes; installing a preset remains a build-time concern."""
from copy import deepcopy
import json
from pathlib import Path
import re
import tempfile

from .. import CompileError, THEME_PROFILES
from ..themes import THEME_PRESETS, load_presets


def register(path):
    path = Path(path)
    with tempfile.TemporaryDirectory(prefix="byclaw-theme-") as temporary:
        candidate = Path(temporary)/"theme.json"
        candidate.write_bytes(path.read_bytes())
        try:
            presets = load_presets(Path(temporary))
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            raise CompileError("INVALID_CUSTOM_THEME", str(error)) from error
    for identity,payload in presets.items():
        if identity in THEME_PRESETS and THEME_PRESETS[identity] != payload:
            raise CompileError("THEME_ID_CONFLICT", "自定义主题不能覆盖已注册主题", theme=identity)
        THEME_PRESETS[identity] = payload
        THEME_PROFILES[identity] = {"label":payload["label"], **payload["palette"]}
    return next(iter(presets))


def create(spec_path, output):
    spec = json.loads(Path(spec_path).read_text(encoding="utf-8-sig"))
    if not isinstance(spec,dict) or set(spec)-{"id","label","description","base","palette","components"}:
        raise CompileError("INVALID_CUSTOM_THEME","主题偏好只接受 id、label、description、base、palette、components")
    identity = spec.get("id","")
    if (not isinstance(identity, str)
            or not re.fullmatch(r"custom-[a-z0-9][a-z0-9-]{0,45}", identity)
            or not isinstance(spec.get("label"), str) or not spec["label"].strip()):
        raise CompileError("INVALID_CUSTOM_THEME","自定义主题 ID 使用 custom- 前缀，且必须有名称")
    if "description" in spec and not isinstance(spec["description"], str):
        raise CompileError("INVALID_CUSTOM_THEME", "主题说明须为文字")
    base = spec.get("base","gzh-red-white")
    if not isinstance(base, str) or base not in THEME_PRESETS:
        raise CompileError("UNKNOWN_THEME", "基础主题不存在", theme=base)
    theme = deepcopy(THEME_PRESETS[base])
    overrides = spec.get("palette",{})
    if not isinstance(overrides,dict) or set(overrides)-set(theme["palette"]):
        raise CompileError("INVALID_CUSTOM_THEME","色板包含未知语义色")
    if any(not isinstance(v,str) or not re.fullmatch(r"#[0-9a-fA-F]{6}",v) for v in overrides.values()):
        raise CompileError("INVALID_CUSTOM_THEME","自定义颜色使用六位十六进制")
    old = dict(theme["palette"])
    theme["palette"].update(overrides)
    # Update corresponding CSS values, retaining the baseline typography.
    for role,properties in theme.get("styles",{}).items():
        for key,value in list(properties.items()):
            for semantic,new in overrides.items():
                value = value.replace(old[semantic],new)
            properties[key] = value
    components = spec.get("components",{})
    if (not isinstance(components,dict) or set(components)-{"radius","hero","heading"}
            or any(not isinstance(v,str) for v in components.values())):
        raise CompileError("INVALID_CUSTOM_THEME","未知组件主题设置")
    if "radius" in components and not re.fullmatch(r"(?:0|[1-9]|1[0-6])px",components["radius"]):
        raise CompileError("INVALID_CUSTOM_THEME","圆角范围 0px–16px")
    if components.get("hero","editorial") not in {"editorial","breaking","journal","quiet","ticket"}:
        raise CompileError("INVALID_CUSTOM_THEME","未知开篇骨架")
    if components.get("heading","minimal") not in {"minimal","label","numbered"}:
        raise CompileError("INVALID_CUSTOM_THEME","未知章节骨架")
    theme.setdefault("components",{}).update(components)
    theme.update(id=identity,label=spec["label"],description=spec.get("description","任务自定义主题"))
    theme["source"] = {"project":"user-theme","base":base,"kind":"task-local"}
    output = Path(output)
    output.mkdir(parents=True,exist_ok=True)
    path = output/(identity+".json")
    path.write_text(json.dumps(theme,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    register(path)
    from .gallery import build
    preview = build(output/"preview",theme=identity)
    return {"ok":True,"theme":identity,"theme_file":str(path),"preview":preview,
            "installed":False,"use_with":"--theme-file "+str(path)}
