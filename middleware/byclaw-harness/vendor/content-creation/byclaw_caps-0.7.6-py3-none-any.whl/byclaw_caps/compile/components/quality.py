"""Checks shared by HTML and image-card channel outputs."""
from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import unquote, urlsplit

from .. import CompileError


def resources(document, source, image_map=None):
    source = Path(source).resolve()
    refs = []
    for block in document["blocks"]:
        if block["kind"] == "image":
            refs.append(block["data"]["src"])
        elif block["kind"] in ("paragraph", "quote"):
            tick = chr(96)
            raw = re.sub(tick + "[^" + tick + "]*" + tick, "", block["data"].get("text", ""))
            refs.extend(re.findall(r"!\[[^]]*\]\(([^)]+)\)", raw))
    findings = []
    for ref in dict.fromkeys(refs):
        parsed = urlsplit(ref)
        if parsed.scheme in ("http", "https"):
            findings.append({"reference": ref, "status": "remote_unverified"})
            continue
        if parsed.scheme and parsed.scheme != "file" and not re.match(r"^[A-Za-z]:[/\\]", ref):
            raise CompileError("UNSUPPORTED_IMAGE_SCHEME", "不支持的图片协议", reference=ref)
        raw_path = unquote(parsed.path if parsed.scheme == "file" else ref.split("?")[0])
        if re.match(r'^/[A-Za-z]:/', raw_path):
            raw_path = raw_path[1:]
        path = Path(raw_path)
        if not path.is_absolute():
            path = source.parent / path
        if not path.is_file() or path.stat().st_size == 0:
            raise CompileError("COMPONENT_ASSET_MISSING", "原文图片不存在或为空", reference=ref, path=str(path))
        findings.append({"reference": ref, "path": str(path.resolve()), "status": "local_present"})
    return findings


def final_components(report, *, allow_placeholders=False):
    pending = [r for r in report["components"] if r["status"] == "pending_material"]
    if pending and not allow_placeholders:
        raise CompileError("COMPONENT_MATERIAL_PENDING", "待补素材组件不能作为最终成品",
                           instances=[r["instance_id"] for r in pending])
    report["materials"] = "pending" if pending else "pass"
    return report
