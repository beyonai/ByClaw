"""Small generated-HTML tree. No source HTML is evaluated."""
from __future__ import annotations

from dataclasses import dataclass, field
from html import escape
from html.parser import HTMLParser

VOID = {"img", "br", "hr", "meta", "link", "input", "source", "wbr"}


@dataclass
class Node:
    tag: str = ""
    attrs: dict = field(default_factory=dict)
    children: list = field(default_factory=list)

    def inner(self):
        return "".join(c.html() if isinstance(c, Node) else escape(c, quote=False)
                       for c in self.children)

    def html(self):
        attrs = "".join(f' {k}="{escape(v or "", quote=True)}"' for k, v in self.attrs.items())
        if not self.tag:
            return self.inner()
        return f"<{self.tag}{attrs}>" + ("" if self.tag in VOID else self.inner() + f"</{self.tag}>")

    def text(self):
        return "".join(c.text() if isinstance(c, Node) else c for c in self.children)

    def plain_text(self):
        """Readable text export: preserve list lines, table cells and link URLs."""
        value = "".join(c.plain_text() if isinstance(c, Node) else c for c in self.children)
        if self.tag == "br":
            return "\n"
        if self.tag == "img":
            return "[图片：" + self.attrs.get("alt", "") + "]"
        if self.tag == "a" and self.attrs.get("href") and self.attrs["href"] != value:
            value += " (" + self.attrs["href"] + ")"
        if self.tag in {"td", "th"}:
            return value + "\t"
        if self.tag in {"p", "li", "h1", "h2", "h3", "blockquote", "tr", "pre"}:
            return value + "\n"
        return value

    def find(self, *tags):
        result = []
        if self.tag in tags:
            result.append(self)
        for child in self.children:
            if isinstance(child, Node):
                result.extend(child.find(*tags))
        return result


class Tree(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=True)
        self.root = Node()
        self.stack = [self.root]
        self.feed(source)

    def handle_starttag(self, tag, attrs):
        node = Node(tag, dict(attrs))
        self.stack[-1].children.append(node)
        if tag not in VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                return

    def handle_data(self, data):
        self.stack[-1].children.append(data)


def parse(source):
    return Tree(source).root
