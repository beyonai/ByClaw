"""Trusted, packaged theme structures over the existing compiler's fragments.

Only data shipped in the wheel is a template. User content enters as parsed
compiler nodes or escaped text; component plans cannot provide HTML or CSS.
"""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re

from ..themes import THEME_PRESETS, merge_style
from .htmltree import Node, parse

DATA = Path(__file__).with_name("data") / "theme-structures.json"


@lru_cache(maxsize=1)
def library():
    return json.loads(DATA.read_text(encoding="utf-8"))


def base_theme(identity):
    preset = THEME_PRESETS.get(identity, {})
    return preset.get("structure_theme", identity)


def fingerprint(identity):
    """Bind reviews to actual runtime code/resources, including custom palettes."""
    paths = [DATA, *sorted(Path(__file__).parent.glob("*.py")),
             *sorted(Path(__file__).parents[1].glob("*.py"))]
    digest = hashlib.sha256()
    for path in paths:
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    digest.update(json.dumps(THEME_PRESETS.get(identity, {}), sort_keys=True).encode())
    return {"template_version": library()["template_version"],
            "upstream_commit": library()["upstream_commit"],
            "renderer_sha256": digest.hexdigest(), "structure_theme": base_theme(identity)}


def css(node, **values):
    node.attrs["style"] = merge_style(node.attrs.get("style", ""), values)
    return node


def elements(node):
    return [c for c in node.children if isinstance(c, Node)]


def slot(tree, values):
    """Replace text slots with nodes, never interpreting authored text as HTML."""
    for node in [tree, *walk(tree)]:
        children = []
        for child in node.children:
            if isinstance(child, str):
                for part in re.split(r"(@@\w+@@)", child):
                    if part.startswith("@@") and part.endswith("@@"):
                        value = values.get(part[2:-2], "")
                        children.extend(deepcopy(value) if isinstance(value, list) else [str(value)])
                    elif part:
                        children.append(part)
            else:
                children.append(child)
        node.children = children
    return tree


def walk(node):
    for c in elements(node):
        yield c
        yield from walk(c)


def template(identity, role):
    source = library()["themes"].get(base_theme(identity), {}).get(role)
    if not source:
        return None
    tree = parse(source["html"])
    if identity != base_theme(identity):
        base_components = THEME_PRESETS[base_theme(identity)].get("components", {})
        components = THEME_PRESETS[identity].get("components", {})
        if ((role == "hero" and components.get("hero") != base_components.get("hero")) or
                (role == "heading" and components.get("heading") != base_components.get("heading"))):
            return None  # Explicit custom skeleton keeps the legacy contract.
        original = THEME_PRESETS[base_theme(identity)]["palette"]
        new = THEME_PRESETS[identity]["palette"]
        replacements = {v.lower(): new[k] for k, v in original.items() if new[k] != v}
        for node in walk(tree):
            node.attrs["style"] = re.sub(r"#[0-9a-fA-F]{6}\b", lambda m: replacements.get(m[0].lower(), m[0]), node.attrs.get("style", ""))
            if components.get("radius") != base_components.get("radius") and "border-radius" in node.attrs["style"]:
                css(node, **{"border-radius": components["radius"]})
    return tree


def finish(tree, layout="balanced"):
    """Portable attributes and responsive safety; retain the theme's hierarchy."""
    scale, line = {"compact": (.8, .93), "comfortable": (1.2, 1.055),
                   "column": (1.1, 1.027)}.get(layout, (1, 1))
    for node in walk(tree):
        node.attrs = {k: v for k, v in node.attrs.items() if k in {"style", "src", "alt", "href"}}
        style = node.attrs.get("style", "")
        style = re.sub(r"background:linear-gradient\([^;]+\)", "background:#FCA5A5", style)
        if scale != 1:
            style = re.sub(r"(margin(?:-top|-bottom)?\s*:\s*)([^;]+)",
                           lambda m: m[1] + re.sub(r"(\d+(?:\.\d+)?)px", lambda v: f"{float(v[1])*scale:.3g}px", m[2]), style)
            style = re.sub(r"(line-height\s*:\s*)(\d+(?:\.\d+)?)(?=\s*;|$)", lambda m: m[1] + f"{float(m[2])*line:.3g}", style)
        node.attrs["style"] = style
        if node.tag in {"section", "p", "h2", "h3", "table", "pre", "figure"}:
            css(node, **{"box-sizing": "border-box", "min-width": "0", "overflow-wrap": "anywhere"})
    return tree.html()


def prose(fragment, kind):
    tree = parse(fragment)
    tags = {"heading": "h2", "subheading": "h3", "quote": "blockquote"}
    found = tree.find(tags.get(kind, "p"))
    if not found:
        return tree.children
    node = found[0]
    if kind == "quote":
        ps = node.find("p")
        if ps:
            nodes = []
            for i, p in enumerate(ps):
                if i:
                    nodes.append(Node("br"))
                nodes.extend(p.children)
            return nodes
    return node.children


def inline_styles(nodes, identity):
    """Style existing authored marks; never select or introduce new emphasis."""
    root = Node(children=nodes)
    tags = [template(identity, r) for r in ('inline-tag','inline-hero-tag')]
    tag_styles = {elements(t)[0].attrs.get('style', '') for t in tags if t}
    for node in walk(root):
        style = node.attrs.get('style', '')
        if style in tag_styles:
            continue
        if (node.tag == 'strong' and not style and any(
                item and 'color:#DC2626' in item["html"] and item["html"].startswith('<strong')
                for item in [library()['themes'][base_theme(identity)].get('inline-bold', {})])):
            continue
        role = ('inline-bold' if node.tag == 'strong' else
                'inline-code' if node.tag == 'code' else
                'inline-underline' if node.tag == 'span' and style.startswith('border-bottom:1px dashed ') else
                'inline-highlight' if node.tag == 'span' and style.startswith('background:') else None)
        if role:
            asset = template(identity, role)
            if asset:
                source = elements(asset)[0].attrs.get('style', '')
                css(node, **dict(item.split(':', 1) for item in source.split(';') if ':' in item))
    return nodes


def mark_fragment(fragment, marks, identity, context=None):
    """Source-checked selections decorate existing text, without rewriting it."""
    from .. import CompileError
    tree = parse(fragment)
    text, intervals = tree.text(), []
    palette = THEME_PRESETS.get(identity, {}).get('palette', {})
    for mark in marks:
        pos = -1
        for _ in range(mark['occurrence']+1):
            pos = text.find(mark['text'], pos+1)
            if pos < 0:
                raise CompileError('COMPONENT_MARK_MISSING', '所选强调短语不在可见正文中')
        end = pos + len(mark['text'])
        if any(pos < b and end > a for a, b, _ in intervals):
            raise CompileError('COMPONENT_MARK_OVERLAP', '同一短语范围不能叠加多个强调')
        source = (template(identity, 'inline-hero-tag') if context == 'article.hero' and mark['kind'] == 'tag' else None)
        source = source or template(identity, 'inline-'+mark['kind'])
        style = elements(source)[0].attrs.get('style','') if source else (
            f"background:{palette.get('surface_strong','#EEEEEE')};color:{palette.get('text','#222222')};")
        intervals.append((pos,end,style))
    offset = 0
    def visit(node):
        nonlocal offset
        children = []
        for child in node.children:
            if isinstance(child, Node):
                visit(child)
                children.append(child)
                continue
            start, stop = offset, offset+len(child)
            cursor = 0
            for a,b,style in sorted(intervals):
                left, right = max(start,a)-start, min(stop,b)-start
                if left < right:
                    children.extend([child[cursor:left], Node('span', {'style':style}, [child[left:right]])])
                    cursor = right
            children.append(child[cursor:])
            offset = stop
        node.children = children
    visit(tree)
    return tree.html()


def slice_nodes(nodes, start, end=None):
    """Slice text offsets while preserving authored inline emphasis/links."""
    end = sum(len(n.text()) if isinstance(n, Node) else len(n) for n in nodes) if end is None else end
    result, offset = [], 0
    for node in nodes:
        size = len(node.text()) if isinstance(node, Node) else len(node)
        a, b = max(0, start-offset), min(size, end-offset)
        if a < b:
            if isinstance(node, str):
                result.append(node[a:b])
            else:
                copy = deepcopy(node)
                copy.children = slice_nodes(node.children, a, b)
                result.append(copy)
        offset += size
    return result


def split_heading(nodes):
    tree = Node(children=deepcopy(nodes))
    text = tree.text()
    match = re.match(r"^(\d{1,3}|∞)\s+", text)
    if not match:
        return {"number": "", "kicker": "", "title": nodes}
    begin = match.end()
    ems = tree.find("em")
    if ems and text[begin:].startswith(ems[0].text()):
        kicker_end = begin + len(ems[0].text())
        title_begin = kicker_end + len(text[kicker_end:]) - len(text[kicker_end:].lstrip())
        return {"number": match[1], "kicker": slice_nodes(nodes, begin, kicker_end),
                "title": slice_nodes(nodes, title_begin)}
    return {"number": match[1], "kicker": "", "title": slice_nodes(nodes, begin)}


def _toc(tree, blocks, fragments):
    candidates = []
    label = "本文看点"
    for block, fragment in zip(blocks, fragments):
        if block["kind"] in {"ordered_list", "unordered_list"}:
            candidates.extend(n.children for n in parse(fragment).find("li"))
        elif block["kind"] in {"heading", "subheading"}:
            candidates.append(prose(fragment, block["kind"]))
        else:
            label = parse(fragment).text().strip()
    cards = [n for n in walk(tree) if len(elements(n)) >= 2 and
             all(c.tag == "p" for c in elements(n)) and
             re.fullmatch(r"(?:PART\s+)?\d+", elements(n)[0].text().strip())]
    # Blue editorial uses a vertical row, not three columns.
    if not cards:
        rows = tree.find("p")
        prototype = deepcopy(rows[0])
        root = next(n for n in walk(tree) if rows[0] in n.children)
        root.children = [Node("p", {"style": "font-size:11px;margin:0 0 12px;"}, [label])]
        for values in candidates:
            row = deepcopy(prototype)
            spans = elements(row)
            fields = split_heading(values)
            spans[0].children = [fields["number"]]
            spans[-1].children = fields["title"]
            root.children.append(row)
        return tree
    prototype = deepcopy(cards[0])
    parent = next(n for n in walk(tree) if cards[0] in n.children)
    parent.children = []
    # Never retain an upstream fake subtitle, conclusion or count.
    labels = [p for p in tree.find("p") if p not in parent.find("p")]
    if labels:
        labels[0].children = [label]
        for p in labels[1:]:
            p.children = []
    for index, values in enumerate(candidates):
        card = deepcopy(prototype)
        ps = card.find("p")
        fields = split_heading(values)
        ps[0].children = [fields["number"]]
        ps[1].children = fields["title"]
        card.children = [c for c in card.children if c not in ps[2:]]
        if index == len(candidates)-1:
            css(card, **{"margin-right": "0", "border-right": "0"})
        css(card, **{"min-width": "0"})
        parent.children.append(card)
    return tree


def themed_component(role, blocks, fragments, *, identity, layout="balanced", fields=None):
    key = {"intro": "hero", "quote-center": "quote-center", "note": "note"}.get(role, role)
    tree = template(identity, key)
    if tree is None:
        return None
    source = library()["themes"][base_theme(identity)][key]
    content = []
    for i, (block, fragment) in enumerate(zip(blocks, fragments)):
        if i:
            content.append(Node("br"))
        content.extend(prose(fragment, block["kind"]))
    inline_styles(content, identity)
    if role in {"paragraph", "subheading", "hero", "intro", "quote", "note", "quote-center"}:
        if any(b["kind"] == "image" for b in blocks):
            return None
        slot(tree, {"content": content})
        # Browsers give <p> a top margin absent in the source's editor reset.
        for p in tree.find("p"):
            if not re.search(r"(?:^|;)\s*margin(?:-top)?\s*:", p.attrs.get("style", "")):
                css(p, **{"margin-top": "0"})
    elif role == "heading":
        values = split_heading(content)
        for node in walk(tree):
            if node.text() == "@@number@@":
                css(node, **{"flex-shrink": "0", "white-space": "nowrap"})
        if isinstance(values['kicker'], list):
            for node in values['kicker']:
                if isinstance(node, Node):
                    css(node, **{"font-style": "normal", "font-weight": "inherit", "color": "inherit", "background": "none"})
        for k in ("number", "kicker"):
            if (fields or {}).get(k) and not values[k]:
                values[k] = fields[k]
        slot(tree, values)
        if base_theme(identity) == "gzh-moyu-ticket":
            row = next(n for n in walk(tree) if "display:flex" in n.attrs.get("style", ""))
            css(row, **{"flex-wrap": "wrap", "column-gap": "12px", "row-gap": "8px"})
            parts = elements(row)
            css(parts[0], **{"flex-shrink": "0", "white-space": "nowrap"})
            if len(parts) > 2:
                css(parts[1], **{"flex": "1 1 180px"})
                css(parts[2], **{"flex": "1 1 100%"})
        # Empty number/kicker shells must not leave an empty coloured badge.
        # Only remove text slot branches, keeping intentional divider shapes.
        for node in walk(tree):
            node.children = [c for c in node.children if not (isinstance(c, Node) and
                             c.tag in {"p", "span"} and not c.text().strip() and not c.find("br"))]
    elif role == "toc":
        tree = _toc(tree, blocks, fragments)
    elif role == "image":
        original = parse("".join(fragments))
        images = original.find("img")
        targets = tree.find("img")
        if len(images) == 1 and not targets and base_theme(identity) == "gzh-moyu-green":
            elements(tree)[0].children = [deepcopy(images[0])]
            targets = tree.find("img")
        if len(images) != 1 or len(targets) != 1:
            return None
        targets[0].attrs.update({k: v for k, v in images[0].attrs.items() if k in {"src", "alt"}})
        # Honour the compiler's contain/fill policy and original caption exactly.
        css(targets[0], **dict(x.split(":", 1) for x in images[0].attrs.get("style", "").split(";") if ":" in x))
        for n in walk(tree):
            n.children = [c for c in n.children if not (isinstance(c, Node) and c.tag == "figcaption")]
        tree.children.extend(deepcopy(original.find("p")))
    elif role == "table":
        original = parse("".join(fragments)).find("table")[0]
        target = tree.find("table")[0]
        examples = target.find("tr")
        rows = []
        for ri, row in enumerate(original.find("tr")):
            example = examples[0 if ri == 0 else 1 + (ri-1) % max(1, len(examples)-1)]
            cells = example.find("th", "td")
            new = Node("tr", deepcopy(example.attrs))
            for ci, cell in enumerate(row.find("th", "td")):
                sample = cells[min(ci, len(cells)-1)]
                value = Node(cell.tag, deepcopy(sample.attrs), deepcopy(cell.children))
                if ri == 0:
                    for inline in walk(value):
                        if inline.tag in {"strong", "em", "a", "code", "span"}:
                            css(inline, color="inherit", background="none", border="0")
                elif ci == 0:
                    css(value, **{"font-weight": "700"})
                new.children.append(value)
            rows.append(new)
        target.children = [Node("thead", children=[rows[0]]), Node("tbody", children=rows[1:])]
        css(target, **{"table-layout": "fixed"})
    elif role == "ordered":
        original = parse("".join(fragments))
        lists = original.find("ol")
        if len(lists) != 1 or original.find("ul"):
            return None  # Preserve authored nested list semantics.
        rows = elements(next(n for n in walk(tree) if len(elements(n)) >= 2 and
                             all(c.tag in {"section", "p"} for c in elements(n))))
        if not rows:
            return None
        row = deepcopy(rows[0])
        parent = next(n for n in walk(tree) if rows[0] in n.children)
        parent.children = []
        start = int(lists[0].attrs.get("start", "1"))
        for index, li in enumerate(original.find("li"), start):
            copy = deepcopy(row)
            targets = elements(copy)
            targets[0].children = [str(index)]
            targets[-1].children = deepcopy(li.children)
            parent.children.append(copy)
    elif role == "code":
        block = blocks[0]
        lines = block["data"]["lines"]
        language = block["data"].get("language", "")
        ps = tree.find("p")
        row_style = ps[-1].attrs.get("style", "")
        # Keep a true <pre> so spaces and blank lines survive rich-text copying.
        body = Node("pre", {"style": row_style}, ["\n".join(lines)])
        css(body, **{"margin": "0", "white-space": "pre-wrap", "overflow-x": "auto",
                     "word-break": "break-all", "font-family": "Consolas,Monaco,monospace"})
        root = elements(tree)[0]
        parts = elements(root)
        if parts and parts[0].tag == "section" and len(parts[0].find("span")) >= 4:
            bar = parts[0]
            spans = elements(bar)
            for dot in spans[:3]:
                dot.children = []
            spans[-1].children = [language]
            root.children = [bar, Node("section", {"style": "padding:11px 14px;"}, [body])]
        else:
            root.children = [body]  # Mono blue's own rectangular code panel.
    else:
        return None
    short = base_theme(identity).removeprefix("gzh-")
    inset_roles = {"red-white": {"paragraph", "subheading", "quote", "note", "code", "ordered", "table", "image"},
                   "graphite-minimal": {"paragraph", "subheading", "code", "ordered"},
                   "moyu-green": {"paragraph", "subheading", "quote", "note", "code", "ordered", "table", "image"},
                   "zen-whitespace": {"code"}, "moyu-ticket": {"code"}}
    if role in inset_roles.get(short, set()):
        inset = {"red-white": 10, "graphite-minimal": 10, "moyu-green": 20,
                 "zen-whitespace": 16, "moyu-ticket": 20}[short]
        tree = Node(children=[Node("section", {"style": f"padding:0 {inset}px;"}, tree.children)])
    output = finish(tree, layout)
    if re.search(r"@@\w+@@|\{\{[^}]+\}\}", output):
        from .. import CompileError
        raise CompileError("UNBOUND_THEME_SLOT", "主题结构存在未绑定的示例字段", role=role)
    return output, {"structure_role": key, "source_file": source["source_file"],
                    "source_index": source.get("source_index"), "source_block": source.get("source_block"),
                    "source_sha256": source.get("source_sha256", ""), "mapping_status": "adapted",
                    "render_status": "pass", "visual_status": "pending"}


def wrap(body, identity):
    tree = template(identity, "container")
    return finish(slot(tree, {"content": parse(body).children})) if tree else None
