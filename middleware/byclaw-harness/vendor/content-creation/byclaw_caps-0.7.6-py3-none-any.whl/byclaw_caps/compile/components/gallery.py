"""Executable component examples, including every source observation."""
from __future__ import annotations

from html import escape
import json
from pathlib import Path

from .. import markdown_to_html, preview_document, validate_channel_html
from .catalog import CATALOG, source_variants
from .render import component
from .semantic import scan

SAMPLES = {
    "paragraph": "示例作者认为，先核实来源，再讨论结论。当前完成率为 62.5%。",
    "conclusion": "**结论需要对应可核实的事实。**",
    "quote": "> 示例访谈对象：事实和个人判断需要分别标注。",
    "heading": "## 第一节：来源与判断",
    "subheading": "### 使用前的边界",
    "ordered_list": "1. 查阅原始资料。\n2. 核对数字与条件。\n3. 保存来源记录。",
    "unordered_list": "- 原始材料。\n- 过程记录。\n- 最终交付。",
    "table": "| 项目 | 本月 | 上月 |\n|---|---|---|\n| 阅读 | 1250 | 1000 |\n| 完成率 | 62.5% | 50% |",
    "image": "![示例图：来源与结论的关系](sample.png)",
    "code": "\n".join([chr(96)*3+"python", "if count < 10:", "    print('保留缩进与 < > &')", chr(96)*3]),
    "divider": "---",
}


def sample_fragment(cid, *, theme):
    spec = CATALOG[cid]
    kind = spec["source_kinds"][0]
    markdown = SAMPLES[kind]
    captured = []
    markdown_to_html(markdown, {}, theme_profile=theme,
                     block_sink=lambda fragment, k, d: captured.append(fragment) or fragment)
    block = scan(markdown)["blocks"][0]
    return block, captured[0]


def build(output, *, theme="gzh-red-white", all_sources=False):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    # A deterministic local PNG, so gallery media never depend on a remote host.
    import struct, zlib
    def chunk(tag, payload):
        return struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag+payload)&0xffffffff)
    width,height = 640,240
    pixels = b"".join(b"\x00"+bytes((235,241,238))*width for _ in range(height))
    (output/"sample.png").write_bytes(b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",struct.pack(">IIBBBBB",width,height,8,2,0,0,0))+chunk(b"IDAT",zlib.compress(pixels))+chunk(b"IEND",b""))
    entries = [{"component_id": cid, "variant_id": "default", "title": spec["label"]}
               for cid,spec in CATALOG.items() if spec["source_kinds"] is not None]
    source_file = theme.removeprefix("gzh-")
    for vid, source in source_variants().items():
        if not all_sources and source["scope"] not in ("common", "custom_preview") and not (
                source["scope"] == "active_theme" and source_file in source["source_file"]):
            continue
        if CATALOG[source["component_id"]]["source_kinds"] is None:
            continue
        entries.append({"component_id": source["component_id"], "variant_id": vid,
                        "title": source["title"], "source_id": source["source_id"]})
    reports, pages = [], []
    for offset in range(0,len(entries),32):
        parts = []
        for entry in entries[offset:offset+32]:
            block, fragment = sample_fragment(entry["component_id"], theme=theme)
            instance = {**entry, "instance_id":entry["variant_id"]+"-"+entry["component_id"],
                        "source_refs":[block["block_id"]]}
            rendered, report = component(instance,[block],[fragment],theme_id=theme)
            gate = validate_channel_html(rendered)
            if not gate["ok"]:
                raise ValueError(f'Invalid gallery component: {entry}: {gate}')
            parts.append('<section style="margin:40px 0;border-top:1px solid #ddd;">'
                         f'<p style="font:12px sans-serif;color:#777;">{escape(entry["component_id"])} · '
                         f'{escape(entry["title"])}</p>{rendered}</section>')
            reports.append({**entry,"rendered":True,"html_valid":True,"visual_review":"pending"})
        name = f"gallery-{offset//32+1:02d}.html"
        (output/name).write_text(preview_document("组件画廊 · "+theme, "\n".join(parts),
                                layout_profile="balanced",theme_profile=theme),encoding="utf-8")
        pages.append(name)
    index = '<h1>组件画廊</h1>'+ "".join(f'<p><a href="{p}">{p}</a></p>' for p in pages)
    (output/"index.html").write_text('<!doctype html><html lang="zh"><meta charset="utf-8">'+index+"</html>",encoding="utf-8")
    (output/"coverage.json").write_text(json.dumps({"theme":theme,"entries":reports,"pages":pages,
                                        "rendered":len(reports),"visual_review":"pending"},
                                        ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return {"ok":True,"output":str(output),"pages":pages,"rendered":len(reports),"visual_review":"pending"}
