#!/usr/bin/env python3
"""排版候选清单：模型只能从这里选，不能自己提供文字。

## 为什么要有这一层

排版的安全底座是「模型选 ID，编译器取字」——模型**永远不提供要渲染的文字**，
连一个字都不提供。上一版方案让模型给 `badge` 与 `strip_prefix`（新增 + 删除），
按它列的全部校验条件可以构造出：

    原标题        不能自动审批
    strip_prefix  不能            → 逐字匹配开头 ✓
    badge         1               → ≤2 字符 ✓
    渲染结果      ① 自动审批                  ← 语义完全反转

五个错误码一个都拦不住。有了候选清单，这类事在**结构上**不可能发生。

## 范围：首版只收普通段落里的完整判断

排除代码块、表格、引用块、标题、列表项、图片，以及**含行内格式的句子**
（加粗 / 链接 / 行内代码 / 已有的 `==高亮==`）。

排除行内格式不是图省事：那些句子的**可见文字连续而源码不连续**，
定位要另走一套；而且作者已经加粗的句子再叠一层底色，是两种强调挤在一处。
**先把有限范围做可靠，再谈扩大。**

## 关联结构不许切断

**「完整」优先于「短」。** 线上评审指出过一个真实的坏例：

    本体的价值不在能不能推理     ← 只高亮这半句
    而在于搬进了多少判断          读者只看到被否定的方向

文字一个字没改，但**真正的判断没有被突出**——这比不高亮更糟，它把重点标反了。

所以后件连接词开头的句子**并回前一句**；并完之后超长就**整条不出候选**，
而不是切一半出来。模型看到的清单里根本不该出现半句。
"""

from __future__ import annotations

import hashlib
import json
import re

from .reading import strip_editorial_comments

#: 句子边界。只认句末标点，**不认逗号顿号**——
#: 「不在……，而在……」本来就是一句话，按逗号切正好切断它。
_SENTENCE_END = re.compile(r"(?<=[。！？!?])(?=[^」』）\"'）]|$)")

#: 后件连接词：以它开头的句子是上一句的另一半，必须并回去。
#: 覆盖评审点名的四类关联结构：不是…而是 / 只有…才 / 虽然…但是 / 与其…不如。
_CONSEQUENT = (
    "而是", "而在于", "而不是", "而", "但是", "但", "却", "才", "则",
    "不如", "反而", "因此", "所以", "于是",
)

#: 含这些就说明句子里有行内格式，首版不收。
#: `=` 也在内：应用高亮时要把句子包成 `==句子==`，
#: 句中出现等号会把 `HIGHLIGHT` 的匹配从中间截断，渲染出半截底色。
_INLINE_FORMAT = re.compile(r"\*\*|`|\[[^\]]*\]\(|=|~~|<[a-zA-Z/]")

#: 候选句的长度上限。**超了不出候选，不切半句。**
#: 「优先短句、长句宁可不选」——高亮是底色，长句会连成一片，打断连续阅读。
MAX_CANDIDATE_CHARS = 40

#: 太短的也不收：三五个字的高亮标不出一个判断。
MIN_CANDIDATE_CHARS = 8


def _visible_length(text: str) -> int:
    return len(re.sub(r"\s+", "", text))


#: 前件标志：出现它就说明这句话还没说完，后面那句可能是它的后件。
_ANTECEDENT = re.compile(r"只有|除非|如果|一旦|虽然|尽管|不是|不在|与其|既然")

#: 后件标志（句中任意位置）。与 `_ANTECEDENT` 成对出现才并句——
#: 单看「才」「就」会把大量普通句子误并成超长句，而超长的**整条不出候选**，
#: 反而把好句子也一起丢掉。
_CONSEQUENT_INLINE = re.compile(r"才|就|也|则|却|反而|而是|但|不如")


def split_spans(paragraph: str) -> list[tuple[int, int]]:
    """分句，返回每句在**原文里的起止偏移**。

    **不返回文本。** 早先返回掩码后的文本、再用 `find()` 回查原文位置——
    掩码是等长同字符替换，于是「看 `AAA` 的用法说明。看 `BBB` 的用法说明。」
    两句掩码后完全相同，两句都还原成第一句的原文：**`BBB` 被改写成 `AAA`**。
    实测确认，而且发生在一个**完全没被选中**的小节里。

    位置一路带着就没有回查，也就没有这一类串换。
    """
    masked = _mask_format_spans(paragraph)
    bounds: list[tuple[int, int]] = []
    start = 0
    for match in _SENTENCE_END.finditer(masked):
        at = match.start()
        if at > start:
            bounds.append((start, at))
        start = at
    if start < len(masked):
        bounds.append((start, len(masked)))

    merged: list[tuple[int, int]] = []
    for begin, end in bounds:
        piece = masked[begin:end].strip()
        if not piece:
            continue
        follows = False
        if merged:
            previous = masked[merged[-1][0]:merged[-1][1]]
            follows = (piece.startswith(_CONSEQUENT)
                       or (_ANTECEDENT.search(previous)
                           and _CONSEQUENT_INLINE.search(piece)))
        if merged and follows:
            merged[-1] = (merged[-1][0], end)
        else:
            merged.append((begin, end))
    return merged


def split_sentences(paragraph: str) -> list[str]:
    """把一段切成句子，**关联结构并回去**。

    只按句末标点切；切完再把后件连接词开头的并回前一句。
    """
    parts = [s for s in _SENTENCE_END.split(paragraph) if s.strip()]
    merged: list[str] = []
    for part in parts:
        stripped = part.strip()
        # 连接词在开头（`而是…`）或**句中**（`系统才有能力…`）都算后件。
        # 只认开头时，「只有把判断搬进系统。系统才有能力自主执行。」
        # 会切成两个独立候选，条件与结论各自可被单独选中——**那就是切半句**。
        follows = (stripped.startswith(_CONSEQUENT)
                   or (merged and _ANTECEDENT.search(merged[-1])
                       and _CONSEQUENT_INLINE.search(stripped)))
        if merged and follows:
            merged[-1] = merged[-1] + stripped
        else:
            merged.append(stripped)
    return merged


#: 完整的行内格式范围。**先整体识别，再分句**——
#: 先分句再逐句查标记会漏掉**跨句的**格式：一段行内代码里有三句话时，
#: 中间那句两侧都没有反引号，会被当成普通句子收进候选。
#: 实测后果：选中它，代码内容被渲染成字面的 `==这里其实仍属于行内代码。==`，
#: **读者看到的内容发生了变化**。
#: 掩码字符：私用区码位，正文里不会出现。
MASK_CHAR = ""

_FORMAT_SPAN = re.compile(
    r"`[^`]*`"                       # 行内代码
    r"|\*\*[^*]*\*\*"                # 加粗
    r"|==[^=]*=="                    # 已有高亮
    r"|~~[^~]*~~"                    # 删除线
    r"|\[[^\]]*\]\([^)]*\)"          # 链接
    r"|!\[[^\]]*\]\([^)]*\)"         # 图片
    r"|<[a-zA-Z/][^>]*>"             # 内联 HTML
)


def _mask_format_spans(text: str) -> str:
    """把整段行内格式替换成等长的占位符，位置不变。

    分句在掩码后的文本上做，所以格式内部的句号不再是句子边界；
    句子是否落在格式范围内，看掩码后有没有残留占位符即可。
    """
    return _FORMAT_SPAN.sub(lambda m: MASK_CHAR * len(m.group(0)), text)


def _is_candidate(sentence: str) -> bool:
    if MASK_CHAR in sentence or _INLINE_FORMAT.search(sentence):
        return False
    length = _visible_length(sentence)
    return MIN_CANDIDATE_CHARS <= length <= MAX_CANDIDATE_CHARS


def collect(markdown: str) -> list[dict]:
    """产出候选清单。

    ID 形如 `s2-03`：第 2 个 h2 之下的第 3 个候选。
    **section 0 是首个 h2 之前的正文**（导语那一段）。

    分块口径与 `markdown_to_html` 对齐——两边对不上时高亮会落在别的句子上，
    所以 `tests/test_compile_candidates.py` 用同一份 markdown 两边对数。
    """
    lines = strip_editorial_comments(markdown, keep_scene_breaks=True).splitlines()
    heading_index = 0
    per_section = 0
    paragraph: list[str] = []
    found: list[dict] = []
    in_code = False
    block_index = -1

    def flush() -> None:
        nonlocal per_section, block_index
        if not paragraph:
            return
        block_index += 1
        text = " ".join(p.strip() for p in paragraph)
        paragraph.clear()
        # 与渲染器一致：并列论点段与独占一段的粗体各有自己的形态，不做高亮候选。
        if re.fullmatch(r"\*\*([^*]+)\*\*", text):
            return
        if re.match(r"^(第[一二三四五六七八九十]+|[0-9]{1,2})\s*[，、：:.]", text):
            return
        # **在掩码后的文本上分句**：格式内部的句号不再是句子边界，
        # 跨句的行内代码整体带着掩码，`_is_candidate` 一看就知道排除。
        # 拿到的是**偏移**，按偏移从原文切——不回查，也就不会串换。
        masked = _mask_format_spans(text)
        for sentence_index, (begin, end) in enumerate(split_spans(text)):
            if not _is_candidate(masked[begin:end].strip()):
                continue
            sentence = text[begin:end].strip()
            per_section += 1
            found.append({
                "id": "s%d-%02d" % (heading_index, per_section),
                "heading_index": heading_index,
                # **位置，不只是文本。** 只按文本做全文首次替换时，
                # 同一句话在两节都出现，选第二节会高亮到第一节去。
                "block_index": block_index,
                "sentence_index": sentence_index,
                "text": sentence,
                "chars": _visible_length(sentence),
            })

    for raw in lines:
        line = raw.strip()
        if line.startswith("```"):
            flush()
            in_code = not in_code
            continue
        if in_code:
            continue
        if not line:
            flush()
            continue
        if line.startswith("#"):
            flush()
            if re.match(r"^#{2}\s", line):
                heading_index += 1
                per_section = 0
            continue
        # 引用、列表、表格、图片、分隔线：整块跳过，不做候选
        if (line.startswith("<!--") or line.startswith(">") or line.startswith("|")
                or re.match(r"^([-*+]|\d+\.)\s+", line)
                or re.fullmatch(r"!\[[^\]]*\]\([^)]+\)", line)
                or re.fullmatch(r"-{3,}", line)):
            flush()
            continue
        paragraph.append(line)
    flush()
    return found


def fingerprint(found: list[dict]) -> str:
    """候选清单指纹。

    **覆盖 ID、文本与位置**——正文不变而分句规则变了时，同一个 ID 会指向另一句话。
    那时正文哈希一致、ID 也存在，只查前两项的校验会全部通过，
    而高亮落在了错的句子上。把编译器版本记进结果只能事后追查，拦不住当场这件事。
    """
    payload = [
        {"id": c["id"], "heading_index": c["heading_index"],
         "block_index": c["block_index"], "sentence_index": c["sentence_index"],
         "text": c["text"]}
        for c in found
    ]
    blob = json.dumps(payload, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def build(markdown: str, *, article_sha256: str = "") -> dict:
    """候选清单 + 指纹，给模型的那一份。"""
    found = collect(markdown)
    return {
        "schema_version": "1.0",
        "article_sha256": article_sha256,
        "candidate_set_sha256": fingerprint(found),
        "candidates": found,
    }

def apply_highlights(markdown: str, targets) -> str:
    """按 `(block_index, sentence_index)` 把选中的句子包成 `==句子==`。

    **只改写被选中的那些段落，其余原样搬运。** 早先的实现把每个段落都拆开重拼，
    于是完全没被选中的小节也会被重建——配合当时靠 `find()` 回查的还原逻辑，
    「看 `AAA` 的用法说明。看 `BBB` 的用法说明。」会被改写成两个 `AAA`。
    **正文内容被改写，而那一节根本没被选中。**

    也不做全文文本查找：同一句话在两节都出现时，按文本替换会高亮到错的那一节；
    句子在源码里跨行时又会静默不生效。
    """
    wanted = {(item["block_index"], item["sentence_index"]) for item in targets}
    if not wanted:
        return markdown

    # 只在内存中去掉注释，与 collect 的段落定位保持一致；分隔标记继续交给编译器。
    cleaned = strip_editorial_comments(markdown, keep_scene_breaks=True)
    if markdown.endswith("\n"):
        cleaned += "\n"
    lines = cleaned.splitlines(keepends=True)
    out: list[str] = []
    paragraph: list[str] = []      # (原始行, 去空白后的行)
    in_code = False
    block_index = -1

    def flush() -> None:
        nonlocal block_index
        if not paragraph:
            return
        block_index += 1
        raw_lines = [raw for raw, _ in paragraph]
        stripped = [s for _, s in paragraph]
        paragraph.clear()
        selected = [i for (b, i) in wanted if b == block_index]
        if not selected:
            # **没被选中的段落原样搬运**，一个字节都不动。
            out.extend(raw_lines)
            return
        text = " ".join(stripped)
        spans = split_spans(text)
        pieces = []
        cursor = 0
        for index, (begin, end) in enumerate(spans):
            pieces.append(text[cursor:begin])
            piece = text[begin:end]
            if index in selected:
                head = piece[:len(piece) - len(piece.lstrip())]
                tail = piece[len(piece.rstrip()):]
                pieces.append(head + "==" + piece.strip() + "==" + tail)
            else:
                pieces.append(piece)
            cursor = end
        pieces.append(text[cursor:])
        out.append("".join(pieces) + (raw_lines[-1][len(raw_lines[-1].rstrip()):]))

    for raw in lines:
        line = raw.strip()
        if line.startswith("```"):
            flush()
            in_code = not in_code
            out.append(raw)
            continue
        if in_code or not line:
            if not in_code:
                flush()
            out.append(raw)
            continue
        if line.startswith(("#", "<!--")) or (
                line.startswith(">") or line.startswith("|")
                or re.match(r"^([-*+]|\d+\.)\s+", line)
                or re.fullmatch(r"!\[[^\]]*\]\([^)]+\)", line)
                or re.fullmatch(r"-{3,}", line)):
            flush()
            out.append(raw)
            continue
        paragraph.append((raw, line))
    flush()
    return "".join(out)
