"""本地主题资源与内联样式覆盖；正文解析仍由 compile 唯一入口负责。"""

from __future__ import annotations

import html
import json
from pathlib import Path
import re
from typing import Any


LEGACY_THEME_IDS = ("warm", "minimal", "tech_blue")
THEME_DIRECTORY = Path(__file__).with_name("themes")
PALETTE_KEYS = frozenset({
    "surface_dark", "on_dark", "primary", "primary_dark", "surface",
    "surface_strong", "border", "text", "muted", "link",
})
STYLE_ROLES = frozenset({
    "wrapper", "p", "h1", "h2", "h3", "blockquote", "conclusion",
    "conclusion_p", "list", "li", "code_panel", "pre", "inline_code",
    "strong", "em", "a", "table_wrapper", "table", "th", "td", "hr",
    "img", "caption",
})


def load_presets(directory: Path = THEME_DIRECTORY) -> dict[str, dict[str, Any]]:
    """主题损坏即报错，不能悄悄以另一套风格产出文章。"""
    result = {}
    for path in sorted(directory.glob("*.json")):
        preset = json.loads(path.read_text(encoding="utf-8"))
        identity = preset.get("id")
        if not isinstance(identity, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", identity):
            raise ValueError(f"主题 ID 无效：{path}")
        if identity in result or identity in LEGACY_THEME_IDS:
            raise ValueError(f"主题 ID 重复：{identity}")
        if not preset.get("label") or not PALETTE_KEYS <= preset.get("palette", {}).keys():
            raise ValueError(f"主题缺少名称或语义色板：{path}")
        for role, properties in preset.get("styles", {}).items():
            if role not in STYLE_ROLES or not isinstance(properties, dict):
                raise ValueError(f"主题样式角色无效：{path} / {role}")
            if any(not isinstance(k, str) or not isinstance(v, str)
                   for k, v in properties.items()):
                raise ValueError(f"主题样式必须是 CSS 属性字符串：{path} / {role}")
        result[identity] = preset
    return result


THEME_PRESETS = load_presets()


def theme_details(profiles: dict[str, dict[str, str]]) -> list[dict[str, Any]]:
    """CLI 维持 themes ID 数组，详细选择信息另放 theme_details。"""
    details = []
    for identity, profile in sorted(profiles.items()):
        preset = THEME_PRESETS.get(identity, {})
        details.append({
            "id": identity, "label": profile["label"],
            "description": preset.get("description", "原有内置主题，保持既有排版"),
            "recommended_layout": preset.get("recommended_layout", "balanced"),
            "source": preset.get("source", {"project": "byclaw", "kind": "built-in"}),
        })
    return details


def theme_styles(identity: str, layout: str) -> dict[str, dict[str, str]]:
    """布局只调新主题的阅读节奏，不再给主题套原有标题装饰。"""
    source = THEME_PRESETS.get(identity, {}).get("styles", {})
    styles = {role: dict(values) for role, values in source.items()}
    if layout == "balanced":
        return styles
    margin_scale, line_scale = {
        "compact": (0.8, 0.93), "comfortable": (1.2, 1.055),
        "column": (1.1, 1.027),
    }.get(layout, (1.0, 1.0))
    rhythm_roles = {"p", "h2", "h3", "blockquote", "conclusion", "conclusion_p",
                    "list", "li", "code_panel", "caption", "hr"}
    for role, properties in styles.items():
        if role not in rhythm_roles:
            continue
        for key, value in list(properties.items()):
            if key == "margin" or key.startswith("margin-"):
                properties[key] = re.sub(
                    r"(-?\d+(?:\.\d+)?)px\b",
                    lambda m: f"{float(m.group(1)) * margin_scale:.3g}px", value)
            elif key == "line-height" and re.fullmatch(r"\d+(?:\.\d+)?(?:px)?", value):
                unit = "px" if value.endswith("px") else ""
                number = value[:-2] if unit else value
                properties[key] = f"{float(number) * line_scale:.3g}{unit}"
    return styles


def merge_style(base: str, overrides: dict[str, str]) -> str:
    """保留未覆盖的默认值，覆盖值置后以正确处理 CSS 简写与长写。"""
    if not overrides:
        return base
    kept = [part for part in base.split(";")
            if part.strip() and part.partition(":")[0].strip() not in overrides]
    return ";".join(kept + [f"{key}:{value}" for key, value in overrides.items()]) + ";"


def style_tag(markup: str, overrides: dict[str, str] | None, *,
              tag: str | None = None, all_matches: bool = False) -> str:
    """覆盖已生成节点的 style，不解析或改写文章内容、术语标记或 DOM 结构。"""
    if not overrides:
        return markup
    pattern = re.compile(r"<(?P<tag>" + (re.escape(tag) if tag else r"[a-z][a-z0-9]*")
                         + r")\b(?P<attrs>[^>]*?)(?P<close>/?)>")

    def replace(match: re.Match[str]) -> str:
        attrs = match.group("attrs")
        found = re.search(r'\sstyle="([^"]*)"', attrs)
        base = html.unescape(found.group(1)) if found else ""
        value = html.escape(merge_style(base, overrides), quote=True)
        replacement = f' style="{value}"'
        attrs = attrs[:found.start()] + replacement + attrs[found.end():] if found else attrs + replacement
        return f'<{match.group("tag")}{attrs}{match.group("close")}>'

    return pattern.sub(replace, markup, count=0 if all_matches else 1)
