# 微信正文主题来源与适配说明

本目录为文章排版流程保留 20 个选定主题的上游来源。核对日期：2026-09-23。每个主题固定到上游提交，主题名与前一轮效果画廊一致。机器可读的文件清单、作者、源文件路径、SHA-256 与许可证位置见 [theme_sources/manifest.json](theme_sources/manifest.json)。

## 原始资源与生产样式

`theme_sources/` 中的原始 CSS、JSON、TypeScript 和许可证按下载版本保存；提取或合并的 CSS 在清单中明确标注。生产排版使用这些主题的兼容适配，保留主要色彩、字体层级、边框与间距，但不是上游编辑器完整 HTML 的逐像素复制。

生产样式移除无法可靠内联的伪元素、CSS 计数器等装饰，使用当前文章编译器的段落、标题、列表、表格和图片结构；不加载上游编辑器、脚本或字体服务。主题选择只改变正文视觉，不修改文章事实、配图或发布目标。样式最终内联并经过现有移动端检查。

兼容适配保留自动居中的相对关系，不把桌面预览的像素宽度或外边距固定到手机上。深色标题和表头里的强调、链接、斜体沿用该标题的前景色；高亮和行内代码使用浅底深字。薄荷、山吹、Orange Heart、兰青、黑金、Pie、赤陶的部分文字或标题底色做了对比度修正，详细改动记录在各主题 JSON 的 `source.adaptation` 中；原始资源仍按来源版本保留。

「手记楷体」使用系统字体栈；设备未安装 KaiTi / STKaiti 等字体时会回退。名称、颜色与布局可以保持一致，但不能保证每个微信客户端都显示同一种楷体。

## 选定主题

| ID | 名称 | 固定版本源文件 | 上游许可证记录 | 本地资源（相对本文件） |
| --- | --- | --- | --- | --- |
| `wemd-eastern-notes` | 东方笺谱 | [源码](https://github.com/tenngoxars/WeMD/blob/70835e141aa94c0296c78c0f6adf67f636475f38/packages/core/src/themes/eastern-notes.ts) | MIT | [资源](theme_sources/wemd/eastern-notes.css) |
| `wemd-morandi-forest` | 莫兰迪森林 | [源码](https://github.com/tenngoxars/WeMD/blob/70835e141aa94c0296c78c0f6adf67f636475f38/packages/core/src/themes/morandi-forest.ts) | MIT | [资源](theme_sources/wemd/morandi-forest.css) |
| `wemd-data-blueprint` | 数据蓝图 | [源码](https://github.com/tenngoxars/WeMD/blob/70835e141aa94c0296c78c0f6adf67f636475f38/packages/core/src/themes/data-blueprint.ts) | MIT | [资源](theme_sources/wemd/data-blueprint.css) |
| `wemd-modern-editorial` | 编辑部手记 | [源码](https://github.com/tenngoxars/WeMD/blob/70835e141aa94c0296c78c0f6adf67f636475f38/packages/core/src/themes/modern-editorial.ts) | MIT | [资源](theme_sources/wemd/modern-editorial.css) |
| `wemd-receipt` | 购物小票 | [源码](https://github.com/tenngoxars/WeMD/blob/70835e141aa94c0296c78c0f6adf67f636475f38/packages/core/src/themes/receipt.ts) | MIT | [资源](theme_sources/wemd/receipt.css) |
| `wemd-luxury-gold` | 黑金奢华 | [源码](https://github.com/tenngoxars/WeMD/blob/70835e141aa94c0296c78c0f6adf67f636475f38/packages/core/src/themes/luxury-gold.ts) | MIT | [资源](theme_sources/wemd/luxury-gold.css) |
| `wenyan-lapis` | Lapis | [源码](https://github.com/caol64/wenyan-core/blob/b1c9edc7c13b8a5e110d29266aa849dfbc4dc6ef/src/assets/themes/lapis.css) | Apache-2.0 (Wenyan); MIT (upstream theme) | [资源](theme_sources/wenyan/lapis.css) |
| `wenyan-orangeheart` | Orange Heart | [源码](https://github.com/caol64/wenyan-core/blob/b1c9edc7c13b8a5e110d29266aa849dfbc4dc6ef/src/assets/themes/orangeheart.css) | Apache-2.0 (Wenyan); MIT (upstream theme) | [资源](theme_sources/wenyan/orangeheart.css) |
| `wenyan-pie` | Pie | [源码](https://github.com/caol64/wenyan-core/blob/b1c9edc7c13b8a5e110d29266aa849dfbc4dc6ef/src/assets/themes/pie.css) | Apache-2.0 (Wenyan); MIT (upstream theme) | [资源](theme_sources/wenyan/pie.css) |
| `wenyan-phycat` | 物理猫-薄荷 | [源码](https://github.com/caol64/wenyan-core/blob/b1c9edc7c13b8a5e110d29266aa849dfbc4dc6ef/src/assets/themes/phycat.css) | Apache-2.0 (Wenyan); MIT (upstream theme) | [资源](theme_sources/wenyan/phycat.css) |
| `mdnice-blueCyan` | 兰青 | [源码](https://github.com/mdnice/markdown-nice/blob/1300506fde2e4c10de312c21189e264497547a5f/src/template/markdown/blueCyan.js) | GPL-3.0 | [资源](theme_sources/mdnice/blueCyan.css) |
| `mdnice-ink` | 墨黑 | [源码](https://github.com/mdnice/markdown-nice/blob/1300506fde2e4c10de312c21189e264497547a5f/src/template/markdown/ink.js) | GPL-3.0 | [资源](theme_sources/mdnice/ink.css) |
| `mdnice-shanchui` | 山吹 | [源码](https://github.com/mdnice/markdown-nice/blob/1300506fde2e4c10de312c21189e264497547a5f/src/template/markdown/shanchui.js) | GPL-3.0 | [资源](theme_sources/mdnice/shanchui.css) |
| `mdnice-rose` | 蔷薇紫 | [源码](https://github.com/mdnice/markdown-nice/blob/1300506fde2e4c10de312c21189e264497547a5f/src/template/markdown/rose.js) | GPL-3.0 | [资源](theme_sources/mdnice/rose.css) |
| `doocs-default` | 经典 | [源码](https://github.com/doocs/md/blob/2cd2b354e60b44d021fcda79a6d3595bfb006847/packages/shared/src/configs/theme-css/default.css) | WTFPL-2.0 | [资源](theme_sources/doocs/default.css) |
| `doocs-grace` | 优雅 | [源码](https://github.com/doocs/md/blob/2cd2b354e60b44d021fcda79a6d3595bfb006847/packages/shared/src/configs/theme-css/grace.css) | WTFPL-2.0 | [资源](theme_sources/doocs/grace.css) |
| `xiaohu-terracotta` | 赤陶 | [源码](https://github.com/xiaohuailabs/xiaohu-wechat-format/blob/dbddf0fd9c1189a6f3e0bec1bebb1b0e47e8ddf0/themes/terracotta.json) | README 声明 MIT | [资源](theme_sources/xiaohu/terracotta.json) |
| `xiaohu-newspaper` | 报纸 | [源码](https://github.com/xiaohuailabs/xiaohu-wechat-format/blob/dbddf0fd9c1189a6f3e0bec1bebb1b0e47e8ddf0/themes/newspaper.json) | README 声明 MIT | [资源](theme_sources/xiaohu/newspaper.json) |
| `xiaohu-swiss-grid` | 瑞士国际主义 | [源码](https://github.com/xiaohuailabs/xiaohu-wechat-format/blob/dbddf0fd9c1189a6f3e0bec1bebb1b0e47e8ddf0/themes/swiss-grid.json) | README 声明 MIT | [资源](theme_sources/xiaohu/swiss-grid.json) |
| `xiaohu-kaiti-journal` | 手记楷体 | [源码](https://github.com/xiaohuailabs/xiaohu-wechat-format/blob/dbddf0fd9c1189a6f3e0bec1bebb1b0e47e8ddf0/themes/kaiti-journal.json) | README 声明 MIT | [资源](theme_sources/xiaohu/kaiti-journal.json) |

## 共享资源与署名

- **Doocs**：原始 `base.css` → `default.css`；「优雅」再追加 `grace.css`。保留项目 WTFPL v2 许可证。
- **mdnice**：固定在 2020-03-22 的历史版本；`basic.css` 与主题 CSS 从原始 JavaScript 模板字符串提取，原始文件也保留在 `mdnice/original/`。保留 GPL v3 完整文本。作者：兰青 Krahets、墨黑 Mayandev、山吹 ElyhG、蔷薇紫 HeyRain。
- **Wenyan / 文颜**：主题 CSS 保留原始顶部署名与链接；项目 Apache 2.0 许可证和对应 Typora 上游 MIT 许可证分别保留。Lapis：YiNN；Orange Heart：evgo2017；Pie：kevinzhao2233；物理猫：sumruler。对应上游许可证来源链接记录在清单中。
- **WeMD**：CSS 按原始注册顺序合并基础、主题与代码高亮样式；原始 TypeScript（包括「编辑部手记」三个组成文件）保留在 `wemd/original/`，MIT 许可证保留 WeMD Team 署名。
- **小互预设**：4 个 JSON 按原样保存。该固定版本的 README 声明 MIT，审计未发现独立 LICENSE 文件；保留 `xiaohu/UPSTREAM-README.md` 作为原始声明，不补写或推定版权主体。

以上许可证记录对应各自资源，不将来源不同的主题统一标成一种许可证。新增主题时，应同时增加固定版本来源、必要的基础样式、原始署名和许可证文件，再验证移动端及最终内联输出。

## gzh-design 结构资源（0.7.2）

新增七套 gzh-* 主题直接复制并适配 gzh-design-skill@750a50dffdc4abb5e853b98136dad13a57e64ce3 的 HTML 结构，许可证 AGPL-3.0-or-later。结构、来源与片段哈希保存在 components/data/theme-structures.json，原许可证在 components/data/gzh-design-LICENSE.txt；两者随 wheel 安装。主题资源不依赖上游运行目录。此项与前述20套CSS兼容主题区分维护，不把旧的827项语义映射当作完整视觉复刻。
