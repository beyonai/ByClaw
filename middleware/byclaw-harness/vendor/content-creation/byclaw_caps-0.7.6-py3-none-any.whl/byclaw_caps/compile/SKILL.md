---
name: channel-html-validate
description: 当需要把 markdown 编译成公众号 HTML、并在投递前校验平台排版红线时使用。编译与校验在同一步完成——分成两步就得指望调用方记得跑第二步，漏跑的代价是草稿在后台渲染错乱而群发不可撤回。这是编译与投递之间的强制门禁——此前编译产出从未被检查过，踩了红线要等草稿在公众号后台渲染错乱才发现，那时已经推送不可撤回。区分 ERROR（阻断投递）与 WARNING（放行但提示）。已实测确认：内联 style、background、linear-gradient、border-left、color 经草稿接口往返后完整保留，不需要 span leaf 包裹。
---

# 渠道包红线校验

## 组件编排与渠道导出（0.7.1）

公共编译器复用既有 Markdown 解析器，新增语义块、源文绑定组件计划与独立渠道呈现：

```bash
python3 -m byclaw_caps.compile components --sources
python3 -m byclaw_caps.compile blocks <源.md> --out <语义块.json>
python3 -m byclaw_caps.compile component-plan <源.md> <组件计划.json> --theme gzh-red-white --recipe tutorial
python3 -m byclaw_caps.compile markdown <源.md> <article.html> --component-plan <组件计划.json> --session-root <任务根>
python3 -m byclaw_caps.compile preview <源.md> <preview.html> --component-plan <组件计划.json> --session-root <任务根>
python3 -m byclaw_caps.compile contract <article.html> <preview.html> --session-root <任务根>
python3 -m byclaw_caps.compile component-gallery <画廊目录> --theme gzh-red-white --all-sources
python3 -m byclaw_caps.compile channel <已审校短稿.md> <导出目录> --channel xiaohongshu.note --render-images
python3 -m byclaw_caps.compile theme-create <偏好.json> <任务主题目录>
```

组件计划与原有 --plan 高亮计划独立；正文、组件计划、自定义 --theme-file 均绑定契约。源文变化、未知组件、重复或乱序引用、缺图、最终成品仍含待补素材时阻断。未选择的原文块照常保留，组件展示字段不接受新正文或数据。

新增 gzh-moyu-green、gzh-red-white、gzh-graphite-minimal、gzh-olive-journal、gzh-zen-whitespace、gzh-moyu-ticket 六套主题。article.hero 等组件只呈现已有语义，不编造身份、观点或数字。配方、组件选用由 self-media-article 的 references/typesetting 解释；完整字段以 components 返回值为准。

channel 支持 wechat.public_article、wechat.image_text、xiaohongshu.note、toutiao.article。图卡使用标准卡无损分页并记录 fallback；长文改编须由创作工作流先审校。render-images 才实际生成 PNG，未审校的清单始终 ready_for_delivery=false。头条另交纯文本，当前 byCLI 不提供正文 HTML 自动投递。所有渠道命令只生成本地文件，不联网发布；源项映射和 HTML 技术通过不代表逐项视觉复刻或目标编辑器验收。

## 调用

```bash
# 渠道包：正文**片段**，投递用的就是它。编译后默认立刻红线校验
python3 -m byclaw_caps.compile markdown <源.md> <渠道包.html>     [--layout balanced] [--theme warm] [--image-map <映射.json>] [--image-fit contain] [--terms <术语.json>] [--skip-validate]

# 预览：**给人打开看的完整文档**，含 H1
python3 -m byclaw_caps.compile preview <源.md> <预览.html>     [--title <标题>] [--layout balanced] [--theme warm] [--image-map <映射.json>] [--terms <术语.json>]

# 只校验已有 HTML
python3 -m byclaw_caps.compile validate <渠道包.html>     [--kind channel]

# 列出版式与主题
python3 -m byclaw_caps.compile themes    # 主题 ID、名称、来源与说明；profiles 兼容保留

# 排版候选清单：**模型只能从这里选 ID，不能自己提供文字**
python3 -m byclaw_caps.compile candidates <源.md>     [--out <候选.json>]
```

## 两个文件，别互相覆盖

排版这一步产**两份**：

| 文件 | 是什么 | 给谁 |
|---|---|---|
| `40-package/渠道包.html` | 正文**片段**，无 `doctype` 无 `<h1>` | `deliver package` 拿去投递 |
| `40-package/预览.html` | 完整文档，含 `<h1>` | 业务打开看效果 |

**首个一级标题在渠道包里被摘掉**，因为它走草稿的 `title` 字段——
正文里再放一遍，读者会看到两个标题。摘掉的那个值在 `markdown` 的结果里：

```json
{"title": "从单兵到军团……", "title_source": "markdown_h1"}
```

`title_source` 为 `none` 说明源文件没有一级标题。**那时不要自己编一个**，
编出来的标题会一路走到草稿标题栏。

> 2026-08-28 实测：当时没有 `preview` 这条路，助理为了给业务一份能打开的东西，
> **把渠道包整个换成了预览文档**——而那时 `validate` 不查文档结构，给了 0 errors。
> 真投出去的话，公众号正文字段会收到 `<!doctype html>`，标题出现两次。

## 两种校验口径

```bash
python3 -m byclaw_caps.compile validate <文件>                  # channel（缺省），严
python3 -m byclaw_caps.compile validate <文件> --kind preview   # 预览，宽
```

`channel` 口径下，`<!doctype>`／`<html>`／`<head>`／`<body>`／`<h1>` **一律 ERROR**——
渠道包是片段，出现这些说明拿错了文件。

`preview` **只跳这五条**，其余照查：预览里出现 `<script>` 同样是问题。

## 图片宽度

```bash
--image-fit contain   # 缺省：max-width:100%，小图保持原尺寸
--image-fit fill      #       width:100%，占满整宽
```

`fill` 会触发 `IMG_WIDTH_100` 告警，**只有表格、封面卡、流程图才该用**。

> 缺省曾经是 `fill`，于是编译器每张图都触发自己的告警，而 CLI 没有开关能改——
> 唯一的满足办法是手改产出，但那违反「不手写 style」，而且一重新编译就丢。

## 版式与主题

4 种版式、3 个兼容主题与 20 个开源适配主题；未传参数仍默认 `balanced` + `warm`。
完整目录见 [LAYOUT-THEME.md](LAYOUT-THEME.md)，或运行 `compile themes` 查看实际安装版本的
`themes` ID 数组与 `theme_details`。已有 `profiles` 命令继续可用。

| 用户说 | 版式 |
|---|---|
| 紧凑、资讯版 | `compact` |
| 舒展、长文版 | `comfortable` |
| 专栏感 | `column` |
| 未指定 | `balanced` |

| 用户说或内容情境 | 主题 |
|---|---|
| 手记楷体；新随笔、复盘 | `xiaohu-kaiti-journal` |
| 数据蓝图；新技术、数据文章 | `wemd-data-blueprint` |
| 莫兰迪森林；自然生活内容 | `wemd-morandi-forest` |
| 编辑部手记；观点专栏 | `wemd-modern-editorial` |
| 极简、黑白 | `minimal` |
| 科技蓝、延续现有技术系列 | `tech_blue` |
| 未指定且没有内容背景 | `warm` |

选择顺序：**用户明确主题优先，其次延续系列，再看内容建议，最后兼容缺省**。
选择写入 `ArticlePlan.distribution_plan.presentation`，渠道包与预览传同一组参数。

开源主题通过当前编译器做微信适配，不是上游编辑器效果的完整复刻。
手记楷体使用系统字体，不下载外部字体；设备缺少楷体时会回退。
新主题首次使用还要在手机微信草稿中检查字体、深色模式、表格和代码；本地检查与真机检查分别报告。

## 故事阅读预设

阅读预设独立于主题：`default` 保持原效果，`story_modern`（现代叙事）、
`story_kaiti`（手记楷体叙事）、`story_serif`（留白宋体叙事）调整字体、段距和装饰，
保留所选主题的纸色与强调色。用户指定主题时不替换它。

```bash
python3 -m byclaw_caps.compile markdown <源.md> <渠道包.html> --article-plan <ArticlePlan.json> --plan <排版计划.json>
python3 -m byclaw_caps.compile preview <源.md> <预览.html> --article-plan <ArticlePlan.json> --plan <排版计划.json>
python3 -m byclaw_caps.compile density <源.md> --article-plan <ArticlePlan.json> --plan <排版计划.json> --check
```

`--article-plan` 读取 `distribution_plan.presentation` 的 `layout_profile`、`theme_profile`、
`reading_profile`。显式 `--layout`、`--theme`、`--reading-profile` 优先；字段缺省时使用
`balanced`、`warm`、`default`。`--plan` 仍只接受高亮排版计划，两份计划不能混用。
渠道包和预览必须使用同一阅读预设，契约会阻断失配；CLI 结果与预览页均说明实际预设。
传入的 ArticlePlan 支持 YAML/JSON，文件哈希纳入契约；计划改动后需重编产物。

故事预设下，独占粗体段保留为普通加粗段，标题不加序号色块，引用保留轻量左线；
显式高亮与术语计划照常生效。`density --check` 不再建议首屏必须有强调，但强调过密仍检查。
场景锚点 `<!-- scene: section-01 -->` 不展示；场景分隔 `<!-- scene-break -->` 显示轻量居中符号。
两种标记都须独占一行，不依赖连续空行产生场景间隔。其它 HTML 注释不会出现在正文中，
围栏代码中的注释示例仍作为代码显示。

## 候选清单：语义排版的地基

```bash
python3 -m byclaw_caps.compile candidates <源.md> --out <候选.json>
```

产出带 ID 的候选句清单与 `candidate_set_sha256`。**规划模型只返回 ID**，
编译器按 ID 从自己解析出来的候选里取字——**模型没有提供文字的通道**，
「打错字改变含义」在结构上不可能发生。

ID 形如 `s2-03`：第 2 个 h2 之下的第 3 个候选；**`s0-xx` 是首个 h2 之前的导语**。

**首版只收普通段落里的完整判断**，这些一律不进清单：

| 不收 | 为什么 |
|---|---|
| 含加粗 / 链接 / 行内代码 / 已有 `==` 的句子 | 可见文字连续而源码不连续；且叠两层强调 |
| 引用块、列表、表格、代码块、标题、图片 | 各有自己的形态 |
| 独占一段的粗体、并列论点段 | 已经是结论卡片与序号段 |
| 太短（< 8 字）或太长（> 40 字） | 短的标不出判断；**长句连成一片，宁可不选** |

**关联结构不切断**：`不是…而是…`、`只有…才…`、`虽然…但是…`、`与其…不如…`
按整句出候选；整体超长就**不出候选，不切半句**——
只高亮「不在能不能推理」而丢掉「而在于搬进了多少判断」，比不高亮更糟。

`candidate_set_sha256` 覆盖 **ID、位置与文本**：正文没变而分句规则变了时，
同一个 ID 会指向另一句话，只查正文哈希拦不住。

## 排版计划：模型只给 ID

```bash
python3 -m byclaw_caps.compile markdown <源.md> <渠道包.html> --plan <计划.json>
python3 -m byclaw_caps.compile preview  <源.md> <预览.html>  --plan <计划.json>
```

计划形如——**没有一个字段承载要渲染的文字**：

```json
{"schema_version": "1.0",
 "article_sha256": "…",
 "candidate_set_sha256": "…",
 "highlights": ["s2-04"]}
```

文字由编译器按 ID 从候选清单取。多塞一个 `text` 字段也不会被采用。

### 三种模式

| 模式 | 行为 |
|---|---|
| **不传** `--plan` | 与现在完全一致：**作者写在正文里的 `==高亮==` 照常渲染** |
| 传**空**计划（`highlights: []`） | 不**新增**高亮；正文自带的全部保留。**这是正常结果，不是失败** |
| 传**非空**计划 | 在既有强调基础上追加 |

**两份产物必须传同一份计划**——预览的价值就是「看到的就是要发的」。

### 四道校验，失配即拒

| 错误码 | 拦的是什么 |
|---|---|
| `UNSUPPORTED_PLAN_VERSION` | 结构变了而校验器还按旧的读 |
| `PLAN_SOURCE_MISMATCH` | **拿旧计划配新正文** |
| `CANDIDATE_SET_MISMATCH` | **正文没变、分句规则变了**——同一个 ID 指向了另一句话 |
| `UNKNOWN_CANDIDATE_ID` | 编出来的 ID |
| `HIGHLIGHT_QUOTA_EXCEEDED` | 见下 |

第三道最容易被漏掉：前两道全过，而高亮落在错的句子上。

### 额度：每节一句，含作者已写的

数的是**背景高亮**——作者写的 `==…==` 加计划新增的，合计每节 ≤ 1 处。
否则两个入口各自合规、合起来超限。

**粗体不算进这个额度**：一节里两个关键词加粗是正常写法，
判成超限会制造一轮毫无必要的创作返修。

## 术语下划线

```bash
--terms <术语.json>    # JSON 数组，元素是非空字符串：["GraphRAG", "向量召回"]
```

给**首次出现**的术语加下划线。**正文里不写任何标记**——术语来自
`ArticlePlan.production_plan.term_glossary`，这样作者不用记新语法，
而且字数测量不受影响（正文标记会被算进篇幅）。

规则：只划首次；最长优先（`RAG` 不从 `GraphRAG` 里切出半截）；
跳过代码与链接文字（链接本来就有自己的下划线）。

**渠道包与预览要传同一份。** 两边不一致的话，业务在预览里看到的下划线与真正投出去的
不同——而他正是靠预览做的判断。

形状不对不会静默跳过：顶层不是数组报 `INVALID_TERMS_SHAPE`，
元素不是非空字符串报 `INVALID_TERM_TYPE` 并指出是第几项。

## 强调语法

| 写法 | 渲染成 |
|---|---|
| `==这一句==` | 行内背景高亮（底色取主题的 `surface_strong`） |
| `## 一、标题` `## 01 标题` `## 2. 标题` | 二级标题前的序号圆圈 |

序号**只给二级标题**，且要求序号与标题分得开：`## 3 个原因` 不认——
那里的 3 是词组的一部分。作者侧完整对照表见 `AUTHORING-MARKS.md`。

## 图片映射

`--image-map` 传一份 JSON：本地路径 → 渠道链接。**缺映射的图片会原样保留本地路径**，
草稿里就是坏图——公众号取不到你机器上的文件。上传素材拿到链接后再编译，或编译后逐个替换。

**SVG 一律先转 PNG**（`byclaw_caps.raster svg`）：公众号不显示 SVG，正文里放 `.svg` 整张不出图。

退出码：`0` 无 ERROR 可投递，`1` 有 ERROR **中止投递**，`2` 文件不存在。
输出 JSON 含逐条命中位置。加 `--result-file <路径>` 落盘留档。

## 门禁位置

```
编译 → 【本校验】 → 投递
         退出码 1 即停，不进投递
```

**不要跳过。** 公众号草稿一旦群发不可撤回，排版错乱只能重发。校验成本是几十毫秒。

## 红线清单

**ERROR — 阻断投递**

| 规则 | 说明 |
| --- | --- |
| `STYLE_TAG` / `SCRIPT_TAG` / `LINK_TAG` | 平台整段剥离，样式全丢 |
| `DIV_TAG` | 编辑器会重排结构 |
| `CLASS_ATTR` / `ID_ATTR` | 选择器随 `<style>` 一起被剥离，等于没写 |
| `POSITION` / `FLOAT` | 定位在移动端渲染错位 |
| `AT_MEDIA` / `AT_KEYFRAMES` / `AT_IMPORT` | at 规则不被支持 |
| `GRID` | 网格布局不被支持 |
| `CSS_VAR` | 变量不解析，属性整条失效 |
| `EXTERNAL_FONT` | 外链字体不加载，回退字形不可控 |
| `IMG_SVG` | **公众号不显示 SVG**，必须先用 `image-rasterize` 转 PNG |

**WARNING — 放行但提示**

| 规则 | 说明 |
| --- | --- |
| `WHITE_SPACE_PRE` | 窄屏易溢出 |
| `IMG_WIDTH_100` | 宽度写死 100% 在部分容器内失真；SVG 已被 `IMG_SVG` 拦掉，此规则对其豁免 |

## 已验证的非问题

曾怀疑内联样式需要 `<span leaf="">` 包裹才能存活。**实测证伪**：A／B 两版草稿发出后再取回，
100 处 `style=`、19 处 `background`、8 处 `linear-gradient`、11 处 `border-left`、
83 处 `color:` 全部原样保留。加包裹只让体积涨 10%，**不要加**。

内置版式与主题的组合由黄金输出和红线测试覆盖；新增主题须补对应组合，不能只改目录文案。

## 红线是强制门禁

`markdown` 子命令编译后**默认立刻校验**，**退出码 1 即中止，不进投递**。
公众号草稿一旦群发不可撤回，排版错乱只能重发；校验成本是几十毫秒。

确需先看产出时传 `--skip-validate`——那是显式选择。
