# -*- coding: utf-8 -*-
"""编译产物的契约记录：把编译这一步实际用了什么，如实记下来。

方案 §三。这里只做**采集与组装**，比较规则全在 `shared.render_contract`——
两处各写一份判定逻辑，必然漂，而这正是这套契约本身要治的病。

采集的东西分两类，落到两个结构：

- `render_input`：正文、计划、资产身份、主题、版式、`image_fit`、术语表、编译器版本
  ——**渠道包与预览必须完全相同**。
- `consumption`：实际写进 HTML 的地址、产物角色、映射版本、地址与源文件的绑定证据
  ——**每份产物各自核对**，两份本来就可以不同。
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ..shared.render_contract import (
    BINDING_DECLARED,
    BINDING_LOCAL_FILE,
    BINDING_TYPES,
    ROLE_CHANNEL,
    build_consumption,
    build_render_input,
    canonical_json,
    render_input_sha256,
    sha256_file,
)


def _sha256_bytes(payload: bytes) -> str:
    import hashlib

    return hashlib.sha256(payload).hexdigest()


def read_image_map(path: str | Path | None) -> tuple[dict[str, str], dict[str, dict], str]:
    """读映射文件，返回 (编译用的扁平映射, 每张图的绑定证据, 映射文件哈希)。

    **两种写法都收**：

    ```json
    {"./visual-001.png": "https://cdn/x.png"}                       // 旧的，够用
    {"./visual-001.png": {"url": "https://cdn/x.png",               // 带证据的
                          "binding": "upload_record",
                          "source_sha256": "…", "uploaded_at": "…"}}
    ```

    只认新写法的话，所有既有映射文件都要先改一遍才能编译；而旧写法本身不是错的，
    它只是**没有携带证据**——那就让它照常编译，在校验那一步说清楚缺什么。
    """
    if not path:
        return {}, {}, ""
    raw_bytes = Path(path).read_bytes()
    parsed = json.loads(raw_bytes.decode("utf-8"))
    flat: dict[str, str] = {}
    bindings: dict[str, dict] = {}
    for source, target in parsed.items():
        if isinstance(target, str):
            flat[source] = target
            continue
        if not isinstance(target, dict) or "url" not in target:
            raise ValueError(
                "映射 %s 的值既不是地址字符串、也不是带 url 的对象" % source)
        flat[source] = str(target["url"])
        binding_type = str(target.get("binding") or BINDING_DECLARED)
        if binding_type not in BINDING_TYPES:
            raise ValueError("映射 %s 的 binding 未知：%s" % (source, binding_type))
        binding = {"type": binding_type}
        for key in ("source_sha256", "uploaded_at"):
            if target.get(key):
                binding[key] = str(target[key])
        bindings[source] = binding
    return flat, bindings, _sha256_bytes(raw_bytes)


def _asset_id(source: str) -> str:
    """映射键 → 资产 id。取文件名去扩展名。

    `../30-assets/visual-001.png` 与 `./visual-001.png` 指的是同一张图，
    **按原始键当 id 会让两份产物的资产表对不上**——而两份写法不同恰恰是常态：
    渠道包与预览各自相对自己的位置写路径。
    """
    return Path(str(source)).stem


#: 正文里的图片引用。资产清单从**正文**来，不从映射文件来。
_IMAGE_REF_RE = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")


def article_image_refs(markdown: str) -> list[str]:
    """正文引用了哪些图。

    **不能拿映射文件当资产清单。** 映射缺了一条时，那张图就整个不出现在记录里——
    校验看到两边都没有它，判定一致，而编译器会把本地路径原样写进渠道包，
    草稿里就是一张坏图。清单要从「正文说要有哪些图」来，
    映射只回答「它们各自去了哪个地址」。
    """
    seen: list[str] = []
    for raw in _IMAGE_REF_RE.findall(markdown):
        ref = raw.strip().split()[0] if raw.strip() else ""
        if ref and ref not in seen:
            seen.append(ref)
    return seen


def collect_assets(image_map: dict[str, str], *, source_path: Path | None,
                   bindings: dict[str, dict], markdown: str = "",
                   output_path: Path | None = None
                   ) -> tuple[list[dict], list[dict], dict[str, Path]]:
    """采集资产身份与消费绑定。

    身份里的 `sha256` 取**本地源文件**。取不到（文件不在）时留空——
    留空会在校验那一步失配并说明原因，比这里猜一个值好。

    `src` 记的是**实际写进 HTML 的那个地址**，不是映射文件里写的那个。
    两者会不一样：编译器把图片路径按输出文件的位置重算过一次
    （正文在 `20-creative/`、HTML 在 `40-package/`）。照抄映射值的话，
    第二层每次都会报「记录的地址没出现在 HTML 里」——**记录错了，产物是对的**，
    那种假警报比不查还糟，它会训练人忽略这个检查。

    **没有上传映射的图照样进消费记录**，绑定强度记 `local_file`——
    排版阶段本来就还没上传，渠道包引用本地图是正常状态，不是缺失。
    早先这里把它 `continue` 掉，门禁于是报"这张图没有映射记录"，
    正常交付被拦；而真正该查的"文件还在不在、是不是还是那一份"反倒没人查。

    第三个返回值是 **`{资产 id: 源文件绝对路径}`**，与 `src` 是两回事：

    * `src` 是**渲染成了什么地址**——上了远程映射就是 `https://…`；
    * 这一份是**源图在磁盘上的哪里**，跟传没传、传到哪毫无关系。

    分开记是因为它们回答的是两个问题。合成一个之后出过一个真实漏洞：
    门禁拿 `src` 去定位源文件，遇到远程 URL 就放弃，**于是一旦上了映射，
    "源图有没有被换过"就再也没人查**——上传回执是"当时传的是哪一份"的凭据，
    它对"现在磁盘上那份还是不是那一份"一个字都没说。
    """
    from . import rebase_image_path

    refs = article_image_refs(markdown) if markdown else list(image_map)
    for source in image_map:
        if source not in refs:
            refs.append(source)

    identity: list[dict] = []
    consumed: list[dict] = []
    sources: dict[str, Path] = {}
    for source in sorted(set(refs)):
        asset_id = _asset_id(source)
        local = Path(source)
        if not local.is_absolute() and source_path is not None:
            local = (Path(source_path).parent / source).resolve()
        digest = sha256_file(local) if local.is_file() else ""
        identity.append({"id": asset_id, "sha256": digest})
        # **不管有没有映射都记**——正是"有映射"那一支后来没人查了。
        sources[asset_id] = local

        if source not in image_map:
            # **没有上传映射是排版阶段的正常状态**，不是缺失。
            # 上传发生在发布阶段；排版产出的渠道包本来就引用本地图。
            # 早先这里 `continue` 掉了整条记录，于是门禁报"这张图没有映射记录"——
            # 本地文件明明在，正常交付被拦。
            #
            # 记本地引用，证据是"文件在、哈希对得上"，绑定强度写 `local_file`。
            actual_local = source
            if source_path is not None and output_path is not None:
                actual_local = rebase_image_path(
                    source, source_path=source_path, output_path=output_path)
            consumed.append({
                "id": asset_id, "src": actual_local,
                "src_binding": {"type": BINDING_LOCAL_FILE,
                                "source_sha256": digest},
            })
            continue
        target = image_map[source]
        actual = target
        if source_path is not None and output_path is not None:
            actual = rebase_image_path(target, source_path=source_path,
                                       output_path=output_path)
        entry: dict[str, Any] = {"id": asset_id, "src": actual}
        binding = dict(bindings.get(source) or {})
        if binding:
            # **不替不完整的回执补 `source_sha256`。**
            # 早先这里 `setdefault(..., digest)` 把当前本地文件的哈希填了进去，
            # 理由写的是"省掉一次人工誊抄"——那个理由是错的：
            # 它拿"现在这个文件是什么"冒充"当时上传了什么"，
            # 于是**没有任何实际回执也能通过绑定检查**，
            # 而"上传时串了一张图"恰好就是这一项要查的。
            # 回执不完整就是没有回执，由校验那一步说出来。
            entry["src_binding"] = binding
        consumed.append(entry)
    identity.sort(key=lambda item: item["id"])
    consumed.sort(key=lambda item: item["id"])
    return identity, consumed, sources


def build_record(
    *,
    src_role: str,
    content_sha256: str,
    plan_sha256: str,
    identity_assets: list[dict],
    consumed_assets: list[dict],
    image_map_sha256: str,
    inputs: dict | None = None,
    theme: str,
    layout_profile: str,
    reading_profile: str = "default",
    article_plan_sha256: str = "",
    component_plan_sha256: str = "",
    theme_file_sha256: str = "",
    renderer_sha256: str = "",
    image_fit: str,
    glossary_sha256: str,
    compiler_version: str,
) -> dict:
    """组装整份记录。

    `content_sha256` 填什么由各案自己定（§3.3「两案绑什么」）：排版填**正文文件
    原始字节**的哈希——它不修改正文，不需要归一化；配图填归一化后的语义哈希。
    这里不替谁决定，只如实记下传进来的那个值。
    """
    render_input = build_render_input(
        content_sha256=content_sha256, plan_sha256=plan_sha256,
        assets=identity_assets, theme=theme, layout_profile=layout_profile,
        reading_profile=reading_profile,
        article_plan_sha256=article_plan_sha256,
        component_plan_sha256=component_plan_sha256, theme_file_sha256=theme_file_sha256,
        renderer_sha256=renderer_sha256,
        image_fit=image_fit, glossary_sha256=glossary_sha256,
        compiler_version=compiler_version)
    consumption = build_consumption(
        src_role=src_role, image_map_sha256=image_map_sha256,
        assets=consumed_assets)
    return {
        "render_input_sha256": render_input_sha256(render_input),
        "render_input": render_input,
        "consumption": consumption,
        # **门禁要能自己重算一遍**，所以输入在哪必须记下来。
        # 只记哈希的话，门禁只能比"两份记录彼此一致"——而计划已经改成 B、
        # 两份产物和记录都停在 A 时，A 和 A 当然一致。
        "inputs": dict(inputs or {}),
    }


def write_record(record: dict, output_path: str | Path, *,
                 kind: str = "", session_root: str | Path | None = None) -> Path:
    """记录落在产物旁边：`渠道包.html` → `渠道包.html.record.json`。

    **跟着产物走，不进正文文件。** 产物被复制、被归档时记录一起动；
    而写进正文会改正文字节，正文的哈希又正是记录要绑的东西。

    落盘时补 `artifact`——**在此之前记录里全是「消费了什么输入」，
    没有一个字段记「产出了什么」**。于是这个反例成立：预览被旧 HTML 覆盖，
    `render_input` 与 `consumption` 一个字节不变，所有输入比较照样通过。
    """
    target = Path(output_path)
    payload = dict(record)
    relative = target.name
    if session_root:
        try:
            relative = target.resolve().relative_to(
                Path(session_root).resolve()).as_posix()
        except ValueError:
            relative = target.name
    payload["artifact"] = {
        "kind": kind or "",
        "path": relative,
        "output_sha256": _sha256_bytes(target.read_bytes()),
    }
    path = Path(str(output_path) + ".record.json")
    path.write_text(canonical_json(payload) + "\n", encoding="utf-8")
    return path


def read_record(output_path: str | Path) -> dict | None:
    """读产物旁边那份记录；没有就返回 None。"""
    import json

    path = Path(str(output_path) + ".record.json")
    if not path.is_file():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def role_for(kind: str) -> str:
    return ROLE_CHANNEL if kind == "channel" else "preview"


__all__ = ["read_image_map", "article_image_refs", "collect_assets", "build_record", "write_record",
           "role_for"]
