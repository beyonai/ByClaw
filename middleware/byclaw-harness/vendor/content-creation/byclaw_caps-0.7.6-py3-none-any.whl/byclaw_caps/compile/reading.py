"""阅读预设是主题之上的节奏与装饰覆盖，不替换用户选择的主题。"""

from __future__ import annotations

import re


DEFAULT_READING_PROFILE = "default"
READING_PROFILES = {
    "default": {"label": "主题默认"},
    "story_modern": {
        "label": "现代叙事", "font_family": "-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif",
        "line_height": "1.75", "indent": "0", "paragraph_gap": "14px",
    },
    "story_kaiti": {
        "label": "手记楷体叙事", "font_family": "'Kaiti SC','STKaiti','KaiTi','楷体','STKaiti SC','AR PL UKai CN',serif",
        "line_height": "1.85", "indent": "2em", "paragraph_gap": "10px",
    },
    "story_serif": {
        "label": "留白宋体叙事", "font_family": "'Songti SC','STSong','Noto Serif CJK SC','SimSun',serif",
        "line_height": "1.8", "indent": "2em", "paragraph_gap": "10px",
    },
}

SCENE_ANCHOR = re.compile(r"^[ \t]*<!--[ \t]*scene:[ \t]*(section-[A-Za-z0-9_-]+)[ \t]*-->[ \t]*$")
SCENE_BREAK = re.compile(r"^[ \t]*<!--[ \t]*scene-break[ \t]*-->[ \t]*$")


def reading_styles(styles: dict, profile: str, palette: dict) -> dict:
    """default 原样返回；故事预设保留主题的纸色和强调色，减去卡片装饰。"""
    if profile == DEFAULT_READING_PROFILE:
        return styles
    spec = READING_PROFILES[profile]
    result = {role: dict(properties) for role, properties in styles.items()}
    # 全部故事正文使用相同的阅读字体，避免主题在各节点指定字体时覆盖容器。
    font = spec["font_family"]
    text = palette["text"]
    accent = palette["primary"]
    for role in ("wrapper", "p", "h1", "h2", "h3", "blockquote", "li", "strong", "em", "a"):
        result.setdefault(role, {})["font-family"] = font
    result["wrapper"].update({"font-size": "17px", "line-height": spec["line_height"], "color": text,
                              "background-image": "none", "border": "0", "box-shadow": "none",
                              "letter-spacing": "0", "text-align": "left"})
    result["p"] = {
        "font-family": font, "font-size": "17px", "line-height": spec["line_height"],
        "color": text, "text-align": "left", "text-indent": spec["indent"],
        "margin": f'0 0 {spec["paragraph_gap"]}', "padding": "0", "letter-spacing": "0",
        "background": "none", "border": "0", "font-weight": "400",
    }
    for role in ("h1", "h2", "h3"):
        result[role] = {
            "font-family": font, "font-size": "26px" if role == "h1" else "18px",
            "font-weight": "600", "line-height": "1.5", "color": text,
            "margin": "28px 0 16px", "padding": "0", "text-indent": "0",
            "text-align": "left", "background": "none", "border": "0",
            "box-shadow": "none", "letter-spacing": "0",
        }
    result["blockquote"] = {
        "font-family": font, "font-size": "17px", "line-height": spec["line_height"],
        "margin": "20px 0", "padding": "0 0 0 14px", "color": text,
        "text-indent": "0", "text-align": "left", "background": "none",
        "border": "0", "border-left": f"2px solid {accent}", "box-shadow": "none",
    }
    result["strong"] = {"font-family": font, "color": text, "font-weight": "700", "background": "none", "border": "0"}
    result["em"] = {"font-family": font, "color": text, "background": "none", "border": "0"}
    result["a"] = {"font-family": font, "color": accent, "text-decoration": "underline", "background": "none", "border": "0"}
    result["list"] = {"margin": "14px 0", "padding": "0", "background": "none", "border": "0", "box-shadow": "none"}
    result["li"].update({"font-size": "17px", "line-height": spec["line_height"], "text-indent": "0", "color": text})
    result["hr"] = {"height": "0", "width": "20%", "margin": "28px auto", "background": "none", "border": "0", "border-top": f"1px solid {accent}"}
    return result


def strip_editorial_comments(markdown: str, *, keep_scene_breaks: bool = False) -> str:
    """隐藏内部注释，保留行位置；围栏代码示例中的注释属于可见代码。"""
    lines = []
    in_fence = False
    in_comment = False
    for raw in markdown.splitlines():
        line = raw
        if not in_comment and line.strip().startswith("```"):
            in_fence = not in_fence
            lines.append(line)
            continue
        if in_fence:
            lines.append(line)
            continue
        if keep_scene_breaks and not in_comment and SCENE_BREAK.fullmatch(line):
            lines.append(line)
            continue
        if in_comment:
            _, sep, line = line.partition("-->")
            if not sep:
                lines.append("")
                continue
            in_comment = False
        line = re.sub(r"<!--.*?-->", "", line)
        if "<!--" in line:
            line = line.partition("<!--")[0]
            in_comment = True
        lines.append(line)
    return "\n".join(lines)
