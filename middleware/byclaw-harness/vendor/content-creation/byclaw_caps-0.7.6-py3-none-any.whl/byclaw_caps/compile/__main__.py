#!/usr/bin/env python3
"""渠道包编译能力 CLI：平台红线校验。

编译与投递之间的强制门禁。此前编译产出从未被检查过合规性，踩了红线要等草稿在后台渲染
错乱才发现。退出码 1 即中止，不进投递。
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from byclaw_caps._cli import add_common, dispatch, EXIT_BUSINESS, EXIT_OK
from byclaw_caps.compile import (
    DEFAULT_IMAGE_FIT, DEFAULT_LAYOUT_PROFILE, DEFAULT_THEME_PROFILE,
    DEFAULT_READING_PROFILE, READING_PROFILES,
    IMAGE_FITS, KIND_CHANNEL, KIND_PREVIEW, LAYOUT_PROFILES,
    THEME_PROFILES, VALIDATE_KINDS, CompileError, extract_title,
    markdown_to_html, preview_document, presentation_profile, theme_details,
    validate_channel_html, validate_reading_profile, VERSION,
)


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="byclaw_caps.compile", description="渠道包校验")
    sub = parser.add_subparsers(dest="command", required=True)
    from .components.cli import add_parsers
    extra_parsers = add_parsers(sub)
    validate = sub.add_parser("validate", help="校验渠道包 HTML 是否踩平台红线")
    validate.add_argument("path", help="待校验的 HTML 文件")
    validate.add_argument(
        "--kind", default=KIND_CHANNEL, choices=sorted(VALIDATE_KINDS),
        help="channel（缺省）按渠道包查，整份文档的标志一律 ERROR；"
             "preview 按预览查，只跳那五条结构规则，其余照查")

    build_html = sub.add_parser("markdown", help="markdown 编译成公众号 HTML")
    build_html.add_argument("source", help="markdown 文件")
    build_html.add_argument("output", help="输出 HTML 文件")
    build_html.add_argument("--layout")
    build_html.add_argument("--theme")
    build_html.add_argument(
        "--image-map", help="JSON 文件：本地图片路径 → 渠道图片链接。"
                            "**缺映射的图片会原样保留本地路径**，草稿里就是坏图")
    build_html.add_argument(
        "--image-fit", default=DEFAULT_IMAGE_FIT, choices=sorted(IMAGE_FITS),
        help="contain（缺省）小图保持原尺寸；fill 占满整宽，"
             "会触发 IMG_WIDTH_100 告警，只有表格、封面卡、流程图才该用")
    build_html.add_argument(
        "--plan", help="排版计划 JSON。**不传也能编译**（存量与调试），"
                       "但是不是新任务、允不允许没有计划，由任务入口与验收门禁判定")
    build_html.add_argument("--session-root", help='会话根。**记录里的输入位置按它算相对路径**——不给就从输出路径往上推两级，正文不在 20-creative/ 下时会推错，导致门禁查不到输入而放行。')
    build_html.add_argument("--terms", help='JSON 数组的术语表，给首次出现的术语加下划线。**渠道包与预览必须传同一份**——预览的价值就是「看到的就是要发的」')
    build_html.add_argument(
        "--skip-validate", action="store_true",
        help="跳过红线校验。默认编译后立刻校验——草稿群发不可撤回，"
             "把门禁放在同一步比指望调用方记得跑要可靠",
    )

    preview = sub.add_parser(
        "preview", help="markdown 编译成**给人看的完整文档**（含 H1，业务可打开）")
    preview.add_argument("source", help="markdown 文件")
    preview.add_argument("output", help="输出 HTML 文件")
    preview.add_argument(
        "--title", help="缺省取 markdown 首个一级标题——"
                        "那正是编译渠道包时被摘掉的那一个")
    preview.add_argument("--layout")
    preview.add_argument("--theme")
    preview.add_argument("--image-map", help="同 markdown 子命令")
    preview.add_argument(
        "--image-fit", default=DEFAULT_IMAGE_FIT, choices=sorted(IMAGE_FITS),
        help="同 markdown 子命令。**必须与渠道包传同一个值**——预览与渠道包的"
             "图片宽度策略不一致时，业务在预览里看到的就不是要发的那一份")
    preview.add_argument("--plan", help="同 markdown 子命令")
    preview.add_argument("--session-root", help='会话根。**记录里的输入位置按它算相对路径**——不给就从输出路径往上推两级，正文不在 20-creative/ 下时会推错，导致门禁查不到输入而放行。')
    preview.add_argument("--terms", help="同 markdown 子命令")

    cands = sub.add_parser(
        "candidates",
        help="产出排版候选清单：**模型只能从这里选 ID，不能自己提供文字**")
    cands.add_argument("source", help="markdown 文件")
    cands.add_argument("--out", help="写到此 JSON；不给就打到 stdout")

    contract = sub.add_parser(
        "contract",
        help="核对渠道包与预览的契约记录：**两层比较，失配阻断**")
    contract.add_argument("channel", help="渠道包 HTML（记录在同名 .record.json）")
    contract.add_argument("preview", help="预览 HTML")
    contract.add_argument(
        "--image-map", help="渠道包**当前**的映射文件。**必须给**——"
                            "第二层要拿它与记录里的版本比，不给就查不出「映射已改、产物没跟上」")
    contract.add_argument(
        "--preview-image-map",
        help="预览当前的映射文件。缺省同 --image-map。"
             "**两份产物各有各的映射是正常的**——渠道包走 CDN、预览走本地，"
             "所以映射版本要各比各的，不能拿一份去比两份")

    dens = sub.add_parser(
        "density",
        help="量强调面积：**默认只出数不判对错**，用来离线校准阈值（§10.2）")
    dens.add_argument("source", nargs="+", help="一个或多个 markdown 文件")
    dens.add_argument("--terms", help="术语表 JSON（数组或 {terms:[…]}）——"
                                      "术语下划线也占面积，不给就漏算这一块")
    dens.add_argument(
        "--plan", help="排版计划。**有计划就必须传**——"
                       "计划新增的高亮不在原始正文里，不传等于把二期最核心的"
                       "那部分排除在检查之外。应用在内存里做，不改正文文件")
    dens.add_argument(
        "--check", action="store_true",
        help="按阈值判一遍并以退出码 1 报失败。**校准期不要用**："
             "阈值还是占位值，拿占位值当结论会把正常文章判成超限")
    dens.add_argument("--max-span-width", type=float,
                      default=PROVISIONAL_MAX_SPAN_WIDTH)
    dens.add_argument("--max-section-ratio", type=float,
                      default=PROVISIONAL_MAX_SECTION_RATIO)
    dens.add_argument("--max-article-ratio", type=float,
                      default=PROVISIONAL_MAX_ARTICLE_RATIO)

    for one in (build_html, preview):
        one.add_argument("--component-plan", help="源文绑定的组件计划；与 --plan 高亮计划独立")
        one.add_argument("--theme-file", help="任务自定义主题 JSON")
        one.add_argument("--allow-placeholders", action="store_true", help="只为待补素材预览放行，不代表最终成品")
    contract.add_argument("--session-root", help="显式任务根，用于重验源文和组件计划")
    for one in (build_html, preview, dens):
        one.add_argument("--reading-profile", choices=sorted(READING_PROFILES),
                         help="阅读预设；default 沿用主题，story_* 调整故事字体、段距与装饰")
        one.add_argument("--article-plan", help="ArticlePlan YAML/JSON；读取 distribution_plan.presentation，显式参数优先。--plan 仍为高亮计划")

    profiles = sub.add_parser("profiles", aliases=["themes"], help="列出版式、主题与来源")

    for one in (validate, build_html, preview, cands, contract, dens, profiles, *extra_parsers):
        add_common(one)
    return parser


from .density import (
    PROVISIONAL_MAX_ARTICLE_RATIO,
    PROVISIONAL_MAX_SECTION_RATIO,
    PROVISIONAL_MAX_SPAN_WIDTH,
)
from ..shared.render_contract import (
    ContractError, compare_render_inputs, verify_consumption,
)
from ._records import (
    build_record, collect_assets, read_image_map, role_for, write_record,
)


def _read_source(args: argparse.Namespace) -> tuple[Path, str, dict]:
    source = Path(args.source)
    if not source.is_file():
        raise FileNotFoundError(f"markdown 不存在：{source}")
    image_map, _, _ = read_image_map(getattr(args, "image_map", None))
    return source, source.read_text(encoding="utf-8"), image_map


def _read_mapping(args: argparse.Namespace):
    """映射的三样东西：编译用的扁平表、绑定证据、映射文件自身的哈希。

    第三样是第二层比较的判据之一：**只改映射文件、HTML 与记录都没动**时，
    记录里的地址与 HTML 里的地址仍然彼此一致，失配的只有这一项。
    """
    return read_image_map(getattr(args, "image_map", None))


def _emit_record(args: argparse.Namespace, *, kind: str, source: Path,
                 out: Path, image_map: dict, bindings: dict,
                 image_map_sha256: str, terms_sha256: str,
                 markdown: str = "") -> dict:
    """产出契约记录，并写到产物旁边。

    渠道包与预览都走这一条——**只给渠道包记，两份就没法比**，
    而"渠道包用 warm、预览用 minimal"正是实际发生过的那个问题。
    """
    identity, consumed, asset_sources = collect_assets(
        image_map, source_path=source, bindings=bindings,
        markdown=markdown, output_path=out)
    record = build_record(
        src_role=role_for(kind),
        # 排版绑**正文文件原始字节**：它不修改正文，不需要归一化（§3.3）。
        content_sha256=_sha256_path(source),
        plan_sha256=_plan_sha256(args),
        identity_assets=identity, consumed_assets=consumed,
        image_map_sha256=image_map_sha256,
        inputs=_input_paths(args, source=source, out=out,
                            asset_sources=asset_sources),
        theme=args.theme, layout_profile=args.layout,
        reading_profile=args.reading_profile,
        article_plan_sha256=(_sha256_path(Path(args.article_plan))
                             if getattr(args, "article_plan", None) else ""),
        component_plan_sha256=(_sha256_path(Path(args.component_plan))
                               if getattr(args, "component_plan", None) else ""),
        theme_file_sha256=(_sha256_path(Path(args.theme_file))
                          if getattr(args, "theme_file", None) else ""),
        renderer_sha256=getattr(args, "_component_report", {}).get("render_binding", {}).get("renderer_sha256", ""),
        image_fit=getattr(args, "image_fit", DEFAULT_IMAGE_FIT),
        glossary_sha256=terms_sha256, compiler_version=VERSION)
    # 产物已经落盘，此刻才能算它的字节哈希——`artifact` 由 write_record 补。
    write_record(record, out, kind=kind,
                 session_root=getattr(args, "session_root", None))
    return record


def _input_paths(args: argparse.Namespace, *, source: Path, out: Path,
                 asset_sources: dict | None = None) -> dict:
    """这份产物是从哪些文件编出来的。

    **写相对会话根的路径**——记绝对路径的话，会话目录一搬家门禁就全查不到，
    而"查不到"和"没变"在实现上很容易被写成同一个分支。
    """
    # **优先用显式给的会话根。** 靠输出路径往上推两级是猜——
    # 正文不在 `20-creative/` 下时推出来的根就是错的，
    # 于是 `article` 记成一个在会话根下解析不到的路径，
    # 门禁那边 `current.is_file()` 为假……而"查不到"与"没变"
    # 很容易被写成同一个分支，结果是**改了正文也照样放行**。实测漏过。
    explicit = getattr(args, "session_root", None)
    root = Path(explicit).resolve() if explicit else out.resolve().parent.parent

    def rel(value) -> str:
        if not value:
            return ""
        try:
            return Path(value).resolve().relative_to(root).as_posix()
        except ValueError:
            return str(Path(value).resolve())

    # **源图的位置也是输入**，跟正文、计划、映射一样要记下来门禁才能重算。
    # 它与 `consumption.assets[].src` 回答的是两个问题：这里记源图在哪，
    # 那里记渲染成了什么地址。上了远程映射之后 `src` 是 `https://…`，
    # 拿它找不到源文件——而"源图有没有被换过"恰恰要在那时候还能查。
    assets = {asset_id: rel(path)
              for asset_id, path in sorted((asset_sources or {}).items())}
    paths = {"article": rel(source), "plan": rel(getattr(args, "plan", None)),
            "terms": rel(getattr(args, "terms", None)),
            "image_map": rel(getattr(args, "image_map", None)),
            "assets": assets}
    if getattr(args, "article_plan", None):
        paths["article_plan"] = rel(args.article_plan)
    for extra in ("component_plan", "theme_file"):
        if getattr(args, extra, None):
            paths[extra] = rel(getattr(args, extra))
    return paths


def _resolve_presentation(args: argparse.Namespace) -> None:
    """正文计划只提供呈现参数，不充当高亮计划；显式 CLI 参数始终优先。"""
    requested = {}
    if getattr(args, "article_plan", None):
        import yaml
        try:
            loaded = yaml.safe_load(Path(args.article_plan).read_text(encoding="utf-8"))
        except yaml.YAMLError as failure:
            raise CompileError("INVALID_ARTICLE_PLAN", "ArticlePlan 不是有效的 YAML/JSON") from failure
        if not isinstance(loaded, dict):
            raise CompileError("INVALID_ARTICLE_PLAN", "ArticlePlan 必须是对象")
        distribution = loaded.get("distribution_plan", {})
        if not isinstance(distribution, dict):
            raise CompileError("INVALID_ARTICLE_PLAN", "distribution_plan 必须是对象")
        requested = distribution.get("presentation", {})
        if not isinstance(requested, dict):
            raise CompileError("INVALID_ARTICLE_PLAN", "distribution_plan.presentation 必须是对象")
    if getattr(args, "theme_file", None):
        from .components.themes import register
        identity = register(args.theme_file)
        if args.theme is not None and args.theme != identity:
            raise CompileError("THEME_ID_CONFLICT", "--theme 与 --theme-file 不一致")
        args.theme = identity
    if getattr(args, "component_plan", None):
        from .components.plans import load
        component = load(args.component_plan)
        for attr,key in (("theme","theme_profile"),("layout","layout_profile"),("reading_profile","reading_profile")):
            if key not in requested:
                requested[key] = component.get(attr)
    for attr, key, default in (("layout", "layout_profile", DEFAULT_LAYOUT_PROFILE),
                               ("theme", "theme_profile", DEFAULT_THEME_PROFILE),
                               ("reading_profile", "reading_profile", DEFAULT_READING_PROFILE)):
        value = getattr(args, attr, None)
        if value is None:
            value = requested.get(key, default)
        if not isinstance(value, str):
            raise CompileError("INVALID_PRESENTATION_PROFILE", f"{key} 必须是字符串")
        setattr(args, attr, value)
    presentation_profile(args.layout, args.theme)
    validate_reading_profile(args.reading_profile)


def _sha256_path(path: Path) -> str:
    import hashlib

    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _plan_sha256(args: argparse.Namespace) -> str:
    """排版计划的哈希。没有计划时留空——**空不等于跳过**。

    是不是新任务、允不允许没有计划，由任务入口与验收门禁判定（§3.6）；
    CLI 接受不带计划的调用是为了存量与调试，不是给流程开的口子。
    """
    raw = getattr(args, "plan", None)
    if not raw:
        return ""
    path = Path(raw)
    if not path.is_file():
        raise FileNotFoundError(f"排版计划不存在：{path}")
    return _sha256_path(path)


def _apply_typeset_plan(args: argparse.Namespace, markdown: str) -> str:
    """三种模式：不传计划 / 空计划 / 非空计划。

    **不传计划时行为与现在完全一致**——作者写在正文里的 `==高亮==` 照常渲染。
    空计划表示「不**新增**」高亮，正文自带的仍然保留。

    选中的句子被包成 `==句子==` 交给既有的高亮渲染，**复用作者那条路**——
    另造一套渲染迟早长出两种样子，而读者看到的该是同一种强调。
    """
    import hashlib

    from byclaw_caps.compile import plan as plan_module

    # **与 `_plan_sha256` 读同一个参数。** 此前应用高亮读 `--typeset-plan`、
    # 记哈希读 `--plan`，两者互不知道：传了 typeset-plan 则记录里 `plan_sha256`
    # 为空，两份用不同计划也比得过；按 Skill 传 `--plan` 则只记哈希、不应用高亮。
    # **实际消费的那一份必须就是进指纹的那一份。**
    raw = getattr(args, "plan", None)
    if not raw:
        return markdown
    loaded = plan_module.load(raw)
    # **按原始文件字节算，与 `compile candidates` 同一口径。**
    # 早先这里用 `markdown.encode()`：`read_text()` 已经把 CRLF 转成了 LF，
    # 于是 CRLF 正文的哈希与候选命令算出来的不同——正文一个字没改，
    # 刚生成的计划也报 `PLAN_SOURCE_MISMATCH`。
    sentences = plan_module.resolve(
        loaded, markdown,
        article_sha256=_sha256_path(Path(args.source)))
    return plan_module.apply_to_markdown(markdown, sentences)


def _terms_sha256(args: argparse.Namespace) -> str:
    raw = getattr(args, "terms", None)
    if not raw:
        return ""
    return _sha256_path(Path(raw))


def _read_terms(args: argparse.Namespace) -> tuple[str, ...]:
    """术语表：JSON 数组，元素是非空字符串。

    **形状不对就报错，不静默跳过。** 静默的后果是产出一份没有下划线的渠道包，
    而调用方以为自己传了术语——要打开公众号后台才看得出来。
    """
    import json

    raw = getattr(args, "terms", None)
    if not raw:
        return ()
    path = Path(raw)
    if not path.is_file():
        raise FileNotFoundError(f"术语表不存在：{path}")
    loaded = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, list):
        raise CompileError(
            "INVALID_TERMS_SHAPE",
            f"术语表顶层必须是数组，实际是 {type(loaded).__name__}。"
            '形如 ["GraphRAG", "向量召回"]',
            path=str(path), actual_type=type(loaded).__name__)
    for index, item in enumerate(loaded):
        if not isinstance(item, str) or not item.strip():
            raise CompileError(
                "INVALID_TERM_TYPE",
                f"术语表第 {index} 项必须是非空字符串，实际是 "
                f"{type(item).__name__}：{item!r}",
                path=str(path), index=index, actual_type=type(item).__name__)
    # 空数组合法，等价于不传。
    return tuple(item.strip() for item in loaded)


def _write(args: argparse.Namespace, document: str) -> Path:
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(document, encoding="utf-8")
    return out


def _component_render(args, source, markdown, image_map):
    from .components import load, make_plan, render, scan_file
    from .components.quality import final_components, resources
    raw = getattr(args, "component_plan", None)
    if not raw and not args.theme.startswith("gzh-") and not getattr(args, "theme_file", None):
        return None
    document = scan_file(source)
    if raw:
        plan = load(raw)
    else:
        plan = make_plan(document, theme=args.theme, layout=args.layout,
                         reading_profile=args.reading_profile)
        generated = Path(str(args.output) + ".component-plan.json")
        generated.parent.mkdir(parents=True, exist_ok=True)
        generated.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        args.component_plan = str(generated)
    if plan.get("channel") != "wechat.public_article":
        raise CompileError("COMPONENT_CHANNEL_MISMATCH", "其他渠道请使用 compile channel")
    for key, expected in (("theme",args.theme),("layout",args.layout),("reading_profile",args.reading_profile)):
        if plan.get(key) != expected:
            raise CompileError("COMPONENT_PRESENTATION_MISMATCH", "组件计划与本次呈现参数不一致", field=key)
    asset_report = resources(document, source, image_map)
    fragment, report = render(plan, document, markdown, image_map, source_path=source,
                              output_path=Path(args.output), image_fit=args.image_fit,
                              terms=_read_terms(args))
    final_components(report, allow_placeholders=args.allow_placeholders)
    report["resources"] = asset_report
    args._component_report = report
    report_path = Path(str(args.output) + ".components-report.json")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return fragment


def _compile_markdown(args: argparse.Namespace):
    """编译渠道包：正文**片段**，编译后默认立刻红线校验。

    分成两步就得指望调用方记得跑第二步；漏跑的代价是草稿在后台渲染错乱，而群发不可撤回。
    确需先看产出时传 `--skip-validate`，那是显式选择。

    **结果里带上被摘掉的 `title`。** 首个一级标题走草稿的 title 字段，
    正文片段里不放——但摘掉了不吭声，下游就拿不到它，人也核对不了。
    实测中助理为了搞清「H1 去哪了」把本模块源码读了四遍。
    """
    source = Path(args.source)
    if not source.is_file():
        raise FileNotFoundError(f"markdown 不存在：{source}")
    markdown = source.read_text(encoding="utf-8")
    image_map, bindings, image_map_sha256 = _read_mapping(args)
    markdown = _apply_typeset_plan(args, markdown)
    document = _component_render(args, source, markdown, image_map)
    if document is None:
        document = markdown_to_html(
            markdown, image_map,
            layout_profile=args.layout, theme_profile=args.theme,
            reading_profile=args.reading_profile,
            image_fit=args.image_fit,
            terms=_read_terms(args),
            # 图片路径同时绑定源文和输出目录。
            source_path=source, output_path=Path(args.output),
        )
    out = _write(args, document)
    record = _emit_record(args, kind="channel", source=source, out=out,
                          image_map=image_map, bindings=bindings,
                          image_map_sha256=image_map_sha256,
                          terms_sha256=_terms_sha256(args), markdown=markdown)
    title = extract_title(markdown)
    result = {"ok": True, "output": str(out), "bytes": len(document.encode("utf-8")),
              "layout": args.layout, "theme": args.theme, "image_fit": args.image_fit,
              "reading_profile": args.reading_profile,
              "render_input_sha256": record["render_input_sha256"],
              "record": str(out) + ".record.json",
              "title": title,
              "title_source": "markdown_h1" if title else "none",
              "note": "首个 H1 已从正文摘出，走草稿 title 字段；"
                      "要一份含 H1 的完整文档用 `compile preview`"}
    if hasattr(args, "_component_report"):
        result["components"] = args._component_report
    if args.skip_validate:
        result["validated"] = False
        return result, EXIT_OK
    report = validate_channel_html(document, kind=KIND_CHANNEL)
    result["validated"] = True
    result["report"] = report
    result["ok"] = bool(report.get("ok"))
    return result, EXIT_OK if result["ok"] else EXIT_BUSINESS


def _compile_preview(args: argparse.Namespace):
    """编译预览：**给人打开看的完整文档**，含 H1。

    这条路以前不存在——`preview_document` 写好了却没接进 CLI，
    而 0 号提示词要求排版产预览。要求在、路不在，于是实测中助理
    **把渠道包整个换成了预览文档**，下游会把 `<!doctype html>` 投进公众号正文字段。

    预览与渠道包是两个文件，各写各的，谁也别覆盖谁。
    """
    source = Path(args.source)
    if not source.is_file():
        raise FileNotFoundError(f"markdown 不存在：{source}")
    markdown = source.read_text(encoding="utf-8")
    image_map, bindings, image_map_sha256 = _read_mapping(args)
    markdown = _apply_typeset_plan(args, markdown)
    fragment = _component_render(args, source, markdown, image_map)
    if fragment is None:
        fragment = markdown_to_html(
            markdown, image_map,
            layout_profile=args.layout, theme_profile=args.theme,
            reading_profile=args.reading_profile,
            # 与正文共用图片策略和路径基准。
            image_fit=args.image_fit,
            terms=_read_terms(args),
            source_path=source, output_path=Path(args.output),
        )
    title = (args.title or "").strip() or extract_title(markdown)
    document = preview_document(
        title, fragment, layout_profile=args.layout, theme_profile=args.theme,
        reading_profile=args.reading_profile)
    out = _write(args, document)
    record = _emit_record(args, kind="preview", source=source, out=out,
                          image_map=image_map, bindings=bindings,
                          image_map_sha256=image_map_sha256,
                          terms_sha256=_terms_sha256(args), markdown=markdown)
    # 按预览口径校验：它天然带 doctype 与 h1，按渠道包口径查必然自己拦自己。
    report = validate_channel_html(document, kind=KIND_PREVIEW)
    return ({"ok": bool(report.get("ok")), "output": str(out),
             "bytes": len(document.encode("utf-8")), "kind": KIND_PREVIEW,
             "title": title, "layout": args.layout, "theme": args.theme,
             "reading_profile": args.reading_profile,
             "image_fit": args.image_fit,
             "render_input_sha256": record["render_input_sha256"],
             "record": str(out) + ".record.json",
             "validated": True, "report": report,
             "components": getattr(args, "_component_report", None),
             "note": "这是预览，不是渠道包。投递用 `compile markdown` 产的那份"},
            EXIT_OK if report.get("ok") else EXIT_BUSINESS)


def _measure_density(args: argparse.Namespace):
    """量一批文章的强调面积。

    **默认不判对错。** §10.2 要的是「先拿到一批历史文章的分布，再决定阈值」——
    测量里混进判断就取不到未经过滤的分布：被判超限的那些恰恰是分布的上半截，
    而那正是定阈值时最需要看的部分。

    `--check` 是校准完成之后才用的开关。
    """
    import json as _json

    from byclaw_caps.compile.density import apply_plan as density_apply
    from byclaw_caps.compile.density import check as density_check
    from byclaw_caps.compile.density import measure

    terms = _read_terms_list(getattr(args, "terms", None))
    rows = []
    failed = False
    for raw in args.source:
        path = Path(raw)
        if not path.is_file():
            raise FileNotFoundError(f"markdown 不存在：{path}")
        markdown = path.read_text(encoding="utf-8")
        targets = _plan_targets(args, path, markdown)
        # **量应用之后的，判断交给 check（它自己应用）。**
        # 两边各应用一次看着重复，但 `check` 的减量要反复重新应用，
        # 传一份「已经应用好的」进去就没法再往回删候选了。
        planned = [(one["heading_index"], one["text"]) for one in targets]
        sections, whole = measure(
            density_apply(markdown, targets), terms=terms, planned=planned)
        row = {
            "path": str(path),
            "plan_applied": bool(getattr(args, "plan", None)),
            "planned_highlights": len(targets),
            "article": {"prose_width": whole.prose_width,
                        "emphasis_width": whole.emphasis_width,
                        "ratio": whole.ratio},
            "sections": [{"heading_index": one.heading_index,
                          "prose_width": one.prose_width,
                          "emphasis_width": one.emphasis_width,
                          "ratio": one.ratio}
                         for one in sections if one.prose_width > 0],
            "widest_highlight": max(
                [w for kind, _, w in whole.spans
                 if kind.startswith("highlight")] or [0.0]),
        }
        if args.check:
            findings = density_check(
                markdown, terms=terms, targets=targets,
                max_span_width=args.max_span_width,
                max_section_ratio=args.max_section_ratio,
                max_article_ratio=args.max_article_ratio,
                reading_profile=args.reading_profile)
            # **两档分开报。** `advice` 是提醒（比如首屏一处强调都没有），
            # 混进退出码的话，一条提醒就能把正常交付挡下来；
            # 而全都降成提醒，超限又拦不住了。
            row["findings"] = [{"code": f.code, "message": f.message, **f.detail}
                               for f in findings if f.blocking]
            row["advice"] = [{"code": f.code, "message": f.message, **f.detail}
                             for f in findings if not f.blocking]
            failed = failed or bool(row["findings"])
        rows.append(row)

    result = {"ok": not failed, "measured": rows, "reading_profile": args.reading_profile}
    if not args.check:
        result["note"] = ("只出数，未判对错。阈值仍是占位值（PROVISIONAL_*），"
                          "按这批分布定下来之后再用 --check。")
    return result, (EXIT_BUSINESS if failed else EXIT_OK)


def _plan_targets(args: argparse.Namespace, source: Path,
                  markdown: str) -> list[dict]:
    """读排版计划，解析成候选条目。**不在这里应用**。

    返回条目而不是应用后的正文，是因为减量要反复地「去掉一个 ID 再重新应用」——
    拿到一份已经应用好的正文就回不去了。

    **复用编译那条路**：`plan.load` → `plan.resolve`（四道校验照跑）。
    另写一套「大概校验一下」的话，这里量的就不是将要编译出来的那份东西。

    计划只在内存里应用（`density.apply_plan`），正文文件一个字节都不动——
    它被验收哈希绑定，改一个字符就 `ACCEPTANCE_STALE`；
    而这里只是想看看「照这份计划排出来会有多密」。
    """
    raw = getattr(args, "plan", None)
    if not raw:
        return []
    from byclaw_caps.compile import plan as plan_module

    loaded = plan_module.load(raw)
    return list(plan_module.resolve(loaded, markdown,
                                    article_sha256=_sha256_path(source)))


def _read_terms_list(raw) -> list[str]:
    """读术语表。接受 `["a","b"]` 与 `{"terms":["a","b"]}` 两种写法。"""
    import json as _json

    if not raw:
        return []
    loaded = _json.loads(Path(raw).read_text(encoding="utf-8"))
    if isinstance(loaded, dict):
        loaded = loaded.get("terms") or []
    return [str(one) for one in loaded if one]


def _collect_candidates(args: argparse.Namespace):
    """候选清单：安全底座的地基。

    模型拿到的是 ID，不是文字；编译器按 ID 从**自己解析出来的**候选里取字。
    「打错字改变含义」因此在结构上不可能发生。
    """
    import hashlib
    import json as _json

    from byclaw_caps.compile.candidates import build as build_candidates

    source = Path(args.source)
    if not source.is_file():
        raise FileNotFoundError(f"markdown 不存在：{source}")
    raw = source.read_bytes()
    result = build_candidates(raw.decode("utf-8"),
                              article_sha256=hashlib.sha256(raw).hexdigest())
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(_json.dumps(result, ensure_ascii=False, indent=2),
                       encoding="utf-8")
        result = {**result, "out": str(out),
                  "candidates": len(result["candidates"])}
    return {"ok": True, **result}, EXIT_OK


def _load_record(path: str) -> tuple[Path, dict, str]:
    html_path = Path(path)
    record_path = Path(str(path) + ".record.json")
    if not html_path.is_file():
        raise FileNotFoundError(f"产物不存在：{html_path}")
    if not record_path.is_file():
        raise CompileError(
            "MISSING_RENDER_RECORD",
            f"{html_path.name} 没有契约记录（{record_path.name}）。"
            "**记录缺失不是通过**——没有记录就无法证明这份产物用了哪一套输入",
            expected=str(record_path))
    record = json.loads(record_path.read_text(encoding="utf-8"))
    return html_path, record, html_path.read_text(encoding="utf-8")


def _compile_contract(args: argparse.Namespace):
    """两层比较，任一层失配即阻断。

    第一层跨产物比、第二层各自比——**两层都要跑**：
    只做第一层，两份可以一起过期；只做第二层，两份可以各自新鲜而互不一致。
    """
    channel_path, channel_record, channel_html = _load_record(args.channel)
    preview_path, preview_record, preview_html = _load_record(args.preview)

    channel_map_sha256 = read_image_map(args.image_map)[2]
    preview_map_sha256 = read_image_map(
        getattr(args, "preview_image_map", None) or args.image_map)[2]

    result: dict = {"ok": True, "channel": str(channel_path),
                    "preview": str(preview_path), "findings": []}
    try:
        compare_render_inputs(channel_record["render_input"],
                              preview_record["render_input"])
    except ContractError as failure:
        result["ok"] = False
        result["findings"].append(failure.as_dict())

    for label, record, html, map_sha256, artifact in (
            ("channel", channel_record, channel_html, channel_map_sha256,
             channel_path),
            ("preview", preview_record, preview_html, preview_map_sha256,
             preview_path)):
        if record["render_input"].get("renderer_sha256"):
            from .components.structures import fingerprint
            if fingerprint(record["render_input"]["theme"])["renderer_sha256"] != record["render_input"]["renderer_sha256"]:
                result["ok"] = False
                result["findings"].append({"artifact": label, "code": "COMPONENT_RENDERER_STALE",
                                           "message": "主题或渲染实现已更新，须重新编译及视觉检查"})
        for finding in verify_consumption(
                record["consumption"], render_input=record["render_input"],
                html=html, current_image_map_sha256=map_sha256,
                # 相对地址是相对**这份 HTML 自己**算的，所以基准是它所在的目录，
                # 不是 CWD——从别处调这条命令时 CWD 与产物目录不是一回事。
                base_dir=Path(artifact).resolve().parent):
            result["ok"] = False
            result["findings"].append({"artifact": label, "code": finding.code,
                                       "message": finding.message,
                                       **finding.detail})
        # Comparing two stale records is insufficient: verify the actual current
        # source and component/theme inputs as well. Old records remain valid.
        if record["render_input"].get("component_plan_sha256"):
            explicit = getattr(args, "session_root", None)
            relative = Path(record.get("artifact", {}).get("path", artifact.name))
            root = Path(explicit).resolve() if explicit else (
                artifact.resolve().parents[len(relative.parts)-1]
                if len(relative.parts)>1 else artifact.resolve().parent.parent)
            for key, field in (("article", "content_sha256"),
                               ("plan", "plan_sha256"),
                               ("component_plan", "component_plan_sha256"),
                               ("article_plan", "article_plan_sha256"),
                               ("theme_file", "theme_file_sha256"),
                               ("terms", "glossary_sha256")):
                expected = record["render_input"].get(field)
                if not expected:
                    continue
                value = record.get("inputs", {}).get(key)
                current = (root / value).resolve() if value else None
                if current is None or not current.is_file() or _sha256_path(current) != expected:
                    result["ok"] = False
                    result["findings"].append({"artifact": label, "code": "COMPONENT_INPUT_STALE",
                                               "field": key, "message": "当前输入与编译记录不一致"})
    if result["ok"]:
        result["render_input_sha256"] = channel_record["render_input_sha256"]
    else:
        result["note"] = ("失配一律拒绝，不静默复用旧计划或旧产物——"
                          "任一项失配即阻断，不要求多项同时失败")
    return result, EXIT_OK if result["ok"] else EXIT_BUSINESS


def handle(args: argparse.Namespace):
    from .components import cli as component_cli
    if args.command in component_cli.COMMANDS:
        return component_cli.handle(args)
    if args.command in {"markdown", "preview", "density"}:
        _resolve_presentation(args)
    if args.command == "candidates":
        return _collect_candidates(args)
    if args.command == "density":
        return _measure_density(args)
    if args.command in {"profiles", "themes"}:
        return {"ok": True, "layouts": sorted(LAYOUT_PROFILES),
                "themes": sorted(THEME_PROFILES),
                "reading_profiles": READING_PROFILES,
                "theme_details": theme_details(THEME_PROFILES)}, 0
    if args.command == "markdown":
        return _compile_markdown(args)
    if args.command == "preview":
        return _compile_preview(args)
    if args.command == "contract":
        return _compile_contract(args)
    target = Path(args.path)
    if not target.is_file():
        raise FileNotFoundError(f"HTML 不存在：{target}")
    report = validate_channel_html(
        target.read_text(encoding="utf-8", errors="replace"), kind=args.kind)
    return report, EXIT_OK if report["ok"] else EXIT_BUSINESS


def main() -> int:
    """控制台入口点。

    `python -m byclaw_caps.<能力>` 与安装后的 `byclaw-<能力>` 走同一条路——
    两条路行为分叉的话，文档里写的那条迟早是错的。
    """
    return dispatch(build(), handle, usage_errors=(FileNotFoundError, CompileError))


if __name__ == "__main__":
    raise SystemExit(main())
