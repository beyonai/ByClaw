> 由 `package-wechat-public-account/references/layout-theme-contract.md` 迁入——该 Skill 已退役，版式与主题表现在住在本能力的 `LAYOUT_PROFILES` / `THEME_PROFILES` 里。

# 公众号布局与主题契约 1.2

布局控制阅读节奏，主题控制字体、颜色、标题样式和装饰。业务人员使用自然语言选择，不接触 CSS 或内部模板代码。

## 故事阅读预设

`ArticlePlan.distribution_plan.presentation.reading_profile` 可选择下列预设。未设置时为
`default`，完全沿用布局和主题；故事预设在主题样式之后应用，不改主题 ID 或替换配色。

| ID | 名称 | 正文 | 首行缩进 | 段后间距 |
|---|---|---|---|---|
| `default` | 主题默认 | 由主题和布局决定 | 由主题决定 | 由主题和布局决定 |
| `story_modern` | 现代叙事 | 17px / 1.75 行高，系统无衬线 | 无 | 14px |
| `story_kaiti` | 手记楷体叙事 | 17px / 1.85 行高，系统楷体 | 2em | 10px |
| `story_serif` | 留白宋体叙事 | 17px / 1.8 行高，系统宋体 | 2em | 10px |

这些数值是本项目的阅读起点，不是微信官方标准。系统没有指定字体时会回退。
故事预设减少标题、序号和结论卡片装饰；保留主题纸色、深色正文与一个主要强调色。
不会自动添加摘要、小标题、高亮或营销行动入口。

CLI 的 `--article-plan` 读取以上字段以及 `layout_profile`、`theme_profile`；显式参数覆盖计划。
`--plan` 始终指高亮排版计划。渠道包、预览和密度检查传同一阅读预设；预设改变必须重编两份产物。

## 布局

- `balanced`（均衡版）：默认选项，适合大多数文章。
- `compact`（紧凑版）：减少段落、标题和图片留白，适合资讯、清单和短内容。
- `comfortable`（舒展版）：增加留白和行高，适合长文、叙事和复盘。
- `column`（专栏版）：适合观点、品牌专栏和系列内容。兼容主题强化居中章节标题与分隔；开源适配主题保留自己的标题样式，只调整阅读节奏。

未指定布局时使用 `balanced`。用户说“紧凑一点”“留白多一点”“专栏感”时分别映射到 `compact`、`comfortable`、`column`。

## 主题

3 个兼容主题继续保留：

| ID | 名称 | 用途 |
|---|---|---|
| `warm` | 暖色品牌 | 低饱和暖色，兼容缺省 |
| `minimal` | 极简黑白 | 正式内容、对外声明 |
| `tech_blue` | 科技蓝 | 保持现有技术系列的配色 |

另有 20 个开源主题的本地微信适配。ID 区分大小写，尤其是 `mdnice-blueCyan`。
这些主题保留各自的上游许可与来源记录；颜色、字体和可兼容的标题装饰进入现有编译器，
不承诺完整复刻上游编辑器的布局、动画或依赖。

| ID | 展示名 | 来源 |
|---|---|---|
| `xiaohu-kaiti-journal` | 手记楷体 | 小互预设 |
| `xiaohu-terracotta` | 赤陶 | 小互预设 |
| `xiaohu-newspaper` | 报纸 | 小互预设 |
| `xiaohu-swiss-grid` | 瑞士国际主义 | 小互预设 |
| `wemd-data-blueprint` | 数据蓝图 | WeMD |
| `wemd-eastern-notes` | 东方笺谱 | WeMD |
| `wemd-morandi-forest` | 莫兰迪森林 | WeMD |
| `wemd-modern-editorial` | 编辑部手记 | WeMD |
| `wemd-receipt` | 购物小票 | WeMD |
| `wemd-luxury-gold` | 黑金奢华 | WeMD |
| `wenyan-lapis` | Lapis | Wenyan / 文颜 |
| `wenyan-orangeheart` | Orange Heart | Wenyan / 文颜 |
| `wenyan-pie` | Pie | Wenyan / 文颜 |
| `wenyan-phycat` | 物理猫-薄荷 | Wenyan / 文颜 |
| `mdnice-blueCyan` | 兰青 | mdnice 历史开源版 |
| `mdnice-ink` | 墨黑 | mdnice 历史开源版 |
| `mdnice-shanchui` | 山吹 | mdnice 历史开源版 |
| `mdnice-rose` | 蔷薇紫 | mdnice 历史开源版 |
| `doocs-default` | 经典 | Doocs |
| `doocs-grace` | 优雅 | Doocs |

### 选择顺序

1. **用户明确指定优先**：中文名映射为上表的 ID，不覆盖明确选择。
2. **延续系列已有选择**：用户未要求更换时，沿用已确认的主题与版式。
3. **新系列按内容推荐**：随笔、复盘推荐 `xiaohu-kaiti-journal`；技术、数据文章推荐
   `wemd-data-blueprint`；自然生活内容可用 `wemd-morandi-forest`。
4. **信息不足时兼容缺省**：`balanced` + `warm`。喜欢一个主题不等于把全部系列永久换成它。

当前安装版本的可用目录：

```bash
python3 -m byclaw_caps.compile themes
```

返回 `themes`（可传给 `--theme` 的 ID 数组）与 `theme_details`（主题说明）。
文档列出的主题若不在实际目录里，先通过 `writing-support` 对齐能力层版本，不能手拼样式替代。

「手记楷体」只使用系统字体，不下载外部字体；不同设备缺少楷体时会回退。
新主题首次使用要在手机微信草稿里实际验样，检查字体、深色模式和窄屏阅读。
本地预览已检查但尚未看微信草稿时，回执分别说明两者的验证状态。

每个主题固定包含 `surface_dark` 与 `on_dark` 两个兼容语义位，分别表示代码面板背景与前景；新增主题必须同时给出这两位。字段沿用旧名，开源适配主题允许采用浅色代码面板，不能因为名字带 `dark` 就强行改成深色。
不得根据单篇文章临时生成新颜色；新增主题进入能力层、测试和版本契约。

## 语义映射

- `h2` / `h3`：章节和次级标题；对齐、边线、字号由所选主题决定。
- `blockquote`：摘要、引言或引用区；有无底色、边框由主题决定。
- 独占一段的粗体：核心结论区；主题可以采用卡片或无底色形式。
- 列表：保持项目与顺序可辨，卡片边框不作为所有主题的必备样式。
- 图片：遵循 `image_fit`；非空 alt 文本作为图注。
- Markdown 分隔线：章节分隔，颜色与形态随主题。

## 装饰原则

**装饰必须承担信息职能。** 编码层级、状态或语义的装饰是有效的；纯粹好看的装饰是噪音，不得使用。

判定方法：去掉这处装饰，读者是否更难判断"这是什么、该怎么读"？答案为是则它承担了职能，为否则是噪音。

### 本介质的阈值

正文有章节结构可供依附，因此**允许结构化装饰**，包括：

- **渐变分隔线**：两端淡出，柔和标记章节边界，比纯色横线更少切断阅读
- **深色代码面板**：把代码块与正文在视觉上分层，读者不必读内容就知道该怎么读这一块
- **宽字距小标签**：标记栏目、状态或类别

仍然不得使用：给每个普通段落加卡片、装饰性背景纹理、与语义无关的多色堆叠。

贴图卡片的阈值更严（禁渐变与阴影），因为 1080×1440 文字密、缩略图尺寸下会糊，且卡片上没有结构层级给渐变编码。见 `write-image-text-post/references/card-design-system.md`。**原则统一，阈值分开。**

### 色板边界

**不引入色板外的颜色。** 这是一致性机制，不是审美偏好——每块装饰各自取色，单看都成立，放一篇里就散。

色板不够用时**补语义位，不要破例**。`surface_dark` / `on_dark` 就是为代码面板补的位；缺位会逼人挪用别的颜色，语义随之错乱。

所有样式必须使用微信兼容的内联 CSS，不使用 class、`style` 标签、脚本、复杂布局或依赖页面级背景。

## 选择记在哪

版式与主题的选择由 `ArticlePlan.distribution_plan.presentation` 承载
（`layout_profile` / `theme_profile` / `rationale`），排版时原样传给
`compile markdown` 与 `compile preview` 的 `--layout` / `--theme`。

**两份产物必须用同一组**：预览的全部价值就是「看到的就是要发的」。

发布 Skill 只消费编译好的渠道包，**不得在发布阶段重新排版**。

> **原先这里写的是 `ChannelPackage.presentation` 与 `rule_versions` 两个字段。**
> 那是退役的 `package-wechat-public-account` 留下的契约，**代码里没有这两个槽位**
> （全仓零命中），连「四种 `layout_preview_paths`」也早就只剩一份预览。
> 照它开发会去找一个不存在的落点。
