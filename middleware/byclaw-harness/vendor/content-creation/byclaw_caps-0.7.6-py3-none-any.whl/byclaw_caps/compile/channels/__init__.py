"""Local channel packaging. Network operations belong to byCLI."""
from __future__ import annotations

import hashlib
from html import escape
import json
import os
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit

from .. import CompileError, extract_title, markdown_to_html, presentation_profile, preview_document, validate_channel_html
from ..components import load, make_plan, render, scan_file, validate
from ..components.htmltree import parse
from ..components.preview import copy_preview
from ..components.quality import final_components, resources

PROFILES = {
    "wechat.public_article": {"format": "html", "delivery": "bycli weixin", "target_verified": False},
    "wechat.image_text": {"format": "cards", "width": 1080, "height": 1440,
                         "max_images": 20, "max_title": 20, "max_body": 80,
                         "source": "现有 references/channels/wechat/image-text.md", "target_verified": False},
    "xiaohongshu.note": {"format": "cards+text", "width": 1080, "height": 1440,
                        "max_images": 9, "max_title": 20, "max_body": 80,
                        "source": "byCLI/clis/xiaohongshu/publish.js MAX_IMAGES/MAX_TITLE_LEN；画幅与单卡密度为本产品规范",
                        "target_verified": False},
    "toutiao.article": {"format": "text+html", "min_title": 2, "max_title": 30,
                        "source": "byCLI/clis/toutiao/article-publish.js；当前接口正文通过 typeText/innerText 写入",
                        "richtext_delivery": "copy_only", "target_verified": False},
}


def _save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _rendered(markdown, document, image_map=None):
    emitted = []
    def receive(fragment, kind, data):
        emitted.append(fragment)
        return fragment
    markdown_to_html(markdown, image_map or {}, block_sink=receive)
    return {block["block_id"]: fragment for block, fragment in zip(document["blocks"], emitted)}


def _split_text(text, limit=80):
    """Lossless pagination, no rewriting or AI-generated facts."""
    chunks = []
    while len(text) > limit:
        cut = max([text.rfind(c, 0, limit + 1) for c in "。！？；\n"] + [0])
        cut = cut + 1 if cut >= limit // 2 else limit
        chunks.append(text[:cut])
        text = text[cut:]
    if text:
        chunks.append(text)
    return chunks


def _card_html(title, body, *, index, total, theme, image=None):
    _, colors = presentation_profile("balanced", theme)
    if index == 0:
        body_markup, title_size = '', 100
    elif image:
        body_markup = f'<img src="{escape(image,quote=True)}" style="max-width:100%;max-height:640px;object-fit:contain;display:block;margin:0 auto;">'
        body_markup += f'<p style="font-size:40px;line-height:1.7;margin:30px 0 0;white-space:pre-wrap;">{escape(body)}</p>'
        title_size = 64
    else:
        body_markup = f'<p style="font-size:48px;line-height:1.85;margin:0;white-space:pre-wrap;">{escape(body)}</p>'
        title_size = 64
    content = (f'<section style="margin-top:56px;padding:48px;background:#fff;'
               f'border:1px solid {colors["border"]};border-radius:20px;box-sizing:border-box;'
               'min-height:580px;display:flex;flex-direction:column;justify-content:center;">'
               f'{body_markup}</section>') if body_markup else ''
    return ('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"></head>'
            f'<body style="margin:0;background:{colors["surface"]};">'
            '<main style="width:1080px;height:1440px;padding:80px 64px;box-sizing:border-box;'
            f'display:flex;flex-direction:column;font-family:Microsoft YaHei,Noto Sans CJK SC,sans-serif;color:{colors["text"]};">'
            f'<section style="border-top:8px solid {colors["primary"]};padding-top:{"240" if index==0 else "64"}px;">'
            f'<h1 style="font-size:{title_size}px;line-height:1.5;margin:0;color:{colors["primary_dark"]};'
            f'word-break:break-word;">{escape(title)}</h1>{content}</section>'
            f'<p style="font-size:28px;color:{colors["muted"]};margin:auto 0 0;padding-top:28px;'
            f'border-top:1px solid {colors["border"]};">{index + 1:02d} / {total:02d}</p>'
            '</main></body></html>\n')


def export(source, output, *, channel, plan_path=None, theme=None,
           recipe="auto", image_map=None, render_images=False, browser=None,
           layout=None, reading_profile=None, theme_file=None):
    if channel not in PROFILES:
        raise CompileError("UNKNOWN_CHANNEL", "未知渠道", channel=channel)
    if theme_file:
        from ..components.themes import register
        identity = register(theme_file)
        if theme and theme != identity:
            raise CompileError('THEME_ID_CONFLICT', '主题文件与显式主题不一致')
        theme = identity
    source, output = Path(source).resolve(), Path(output).resolve()
    markdown = source.read_text(encoding="utf-8-sig")
    document = scan_file(source)
    plan = load(plan_path) if plan_path else make_plan(document, channel=channel, theme=theme or 'gzh-red-white',
                      recipe=recipe, layout=layout or 'balanced', reading_profile=reading_profile or 'default')
    validate(plan, document)
    for key, value in (('theme',theme),('layout',layout),('reading_profile',reading_profile)):
        if value and value != plan[key]:
            raise CompileError('COMPONENT_PRESENTATION_MISMATCH', '计划与显式呈现参数不一致',field=key)
    if plan["channel"] != channel:
        raise CompileError("COMPONENT_CHANNEL_MISMATCH", "计划与导出渠道不一致")
    assets = resources(document, source, image_map)
    _, component_report = render(plan, document, markdown, image_map or {},
                                 source_path=source, output_path=output / 'article.html')
    final_components(component_report)
    profile = PROFILES[channel]
    title = extract_title(markdown)
    if not title:
        raise CompileError("CHANNEL_TITLE_MISSING", "渠道作品需要已审校标题")
    if len(title) > profile.get("max_title", 200) or len(title) < profile.get("min_title", 1):
        raise CompileError("CHANNEL_TITLE_LENGTH", "标题超出当前渠道范围；请先生成并审校派生标题",
                           title_length=len(title), profile=profile)
    rendered = _rendered(markdown, document, image_map)
    pieces = [parse(rendered[b["block_id"]]).plain_text().strip() for b in document["blocks"] if b["kind"] != "title"]
    output.mkdir(parents=True, exist_ok=True)
    outputs = []
    def write(name, text):
        (output / name).write_text(text, encoding="utf-8")
        outputs.append(name)
    _save(output / "component-plan.json", plan)
    if profile["format"] in ("cards", "cards+text"):
        cards = [{"title": title, "body": "", "cover": True, "source_refs": []}]
        heading = title
        pending_heading = None
        for block in document["blocks"]:
            kind, ident = block["kind"], block["block_id"]
            if kind in ("title", "divider", "scene_break"):
                continue
            tree = parse(rendered[ident])
            text = tree.plain_text().strip()
            # Alt text is carried by the dedicated image card, not duplicated.
            for img in tree.find("img"):
                text = text.replace("[图片：" + img.attrs.get("alt", "") + "]", "")
            if kind in ("heading", "subheading"):
                if pending_heading:
                    cards.append({"title":heading,"body":"","section":True,"source_refs":[pending_heading]})
                heading = text
                if len(heading) > 20:
                    raise CompileError("CARD_HEADING_LENGTH", "卡片小标题超过20字，需先审校派生稿", title=heading)
                pending_heading = ident
                continue
            refs = ([pending_heading] if pending_heading else []) + [ident]
            pending_heading = None
            if kind != "image":
                for part in _split_text(text, profile["max_body"]):
                    cards.append({"title": heading, "body": part, "source_refs": refs})
            for img in tree.find("img"):
                ref = img.attrs["src"]
                if ref.startswith(("https://", "http://")):
                    image = ref
                else:
                    parsed = urlsplit(ref)
                    path = unquote(parsed.path if parsed.scheme == 'file' else ref)
                    if re.match(r'^/[A-Za-z]:/',path):
                        path = path[1:]
                    local = Path(path)
                    if not local.is_absolute():
                        local = source.parent / local
                    image = Path(os.path.relpath(local.resolve(),output)).as_posix()
                caption = img.attrs.get("alt", "")
                parts = _split_text(caption, profile["max_body"]) or [""]
                cards.append({"title": heading, "body": parts[0], "image": image, "source_refs": refs})
                cards.extend({"title": heading, "body": p, "source_refs": [ident]} for p in parts[1:])
        if pending_heading:
            cards.append({"title":heading,"body":"","section":True,"source_refs":[pending_heading]})
        if len(cards) > profile["max_images"]:
            raise CompileError("CHANNEL_CARD_COUNT", "无损分页超过渠道张数，请先走图文改编流程",
                               cards=len(cards), maximum=profile["max_images"])
        for index, card in enumerate(cards):
            filename = f"card-{index + 1:02d}.html"
            write(filename, _card_html(card["title"], card["body"], index=index, total=len(cards),
                                      theme=plan["theme"], image=card.get("image")))
            card["html"] = filename
            if render_images:
                from byclaw_caps.raster import rasterize_html
                png = filename.replace(".html", ".png")
                result = rasterize_html(output / filename, output / png, width=1080, height=1440, browser=browser)
                if result.get("truncated") is not False:
                    raise CompileError("CARD_TRUNCATED", "卡片内容截断或无法确认，请修改卡片计划", card=index + 1)
                card["image_file"] = png
                outputs.append(png)
        _save(output / "cards.json", {"channel":channel, "width":1080, "height":1440,
                                     "cards":cards, "rendered":render_images})
        write("title.txt", title + "\n")
        write("content.txt", "\n\n".join(p for p in pieces if p) + "\n")
        _save(output / "note.json", {"title":title, "content":"\n\n".join(p for p in pieces if p),
                                    "topics":[], "images":[c['image_file'] for c in cards if 'image_file' in c],
                                    "ready_for_delivery":False, "rendered":render_images, "needs_editor_review":True})
        outputs += ["cards.json", "note.json"]
        report = {"content_fidelity":"lossless_pagination", "cards":len(cards),
                  "components":[{"instance_id":e["instance_id"], "component_id":e["component_id"],
                                 "source_refs":e["source_refs"], "status":"fallback",
                                 "reason":"无损分页为标准图卡；复杂组件需图文工作流设计后重排"}
                                for e in plan["components"]],
                  "rendered_images":render_images, "visual_review":"pending"}
    else:
        fragment, report = render(plan, document, markdown, image_map or {}, source_path=source,
                                  output_path=output / "article.html")
        final_components(report)
        gate = validate_channel_html(fragment)
        if not gate["ok"]:
            raise CompileError("CHANNEL_HTML_INVALID", "渠道 HTML 未通过兼容校验", report=gate)
        write("article.html", fragment)
        write("preview.html", preview_document(title, fragment, layout_profile=plan["layout"], theme_profile=plan["theme"]))
        write("copy.html", copy_preview(fragment, title))
        write("title.txt", title + "\n")
        write("article.txt", "\n\n".join(p for p in pieces if p) + "\n")
        if channel == "toutiao.article":
            report["delivery_format"] = "plain_text_bycli_or_manual_richtext_copy"
            report["richtext_api"] = "not_supported_by_current_bycli"
    manifest = {"schema_version":"1.0", "channel":channel, "source_sha256":document["article_sha256"],
                "component_plan_sha256":hashlib.sha256((output/"component-plan.json").read_bytes()).hexdigest(),
                "theme_file_sha256":hashlib.sha256(Path(theme_file).read_bytes()).hexdigest() if theme_file else "",
                "files":[{"path":name,"sha256":hashlib.sha256((output/name).read_bytes()).hexdigest()} for name in outputs],
                "resources":assets, "report":report, "target_environment":"pending", "published":False}
    _save(output / "manifest.json", manifest)
    return {"ok":True,"output":str(output),"outputs":outputs + ["component-plan.json","manifest.json"],
            "report":report, "published":False}
