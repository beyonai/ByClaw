#!/usr/bin/env python3
"""强调密度：把「优先短句」「减少叠加」从形容词变成数（方案 §8.1）。

## 为什么必须先有口径

「优先选短句」「总量别太多」这类说法，**不同次运行会解释成不同结果**。
规划器每次看到的正文不一样，判断尺度就跟着飘；而排版要跨整个系列保持一致，
尺度飘了就等于没有规则。

所以 §8.1 列的四个问题，这里逐个给一个确定的答案：

| §8.1 的问题 | 本模块的答案 |
|---|---|
| 高亮长度怎么算 | `visual_width()`：**按视觉宽度**，不是字符数 |
| 总占比怎么算 | **节内与全文各算一份**，两个都要过 |
| 既有强调怎么计入 | 粗体、高亮、术语下划线**全部计入面积**；只有高亮另占「每节一句」 |
| 超限后怎么办 | `trim()` 给出**减哪几处**，从最长的开始 |

## 为什么是视觉宽度而不是字符数

「面积」问的是页面上被染色的那块有多大。`RAG` 三个字符与「检索增强」四个字符
在手机上宽度差得远，按字符数算会把英文术语的占比系统性低估——
而英文术语恰恰是术语表里最常见的那一类。

所以全角按 1、半角按 0.5 折算。**这不是精确排版测量**（真实宽度还取决于字体），
但它把「中英混排怎么折算」回答成了一个确定的数，这就够用了：
口径的作用是让两次运行得到同一个结论，不是预测像素。

## 阈值是待校准的，不是拍死的

方案写明「阈值可以用离线样本校准，现在不必拍死」。所以：

* 默认阈值一律标 `PROVISIONAL_`，**是占位不是结论**；
* `measure()` 不带阈值，只出数——离线跑一批历史文章取分布，
  再回来定 `check()` 用的那两个数（§10.2）。

阈值走 `check()` 的参数而不是硬编码进判断，就是为了换数时不必改逻辑。
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

#: 单处高亮的视觉宽度上限。**超过就不该选**——「首版优先选短句，长句宁可不选」。
#:
#: 与候选生成那侧的 `MAX_CANDIDATE_CHARS` 口径不同，是有意的：
#: 那里按字符数粗筛（要快），这里按面积复核（要准）。
PROVISIONAL_MAX_SPAN_WIDTH = 40.0

#: 节内强调面积占比上限。待离线校准。
PROVISIONAL_MAX_SECTION_RATIO = 0.20

#: 全文强调面积占比上限。待离线校准。
#:
#: **比节内那个小。** 允许某一节偏密——那节确实在下判断；
#: 但不允许整篇都密，整篇都密等于整篇都不强调。
PROVISIONAL_MAX_ARTICLE_RATIO = 0.12

#: 首屏（读者划走之前看到的那一段）至少要有一处强调。
#:
#: ⛔ **这一项是「下限」，与上面三条方向相反。**
#:
#: 上面三条只回答「会不会太多」。只有上限的检查有一个盲区：
#: 一篇全文占比 6.0%、每节都克制、**首屏一处计划高亮都没有**的文章，
#: 在这套口径里是满分——而读者在首屏看不到任何重点。
#:
#: 实测遇到过：0913 那篇全文 6.0%、各节都在阈值内，两份分析报告一份判
#: 「密度健康」、一份判「重点样式太轻、首屏覆盖不足」。两份都对，
#: 因为量的不是同一件事。补上这一项，两个问题才由同一套口径回答。
#:
#: 数是按视觉宽度算的：420px 视口、16px 正文、行高 1.85 时一屏大约
#: 装 25 行 × 24 全角字 ≈ 600。**只是量级，不是精确值**，与三条上限一样待校准。
PROVISIONAL_FIRST_SCREEN_WIDTH = 600.0

#: 小节的最小分母。低于此不判占比。
#:
#: **短节的占比天然不稳。** 实测那篇第 6 节只有 177 宽，一处强调就到 18.1%，
#: 逼近 20% 的上限——而它其实只是一句过渡。拿一个几十字的小节去和整篇
#: 用同一个比例判，判的是分母的抖动，不是排版的密度。
#:
#: 低于这个宽度的小节改判「单处宽度」那一条（`max_span_width`），
#: 那条不受分母影响。
PROVISIONAL_MIN_SECTION_WIDTH = 300.0

_BOLD = re.compile(r"\*\*([^*\n]+)\*\*")
_HIGHLIGHT = re.compile(r"==([^=\n]+)==")
_CODE = re.compile(r"`([^`\n]*)`")
_LINK = re.compile(r"!?\[([^\]\n]*)\]\([^)\n]*\)")
_HEADING = re.compile(r"^#{1,6}\s")

#: 计入面积的强调种类。**术语下划线也算**——它同样在页面上占一块。
#: 只有背景高亮另外受「每节最多一句」约束（§5.1.1），那是次数口径，与面积无关。
#:
#: 高亮按**来源**分成两种。这不是分类癖：它决定了超限时该往哪走。
EMPHASIS_KINDS = ("bold", "highlight_author", "highlight_planned", "term")

#: 排版这一侧真正能减的，**只有排版计划自己新增的高亮**。
#:
#: 其余三种都动不了：
#:
#: * `bold`、`highlight_author` 是作者写在正文里的，而正文被验收哈希绑定，
#:   改一个字符就 `ACCEPTANCE_STALE`；
#: * `term` 来自 `ArticlePlan.production_plan.term_glossary`，也是创作侧的东西。
#:
#: 早先把 `highlight` 整类列为可减，于是**正文只含作者已验收的高亮时，
#: 检查会要求删掉那处**——照着做要么做不到，要么就越过了
#: 「排版阶段不得修改已验收正文」这条边界。
REDUCIBLE_KINDS = ("highlight_planned",)


def visual_width(text: str) -> float:
    """视觉宽度：全角 1、半角 0.5，空白与组合记号不计。

    `east_asian_width` 的 W/F 是全角；A（歧义宽度，如 `±`）在中文环境下
    按全角渲染，所以也算 1。
    """
    total = 0.0
    for char in text:
        if char.isspace() or unicodedata.combining(char):
            continue
        total += 1.0 if unicodedata.east_asian_width(char) in "WFA" else 0.5
    return round(total, 2)


@dataclass
class SectionDensity:
    """一节（或整篇）的强调面积。整篇那一份的 `heading_index` 为 -1。"""

    heading_index: int
    prose_width: float = 0.0
    emphasis_width: float = 0.0
    spans: list[tuple[str, str, float]] = field(default_factory=list)

    @property
    def ratio(self) -> float:
        if self.prose_width <= 0:
            return 0.0
        return round(self.emphasis_width / self.prose_width, 4)

    @property
    def is_article(self) -> bool:
        return self.heading_index < 0


def strip_marks(text: str) -> str:
    """剥掉标记，留下读者看得见的字。

    **分母必须用剥过的文本。** 不剥的话 `**`、`==` 这些标记本身进了分母，
    强调越多分母越大、占比反而越低——**一个越违规越合规的判据**。
    """
    text = _CODE.sub(lambda m: m.group(1), text)
    text = _LINK.sub(lambda m: m.group(1), text)
    text = _BOLD.sub(lambda m: m.group(1), text)
    text = _HIGHLIGHT.sub(lambda m: m.group(1), text)
    return text


def measure(markdown: str, *, terms=(), planned=()
            ) -> tuple[list[SectionDensity], SectionDensity]:
    """量出每节与全文的强调面积。**只出数，不判对错。**

    返回 `(每节, 全文)`。判对错在 `check()`，分开是因为离线校准要的正是
    「先拿到一批数，再决定阈值」——判断混在测量里就取不到未经过滤的分布。

    ## `markdown` 要传**应用过计划的那一份**

    量的是读者最终看到的页面。计划新增的高亮不在原始正文里，
    传原始正文等于把二期最核心的那部分排除在检查之外——
    实测过：同一份正文应用计划后高亮占 73.68%，量原始正文报 0%，顺利通过。

    应用在内存里做（`compile density --plan` 就是这么干的），**不落盘、不改正文**。

    ## `planned` 是计划新增的那些高亮，**带小节**

    形如 `[(小节序号, 句子), …]`，直接从候选条目来
    （`candidates.collect()` 的每条都有 `heading_index` 与 `text`）。

    用来把高亮分成 `highlight_planned` 与 `highlight_author`。
    分开的理由在 `REDUCIBLE_KINDS`：超限时只有前者是排版侧能减的。

    ⛔ **不能只按句子文本认。** 同一句话在两节各出现一次、
    作者在第一节加了高亮而计划只选了第二节时，纯文本匹配会把两处都算成计划加的，
    于是**作者那处也进了删除建议**——照着删要么删不掉（计划里根本没有它），
    要么就改了已验收正文。实测过：程序预测删完占 0%，实际清空计划后仍有 33.33%。

    所以按 `(小节, 文本)` 配对，并且**按数量配**：某节有几条计划高亮，
    该节就最多有几处被标成 planned，多出来的是作者写的。
    每节至多一条计划高亮（§5.1.1 的额度由 `plan.resolve` 保证），
    所以这个配法不会有歧义。
    """
    quota: dict[tuple[int, str], int] = {}
    for item in planned:
        index, text = item
        key = (int(index), str(text))
        quota[key] = quota.get(key, 0) + 1
    sections: list[SectionDensity] = [SectionDensity(heading_index=0)]
    current = sections[0]
    in_code = False
    from .reading import strip_editorial_comments
    for raw in strip_editorial_comments(markdown).splitlines():
        line = raw.strip()
        if line.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        if _HEADING.match(line):
            if line.startswith("## "):
                current = SectionDensity(heading_index=len(sections))
                sections.append(current)
            continue
        current.prose_width += visual_width(strip_marks(line))
        for kind, pattern in (("bold", _BOLD), ("highlight", _HIGHLIGHT)):
            for found in pattern.finditer(line):
                text = found.group(1)
                width = visual_width(text)
                if kind == "highlight":
                    key = (current.heading_index, text)
                    if quota.get(key, 0) > 0:
                        quota[key] -= 1
                        kind = "highlight_planned"
                    else:
                        kind = "highlight_author"
                current.emphasis_width += width
                current.spans.append((kind, text, width))

    _add_terms(sections, markdown, terms)

    whole = SectionDensity(heading_index=-1)
    for section in sections:
        section.prose_width = round(section.prose_width, 2)
        section.emphasis_width = round(section.emphasis_width, 2)
        whole.prose_width += section.prose_width
        whole.emphasis_width += section.emphasis_width
        whole.spans.extend(section.spans)
    whole.prose_width = round(whole.prose_width, 2)
    whole.emphasis_width = round(whole.emphasis_width, 2)
    return sections, whole


def _add_terms(sections: list[SectionDensity], markdown: str, terms) -> None:
    """术语面积按**渲染器实际画线的位置**计入。

    这里不做匹配。跳过高亮／链接／行内代码、长术语优先、整篇只划首次——
    规则都在渲染那一侧，**在这里重写一遍必然分叉**，
    而分叉出来的数会被当成事实去指导「该减哪一节」。
    """
    from byclaw_caps.compile import locate_underlined_terms

    for index, term in locate_underlined_terms(markdown, terms):
        if index >= len(sections):
            continue
        width = visual_width(term)
        sections[index].emphasis_width += width
        sections[index].spans.append(("term", term, width))


@dataclass
class DensityFinding:
    code: str
    message: str
    detail: dict = field(default_factory=dict)
    #: `"block"` 要挡住，`"advice"` 只提醒。
    #:
    #: **不能混成一个列表让调用方自己猜。** CLI 按「有没有 finding」定退出码，
    #: 把一条提醒塞进去就等于用告警挡住交付；而全都降成提醒，
    #: 超限又拦不住了。分成两档，两边各自成立。
    severity: str = "block"

    @property
    def blocking(self) -> bool:
        return self.severity == "block"


EMPHASIS_TOO_WIDE = "EMPHASIS_TOO_WIDE"
EMPHASIS_DENSITY_EXCEEDED = "EMPHASIS_DENSITY_EXCEEDED"
#: 首屏一处强调都没有。**这是唯一一条「下限」**，其余都是上限；
#: 也是唯一一条 `severity="advice"`——该不该强调终究是语义判断。
FIRST_SCREEN_UNMARKED = "FIRST_SCREEN_UNMARKED"


#: 计入单处长度上限的高亮种类。**两种来源都算**——
#: 一句过长的高亮不因为是作者写的就不刺眼。区别只在超限之后往哪走，
#: 那由 `trim()` 的 `achievable` 说，不在这里分。
_HIGHLIGHT_KINDS = ("highlight_author", "highlight_planned")


def apply_plan(markdown: str, targets) -> str:
    """把候选条目应用成 `==…==`。**复用编译那条路**，不另写一套。

    另写的话，量出来的就不是将要编译出来的那份东西。
    """
    from byclaw_caps.compile.candidates import apply_highlights

    return apply_highlights(markdown, list(targets)) if targets else markdown


def first_screen_emphasis(markdown: str, *, terms=(), targets=(),
                          width: float = PROVISIONAL_FIRST_SCREEN_WIDTH
                          ) -> list[tuple[str, str, float]]:
    """首屏那一段里有哪些强调。

    「首屏」按**累计视觉宽度逐行切**，不按小节、不按行数、不按字符数：

    * 按小节切太粗——一节只有 300 宽时会把下一整节吞进来，
      于是「第二节有强调」被算成「首屏有强调」，而读者划走时还没看到它；
    * 按字符数切在中英混排时不准，同样的字符数占的屏幅差一倍，
      而读者划不划走看的是屏幅。

    标题不计入累计：它自己占一屏的开头，且有独立的视觉层级。

    术语下划线按「这个词出现在首屏那一段里」算。它只画首次出现，
    所以词一旦落在这一段里，线就在这一段——除非它被高亮吃掉，
    而那种情况下高亮本身已经算作这一段的强调了。
    """
    from byclaw_caps.compile import locate_underlined_terms

    applied = apply_plan(markdown, targets)
    planned: dict[tuple[int, str], int] = {}
    for one in targets:
        key = (one["heading_index"], one["text"])
        planned[key] = planned.get(key, 0) + 1

    underlined = {term for _, term in locate_underlined_terms(applied, terms)}

    seen = 0.0
    index = 0
    in_code = False
    found: list[tuple[str, str, float]] = []
    from .reading import strip_editorial_comments
    for raw in strip_editorial_comments(applied).splitlines():
        if seen >= width:
            break
        line = raw.strip()
        if line.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        if _HEADING.match(line):
            if line.startswith("## "):
                index += 1
            continue
        visible = strip_marks(line)
        # **按强调的起始位置判，不是「这一行里有没有」。**
        #
        # 一行可能比一屏还长。整行算的话，一段 700 宽的普通文字、
        # 末尾才出现一处加粗，也会被判成「首屏有强调」——而读者划走时
        # 那处加粗还在屏外。实测过：阈值 600，强调在 700 宽处，仍判为有。
        #
        # 所以量的是**这一处强调在剥掉标记后的正文里从第几宽开始**，
        # 加上它前面已经累计的宽度，超过预算就不算进首屏。
        line_start = seen
        seen += visual_width(visible)
        for kind, pattern in (("bold", _BOLD), ("highlight", _HIGHLIGHT)):
            for hit in pattern.finditer(line):
                text = hit.group(1)
                at = line_start + visual_width(strip_marks(line[:hit.start()]))
                if at >= width:
                    continue  # 这一处落在屏外
                if kind == "highlight":
                    key = (index, text)
                    if planned.get(key, 0) > 0:
                        planned[key] -= 1
                        kind = "highlight_planned"
                    else:
                        kind = "highlight_author"
                found.append((kind, text, visual_width(text)))
        for term in underlined:
            at = visible.find(term)
            if at < 0:
                continue
            if line_start + visual_width(visible[:at]) >= width:
                continue
            found.append(("term", term, visual_width(term)))
    return found


def check(markdown: str, *, terms=(), targets=(),
          max_span_width: float = PROVISIONAL_MAX_SPAN_WIDTH,
          max_section_ratio: float = PROVISIONAL_MAX_SECTION_RATIO,
          max_article_ratio: float = PROVISIONAL_MAX_ARTICLE_RATIO,
          min_section_width: float = PROVISIONAL_MIN_SECTION_WIDTH,
          first_screen_width: float = PROVISIONAL_FIRST_SCREEN_WIDTH,
          reading_profile: str = "default"
          ) -> list[DensityFinding]:
    """按给定阈值判一遍，返回**全部**问题。

    不遇到第一个就停：一次跑完看得到所有超限处，否则改一处跑一轮。

    ## `markdown` 传**原始正文**，计划由 `targets` 传

    应用放在这里做，不由调用方先应用好再传进来。这样减量才能**真的重算**：
    去掉几个候选 ID → 重新应用 → 重新测量，而不是从面积里减几个宽度。
    两者会差出很多，见 `trim()`。

    `targets` 是候选条目（`plan.resolve()` 的返回值），带 `id`、
    `heading_index`、`text`。**不是句子字符串**——按文本认来源会把
    重复句子里作者那处也当成计划加的。
    """
    from . import validate_reading_profile
    validate_reading_profile(reading_profile)
    applied = apply_plan(markdown, targets)
    planned = [(one["heading_index"], one["text"]) for one in targets]
    sections, whole = measure(applied, terms=terms, planned=planned)
    findings: list[DensityFinding] = []

    for kind, text, width in whole.spans:
        if kind in _HIGHLIGHT_KINDS and width > max_span_width:
            findings.append(DensityFinding(
                EMPHASIS_TOO_WIDE,
                "这处高亮太长（视觉宽度 %.1f，上限 %.1f）：「%s」。"
                "**长句宁可不选**——整段染色等于没有强调，"
                "读者分不出哪一句才是判断。%s"
                % (width, max_span_width, clip(text),
                   "" if kind == "highlight_planned"
                   else "这处是作者写在正文里的，排版改不了，要回创作返修。"),
                {"kind": kind, "width": width, "limit": max_span_width,
                 "text": text, "reducible": kind == "highlight_planned"}))

    # **太短的小节不判占比。** 分母几十字时，一处强调就能把比例顶到上限附近，
    # 判的是分母的抖动不是排版的密度——实测那篇第 6 节 177 宽、一处强调、18.1%，
    # 而它只是一句过渡。这类小节由「单处宽度」那一条管，那条不受分母影响。
    #
    # ⛔ **这条线要与 `trim()` 同源**，下面调它时把同一个值传下去。
    # 两处分叉过一次：这里豁免了、那里没有，于是删光所有候选之后仍报
    # `achievable=false`，结论是「排版解决不了，回创作返修」——
    # 而实际清空计划后这里一条阻断项都没有。**减量去追了一个检查不要求的目标。**
    over_sections = [one for one in sections
                     if one.prose_width >= min_section_width
                     and one.ratio > max_section_ratio]
    over_article = whole.prose_width > 0 and whole.ratio > max_article_ratio
    if reading_profile == "default":
        findings.extend(_check_first_screen(
            markdown, terms=terms, targets=targets, width=first_screen_width))

    if not over_sections and not over_article:
        return findings

    # **一份删法管全篇，不是每个口径各算各的。**
    # 各算各的会互相打架：为第 2 节算出来的删法可能把第 1 节顶穿，
    # 而调用方拿到两份清单也不知道该照哪一份做。
    # `focus` 只影响并列时先删谁，不限制搜索范围——理由见 `trim()`。
    focus = over_sections[0].heading_index if over_sections else None
    # **同一条豁免线传下去**，否则减量会去追一个检查不要求的目标。
    result = trim(markdown, targets, terms=terms,
                  section_limit=max_section_ratio,
                  article_limit=max_article_ratio, focus=focus,
                  min_section_width=min_section_width)

    for section in over_sections:
        findings.append(DensityFinding(
            EMPHASIS_DENSITY_EXCEEDED,
            "第 %d 节强调面积占 %.0f%%，上限 %.0f%%。%s"
            % (section.heading_index, section.ratio * 100,
               max_section_ratio * 100, _advice(result)),
            {"scope": "section", "heading_index": section.heading_index,
             "ratio": section.ratio, "limit": max_section_ratio,
             **result.as_detail(section.heading_index)}))

    if over_article:
        findings.append(DensityFinding(
            EMPHASIS_DENSITY_EXCEEDED,
            "全文强调面积占 %.0f%%，上限 %.0f%%。"
            "**整篇都密等于整篇都不强调**——某节偏密可以，整篇偏密不行。%s"
            % (whole.ratio * 100, max_article_ratio * 100, _advice(result)),
            {"scope": "article", "ratio": whole.ratio,
             "limit": max_article_ratio, **result.as_detail(None)}))
    return findings


@dataclass
class TrimResult:
    """减量的结论：**从计划里删哪几个 ID**、删完剩多少、够不够。

    `drop` 装的是候选 ID，不是句子文本。ID 才是能直接从计划里删掉的东西；
    给文本的话，同一句话在两节都出现时不知道该删哪一个。

    `remaining_ratio` 是**真的重算出来的**，不是从面积里减几个宽度。
    理由见 `trim()`。
    """

    drop: list[str] = field(default_factory=list)
    drop_texts: list[str] = field(default_factory=list)
    remaining_ratio: float = 0.0
    achievable: bool = True
    #: 删完之后每个口径的占比：`{小节序号: 占比}`，全文那一份的键是 `None`。
    #: **判「达标」看的是它全体**，不是某一个。
    scope_ratios: dict = field(default_factory=dict)

    @property
    def stuck(self) -> bool:
        """能删的全删完仍然超限——**排版这一侧解决不了**。"""
        return not self.achievable

    def ratio_for(self, scope) -> float:
        return self.scope_ratios.get(scope, 0.0)

    def as_detail(self, scope=None) -> dict:
        """摊平进 finding 的 `detail`。

        **`achievable` 要出现在机器可读的那一层**，不能只藏在提示文字里——
        调用方要据此决定是「重出计划」还是「报 blocked」，
        让它去解析中文提示等于把判断又交回给不确定的一侧。
        """
        return {"drop": list(self.drop), "drop_texts": list(self.drop_texts),
                "remaining_ratio": round(self.ratio_for(scope), 4),
                "achievable": self.achievable}


def _check_first_screen(markdown: str, *, terms, targets,
                        width: float) -> list[DensityFinding]:
    """首屏里一处强调都没有的话，说一句。**只提醒，不阻断。**

    两个理由：阈值还是占位值（一屏装多少字取决于机型与字号），
    拿它当硬失败会误伤；而「该不该强调」终究是语义判断，
    代码能说的只是「这里一处都没有，你是有意的吗」。

    但它必须被说出来。只有上限的检查有个盲区：一篇全文占比 6.0%、
    每节都克制、**首屏一处计划高亮都没有**的文章，在那套口径里是满分，
    而读者在首屏看不到任何重点。实测中两份分析报告正是在这里分了岔——
    一份判「密度健康」，一份判「首屏覆盖不足」，两份都对，量的不是同一件事。
    """
    if first_screen_emphasis(markdown, terms=terms, targets=targets,
                             width=width):
        return []
    return [DensityFinding(
        FIRST_SCREEN_UNMARKED,
        "首屏（约前 %.0f 个全角字）里一处强调都没有。\n"
        "**读者划走之前看到的就是这一段**——全是标题、导语和普通段落时，"
        "他不知道这篇要争的是什么。\n"
        "看看首屏那几段里有没有一句核心判断值得选进计划；"
        "**确实没有就放着**，「这一屏不强调」是正常结果，不是失败。"
        % width,
        {"scope": "first_screen", "width": width},
        severity="advice")]


def _scope_ratios(markdown: str, targets, terms,
                  min_section_width: float = PROVISIONAL_MIN_SECTION_WIDTH
                  ) -> dict:
    """当前这套候选下，各节与全文的占比。全文的键是 `None`。

    ⛔ **短节的豁免必须与 `check()` 用同一条线。**

    `check()` 不判宽度不足 `min_section_width` 的小节（分母几十字时判的是
    抖动，不是密度）。这里若照判，两处的规则就分叉了，后果是**减量建议
    去追一个检查根本不要求的目标**：

    实测过一次。一篇里有个 9 宽的小节带一处强调、占比 100%——`check()`
    压根不看它，而 `trim()` 把它算进「还没达标」，于是删光所有候选之后
    仍报 `achievable=false`，结论是「排版解决不了，报 blocked 回创作返修」。
    而实际把计划清空后全文 8.91%、`check()` 一条阻断项都没有。
    **凭空造出一轮跨阶段返工**，去满足一个不存在的要求。

    所以这个参数要一路传到底，两处同源。
    """
    sections, whole = measure(
        apply_plan(markdown, targets), terms=terms,
        planned=[(one["heading_index"], one["text"]) for one in targets])
    ratios = {section.heading_index: section.ratio
              for section in sections
              if section.prose_width >= min_section_width}
    ratios[None] = whole.ratio
    return ratios


def _excess_vector(ratios: dict, section_limit: float,
                   article_limit: float) -> tuple:
    """离达标还差多远——**所有口径各记一笔，按超得多少降序排**。

    只看触发这次检查的那一节是不够的：删掉它的高亮可能把术语下划线推到别节去，
    顶穿另一处。要判「这套删法行不行」，就得把每一节和全文一起看。

    ⛔ **必须是向量，不能压成「最差的那个数」。**

    两节同样超限时（两节结构对称就会这样），删掉其中一节的候选，
    另一节纹丝不动——**最大值没变**。把「最大值必须下降」当成进度判据的话，
    第一步就判定「再删也没用」，返回 `drop: []` 要求创作返修。

    实测过：两节各 82.35%、全文 12.39%，两个候选全是排版计划自己加的，
    **一起删掉之后各节与全文统统归零、检查通过**，而程序说要返修。

    按向量比就不会：`(0.62, 0.62, …)` → `(0.62, 0, …)` 在字典序上是**下降**的，
    尽管首项相同。它如实反映了「这一步确实解决了一个口径」。
    """
    excesses = []
    for scope, ratio in ratios.items():
        limit = article_limit if scope is None else section_limit
        excesses.append(max(0.0, round(ratio - limit, 6)))
    return tuple(sorted(excesses, reverse=True))


def _is_clear(vector: tuple) -> bool:
    return not vector or vector[0] <= 0


def trim(markdown: str, targets, *, terms=(), section_limit: float,
         article_limit: float, focus=None,
         min_section_width: float = PROVISIONAL_MIN_SECTION_WIDTH
         ) -> TrimResult:
    """要达标该从计划里删掉哪几个候选——**每删一个就重新量整篇**。

    ## 为什么不能只做减法

    从面积里减去那处高亮的宽度，看起来等价，其实不是：**删掉高亮会让页面
    变出新的强调**。术语下划线在高亮内部是不画的（§8.2），高亮一删，
    那些词恢复画线；术语「首次出现」还会因此挪到别的小节去。

    实测过差多少：计划高亮一句、术语表里两个词都落在那句里时，
    按减法预测删完占比 0%、`achievable=true`；实际删掉再测是 31.58%，仍然超限。
    照着改一遍、再跑、再次失败——正是这个函数要消灭的那种无效重试。

    ## 为什么候选不按小节切

    **术语下划线的位置是全文性的，超限却是按节报的。** 于是有这种局面：
    某一节自己一个计划高亮都没有，密度却被**前一节的高亮**顶上去了——
    前一节把某个术语的首次出现吃掉（高亮内部不画线），那个词的线就落到后一节。

    只在本节的候选里找可删项时，这一节会得到 `drop: []`、`achievable: false`，
    结论是「排版解决不了，回创作返修」。而实测：删掉**前一节**那一个候选，
    两节分别降到 1.87% 和 0%，整篇通过，**正文一个字都不用改**。
    把可解决的问题判成必须返修，代价是一整轮无谓的创作返工。

    所以这里对整篇的候选一起搜，并且**每一步都核验全部口径**——
    每节都要达标、全文也要达标，才算 `achievable`。

    ## 删的顺序

    每一步试删每个还剩的候选，取「删完之后最差口径离达标最近」的那个。
    并列时优先删 `focus` 那一节的、再优先删长的——面积超限本来就是长句造成的，
    而**短的那几处往往正是最该留的**，短句才是一句判断。

    候选通常只有几个，多量几遍不值一提，而**猜错的代价是一整轮返工**。

    ## 只删计划自己选的候选

    作者写在正文里的粗体与高亮、以及术语表带来的下划线，排版这一侧都动不了；
    把它们列进删除建议，照着做要么做不到，要么就越过了
    「排版阶段不得修改已验收正文」这条边界。
    """
    remaining = list(targets)
    ratios = _scope_ratios(markdown, remaining, terms,
                           min_section_width)
    vector = _excess_vector(ratios, section_limit, article_limit)

    drop: list[str] = []
    drop_texts: list[str] = []
    while not _is_clear(vector) and remaining:
        best = None
        for one in remaining:
            trial = [other for other in remaining if other["id"] != one["id"]]
            trial_ratios = _scope_ratios(markdown, trial, terms,
                                         min_section_width)
            trial_vector = _excess_vector(trial_ratios, section_limit,
                                          article_limit)
            key = (trial_vector,
                   0 if one["heading_index"] == focus else 1,
                   -visual_width(one["text"]))
            if best is None or key < best[0]:
                best = (key, one, trial, trial_ratios, trial_vector)
        if best is None or best[4] >= vector:
            break
        _, chosen, remaining, ratios, vector = best
        drop.append(str(chosen["id"]))
        drop_texts.append(str(chosen["text"]))

    if not _is_clear(vector) and targets:
        # **兜底：贪心停下来了，不代表真的无解。**
        #
        # 每步取「最优的一步」是启发式，它可能卡在需要**同时**删好几个才见效的
        # 局面上。所以在下「排版解决不了」这个结论之前，**实际把计划清空再量一遍**——
        # 那是排版这一侧能做到的极限，一次测量就能判定。
        #
        # 清空能达标而贪心没找到时，就交清空这个方案：它一定可行，
        # 只是可能删多了。**宁可多删几处高亮，也不要把可解决的判成创作返修**——
        # 前者是本阶段重出一次计划，后者是整条链退回上一环。
        cleared = _scope_ratios(markdown, [], terms,
                                min_section_width)
        cleared_vector = _excess_vector(cleared, section_limit, article_limit)
        if _is_clear(cleared_vector):
            drop = [str(one["id"]) for one in targets]
            drop_texts = [str(one["text"]) for one in targets]
            ratios, vector = cleared, cleared_vector

    return TrimResult(drop=drop, drop_texts=drop_texts,
                      remaining_ratio=round(ratios.get(focus, 0.0), 4),
                      achievable=_is_clear(vector), scope_ratios=ratios)


def _advice(result: TrimResult) -> str:
    """超限时该说什么。**能不能达标先说清楚**，再说删哪几个。"""
    if result.stuck:
        return ("**排版这一侧减不下来**：能删的只有排版计划自己选的候选，"
                "全部删掉之后仍占 %.0f%%。剩下的是作者写在正文里的粗体与高亮、"
                "以及术语表带来的下划线——正文被验收哈希绑定，排版改不了。"
                "报 `blocked` 回创作返修。" % (result.remaining_ratio * 100))
    if not result.drop:
        return "已经达标，无需减少。"
    listed = "、".join(
        "%s（%s）" % (one, clip(text))
        for one, text in list(zip(result.drop, result.drop_texts))[:3])
    return ("从计划里删掉这几个 ID，**各节与全文就都达标了**"
            "（删完**实测**：本项 %.0f%%）：%s。"
            "**删的不一定是本节的那个**——术语下划线的位置是全文性的，"
            "别节的高亮吃掉某个词的首次出现时，线会落到这一节来。"
            % (result.remaining_ratio * 100, listed))


def blocking(findings) -> list:
    """只留要挡住的那些。

    调用方按「有没有 finding」定退出码时**必须先过这一层**，
    否则一条提醒就能把正常交付挡下来。
    """
    return [one for one in findings if one.blocking]


def clip(text: str, keep: int = 18) -> str:
    return text if len(text) <= keep else text[:keep] + "…"


__all__ = ["visual_width", "strip_marks", "measure", "check", "trim", "clip",
           "SectionDensity", "DensityFinding", "TrimResult",
           "EMPHASIS_TOO_WIDE", "EMPHASIS_DENSITY_EXCEEDED",
           "FIRST_SCREEN_UNMARKED", "blocking", "first_screen_emphasis",
           "PROVISIONAL_FIRST_SCREEN_WIDTH", "PROVISIONAL_MIN_SECTION_WIDTH",
           "EMPHASIS_KINDS", "REDUCIBLE_KINDS",
           "PROVISIONAL_MAX_SPAN_WIDTH", "PROVISIONAL_MAX_SECTION_RATIO",
           "PROVISIONAL_MAX_ARTICLE_RATIO"]
