#!/usr/bin/env python3
"""排版计划：校验，然后把 ID 解析成原文句子。

## 模型交出来的只有 ID

```json
{"schema_version": "1.0",
 "article_sha256": "…",
 "candidate_set_sha256": "…",
 "highlights": ["s2-04"]}
```

**没有一个字段承载要渲染的文字。** 文字由本模块按 ID 从
`candidates.collect()` 的结果里取——那是编译器自己解析出来的那一份。
所以「模型打错字改变含义」在结构上不可能发生。

## 四道校验，一道都不能省

| 检查 | 拦的是什么 |
|---|---|
| `schema_version` | 结构变了而校验器还按旧的读 |
| `article_sha256` | **拿旧计划配新正文** |
| `candidate_set_sha256` | **正文没变、分句规则变了**——同一个 ID 指向了另一句话 |
| ID 在清单内 | 编出来的 ID |

第三道最容易被漏掉：前两道全过，而高亮落在错的句子上。
把编译器版本记进结果只能事后追查，拦不住当场这件事。

## 额度：按最终页面算，含作者已写的

「每节最多一句」数的是**背景高亮**：作者写的 `==…==` 加上计划新增的，合计。
否则两个入口各自合规、合起来超限——作者在某节写了一句，规划器又加一句，
页面上就是两句。

**粗体不算进这个额度。** 一节里两个关键词加粗是正常写法，
把它判成超限会制造一轮毫无必要的创作返修——返修的是作者本来写对的东西。
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from byclaw_caps.compile import CompileError
from byclaw_caps.compile.candidates import collect, fingerprint

SUPPORTED_PLAN_VERSIONS = frozenset({"1.0"})

#: 每节的背景高亮上限。**是上限，不是每节必选一句。**
MAX_HIGHLIGHTS_PER_SECTION = 1


def _author_highlights_per_section(markdown: str) -> dict[int, int]:
    """数出作者自己在正文里写的 `==高亮==`，按小节归拢。

    规划器必须先看正文里已有什么——**额度按最终页面上的总量算**。
    """
    counts: dict[int, int] = {}
    heading_index = 0
    in_code = False
    for raw in markdown.splitlines():
        line = raw.strip()
        if line.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        if re.match(r"^#{2}\s", line):
            heading_index += 1
            continue
        found = len(re.findall(r"==([^=\n]+)==", line))
        if found:
            counts[heading_index] = counts.get(heading_index, 0) + found
    return counts


def load(path: str | Path) -> dict:
    """读计划文件。形状不对就报错，**不静默跳过**。

    静默的后果是产出一份没有高亮的渠道包，而调用方以为自己传了计划——
    要打开公众号后台才看得出来。
    """
    target = Path(path)
    if not target.is_file():
        raise FileNotFoundError(f"排版计划不存在：{target}")
    loaded = json.loads(target.read_text(encoding="utf-8"))
    if not isinstance(loaded, dict):
        raise CompileError(
            "INVALID_PLAN_SHAPE",
            f"排版计划顶层必须是对象，实际是 {type(loaded).__name__}",
            path=str(target))
    return loaded


def resolve(plan: dict, markdown: str, *, article_sha256: str = "") -> tuple[str, ...]:
    """校验计划并把 ID 解析成原文句子。

    返回要高亮的**句子原文**（编译器自己取的字），空元组表示不新增高亮。
    """
    version = str(plan.get("schema_version") or "")
    if version not in SUPPORTED_PLAN_VERSIONS:
        raise CompileError(
            "UNSUPPORTED_PLAN_VERSION",
            f"不支持的计划版本：{version or '(缺失)'}。"
            f"支持 {'、'.join(sorted(SUPPORTED_PLAN_VERSIONS))}",
            actual=version, supported=sorted(SUPPORTED_PLAN_VERSIONS))

    if article_sha256:
        declared = str(plan.get("article_sha256") or "")
        if declared != article_sha256:
            raise CompileError(
                "PLAN_SOURCE_MISMATCH",
                "计划绑的正文不是当前这一份——**拒绝使用旧计划**。"
                "正文改过之后要重新产候选、重新规划，"
                "不要在旧计划上改 ID。",
                plan_article_sha256=declared, actual_article_sha256=article_sha256)

    found = collect(markdown)
    actual_set = fingerprint(found)
    declared_set = str(plan.get("candidate_set_sha256") or "")
    if declared_set != actual_set:
        raise CompileError(
            "CANDIDATE_SET_MISMATCH",
            "候选清单指纹对不上。**正文可能没变，但分句结果变了**——"
            "同一个 ID 会指向另一句话，高亮会落在错的地方。"
            "重新跑 `compile candidates` 再规划。",
            plan_candidate_set=declared_set, actual_candidate_set=actual_set)

    wanted = plan.get("highlights") or []
    if not isinstance(wanted, list):
        raise CompileError(
            "INVALID_PLAN_SHAPE", "highlights 必须是数组",
            actual_type=type(wanted).__name__)

    by_id = {c["id"]: c for c in found}
    unknown = [i for i in wanted if i not in by_id]
    if unknown:
        raise CompileError(
            "UNKNOWN_CANDIDATE_ID",
            f"计划里的 ID 不在候选清单内：{'、'.join(map(str, unknown))}。"
            "**只能从清单里选**，不能自己编 ID。",
            unknown=unknown, known_count=len(by_id))

    _check_quota(wanted, by_id, markdown)
    # **返回候选条目本身，不只是文本。** 应用要按 (block_index, sentence_index)
    # 定位——只给文本时，同句在两节都出现会高亮到错的那一节。
    return tuple(by_id[i] for i in wanted)


def _check_quota(wanted, by_id, markdown: str) -> None:
    author = _author_highlights_per_section(markdown)
    planned: dict[int, int] = {}
    for candidate_id in wanted:
        section = by_id[candidate_id]["heading_index"]
        planned[section] = planned.get(section, 0) + 1

    over = []
    for section in sorted(set(author) | set(planned)):
        total = author.get(section, 0) + planned.get(section, 0)
        if total > MAX_HIGHLIGHTS_PER_SECTION:
            over.append(
                "第 %d 节共 %d 处（作者已写 %d、计划新增 %d）"
                % (section, total, author.get(section, 0), planned.get(section, 0)))
    if over:
        raise CompileError(
            "HIGHLIGHT_QUOTA_EXCEEDED",
            "背景高亮超出每节 %d 处的护栏：%s。\n"
            "**额度按最终页面算，含作者已写在正文里的 `==…==`**——"
            "规划时要先看正文里已有什么。\n"
            "少选几句即可；**「本节不高亮」是正常结果，不是失败**。"
            % (MAX_HIGHLIGHTS_PER_SECTION, "；".join(over)),
            over=over, quota=MAX_HIGHLIGHTS_PER_SECTION)


def apply_to_markdown(markdown: str, targets) -> str:
    """把选中的候选包成 `==句子==`，交给既有的高亮渲染。

    **复用作者写 `==` 那条路**，而不是另造一套渲染——
    两条路各自渲染迟早长出两种样子，而读者看到的该是同一种强调。

    定位交给 `candidates.apply_highlights`：与候选生成**共用同一套分块分句**，
    按位置改写。早先按文本全文替换的实现有两个坏法：同句跨节会高亮错节，
    句子在源码里跨行会静默不生效。
    """
    from byclaw_caps.compile.candidates import apply_highlights

    return apply_highlights(markdown, targets)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
