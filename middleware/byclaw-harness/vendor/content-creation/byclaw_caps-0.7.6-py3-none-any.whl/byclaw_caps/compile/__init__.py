#!/usr/bin/env python3
"""渠道包编译：平台红线校验。

**这是现在完全缺失的一环。** 既有 ``validate_channel_package.py`` 只校验包结构
（``package_id``、文件存在性），HTML 有没有踩公众号红线今天没人查——踩了要等草稿在后台
渲染错乱才发现。本模块作为编译后的强制门禁，遇 ERROR 即中止，不进投递。

分级有实际含义：

* **ERROR** —— 会被平台**过滤或改写**，粘上去必坏。中止编译。
* **WARNING** —— 排版实践的坑，不会被过滤但会渲染难看或丢信息。不中止。

**不检查 `<span leaf="">`。** 实测结论：A／B 两版草稿经 ``draft/get`` 取回比对，
100 处 ``style=``、19 处 ``background``、8 处 ``linear-gradient``、83 处 ``color:``
全部原样保留，一处样式都没被剥离；而包裹会让体积增加 10%。开源实现把「漏 leaf」列为
最常见致命错，那是**编辑器粘贴路径**特有的，我们走 ``draft/add`` API 不受影响。
"""

from __future__ import annotations

import html
import re
from typing import Any

from .themes import (LEGACY_THEME_IDS, THEME_PRESETS, style_tag, theme_details,
                     theme_styles)
from .reading import (DEFAULT_READING_PROFILE, READING_PROFILES, SCENE_BREAK,
                      reading_styles, strip_editorial_comments)


class CompileError(RuntimeError):
    """编译失败。

    与其余能力的异常同形：带错误码与结构化细节，`_cli.dispatch` 会原样透出——
    两份数字员工提示词都写着「同一错误码连续出现 2 次即停」，那条规则要成立，
    错误码就得真的出现在输出里。
    """

    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details

    def as_dict(self) -> dict[str, Any]:
        return {"ok": False, "status": self.code, "message": self.message, **self.details}


VERSION = "1.2.0"


class _BlockBuffer(list):
    """The existing parser emits semantic metadata alongside its original HTML.

    No second Markdown parser: component planning and rendering observe the same
    flush operations as legacy compilation. An absent sink preserves its output.
    """
    def __init__(self, sink=None):
        super().__init__()
        self.sink = sink

    def emit(self, fragment, kind, data):
        self.append(self.sink(fragment, kind, data) if self.sink else fragment)


LEVEL_ERROR = "ERROR"
LEVEL_WARNING = "WARNING"

# (code, 正则, 级别, 说明, 可执行提示)
_RULES: tuple[tuple[str, re.Pattern[str], str, str, str], ...] = (
    (
        "STYLE_TAG", re.compile(r"<style[\s>]", re.I), LEVEL_ERROR,
        "<style> 会被过滤", "样式必须内联到 style 属性上。",
    ),
    (
        "SCRIPT_TAG", re.compile(r"<script[\s>]", re.I), LEVEL_ERROR,
        "<script> 会被过滤", "公众号不执行脚本，删除即可。",
    ),
    (
        "DIV_TAG", re.compile(r"</?div[\s>]", re.I), LEVEL_ERROR,
        "<div> 会被改写", "改用 <section>。",
    ),
    (
        "LINK_TAG", re.compile(r"<link[\s>]", re.I), LEVEL_ERROR,
        "外部 <link> 会被过滤", "外链 CSS 与字体一律不可用，样式内联。",
    ),
    (
        "CLASS_ATTR", re.compile(r"\sclass\s*=", re.I), LEVEL_ERROR,
        "class 属性会被剥离", "改用内联 style。",
    ),
    (
        "ID_ATTR", re.compile(r"\sid\s*=", re.I), LEVEL_ERROR,
        "id 属性会被剥离", "删除；公众号内无需锚点。",
    ),
    (
        "POSITION", re.compile(r"position\s*:\s*(fixed|absolute|sticky)", re.I),
        LEVEL_ERROR, "定位方式不被支持", "改用常规文档流。",
    ),
    (
        "FLOAT", re.compile(r"float\s*:", re.I), LEVEL_ERROR,
        "float 不被支持", "改用 flex 或常规文档流。",
    ),
    (
        "AT_MEDIA", re.compile(r"@media", re.I), LEVEL_ERROR,
        "@media 不被支持", "公众号无响应式，写死一套尺寸。",
    ),
    (
        "AT_KEYFRAMES", re.compile(r"@keyframes", re.I), LEVEL_ERROR,
        "@keyframes 不被支持", "删除动画。",
    ),
    (
        "AT_IMPORT", re.compile(r"@import", re.I), LEVEL_ERROR,
        "@import 不被支持", "删除。",
    ),
    (
        "GRID", re.compile(r"display\s*:\s*grid", re.I), LEVEL_ERROR,
        "display:grid 不被支持", "改用 display:flex（有限支持）。",
    ),
    (
        "CSS_VAR", re.compile(r"var\s*\(\s*--", re.I), LEVEL_ERROR,
        "CSS 变量不被支持", "把值写死。",
    ),
    (
        "EXTERNAL_FONT", re.compile(r"@font-face|fonts\.(googleapis|gstatic)\.com", re.I),
        LEVEL_ERROR, "外部字体不被支持", "只用系统字体栈。",
    ),
    (
        "WHITE_SPACE_PRE", re.compile(r"white-space\s*:\s*pre", re.I), LEVEL_WARNING,
        "white-space:pre 会把源码缩进原样渲染成大左缩进与空行",
        "代码块改用每行一个 <p style=\"margin:0\">，缩进用全角空格，行距靠 line-height。",
    ),
)

# `<img>` 上的 width:100% 会把小图也拉伸变糊；只有表格、封面卡、流程图才该用。
# **SVG 豁免**：矢量图缩放无损，width:100% 反而是想要的效果。真实文章的 6 处告警
# 全是 SVG 示意图，不区分就是假阳性——而假阳性多了没人再看告警。
# 与下方 IMG_SVG 不冲突：一条说「渠道包里不该有 SVG」，另一条说「若有，别再叠一条
# 无关的宽度告警」。该豁免实际只在 preview.html（浏览器渲染，SVG 可用）时有意义。
_IMG = re.compile(r"<img\b[^>]*>", re.I)
_WIDTH_100 = re.compile(r"(?<!max-)width\s*:\s*100%", re.I)
_VECTOR_SRC = re.compile(r'src\s*=\s*["\'][^"\']*\.svg\b', re.I)

# 图片 src 指向本地会话目录。公众号取不到你机器上的文件，草稿里就是坏图。
# 排版这一步只**告警**：那时素材还没上传，有本地路径是正常的。
# 硬拦在 `deliver package`——那才是不可撤回的一刻。
_LOCAL_SRC = re.compile(r'src\s*=\s*["\'](?:file://)?/by/\.sessions/', re.I)


#: 整份 HTML 文档的标志。渠道包是**正文片段**，出现任何一个都是拿错了文件。
#:
#: 2026-08-28 实测：助理需要一份业务能打开的预览，而 `preview_document` 够不着
#: CLI，于是它把 `渠道包.html` 整个换成了预览文档——**而当时这十六条一条都没拦**。
#: 下游 `deliver package` 把 HTML 原样当 content，`<!doctype html>` 就这么
#: 进了公众号正文字段，标题还会出现两次：标题栏一次，正文 H1 一次。
_DOCUMENT_RULES: tuple[tuple[str, re.Pattern[str], str, str, str], ...] = (
    (
        "DOC_DOCTYPE", re.compile(r"<!doctype\b", re.I), LEVEL_ERROR,
        "渠道包里出现 <!doctype>，这是整份文档不是正文片段",
        "公众号正文只收片段。预览文档是 40-package/预览.html，"
        "渠道包是 40-package/渠道包.html——你可能拿错了文件。",
    ),
    (
        "DOC_HTML_TAG", re.compile(r"</?html[\s>]", re.I), LEVEL_ERROR,
        "渠道包里出现 <html>，这是整份文档不是正文片段",
        "同上：渠道包只要 <section> 起头的片段。",
    ),
    (
        "DOC_HEAD_TAG", re.compile(r"</?head[\s>]", re.I), LEVEL_ERROR,
        "渠道包里出现 <head>，这是整份文档不是正文片段",
        "同上。",
    ),
    (
        "DOC_BODY_TAG", re.compile(r"</?body[\s>]", re.I), LEVEL_ERROR,
        "渠道包里出现 <body>，这是整份文档不是正文片段",
        "同上。",
    ),
    (
        "DOC_H1_TAG", re.compile(r"</?h1[\s>]", re.I), LEVEL_ERROR,
        "渠道包里出现 <h1>，主标题会重复一次",
        "主标题走草稿的 title 字段，正文里再放一遍，读者会看到两个标题。"
        "编译器本来就摘掉了首个 H1（见 markdown_to_html），这里出现说明是手工加回去的。",
    ),
)

#: 图片宽度策略。`contain` 让小图保持原尺寸，`fill` 占满整宽。
#:
#: 缺省曾经是 `fill`，于是编译器每张图都触发自己的 `IMG_WIDTH_100` 告警，
#: 而 CLI 没有开关能改——唯一的满足办法是手改编译产物，
#: 但 3 号提示词写着「换版式，不要手写 style」，而且手改一重新编译就丢。
IMAGE_FITS: dict[str, str] = {
    "contain": "max-width:100%;height:auto;",
    "fill": "width:100%;height:auto;",
}
DEFAULT_IMAGE_FIT = "contain"

_MD_H1 = re.compile(r"^#\s+(.+?)\s*$", re.M)


def extract_title(markdown: str) -> str:
    """取首个一级标题——**正是 `markdown_to_html` 摘掉的那一个**。

    没有就返回空串，**不要编一个**：编出来的标题会一路走到草稿标题栏。
    """
    found = _MD_H1.search(markdown or "")
    return found.group(1).strip() if found else ""


#: 两种校验口径。**缺省是严的那档**——默认宽松等于这条规则只在有人记得时生效。
KIND_CHANNEL = "channel"
KIND_PREVIEW = "preview"
VALIDATE_KINDS: frozenset[str] = frozenset({KIND_CHANNEL, KIND_PREVIEW})


def _finding(code: str, level: str, message: str, hint: str, line: int) -> dict[str, Any]:
    return {
        "code": code, "level": level, "message": message, "hint": hint, "line": line,
    }


def validate_channel_html(html: str, *, kind: str = KIND_CHANNEL) -> dict[str, Any]:
    """校验渠道包 HTML 是否踩公众号红线。

    返回 ``ok``／``errors``／``warnings``／``findings``。``ok`` 只看 ERROR——
    WARNING 该修但不中止，否则一个图片宽度问题会挡住整篇发布。

    ``kind`` 分两档：

    - ``channel``（**缺省**）：渠道包，正文片段，整份文档的五个标志一律 ERROR
    - ``preview``：给业务打开看的完整文档，**只跳那五条结构规则**，其余照查

    只跳五条是有意的：预览里出现 ``<script>`` 同样是问题，整个放行等于没校验。
    """
    if kind not in VALIDATE_KINDS:
        # 静默当成缺省的话，`--kind preveiw` 这种笔误会悄悄走进严格档，
        # 报出一堆看不懂的结构错误，而根因是拼错了一个字母。
        raise CompileError("UNKNOWN_KIND", f"未知校验口径：{kind}",
                           known_kinds=sorted(VALIDATE_KINDS))
    rules = _RULES if kind == KIND_PREVIEW else _RULES + _DOCUMENT_RULES

    findings: list[dict[str, Any]] = []
    lines = (html or "").split("\n")

    for number, line in enumerate(lines, start=1):
        for code, pattern, level, message, hint in rules:
            if pattern.search(line):
                findings.append(_finding(code, level, message, hint, number))
        if kind == KIND_CHANNEL and _LOCAL_SRC.search(line):
            findings.append(
                _finding(
                    "IMG_LOCAL_PATH", LEVEL_WARNING,
                    "图片指向本地会话路径，公众号取不到",
                    "草稿里就是坏图。先上传素材拿到渠道链接，"
                    "再用 compile markdown --image-map 重新编译。"
                    "**排版这一步只是提醒**——素材还没上传是正常的；"
                    "真正拦住它的是 deliver package。",
                    number,
                )
            )
        for tag in _IMG.findall(line):
            if _VECTOR_SRC.search(tag):
                # 真实发布时撞到的：6 张 SVG 配图一张也显示不出来。不会被「过滤」成
                # 语法错误，却让内容缺失，后果同样严重——宁可编译中止，也不要发出去
                # 一篇有六个空洞的文章。
                findings.append(
                    _finding(
                        "IMG_SVG", LEVEL_ERROR,
                        "公众号不支持 SVG，该图将无法显示",
                        "上传接口只收 jpg／png／gif，内联 SVG 同样被剥。"
                        "请先栅格化为 PNG（图像栅格化能力负责），再引用转换后的文件。",
                        number,
                    )
                )
            if _WIDTH_100.search(tag) and not _VECTOR_SRC.search(tag):
                findings.append(
                    _finding(
                        "IMG_WIDTH_100", LEVEL_WARNING,
                        "<img> 用了 width:100%，会把小图也拉伸变糊",
                        "改用 max-width:100%;height:auto——按图片自身尺寸显示，"
                        "大图缩到容器宽、小图保持原尺寸；只有表格、封面卡、流程图才用 width:100%。",
                        number,
                    )
                )

    errors = sum(1 for f in findings if f["level"] == LEVEL_ERROR)
    warnings = sum(1 for f in findings if f["level"] == LEVEL_WARNING)
    return {
        "ok": errors == 0,
        "errors": errors,
        "warnings": warnings,
        "findings": findings,
    }


__all__ = [
    "VERSION",
    "LEVEL_ERROR",
    "LEVEL_WARNING",
    "KIND_CHANNEL",
    "KIND_PREVIEW",
    "VALIDATE_KINDS",
    "IMAGE_FITS",
    "DEFAULT_IMAGE_FIT",
    "extract_title",
    "validate_channel_html",
]


# ── 编译主体：markdown → 公众号 HTML ────────────────────────────────────────
#
# 由 `package-wechat-public-account/scripts/compile_wechat_package.py` **原样搬入**，
# 唯一改动是异常类型换成 CompileError。
#
# 不重写的理由：这是 425 行的确定性转换器，输出是内联样式密集的 HTML。一处 `margin:24px`
# 写成 `margin:20px`、一个 `border-left` 漏掉，人眼看不出来，而公众号后台渲染出来就是版式
# 错乱，且草稿一旦群发不可撤回。等价性由 `tests/test_compile_markdown.py` 的 12 组黄金
# 输出逐字节比对保证——"看起来一样"不算。
#
# 此前能力层只有红线校验：门禁建好了，被门禁检查的东西却在另一层。现在两件事同层，
# 测试直接拿编译产出去过红线。

TEMPLATE_VERSION = "1.3"


DEFAULT_LAYOUT_PROFILE = "balanced"


DEFAULT_THEME_PROFILE = "warm"


LAYOUT_PROFILES: dict[str, dict[str, Any]] = {
    "balanced": {
        "label": "均衡版",
        "heading_weight": 800,
        "paragraph_margin": 16,
        "line_height": 1.85,
        "h2_margin_top": 34,
        "h2_margin_bottom": 16,
        "h3_margin_top": 26,
        "image_margin": 26,
        "card_padding": "15px 18px",
        "section_padding": "10px 13px",
    },
    "compact": {
        "label": "紧凑版",
        "heading_weight": 800,
        "paragraph_margin": 12,
        "line_height": 1.72,
        "h2_margin_top": 28,
        "h2_margin_bottom": 12,
        "h3_margin_top": 22,
        "image_margin": 20,
        "card_padding": "12px 15px",
        "section_padding": "8px 11px",
    },
    "comfortable": {
        "label": "舒展版",
        "heading_weight": 700,
        "paragraph_margin": 20,
        "line_height": 1.95,
        "h2_margin_top": 42,
        "h2_margin_bottom": 18,
        "h3_margin_top": 30,
        "image_margin": 32,
        "card_padding": "18px 20px",
        "section_padding": "12px 15px",
    },
    "column": {
        "label": "专栏版",
        "heading_weight": 900,
        "paragraph_margin": 18,
        "line_height": 1.9,
        "h2_margin_top": 44,
        "h2_margin_bottom": 18,
        "h3_margin_top": 28,
        "image_margin": 30,
        "card_padding": "16px 20px",
        "section_padding": "12px 8px",
    },
}


THEME_PROFILES: dict[str, dict[str, str]] = {
    "warm": {
        "label": "暖色品牌",
        "surface_dark": "#2b1d18",
        "on_dark": "#f7ece6",
        "primary": "#c4513b",
        "primary_dark": "#8f3829",
        "surface": "#fbf6f2",
        "surface_strong": "#f5e9e2",
        "border": "#eadbd2",
        "text": "#262626",
        "muted": "#6f665f",
        "link": "#8f4a3b",
    },
    "minimal": {
        "label": "极简黑白",
        "surface_dark": "#1b1b1b",
        "on_dark": "#f2f2f2",
        "primary": "#202020",
        "primary_dark": "#111111",
        "surface": "#f7f7f7",
        "surface_strong": "#eeeeee",
        "border": "#dddddd",
        "text": "#262626",
        "muted": "#666666",
        "link": "#4f5f75",
    },
    "tech_blue": {
        "label": "科技蓝",
        "surface_dark": "#16242f",
        "on_dark": "#e8f1f6",
        "primary": "#3f708e",
        "primary_dark": "#28536d",
        "surface": "#f3f8fb",
        "surface_strong": "#e5f0f5",
        "border": "#d3e3eb",
        "text": "#24313a",
        "muted": "#5d6e78",
        "link": "#315f7c",
    },
}


THEME_PROFILES.update({identity: {"label": preset["label"], **preset["palette"]}
                       for identity, preset in THEME_PRESETS.items()})


def presentation_profile(
    layout_profile: str, theme_profile: str
) -> tuple[dict[str, Any], dict[str, str]]:
    if layout_profile not in LAYOUT_PROFILES:
        raise CompileError(
            "INVALID_LAYOUT_PROFILE",
            f"未知排版布局：{layout_profile}",
            allowed=sorted(LAYOUT_PROFILES),
        )
    if theme_profile not in THEME_PROFILES:
        raise CompileError(
            "INVALID_THEME_PROFILE",
            f"未知视觉主题：{theme_profile}",
            allowed=sorted(THEME_PROFILES),
        )
    return LAYOUT_PROFILES[layout_profile], THEME_PROFILES[theme_profile]


def validate_reading_profile(reading_profile: str) -> None:
    if reading_profile not in READING_PROFILES:
        raise CompileError("INVALID_READING_PROFILE", f"未知阅读预设：{reading_profile}",
                           allowed=sorted(READING_PROFILES))


#: 行内高亮：`==核心论断==`。
#:
#: **它标的是「这一句是本节的核心判断」，不是「这里很重要」。** 全篇都重要等于都不重要；
#: 密度阈值写在 `typeset-article/references/layout-selection.md`。
#:
#: 不吃跨行的 `==`，也不吃 `====` 这类分隔线写法。
HIGHLIGHT = re.compile(r"==([^=\n]+)==")

#: 高亮 span 的开标签前缀。**产出与识别共用这一个常量。**
#:
#: `_underline_terms` 要认出「这段文字在高亮里面」才能跳过它（§8.2）。
#: 用 style 的起始片段来认，而不是给 span 另加一个标记属性——
#: 加属性会改变 HTML 字节，而渠道包的字节正是验收链绑定的东西，
#: 一改就要重跑 12 组黄金比对、并让所有在途产物的验收章失效。
#:
#: 这个前缀分得开：序号徽章的 style 以 `display:inline-block` 开头，
#: 术语下划线以 `border-bottom` 开头，**只有高亮以 `background` 开头**。
#: 耦合由测试守着——它断言真实产出的开标签确实以此开头，
#: 改了渲染而忘了改这里时当场红。
_HIGHLIGHT_SPAN_OPEN = '<span style="background:'

#: 术语下划线的样式前缀。**画线与找线共用这一个常量。**
#:
#: 密度测量要知道「线实际画在哪了」。它不能自己再匹配一遍正文——
#: 匹配规则有一长串（跳过高亮、链接、行内代码；长术语优先；整篇只划首次），
#: 写第二遍必然与渲染分叉，而分叉出来的数会被当成事实去指导减哪一处。
#: 实测过分叉的样子：术语只出现在高亮里时实际一条线没画，测量却记了一处面积；
#: 正文只有 `GraphRAG` 而术语表配了两个词时，测量把 `RAG` 也算了一遍。
#:
#: 所以测量改成**读渲染结果**（`locate_underlined_terms`），靠这个前缀认出线。
_TERM_SPAN_STYLE = "border-bottom:1px dashed "

#: 二级标题上的序号圆圈：`## 一、RAG 的天花板`、`## 01 谁在买单`。
#:
#: **两种写法，都要求序号与标题分得开**：
#:
#: * 序数 + 紧跟分隔符——`第一、` `一、` `1.` `02：`；
#: * **补零两位数** + 空格——`01 ` `02 `。补零本身就是「这是编号」的信号。
#:
#: 不接受「裸数字 + 空格」：`## 3 个原因` 里的 `3` 是词组的一部分，不是节号，
#: 划成圆圈就把一句话切开了。**宁可漏认，不可错认**——与段落级 `ORDINAL` 同一条原则。
#:
#: 也不接受「中文数字 + 空格」：`## 二级标题` 会被切成「二」+「级标题」。
#: **量词不枚举，用「第」来判。**
#:
#: 前一版列了「节|章|部分|步|讲|篇」，下一篇文章就写了「第一**层**：」，一个都没命中。
#: 枚举量词是输不掉的赌局——层、讲、幕、式、招、关、卷，写的人想用哪个用哪个。
#:
#: 真正把「章节编号」和「数量词组」分开的不是量词表，是**「第」字**：
#:
#: * 有「第」——`第一层：` `第三部分：` `第2节、`——**量词随便写**（0–2 个汉字）；
#: * 没「第」——`一、` `2.` `01 `——**不许带量词**，序数后必须紧跟分隔符。
#:
#: 这条规则同时挡住了两类误认：`三大误区：`（数量词组，没有「第」）与
#: `二级标题`（黄金 fixture 里的标题，没有「第」且「级」后面不是分隔符）。
#: `第三方接口：`、`第一次尝试：` 也不会命中——量词最多吃两个汉字，
#: 吃完之后必须是分隔符，而那里是「口」「试」。
#: **序号与量词之间允许空格，量词之后允许直接接空格。**
#:
#: 第三篇实测写的是 `## 第 1 层 数据管理：查数录数`——数字两侧有空格、量词后面跟的是
#: 空格而不是分隔符。前一版要求 `第` 紧跟数字、量词紧跟分隔符，**又是 0 命中**。
#:
#: 三篇文章三种写法（`第一节：` / `第一层：` / `第 1 层 `），共同点只有
#: 「第 + 数字 + 可选量词」这个头部。**所以收尾放宽成「分隔符**或**空白」**——
#: 这是结构上的放宽（空白与量词正交），不是再往量词表里加字。
#: **分隔符不枚举。** 四篇实测四种写法：`第一节｜`（全角竖线）、`第一层：`、
#: `第 1 层 `（空格）、`一、`。每补一种，下一篇就换一种——分隔符这一维是开放的，
#: 写的人想用竖线用竖线，想用破折号用破折号。
#:
#: `[^\w\s]` 在 Python 3 的 str 模式下正好是「非字母数字、非汉字、非空白」，
#: 也就是**任意标点**。这样 `｜丨·—-/` 全都认，而汉字与字母不会被当成分隔符——
#: `第三方接口：` 里的「方」是 `\w`，挡得住。
_PUNCT = r"[^\w\s]"
_NUM = r"[一二三四五六七八九十]+|[0-9]{1,2}"
#: 序号部分结束的标志：标点（两侧可有空格），或直接就是空白。
_ORDINAL_END = r"(?:\s*" + _PUNCT + r"+\s*|\s+)"

HEADING_ORDINAL = re.compile(
    r"^(?:"
    # 有「第」：数字两侧可有空格，量词 0–2 字，收尾是分隔符或空白
    r"第\s*(" + _NUM + r")\s*[一-鿿]{0,2}" + _ORDINAL_END +
    r"|"
    # 没「第」：不许量词，**也不许只靠空格**，序数后必须是标点——
    # 靠这条挡住 `三大误区：`（数量词组）、`3 个原因`、`二级标题`（黄金 fixture 的标题）
    r"(" + _NUM + r")\s*" + _PUNCT + r"+\s*"
    r"|"
    r"(0[0-9])\s+"                                        # 补零两位数 + 空格
    r")(.+)$"
)


def _is_part_of_longer_word(text: str, at: int, term: str) -> bool:
    """命中的位置是不是某个更长的词的一部分。

    **最长优先只在术语表内部生效**——它防的是表里同时有 `RAG` 和 `GraphRAG`。
    表里的词是**正文里**更长词的前缀时，那条规则完全不管用。

    线上实测踩到的就是这个：术语表填了 `Function`，正文写的是 `Function Calling`
    （全文 5 处）。渲染出来是划了线的 `Function` 加上没划线的 ` Calling`——
    一个专名被从中间切开。`本体` 与 `本体论` 是同一个坑。

    两条判据：

    * **紧邻字符还是 ASCII 字母或数字** —— `RAG` 落在 `GraphRAG` 中间就是这种；
    * **英文词后面紧跟空格 + 大写字母** —— `Function Calling`、`Ontology Schema`
      这类由两个词组成的专名。后面跟中文（`Action 表达业务`）不算，
      那才是术语的正常用法。

    中文没有词边界，`本体建模` 里的 `本体` 该不该划，字符层面判不出来——
    那一类交给校验器在有正文时提示，不在这里猜。
    """
    before = text[at - 1] if at > 0 else ""
    after_at = at + len(term)
    after = text[after_at] if after_at < len(text) else ""
    if before.isascii() and before.isalnum():
        return True
    if after.isascii() and after.isalnum():
        return True
    # `Function Calling`：英文术语 + 空格 + 大写开头的英文词。
    if term[-1:].isascii() and term[-1:].isalnum() and after == " ":
        nxt = text[after_at + 1:after_at + 2]
        if nxt.isascii() and nxt.isupper():
            return True
    return False


def _underline_terms(html_text: str, terms, used: set[str], color: str) -> str:
    """给术语的**首次出现**加下划线。

    ## 为什么走计划字段而不是正文标记

    术语取自 `ArticlePlan.production_plan.terminology`，不是 `[术语]…[/术语]`
    这类正文标记。换来三件事：作者不用记新语法；正文不引入自造标记；
    **字数测量完全不受影响**——`clean_prose` 不剥的标记会被算进篇幅，
    实测一句话里一个高亮加一个术语虚增 13 字。

    ## 跳过哪些位置

    * **标签内部**——`<a href="…">` 的属性值命中术语的话会把 HTML 打烂；
    * **链接文字**——链接本来就有自己的下划线，再叠一层是两种语义挤在一处；
    * **代码**——此时代码还是占位符，天然不会命中。

    ## 最长优先

    `RAG` 与 `GraphRAG` 同时在表里时，短的先匹配会把 `GraphRAG` 里的 `RAG` 划出来，
    留下一个半截词。按长度倒序处理，长的先占位。
    """
    candidates = [term for term in terms if term]
    if not candidates:
        return html_text
    # **已划过的词仍要参与定位。** 它们不再加下划线，但必须整词跳过——
    # 否则 `RAG` 会命中后一处 `GraphRAG` 的内部，把它切成 `Graph` + 半截下划线。
    # 全部划完之后没有任何词还能被划，那时才可以直接返回。
    if all(term in used for term in candidates):
        return html_text

    # **虚线，不是实线。** 三种强调必须一眼分得开：链接是 1px 实线、高亮是底色，
    # 术语再用实线就只剩粗细之差，手机上分不出来。1px 在中文正文里也比 2px 轻。
    style = _TERM_SPAN_STYLE + "%s;" % color
    out: list[str] = []
    index = 0
    in_link = 0
    # 每进一层 `<span>` 压一个「它是不是高亮」，`</span>` 弹出。
    # **要按层计数，不能用一个布尔值**：高亮里面还能再嵌 `<strong>`、`<em>`，
    # 以及本函数自己插进去的下划线 span；只记「在不在高亮里」的话，
    # 内层 span 的 `</span>` 会把外层高亮提前关掉。
    spans: list[bool] = []
    length = len(html_text)
    while index < length:
        if html_text[index] == "<":
            # 标签整体原样搬运，术语不进标签内部。
            close = html_text.find(">", index)
            if close == -1:
                out.append(html_text[index:])
                break
            tag = html_text[index:close + 1]
            lowered = tag.lower()
            if lowered.startswith("<a "):
                in_link += 1
            elif lowered.startswith("</a"):
                in_link = max(0, in_link - 1)
            elif lowered.startswith("<span"):
                spans.append(tag.startswith(_HIGHLIGHT_SPAN_OPEN))
            elif lowered.startswith("</span"):
                if spans:
                    spans.pop()
            out.append(tag)
            index = close + 1
            continue
        nxt = html_text.find("<", index)
        segment = html_text[index:] if nxt == -1 else html_text[index:nxt]
        index = length if nxt == -1 else nxt
        if in_link or any(spans):
            # 链接里：链接自带实线下划线，再叠一层是两种语义挤在一处。
            # 高亮里：底色已经是更强的信号，压一条虚线只是把一处画两遍（§8.2）。
            #
            # **两处都不把词记进 `used`。** 记了的话这个词的「首次出现」额度
            # 就花在了一个不画线的位置上，后面真正该画的那一处反而没有线——
            # 实测过：术语首次出现正好落在高亮里，于是整篇一条术语线都没有。
            out.append(segment)
            continue
        # **处理完一个词就从它后面继续扫**，不能在同一份字符串上反复 find——
        # 那样会命中刚插进去的标记内部，套出嵌套 span。
        while segment:
            best_at, best_term = -1, ""
            for term in candidates:
                at = segment.find(term)
                if at == -1:
                    continue
                # 同一位置上长的赢：`GraphRAG` 与 `RAG` 都从这里开始时，认长的那个。
                if best_at == -1 or at < best_at or (
                        at == best_at and len(term) > len(best_term)):
                    best_at, best_term = at, term
            if best_at == -1:
                break
            if _is_part_of_longer_word(segment, best_at, best_term):
                # 命中的是更长词的一部分。**原样输出并跳过它**，
                # 不然会留下半截下划线。
                out.append(segment[:best_at + len(best_term)])
                segment = segment[best_at + len(best_term):]
                continue
            out.append(segment[:best_at])
            if best_term in used:
                # 已经划过了。原样输出，但**整词跳过**——保护它不被更短的词切开。
                out.append(best_term)
            else:
                out.append('<span style="%s">%s</span>' % (style, best_term))
                used.add(best_term)
            segment = segment[best_at + len(best_term):]
        out.append(segment)
    return "".join(out)


def inline(
    text: str,
    *,
    image_style: str = "display:block;width:100%;height:auto;margin:24px auto;",
    link_color: str = "#576b95",
    strong_color: str = "#111111",
    highlight_bg: str = "",
    highlight_color: str = "",
    term_color: str = "",
    terms=(),
    used_terms: set[str] | None = None,
    styles: dict[str, dict[str, str]] | None = None,
) -> str:
    tokens: list[str] = []

    def stash(value: str) -> str:
        tokens.append(value)
        return f"\x00{len(tokens) - 1}\x00"

    text = re.sub(
        r"`([^`]+)`",
        lambda m: stash(
            f'<code style="padding:2px 5px;background:#f4f4f4;border-radius:3px;font-size:0.92em;">{html.escape(m.group(1))}</code>'
        ),
        text,
    )
    escaped = html.escape(text, quote=False)
    escaped = re.sub(
        r"!\[([^\]]*)\]\(([^)]+)\)",
        lambda m: stash(
            f'<img src="{html.escape(m.group(2), quote=True)}" alt="{html.escape(m.group(1), quote=True)}" style="{image_style}"/>'
        ),
        escaped,
    )
    escaped = re.sub(
        r"\[([^\]]+)\]\((https?://[^)]+)\)",
        lambda m: f'<a href="{html.escape(m.group(2), quote=True)}" style="color:{link_color};text-decoration:none;border-bottom:1px solid {link_color};">{m.group(1)}</a>',
        escaped,
    )
    escaped = re.sub(
        r"\*\*([^*]+)\*\*",
        rf'<strong style="font-weight:700;color:{strong_color};">\1</strong>',
        escaped,
    )
    escaped = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", escaped)
    if highlight_bg:
        # 底色取主题的 surface_strong：**色板之外不另取色**——
        # 每块装饰各自取色，单看都成立，放一篇里就散。
        foreground = f"color:{highlight_color};" if highlight_color else ""
        escaped = HIGHLIGHT.sub(
            lambda m: ('%s%s;padding:1px 4px;border-radius:2px;%s">'
                       "%s</span>" % (_HIGHLIGHT_SPAN_OPEN, highlight_bg,
                                      foreground, m.group(1))),
            escaped,
        )
    if terms and term_color:
        escaped = _underline_terms(
            escaped, terms, used_terms if used_terms is not None else set(), term_color)
    for index, value in enumerate(tokens):
        escaped = escaped.replace(f"\x00{index}\x00", value)
    if styles:
        for tag, role in (("strong", "strong"), ("em", "em"), ("a", "a"),
                          ("code", "inline_code"), ("img", "img")):
            escaped = style_tag(escaped, styles.get(role), tag=tag, all_matches=True)
    return escaped


#: 并列论点段：**段首**的序数 + 紧跟的标点。
#:
#: 作者写「第一，……」是在说「接下来是并列的 N 条，请分开记」——那是**结构**不是叙述。
#: 渲染成与普通段落一样的灰底黑字，等于把作者已经标好的结构抹平，读者扫读时数不出有几条。
#:
#: **只认段首，且要求紧跟标点。** 「第一次尝试失败了」不是并列论点，「第三方接口」也不是。
#: 宁可漏认，不可错认——错认会把正常叙述切成色块，比不认更刺眼。
ORDINAL = re.compile(
    r"^(第[一二三四五六七八九十]+|[0-9]{1,2})\s*([，、：:.])\s*(.+)$", re.S)


#: 不重算的路径：外链与内联数据。它们不是本地文件，算相对没有意义。
_ABSOLUTE_SRC = ("http://", "https://", "data:", "//", "/")


def rebase_image_path(raw: str, *, source_path, output_path) -> str:
    """把源文件里写的图片路径，换成**相对输出文件**的写法。

    线上撞到的：`40-package/渠道包.html` 里是 `30-assets/visual-001.png`，
    解析成 `40-package/30-assets/…`——图真的显示不出来，而 HTML 本身不报错。

    根因是路径基准写在文档里靠人记：`illustrate-article` 一处说「相对会话根」，
    另一处的示例又写 `../../30-assets/`。**「相对谁」本来就不该由写的人回答**——
    编译时源文件与输出文件都在手上，算得出来。

    两种写法都要落到同一个结果：既接受「相对会话根」（旧文档教的），
    也接受「相对正文」（另一处示例教的）。**只认一种的话，改完文档还得等
    所有旧正文重写一遍**，而没重写的那些会静默破图。
    """
    from pathlib import Path

    text = str(raw).strip()
    if not text or text.startswith(_ABSOLUTE_SRC):
        return raw
    source_dir = Path(source_path).parent
    out_dir = Path(output_path).parent

    # 先按「相对源文件」解；解不到实体文件时，再按「相对会话根」试一次。
    # 会话根取源文件的上一层——阶段目录直挂会话根，没有中间层。
    candidates = [source_dir / text, source_dir.parent / text]
    target = next((c for c in candidates if c.exists()), candidates[0])
    try:
        import os

        return Path(os.path.relpath(target, out_dir)).as_posix()
    except ValueError:
        # 跨盘符（Windows）算不出相对路径。原样返回**比抛异常好**：
        # 编译还能跑完，破图由 validate 那道去报。
        return raw


def locate_underlined_terms(markdown: str, terms, **render) -> list[tuple[int, str]]:
    """术语下划线**实际**画在哪了：返回 `[(小节序号, 术语), …]`。

    ## 为什么是「跑一遍渲染再读结果」

    密度测量要把术语面积算进去，就得知道哪些词真的画了线。
    自己按正文再匹配一遍是不行的——匹配规则有一长串：

    * 跳过高亮内部（§8.2）、链接文字、行内代码；
    * 长术语优先，`RAG` 不能从 `GraphRAG` 里面切出来；
    * 整篇只划**首次出现**，而「首次」要跨段累计。

    **写第二遍必然分叉**，而分叉出来的数会被当成事实去指导「该减哪一处」。
    实测过分叉的样子：术语只出现在高亮里时一条线都没画，测量却记了一处面积；
    正文只有 `GraphRAG` 而术语表配了 `GraphRAG` 和 `RAG` 两个词时，
    测量把两个都算了，占比一路报到 137%。

    所以这里不匹配，只**读渲染产物**：渲染器画了几条线、画在哪一节，
    数出来的就是几条。规则改了，这个函数自动跟着改。

    小节序号与 `density.measure` 一致：正文开头（首个 `##` 之前）算第 0 节，
    此后每遇到一个 `<h2` 加一。
    """
    if not terms:
        return []
    html = markdown_to_html(markdown, {}, terms=list(terms), **render)
    marker = '<span style="' + _TERM_SPAN_STYLE
    found: list[tuple[int, str]] = []
    section = 0
    index = 0
    while index < len(html):
        heading = html.find("<h2", index)
        spot = html.find(marker, index)
        if spot == -1:
            break
        if heading != -1 and heading < spot:
            section += 1
            index = heading + 3
            continue
        close = html.find(">", spot)
        end = html.find("</span>", close)
        if close == -1 or end == -1:
            break
        found.append((section, html[close + 1:end]))
        index = end
    return found


def markdown_to_html(
    markdown: str,
    image_map: dict[str, str],
    *,
    layout_profile: str = DEFAULT_LAYOUT_PROFILE,
    theme_profile: str = DEFAULT_THEME_PROFILE,
    reading_profile: str = DEFAULT_READING_PROFILE,
    image_fit: str = DEFAULT_IMAGE_FIT,
    source_path=None,
    output_path=None,
    terms=(),
    block_sink=None,
) -> str:
    """把 markdown 编译成公众号正文**片段**。

    首个一级标题会被摘掉——它走草稿的 `title` 字段，正文里再放一遍就是重复。
    需要知道被摘掉的是什么，用 `extract_title`；需要一份含 H1 的完整文档，
    用 `preview_document`。**摘掉不是问题，摘掉了不吭声才是。**
    """
    if image_fit not in IMAGE_FITS:
        raise CompileError("UNKNOWN_IMAGE_FIT", f"未知图片宽度策略：{image_fit}",
                           known_fits=sorted(IMAGE_FITS))
    validate_reading_profile(reading_profile)
    layout, theme = presentation_profile(layout_profile, theme_profile)
    styles = reading_styles(theme_styles(theme_profile, layout_profile), reading_profile, theme)
    is_story = reading_profile != DEFAULT_READING_PROFILE
    is_preset = theme_profile in THEME_PRESETS
    markdown = strip_editorial_comments(markdown, keep_scene_breaks=True)

    def styled(role: str, markup: str, *, tag: str | None = None,
               all_matches: bool = False) -> str:
        return style_tag(markup, styles.get(role), tag=tag, all_matches=all_matches)

    for source, target in image_map.items():
        markdown = markdown.replace(f"]({source})", f"]({target})")

    # **路径基准由这里算，不由写的人记。** 两头都给了才算——
    # 少一头就退回原样搬运，老调用方不会因为这次改动而崩。
    if source_path is not None and output_path is not None:
        import re as _re

        markdown = _re.sub(
            r"(!\[[^\]]*\]\()([^)]+)(\))",
            lambda m: m.group(1) + rebase_image_path(
                m.group(2), source_path=source_path,
                output_path=output_path) + m.group(3),
            markdown)
    lines = markdown.splitlines()
    blocks = _BlockBuffer(block_sink)
    paragraph: list[str] = []
    list_type: str | None = None
    list_items: list[str] = []
    # 连续引用行属于同一个引用块，先攒后出——逐行成块会把一段引言拆成多张卡片
    quote_lines: list[str] = []
    # 表格必须整块攒齐才能出：第一行是表头，第二行是分隔，之后才是数据。
    # 逐行处理会把分隔行 `|---|---|` 当成数据渲染出来。
    table_lines: list[str] = []
    # `contain` 是缺省：`width:100%` 会把小图拉伸变糊，而校验器的 IMG_WIDTH_100
    # 本来就在提示改成 max-width。默认产出踩自己的告警，等于每篇文章开局带一串噪声，
    # 而噪声多了没人再看告警。表格、封面卡、流程图确实要占满整宽，走 `fill`。
    image_style = (
        f"display:block;{IMAGE_FITS[image_fit]}margin:0 auto;"
        "border-radius:4px;box-sizing:border-box;"
    )

    # 术语「首次出现」是**整篇一次**，不是每段一次——所以这个集合跨段共享。
    used_terms: set[str] = set()

    def render_inline(value: str, *, inherit_foreground: bool = False) -> str:
        inline_styles = styles
        if is_preset and inherit_foreground:
            # 深底标题/表头已有成对的前景与背景，不能再把正文强调色覆盖到其上。
            inline_styles = dict(styles)
            for role in ("strong", "a", "em"):
                properties = {key: val for key, val in styles.get(role, {}).items()
                              if key != "color" and not key.startswith(("background", "border"))}
                properties.update({"color": "inherit", "background": "none", "border": "0"})
                if role == "a":
                    properties["text-decoration"] = "underline"
                inline_styles[role] = properties
            code_properties = {key: val for key, val in styles.get("inline_code", {}).items()
                               if key != "color" and not key.startswith(("background", "border"))}
            code_properties.update({"color": theme["text"], "background": theme["surface_strong"],
                                    "border": "0"})
            inline_styles["inline_code"] = code_properties
        return inline(
            value,
            image_style=image_style,
            link_color=theme["link"],
            strong_color=theme["primary_dark"],
            highlight_bg=theme["surface_strong"],
            highlight_color=theme["text"] if is_preset else "",
            term_color=theme["primary"],
            terms=terms,
            used_terms=used_terms,
            styles=inline_styles,
        )

    def flush_paragraph() -> None:
        if paragraph:
            value = " ".join(part.strip() for part in paragraph)
            ordinal = ORDINAL.match(value)
            if ordinal and not is_preset and not is_story:
                # 序号提成色块，**正文留在段落里**——切成列表项会破坏中文并列论点的行文，
                # 那些段落常常自带论证，不是短句罗列。
                marker, _, rest = ordinal.groups()
                blocks.emit(
                    f'<p style="margin:{layout["paragraph_margin"]}px 0;'
                    f'line-height:{layout["line_height"]};font-size:16px;'
                    f'color:{theme["text"]};text-align:justify;letter-spacing:0.02em;">'
                    f'<span style="display:inline-block;min-width:26px;padding:1px 7px;'
                    f'margin-right:8px;background:{theme["primary"]};color:#ffffff;'
                    'border-radius:3px;font-size:14px;font-weight:700;text-align:center;'
                    f'line-height:1.6;">{html.escape(marker)}</span>'
                    f'{render_inline(rest)}</p>', "paragraph", {"text": value}
                )
                paragraph.clear()
                return
            standalone_strong = re.fullmatch(r"\*\*([^*]+)\*\*", value)
            if standalone_strong and not is_story:
                blocks.emit(styled("conclusion", styled("conclusion_p",
                    '<section style="'
                    f'margin:{layout["paragraph_margin"] + 4}px 0;padding:{layout["card_padding"]};'
                    f'background:{theme["surface_strong"]};border-left:4px solid {theme["primary"]};'
                    f'border-top:1px solid {theme["border"]};border-bottom:1px solid {theme["border"]};'
                    'box-sizing:border-box;">'
                    f'<p style="margin:0;line-height:{layout["line_height"]};font-size:16px;'
                    f'color:{theme["primary_dark"]};font-weight:700;">'
                    f'{render_inline(standalone_strong.group(1))}</p></section>',
                    tag="p")), "conclusion", {"text": value})
            else:
                blocks.emit(styled("p",
                    f'<p style="margin:{layout["paragraph_margin"]}px 0;'
                    f'line-height:{layout["line_height"]};font-size:16px;'
                    f'color:{theme["text"]};text-align:justify;letter-spacing:0.02em;">'
                    f'{render_inline(value)}</p>'
                ), "paragraph", {"text": value})
            paragraph.clear()

    def flush_list() -> None:
        nonlocal list_type
        if list_items:
            tag = list_type or "ul"
            items = "".join(
                f'<li style="margin:8px 0;line-height:{layout["line_height"]};'
                f'color:{theme["text"]};">{render_inline(item)}</li>'
                for item in list_items
            )
            items = styled("li", items, tag="li", all_matches=True)
            blocks.emit(styled("list",
                f'<section style="margin:{layout["paragraph_margin"] + 2}px 0;'
                f'padding:{layout["card_padding"]};background:{theme["surface"]};'
                f'border:1px solid {theme["border"]};box-sizing:border-box;">'
                f'<{tag} style="padding-left:22px;margin:0;">{items}</{tag}></section>'
            ), "ordered_list" if tag == "ol" else "unordered_list", {"items": list(list_items)})
            list_items.clear()
        list_type = None

    def render_code_panel(code_lines: list[str]) -> str:
        """围栏代码块渲染为主题面板。

        面板的背景与文字可深可浅，由主题语义色决定。
        颜色取自主题的 surface_dark/on_dark 语义位，不引入色板外的颜色。
        """
        body = html.escape("\n".join(code_lines))
        return styled("code_panel", styled("pre",
            f'<section style="margin:{layout["paragraph_margin"] + 6}px 0;'
            f'padding:14px 16px;background:{theme["surface_dark"]};'
            'border-radius:6px;box-sizing:border-box;overflow-x:auto;">'
            f'<pre style="margin:0;white-space:pre-wrap;word-break:break-all;'
            f'font-size:14px;line-height:1.7;color:{theme["on_dark"]};'
            "font-family:'SFMono-Regular',Consolas,'Liberation Mono',Menlo,monospace;\">"
            f"{body}</pre></section>", tag="pre"
        ))

    def is_quote_line(value: str) -> bool:
        """引用行包含「空引用行」：`> ` 经 strip 后只剩 `>`，仍属引用块的一部分。

        漏掉这一形态会让 `>` 落到正文分支被当字面量输出——真实发布时正是如此，
        文章开头多出一个孤零零的 `>`。
        """
        return value == ">" or value.startswith("> ")

    def flush_quote() -> None:
        if not quote_lines:
            return
        parts = [render_inline(item) if item else "" for item in quote_lines]
        while parts and not parts[0]:
            parts.pop(0)
        while parts and not parts[-1]:
            parts.pop()
        quote_text = "\n".join(quote_lines)
        quote_lines.clear()
        if not parts:
            return
        # 空行成为空串，join 后自然形成 <br /><br />，即视觉上的段间距
        body = "<br />".join(parts)
        blocks.emit(styled("blockquote",
            f'<blockquote style="margin:{layout["paragraph_margin"] + 4}px 0;'
            f'padding:{layout["card_padding"]};border-left:4px solid {theme["primary"]};'
            f'border-top:1px solid {theme["border"]};border-bottom:1px solid {theme["border"]};'
            f'background:{theme["surface"]};color:{theme["muted"]};'
            f'line-height:{layout["line_height"]};box-sizing:border-box;">'
            f"{body}</blockquote>"
        ), "quote", {"text": quote_text})

    first_heading_skipped = False
    fence_lines: list[str] = []
    in_fence = False
    fence_language = ""
    def is_table_line(value: str) -> bool:
        return value.startswith("|") and value.endswith("|") and len(value) > 2

    def is_separator(value: str) -> bool:
        """`|---|:--:|` 这一行是语法不是内容——漏出来就是一行竖线。"""
        cells = [c.strip() for c in value.strip("|").split("|")]
        return bool(cells) and all(
            c and set(c) <= set("-: ") and "-" in c for c in cells)

    def split_row(value: str) -> list[str]:
        return [c.strip() for c in value.strip().strip("|").split("|")]

    def flush_table() -> None:
        """整块渲染成内联样式的表格。

        **样式必须逐标签内联**：公众号会剥掉 `<style>` 与 class 选择器，
        写在样式表里等于没写。

        **容器要能横向滚动**：手机屏窄，三列以上必然溢出；没有滚动容器时，
        右边的内容不是显示不全，是完全够不着。
        """
        if not table_lines:
            return
        rows = [split_row(l) for l in table_lines if not is_separator(l)]
        table_lines.clear()
        if not rows:
            return
        head, body = rows[0], rows[1:]
        cell_border = f'1px solid {theme["border"]}'
        head_html = "".join(
            f'<th style="padding:8px 10px;border:{cell_border};'
            f'background:{theme["surface_strong"]};color:{theme["primary_dark"]};'
            f'font-weight:700;font-size:15px;text-align:left;">{render_inline(c, inherit_foreground=True)}</th>'
            for c in head
        )
        body_html = "".join(
            "<tr>" + "".join(
                f'<td style="padding:8px 10px;border:{cell_border};'
                f'color:{theme["text"]};font-size:15px;line-height:1.6;">'
                f"{render_inline(c)}</td>" for c in row
            ) + "</tr>"
            for row in body
        )
        head_html = styled("th", head_html, tag="th", all_matches=True)
        body_html = styled("td", body_html, tag="td", all_matches=True)
        blocks.emit(styled("table_wrapper", styled("table",
            f'<section style="margin:{layout["paragraph_margin"] + 2}px 0;'
            'overflow-x:auto;box-sizing:border-box;">'
            '<table style="width:100%;border-collapse:collapse;'
            f'border:{cell_border};box-sizing:border-box;">'
            f"<thead><tr>{head_html}</tr></thead><tbody>{body_html}</tbody>"
            "</table></section>", tag="table"
        )), "table", {"rows": rows})

    for raw in lines:
        line = raw.strip()
        # 围栏必须最先判定：否则栏内的 #、- 会被当成标题和列表解析
        if line.startswith("```"):
            if in_fence:
                blocks.emit(render_code_panel(fence_lines), "code", {"lines": list(fence_lines), "language": fence_language})
                fence_lines.clear()
                in_fence = False
            else:
                flush_paragraph()
                flush_list()
                in_fence = True
                fence_language = line[3:].strip()
            continue
        if in_fence:
            fence_lines.append(raw)
            continue
        # 非引用行即引用块结束。放在此处一次性拦截，胜过在十余个分支各加一次
        if not is_quote_line(line):
            flush_quote()
        if is_table_line(line):
            flush_paragraph()
            flush_list()
            table_lines.append(line)
            continue
        # 同理：非表格行即表格结束，一处拦截
        if table_lines:
            flush_table()
        if SCENE_BREAK.fullmatch(line):
            flush_paragraph()
            flush_list()
            blocks.emit(
                '<p style="margin:28px 0;text-align:center;text-indent:0;'
                f'font-size:14px;line-height:1.5;color:{theme["primary"]};'
                'letter-spacing:0.4em;">* * *</p>', "scene_break", {})
            continue
        if not line:
            flush_paragraph()
            flush_list()
            continue
        if line.startswith("# ") and not first_heading_skipped:
            # 首个一级标题由渠道包的 `title` 字段单独承载，正文里再放一遍就是重复。
            first_heading_skipped = True
            if block_sink:
                block_sink("", "title", {"text": line[2:]})
            flush_paragraph()
            flush_list()
            continue
        if line.startswith("# "):
            # **后续的一级标题降级成 h2，不能继续跳过、更不能漏成正文。**
            #
            # 线上实证：一篇文章的源数据里标题出现了两遍，第二个 `# ` 既不匹配
            # `#{2,3}`（那是二三级），又不再走跳过分支，于是原样掉进普通段落——
            # 草稿里多出一行字面的 `# 为什么是数据本体论？`。不报错、不崩溃，
            # 要人打开公众号后台才看得见。
            #
            # 降级而不是跳过：跳过会**静默吞掉内容**，作者写了标题却什么都没有，
            # 比多个井号更糟。降到 h2 是因为 h1 已被 `title` 占用，同页两个 h1
            # 在公众号里层级混乱。
            line = "#" + line
        heading = re.match(r"^(#{2,3})\s+(.+)$", line)
        if heading:
            flush_paragraph()
            flush_list()
            tag = "h2" if len(heading.group(1)) == 2 else "h3"
            if tag == "h2" and layout_profile == "column":
                style = (
                    f'margin:{layout["h2_margin_top"]}px 0 {layout["h2_margin_bottom"]}px;'
                    f'padding:{layout["section_padding"]};font-size:22px;line-height:1.45;'
                    f'color:{theme["primary_dark"]};font-weight:{layout["heading_weight"]};text-align:center;'
                    f'border-top:1px solid {theme["border"]};border-bottom:2px solid {theme["primary"]};'
                    'letter-spacing:0.04em;box-sizing:border-box;'
                )
            elif tag == "h2":
                style = (
                    f'margin:{layout["h2_margin_top"]}px 0 {layout["h2_margin_bottom"]}px;'
                    f'padding:{layout["section_padding"]};font-size:22px;line-height:1.45;'
                    f'color:{theme["primary_dark"]};font-weight:{layout["heading_weight"]};'
                    f'background:{theme["surface"]};border-left:4px solid {theme["primary"]};'
                    f'border-bottom:1px solid {theme["border"]};box-sizing:border-box;'
                )
            else:
                style = (
                    f'margin:{layout["h3_margin_top"]}px 0 12px;padding:0 0 7px;'
                    f'font-size:18px;line-height:1.5;color:{theme["primary_dark"]};font-weight:{layout["heading_weight"]};'
                    f'border-bottom:1px solid {theme["border"]};'
                )
            text = heading.group(2)
            badge = ""
            numbered = HEADING_ORDINAL.match(text) if tag == "h2" else None
            if numbered and not is_preset and not is_story:
                # 三种写法各占一个捕获组，命中哪个用哪个。
                # **圆圈里只放数字，量词不进去**——「第一节」三个字塞进圆圈会挤成一团，
                # 而「第」和「节」对读者不提供任何信息，序号本身才提供。
                marker = (numbered.group(1) or numbered.group(2)
                          or numbered.group(3))
                text = numbered.group(4)
                badge = (
                    '<span style="display:inline-block;min-width:30px;height:30px;'
                    f'line-height:30px;margin-right:10px;background:{theme["primary"]};'
                    'color:#ffffff;border-radius:15px;font-size:15px;font-weight:700;'
                    f'text-align:center;vertical-align:middle;">{html.escape(marker)}</span>'
                )
            blocks.emit(
                styled(tag, f'<{tag} style="{style}">{badge}{render_inline(text, inherit_foreground=True)}</{tag}>'),
                "heading" if tag == "h2" else "subheading", {"text": heading.group(2), "level": int(tag[1])}
            )
            continue
        image = re.fullmatch(r"!\[([^\]]*)\]\(([^)]+)\)", line)
        if image:
            flush_paragraph()
            flush_list()
            alt_text = image.group(1).strip()
            caption = (
                f'<p style="margin:9px 8px 0;line-height:1.55;font-size:13px;'
                f'color:{theme["muted"]};text-align:center;">'
                f'{html.escape(alt_text)}</p>'
                if alt_text
                else ""
            )
            caption = styled("caption", caption)
            blocks.emit(
                f'<section style="margin:{layout["image_margin"]}px 0;'
                'box-sizing:border-box;text-align:center;">'
                f'{render_inline(line)}{caption}</section>', "image", {"alt": alt_text, "src": image.group(2)}
            )
            continue
        if is_quote_line(line):
            flush_paragraph()
            flush_list()
            quote_lines.append(line[2:].strip() if line != ">" else "")
            continue
        unordered = re.match(r"^[-*+]\s+(.+)$", line)
        ordered = re.match(r"^\d+\.\s+(.+)$", line)
        if unordered or ordered:
            flush_paragraph()
            current = "ul" if unordered else "ol"
            if list_type and current != list_type:
                flush_list()
            list_type = current
            list_items.append((unordered or ordered).group(1))
            continue
        if line in {"---", "***", "___"}:
            flush_paragraph()
            flush_list()
            blocks.emit(styled("hr",
                f'<section style="height:2px;border:0;'
                f'background:linear-gradient(to right,transparent,{theme["primary"]},transparent);'
                f'margin:{layout["h2_margin_top"]}px auto;width:60%;"></section>'
            ), "divider", {})
            continue
        paragraph.append(line)
    if in_fence and fence_lines:
        # 围栏未闭合：照样输出，不要静默吞掉正文内容
        blocks.emit(render_code_panel(fence_lines), "code", {"lines": list(fence_lines), "language": fence_language})
    flush_paragraph()
    flush_list()
    flush_table()
    flush_quote()
    return styled("wrapper",
        '<section style="max-width:100%;box-sizing:border-box;word-break:break-word;'
        "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC',"
        "'Hiragino Sans GB','Microsoft YaHei',sans-serif;\">\n"
        + "\n".join(blocks)
        + "\n</section>\n"
    )


def preview_document(
    title: str,
    html_fragment: str,
    *,
    layout_profile: str,
    theme_profile: str,
    reading_profile: str = DEFAULT_READING_PROFILE,
) -> str:
    validate_reading_profile(reading_profile)
    layout, theme = presentation_profile(layout_profile, theme_profile)
    label = f'{layout["label"]} · {theme["label"]}'
    if reading_profile != DEFAULT_READING_PROFILE:
        label += f' · {READING_PROFILES[reading_profile]["label"]}'
    document = (
        '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>{html.escape(title)} - {html.escape(label)}</title></head>'
        '<body style="margin:0;background:#f1f1f1;">'
        '<main style="max-width:720px;margin:24px auto;padding:28px;background:#fff;box-sizing:border-box;">'
        f'<p style="margin:0 0 10px;font-size:12px;color:{theme["muted"]};">'
        f'{html.escape(label)}</p>'
        f'<h1 style="font-size:28px;line-height:1.4;margin:0 0 24px;color:{theme["primary_dark"]};">'
        f'{html.escape(title)}</h1>{html_fragment}</main></body></html>\n'
    )
    if theme_profile in THEME_PRESETS or reading_profile != DEFAULT_READING_PROFILE:
        styles = reading_styles(theme_styles(theme_profile, layout_profile), reading_profile, theme)
        wrapper = styles.get("wrapper", {})
        # 预览主标题沿用主题字体与底色；正文片段原样嵌入，契约记录仍绑定同一输入。
        main_style = {key: value for key, value in wrapper.items()
                      if key in {"font-family", "color", "background-color", "background-image"}}
        background = main_style.get("background-color", "").strip()
        # 上游透明背景以白纸为底，不能在预览中透出页面外侧的灰色画布。
        if background == "transparent" or re.fullmatch(r"rgba\([^)]*,\s*0(?:\.0+)?\s*\)", background):
            main_style.pop("background-color", None)
        document = style_tag(document, main_style, tag="main")
        document = style_tag(document, styles.get("h1"), tag="h1")
    return document
