#!/usr/bin/env python3
"""视频合成：字幕烧录、分段拼接、响度归一。

最要紧的一条来自真实事故：**FFmpeg 的 ``drawtext`` 会把 ``%`` 静默吞掉，而退出码是 0。**
曾导致「16% → 54%」整句从成片里消失，没有任何报错——渲染成功、文件正常、内容缺失。
``%`` 在 drawtext 里是文本展开的引导符，必须显式 ``expansion=none`` 关掉。

因此本模块**不提供**手工拼 drawtext 串的口子：唯一入口 :func:`build_drawtext` 恒带该开关。
把「记得加 expansion=none」从纪律变成机制，与空间寻址那条同理——纪律能维持一时。

与图像栅格化分开而非合并：依赖不同（ffmpeg 对 chromium）、调用者不同（本能力只服务视频，
栅格化服务全部三条创作链路）、失败模式不同（编码失败与音画不同步，对渲染超时与字体缺失）。
"""

from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Iterable, Sequence

VERSION = "1.0.0"

#: 响度归一。三个参数一起才是这条规格，不许只写其一。
LOUDNORM = "loudnorm=I=-16:LRA=7:TP=-1.5"

#: 阶段产出：重做下游靠它们，**不可当中间件清理**。
STAGE_OUTPUTS: frozenset[str] = frozenset({"final.mp4", "narration.wav", "subtitles.ass"})

#: 过程中间件的特征。实测一件 132 秒作品，这部分逾 60 MB 而成片仅 3.8 MB。
_INTERMEDIATE_MARKERS = (
    "segment_", "final_nosub", "lines/", "trimmed/", "padded/", "norm_",
)


class VideoError(RuntimeError):
    """参数非法、ffmpeg 不可用，或产物缺失。"""


def _ffmpeg() -> str:
    found = shutil.which("ffmpeg")
    if not found:
        raise VideoError("未找到 ffmpeg。Linux 上：apt-get install -y ffmpeg。")
    return found


def _ffprobe() -> str:
    found = shutil.which("ffprobe")
    if not found:
        raise VideoError("未找到 ffprobe（通常随 ffmpeg 一同安装）。")
    return found


# ── drawtext ──────────────────────────────────────────────────────────────


def _escape(value: str) -> str:
    """转义 drawtext 的元字符。

    冒号是滤镜参数分隔符，反斜杠与单引号会破坏引号配对——漏转会让整条滤镜串解析错位，
    而 ffmpeg 未必报错，可能只是渲出别的东西。
    """
    out = value.replace("\\", r"\\\\")
    out = out.replace("'", r"\'")
    out = out.replace(":", r"\:")
    return out


def build_drawtext(
    text: str,
    *,
    fontfile: str | None = None,
    fontsize: int = 42,
    fontcolor: str = "white",
    x: str = "(w-text_w)/2",
    y: str = "h-text_h-40",
    box: bool = False,
) -> str:
    """构造 drawtext 滤镜串。**恒带 ``expansion=none``。**

    这是本模块唯一的 drawtext 入口，不另开手工拼串的口子——``%`` 被静默吞掉且退出码为 0，
    靠人记得加开关，迟早会漏。
    """
    if not str(text or "").strip():
        raise VideoError("drawtext 需要非空文本。")

    parts = [
        f"text='{_escape(str(text))}'",
        # 关掉文本展开：否则 % 与 {} 会被当作展开指令吞掉，且退出码仍为 0
        "expansion=none",
        f"fontsize={int(fontsize)}",
        f"fontcolor={fontcolor}",
        f"x={x}",
        f"y={y}",
    ]
    if fontfile:
        parts.insert(1, f"fontfile='{_escape(str(fontfile))}'")
    if box:
        parts.extend(["box=1", "boxcolor=black@0.5", "boxborderw=8"])
    return "drawtext=" + ":".join(parts)


# ── 阶段产出与中间件 ──────────────────────────────────────────────────────


def is_intermediate(name: str) -> bool:
    """是否为过程中间件（可清理）。

    ``.meta/`` 中的内容**同属阶段产出**，只是机器读——manifest 是下游的输入，
    删了就重做不了，故不算中间件。
    """
    value = str(name or "").replace("\\", "/")
    tail = value.rsplit("/", 1)[-1]
    if tail in STAGE_OUTPUTS:
        return False
    if "/.meta/" in f"/{value}" or value.startswith(".meta/"):
        return False
    return any(marker in value for marker in _INTERMEDIATE_MARKERS)


# ── 拼接 ──────────────────────────────────────────────────────────────────


def concat_list(parts: Sequence[str | Path], output: str | Path) -> Path:
    """写 ffmpeg concat 清单。单引号按 shell 规则转义，否则含引号的文件名会截断路径。"""
    items = [Path(item) for item in parts]
    if not items:
        raise VideoError("拼接清单不能为空。")
    lines = []
    for item in items:
        escaped = str(item.resolve()).replace("\\", "/").replace("'", r"'\''")
        lines.append(f"file '{escaped}'")
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target


# ── 探测 ──────────────────────────────────────────────────────────────────


def ffprobe_duration(path: str | Path) -> float:
    """实测时长。与配音能力同源：时长只测不算。"""
    target = Path(path)
    if not target.is_file():
        raise VideoError(f"文件不存在：{target}")
    done = subprocess.run(
        [
            _ffprobe(), "-v", "quiet", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(target),
        ],
        capture_output=True, text=True, timeout=60, check=False,
    )
    try:
        return float((done.stdout or "").strip())
    except ValueError:
        raise VideoError(f"无法读取时长：{target}") from None


def run_ffmpeg(argv: Iterable[str], *, expect: str | Path | None = None) -> dict[str, Any]:
    """执行 ffmpeg 并校验产物。

    **不以退出码为唯一判据**——当年正是退出码 0 掩盖了内容缺失。产物不存在或为空一律失败。
    """
    command = [_ffmpeg(), "-v", "error", "-y", *[str(item) for item in argv]]
    done = subprocess.run(command, capture_output=True, text=True, timeout=1800, check=False)
    if expect is not None:
        target = Path(expect)
        if not target.is_file() or target.stat().st_size == 0:
            detail = (done.stderr or done.stdout or "").strip()[:400]
            raise VideoError(
                f"ffmpeg 退出码 {done.returncode}，但产物缺失或为空：{target}。"
                f"输出：{detail or '（无）'}"
            )
    return {"returncode": done.returncode, "stderr": (done.stderr or "").strip()}


__all__ = [
    "VERSION",
    "LOUDNORM",
    "STAGE_OUTPUTS",
    "VideoError",
    "build_drawtext",
    "is_intermediate",
    "concat_list",
    "ffprobe_duration",
    "run_ffmpeg",
    "wrap_subtitle",
    "check_framing_loss",

]


# ── 画幅归一：任意尺寸素材 → 视频画幅（A6）─────────────────────────────────
#
# 由 `article-scene-render/scripts/normalize_scene_images.py` 迁入。
# **只迁了归一，没迁场景路由**——`route_scenes.py` 判定每个场景走复用配图／Infographic／
# AI 生图，那是业务判断，按方案归视频创作 Skill。把它也拖进来，能力就重新长出业务判断。

NORMALIZE_WIDTH = 1920
NORMALIZE_HEIGHT = 1080
NORMALIZE_PAD_COLOR = "white"
#: 宽高比差异小于此值视为无需补边。
RATIO_EPSILON = 0.005


def probe_video(path) -> dict:
    """探测成片的画幅与帧率。

    门禁必须看**真实文件**：脚本里写 `aspect_ratio: "9:16"` 只说明打算竖屏。
    我们这次脚本里就写着 9:16，出来的仍是 1920×1080——声明与产物脱节，
    而脱节正是这类 bug 的常态。
    """
    target = Path(path)
    if not target.is_file():
        raise VideoError(f"成片不存在：{target}")
    done = subprocess.run(
        [_ffprobe(), "-v", "quiet", "-select_streams", "v:0", "-show_entries",
         "stream=width,height,r_frame_rate", "-of", "default=nw=1:nk=1", str(target)],
        capture_output=True, text=True)
    fields = [line for line in done.stdout.splitlines() if line.strip()]
    if len(fields) < 3:
        raise VideoError(f"ffprobe 读不出视频流：{target}")
    num, _, den = fields[2].partition("/")
    return {"width": int(fields[0]), "height": int(fields[1]),
            "fps": int(num) / int(den or 1)}


def normalize_filter(width: int = NORMALIZE_WIDTH, height: int = NORMALIZE_HEIGHT,
                     *, pad_color: str = NORMALIZE_PAD_COLOR) -> str:
    """等比缩放进目标框，白底居中补边。

    **不拉伸**——拉伸会让人脸和图表变形，补边只是加边，信息不失真。

    ``pad_color`` **默认仍是白**：文章配图与图文卡片链路都在用白底，改默认会打坏它们。
    暗色视频要显式传底色——白边框在近黑画面里是两道刺眼的亮杠。
    **`setsar=1` 不能省**——少了它像素比会漂，同一批图在播放器里宽窄不一，而 ffmpeg 不报错。
    """
    return (
        f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
        f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:{pad_color},"
        "setsar=1"
    )


def normalize_command(source, target, *, width: int = NORMALIZE_WIDTH,
                      height: int = NORMALIZE_HEIGHT, ffmpeg: str = "ffmpeg",
                      pad_color: str = NORMALIZE_PAD_COLOR) -> list[str]:
    """归一的是**图**不是视频：`-frames:v 1` 不能省，否则静态图会被编成一段。"""
    return [
        ffmpeg, "-y", "-loglevel", "error",
        "-i", str(source),
        "-vf", normalize_filter(width, height, pad_color=pad_color),
        "-frames:v", "1",
        str(target),
    ]


def needs_padding(source_size, target: tuple[int, int]) -> bool:
    """尺寸未知时**保守判为需要补边**。

    猜一个可能错的结论，不如提醒复核。这是显式选择，不是遗漏。
    """
    if (not isinstance(source_size, (list, tuple)) or len(source_size) != 2
            or not all(isinstance(v, int) and v > 0 for v in source_size)):
        return True
    return abs(source_size[0] / source_size[1] - target[0] / target[1]) > RATIO_EPSILON


def normalize_image(source, target, *, width: int = NORMALIZE_WIDTH,
                    height: int = NORMALIZE_HEIGHT, ffmpeg: str | None = None,
                    pad_color: str = NORMALIZE_PAD_COLOR):
    """归一单张素材。**ffmpeg 退出码不可信，故回验产出文件确实存在。**"""
    import shutil as _shutil
    import subprocess as _subprocess
    from pathlib import Path as _Path

    source, target = _Path(source), _Path(target)
    if not source.is_file():
        raise VideoError(f"源素材不存在：{source}")
    binary = ffmpeg or _shutil.which("ffmpeg")
    if not binary:
        raise VideoError("未找到 ffmpeg；归一化依赖它，请先安装或显式传入路径")
    target.parent.mkdir(parents=True, exist_ok=True)
    command = normalize_command(source, target, width=width, height=height, ffmpeg=binary)
    try:
        done = _subprocess.run(command, capture_output=True, text=True)
    except OSError as exc:
        raise VideoError(f"调用 ffmpeg 失败：{type(exc).__name__}") from exc
    if done.returncode != 0:
        tail = (done.stderr or "").strip().splitlines()
        raise VideoError(f"ffmpeg 归一化失败（退出码 {done.returncode}）："
                         f"{tail[-1] if tail else '无错误输出'}")
    if not target.is_file():
        raise VideoError(f"ffmpeg 未产出输出文件：{target}")
    return target


# ── 竖屏三段式布局（A5）────────────────────────────────────────────────────
#
# 由 `article-video-orchestrator/scripts/build_vertical_layout.py` 迁入。
# 该 Skill 的另一半——九阶段调度与三个确认节点——是**业务编排**，归视频创作 Skill。

VERTICAL_WIDTH = 1080
VERTICAL_HEIGHT = 1920
#: 三段式的底色**从风格档取**，这里不留常量。
#: 曾经这里是两行 `= "white"`——用暗色档出竖屏，标题区与字幕区是白的，
#: 中间嵌一张近黑的图，渲染成功、退出码 0，只是没法发。
#: 这是 `style/__init__.py` 开篇说的那个坑的第四处。

#: 竖屏字幕 54 号，不是横屏那个 35——竖屏观看距离更近但画面更窄，
#: 沿用横屏字号会小到看不清。这是实拍调出来的，不是等比换算。
VERTICAL_SUBTITLE_FONT_SIZE = 54
VERTICAL_SUBTITLE_OUTLINE = 3
VERTICAL_SUBTITLE_SHADOW = 0
VERTICAL_SUBTITLE_FONT = "Microsoft YaHei"

_TITLE_BAND_HEIGHT = 600


def _even(value: int) -> int:
    """向上取偶。

    yuv420p 要求偶数尺寸，奇数会编码失败**或被静默缩放**——后者更麻烦：
    产出存在、退出码为 0，只是画面比预期小一点，肉眼几乎看不出来。
    """
    return value if value % 2 == 0 else value + 1


def band_layout() -> dict[str, dict[str, int]]:
    """三条带的 y 偏移与高度，自上而下：标题、配图、字幕。

    三条必须**恰好铺满**画面：留缝会露出背景色，重叠会盖住内容，两种都不报错。
    """
    image_height = _even(round(VERTICAL_WIDTH * 9 / 16))
    title_height = _even(_TITLE_BAND_HEIGHT)
    subtitle_height = VERTICAL_HEIGHT - title_height - image_height
    if subtitle_height <= 0 or subtitle_height % 2 != 0:
        raise VideoError("三段式高度分配无法满足偶数约束，请调整 _TITLE_BAND_HEIGHT")
    return {
        "title": {"y": 0, "height": title_height, "width": VERTICAL_WIDTH},
        "image": {"y": title_height, "height": image_height, "width": VERTICAL_WIDTH},
        "subtitle": {"y": title_height + image_height,
                     "height": subtitle_height, "width": VERTICAL_WIDTH},
    }


def vertical_filter_complex(*, pack: str, duration: float | None = None) -> str:
    """把归一后的 16:9 素材合入竖屏帧。输入 0 为场景图，输出标签 ``[vout]``。

    字幕由 ASS 单独烧录，不在此处叠加。

    Args:
        pack: 风格档 id。**必填，没有默认值**——给默认就等于又造一个
            「写死在代码里的白」，而那正是风格档存在的理由。
    """
    from byclaw_caps.style import get_pack

    colour = get_pack(pack)["background"]
    image = band_layout()["image"]
    length = f":d={duration:g}" if duration else ""
    return (
        f"[0:v]scale={VERTICAL_WIDTH}:{image['height']}"
        ":force_original_aspect_ratio=decrease,"
        f"pad={VERTICAL_WIDTH}:{image['height']}:(ow-iw)/2:(oh-ih)/2:{colour},"
        "setsar=1[scene];"
        f"color=c={colour}:s={VERTICAL_WIDTH}x{VERTICAL_HEIGHT}{length}[bg];"
        f"[bg][scene]overlay=0:{image['y']}[vout]"
    )


def vertical_ass_margin() -> int:
    """让字幕落在下带中部，**不贴帧底**。

    贴底会被各平台的进度条与点赞栏挡住，而预览时看不出来——那些控件是播放器叠上去的。
    """
    return _even(band_layout()["subtitle"]["height"] // 3)


def vertical_ass_style() -> str:
    """竖屏字幕的 ASS 样式头，用于覆盖默认的横屏参数。"""
    return (
        f"PlayResX={VERTICAL_WIDTH}\n"
        f"PlayResY={VERTICAL_HEIGHT}\n"
        f"FontName={VERTICAL_SUBTITLE_FONT}\n"
        f"FontSize={VERTICAL_SUBTITLE_FONT_SIZE}\n"
        f"Outline={VERTICAL_SUBTITLE_OUTLINE}\n"
        f"Shadow={VERTICAL_SUBTITLE_SHADOW}\n"
        "Alignment=2\n"
        f"MarginV={vertical_ass_margin()}\n"
    )


# ── 镜头运动：一张图靠取景变化支撑多个镜头 ────────────────────────────────
#
# 分镜契约的 `standard` 档（默认）是「每段旁白一个镜头，但镜头可复用同一张图的不同取景」。
# **没有运镜这一档就不成立**：同一张图配两个镜头会变成静止画面横跨两段旁白，
# 正是那份契约要消灭的东西。

#: 取景区域，(x, y, w, h) 均为占全图的比例。
#: 左右半不重叠——重叠的话两个镜头会讲同一块内容。
FRAMING_REGIONS: dict[str, tuple[float, float, float, float]] = {
    "full": (0.0, 0.0, 1.0, 1.0),
    "left-half": (0.0, 0.0, 0.5, 1.0),
    "right-half": (0.5, 0.0, 0.5, 1.0),
    "top": (0.0, 0.0, 1.0, 0.5),
    "bottom": (0.0, 0.5, 1.0, 0.5),
    "center": (0.2, 0.2, 0.6, 0.6),
}

MOTION_TYPES: frozenset[str] = frozenset({"none", "push-in", "pull-out", "pan"})

#: 静止画面上限，**与档位无关**。超过这个时长画面不动，观众会以为卡住了。
#: 它会反过来限制 economy 档：三段旁白 12 秒共用一个静止镜头，即使 must_show 相同
#: 也不许——经济档省的钱因此有天花板，这是对的。
MAX_STILL_SECONDS = 8

# 运镜行程上限。1.15 之上，确定性渲染的图表会被切掉边缘文字；
# 之下则在大屏上看不出画面在动。
MAX_ZOOM = 1.15

#: 超采样倍率。zoompan 每帧按 z 裁一块，裁剪坐标落在**整数像素**上——
#: z 平滑变化而裁剪框在整数格上跳，这就是肉眼看到的抖动。
#: 先放大再 zoompan，同样的整数误差在最终画面上只剩 1/N。
#: 4 倍在 1080p 下是 7680×4320 的中间帧，内存与 CPU 都不低，所以做成可配。
SUPERSAMPLE = 4

#: 按素材类型分档。**全局 1.15 对文字密集的信息图太大**——
#: 哪怕留了 8% 安全区，画面也会飘。而且每一镜都 push-in，本身就机械。
CAMERA_PROFILES: dict[str, dict] = {
    # 元素已经在依次出现，画面本来就在变，不必再推镜头。
    "infographic_build": {"type": "none", "max_zoom": 1.0},
    "number_card":       {"type": "none", "max_zoom": 1.0},
    "concept_ai":        {"type": "push-in", "max_zoom": 1.04},
    # 只有旁白确实从左讲到右时才 pan，否则是为动而动。
    "wide_flow":         {"type": "pan", "max_zoom": 1.08},
    "title_card":        {"type": "push-in", "max_zoom": 1.06},
}


def camera_for_material(material: str) -> dict:
    """取该素材类型的默认运镜。未知类型报错，不回落到 push-in。"""
    profile = CAMERA_PROFILES.get(str(material))
    if profile is None:
        raise VideoError(
            f"未知素材类型 {material!r}。可用：{'、'.join(sorted(CAMERA_PROFILES))}。")
    return dict(profile)


def check_framing_loss(shots) -> list[str]:
    """事实类画面必须整幅显示——`framing` 只能是 `full`。

    ## 这条判据改过一次，第一版是错的

    第一版判「取景会不会裁掉**所选区域**」，并把 `fit: contain` 当成合法出路。
    重制之后用户说「图片还是没有修复，还是只显示局部」——他是对的：

        SH014  framing: left-half  fit: contain
        → 所选区域（左半张）完整显示了，**可它本来就只是半张图**，
          而且 8:9 的竖条塞进 16:9 要留两条大边，内容缩到 473/1080 宽。

    **「完整显示所选区域」不等于「完整显示这张图」。** 第一版修的是前者，
    用户要的是后者。`contain` 只是把「悄悄丢一半」变成「明明白白丢一半，还更小」。

    各取景实际展示整幅图的比例：`full` 100%，`top`／`bottom`／`left-half`／
    `right-half` 各 50%，`center` 只有 36%。**除 `full` 外没有一种是完整的**——
    `center` 一度被列进「无损」名单，那是同一个错误的另一面：
    它不裁所选区域，但所选区域只有 36%。

    ## 那变化从哪来

    `shot-contract.md` 要求「复用时 framing 必须不同」，是为了避免静止画面横跨
    两段旁白。对事实类画面，那个变化**只能由 `motion` 提供**（push-in／pan），
    不能靠裁取景——裁掉的是事实。

    ## 为什么只能在脚本层判

    滤镜层不知道图是什么。照片裁到左半边是正常镜头语言，
    一刀切会让所有隐喻镜挂上黑边。能分辨的只有 `visual.intent`。

    缺 `intent` 不在这里报：那由路由那条规则管，重复报一遍只会淹掉真问题。
    """
    issues: list[str] = []
    for shot in (shots or []):
        if not shot:
            continue
        visual = shot.get("visual") or {}
        intent = str(visual.get("intent") or "").strip()
        if intent not in FACT_INTENTS:
            continue
        framing = str(visual.get("framing") or "full").strip() or "full"
        if framing == "full":
            continue
        region = FRAMING_REGIONS.get(framing)
        share = f"{region[2] * region[3]:.0%}" if region else "不到整幅"
        issues.append(
            f"{shot.get('id') or '?'} 是事实类画面（intent {intent}），"
            f"却用了 framing {framing!r}——它只展示整幅图的 {share}，"
            "**裁掉的那部分就是被裁掉的事实**。"
            "改成 framing: full；同一张图复用多次要的变化由 motion 提供"
            "（push-in／pan），不能靠裁取景。"
            "（`fit: contain` 不解决这个：所选区域完整了，可它仍然只是一部分，"
            "而且留边之后更小。）")
    return issues



def _framing_ratio(framing: str) -> tuple[float, float, float, float]:
    region = FRAMING_REGIONS.get(framing)
    if region is None:
        raise VideoError(
            f"未知取景 {framing!r}。可用：{'、'.join(sorted(FRAMING_REGIONS))}。")
    return region


def framing_crop(framing: str, width: int, height: int) -> dict[str, int]:
    """把取景比例换算成像素。**结果一律取偶数**——yuv420p 要求偶数尺寸，
    奇数会编码失败或被静默缩放。"""
    region = FRAMING_REGIONS.get(framing)
    if region is None:
        raise VideoError(
            f"未知取景 {framing!r}。可用：{'、'.join(sorted(FRAMING_REGIONS))}。")
    x, y, w, h = region
    return {
        "x": _even(int(width * x)), "y": _even(int(height * y)),
        "w": _even(int(width * w)), "h": _even(int(height * h)),
    }


def build_motion_filter(motion: str, *, duration: float, fps: int,
                        width: int, height: int, framing: str = "full",
                        fit: str = "cover", background: str | None = None,
                        max_zoom: float = MAX_ZOOM,
                        supersample: int = SUPERSAMPLE) -> str:
    """构造运镜滤镜串。

    **`d` 是帧数不是秒数。** 写成秒会得到一个几乎瞬间结束的运镜，而 ffmpeg 退出码正常——
    又一个"看起来成功的坏产物"。必须用 `时长 × 帧率` 换算。

    **输出尺寸必须显式给 `s=`。** 不给的话 zoompan 按输入尺寸输出，
    一张 2736×1536 的生图会直接把整条视频拖成那个画幅。
    """
    if motion not in MOTION_TYPES:
        raise VideoError(
            f"未知镜头运动 {motion!r}。可用：{'、'.join(sorted(MOTION_TYPES))}。")
    if duration <= 0:
        raise VideoError("镜头时长必须为正——0 秒会让 zoompan 的 d=0，行为未定义。")
    # **取景按输入图尺寸算，不能按输出尺寸算。**
    # 曾经把输出的 640×360 传进 framing_crop，于是 right-half 只裁到 x=320，
    # 而源图 1920 宽——那个位置还在左半边。ffmpeg 退出码 0、时长画幅全对，
    # 只是画面裁错了地方，抽帧比对才发现。
    #
    # 故用 iw/ih 表达式让 ffmpeg 在运行时按真实输入尺寸计算。
    x, y, w, h = _framing_ratio(framing)
    # **取完区域之后，宽高比多半就不是画幅的比例了。** `bottom` 取的是
    # 1920×540 那条 3.56:1 的横条，塞进 16:9 只有两条路：
    #
    # * `cover`（默认）：裁掉两侧铺满。**照片就该这样**——「推近到左半边」
    #   本来就是正常镜头语言，丢掉上下不影响看懂。
    # * `contain`：留边，所选区域一点不少。**信息图必须这样**。
    #
    # 以前只有 cover 一条路，于是一张三卡信息图配 `framing: bottom`，
    # 一半宽度静默消失——而 `must_show` 点名要展示的那行口径注，
    # 恰恰在被裁掉的那半里。画面看着是好的，只是少了东西，
    # 要抽帧与原图逐一比对才发现，那条片子已经验收交付了。
    #
    # 该走哪条不由这里判（这里不知道图是什么），由 `check_framing_loss`
    # 在脚本层按 `visual.intent` 拦。
    if fit not in ("cover", "contain"):
        raise VideoError(f"未知 fit {fit!r}。可用：cover（裁到铺满）、contain（留边全见）。")
    # 判据是 `w != h`，不是拿区域去比画幅：区域是**源图**的比例，
    # 而源图在进这一步之前已经归一到画幅比例（`img-*-1920.png` 那批）。
    # 于是「区域比例 == 画幅比例」⇔「w == h」。
    needs_pad = fit == "contain" and abs(w - h) > 1e-9
    if needs_pad:
        if not background:
            raise VideoError(
                f"fit='contain' 且取景 {framing!r} 与画幅 {width}x{height} 比例不同，"
                "要留边才能完整显示——请传 background=<风格档底色>。"
                "**不给默认色**：默认就是又造一个写死在代码里的白，"
                "而风格档存在的理由正是这个。")
        normalise = (f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
                     f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:{background}")
    else:
        normalise = (f"scale={width}:{height}:force_original_aspect_ratio=increase,"
                     f"crop={width}:{height}")
    base = f"crop=iw*{w:g}:ih*{h:g}:iw*{x:g}:ih*{y:g},{normalise}"
    if motion == "none":
        # 静止镜头也要归一到目标画幅，否则同一条片子里画幅会跳。
        return f"{base},setsar=1"
    frames = max(1, round(duration * fps))
    span = max(0.0, float(max_zoom) - 1.0)
    # **行程铺满整个镜头，且走余弦缓入缓出。**
    #
    # 速率写死过一次：0.0012/帧，125 帧（5 秒）就撞上限，一个 11 秒镜头后 6 秒完全不动，
    # 而 check_stillness 见 motion != none 就放行，静止上限管不到它。
    #
    # 匀速则是「生硬」的直接来源。余弦缓动让起止两端速度为零、中段最快——
    # 缺了它，任何运镜都像机器在推。终点仍落在 max_zoom，不因缓动而漂。
    ease = f"(0.5-0.5*cos(PI*on/{frames}))"
    zoom = {
        "push-in": f"1+{span:.6f}*{ease}",
        "pull-out": f"{max_zoom:g}-{span:.6f}*{ease}",
        "pan": f"{max_zoom:g}",
    }[motion]
    x = ("iw/2-(iw/zoom/2)" if motion != "pan"
         else f"(iw-iw/zoom)*{ease}")
    # **先放大再 zoompan，最后缩回。** 裁剪坐标落在整数像素上，
    # z 平滑变化而裁剪框在整数格上跳——那就是抖动。放大 N 倍后误差只剩 1/N。
    up = f"scale=iw*{int(supersample)}:ih*{int(supersample)}:flags=lanczos," if supersample > 1 else ""
    return (f"{base},{up}zoompan=z='{zoom}':x='{x}':y='ih/2-(ih/zoom/2)':"
            f"d={frames}:s={width}x{height}:fps={fps},setsar=1")


#: 一行汉字上限。1080p 下超过这个数会压到画面外沿，读不完。
SUBTITLE_LINE_CHARS = 22
#: 字幕最多两行——三行会吃掉画面下三分之一。
SUBTITLE_MAX_LINES = 2
#: 到达字数上限后，最多再往前够这么多个字去找标点。
#: 给 0 就退回硬断，会断在词中间。
SUBTITLE_REACH = 4
#: 优先在这些标点后断行。
_SUBTITLE_BREAKS = "，。：；？！—、"


def _balance(source: str, max_lines: int, per_line: int, *,
             cap: int | None = None) -> list[str]:
    """把整段文本平分成 max_lines 行，断点优先落在中点附近的标点上。

    **够得着的标点未必是安全的标点。** 原来只按中点 ±(per_line//3) 找最近的标点，
    完全不看切出来的行有多长——总长 42、标点在第 14 字时，第二行 28 字，
    而 `validate_script` 的行长上限是 `per_line + reach` = 26。
    **同一个模块，产出的东西过不了自己的检查**：作者只能反复改文案，
    直到标点碰巧落在合适的位置。共有 92 种输入会这样。

    所以候选点先过一道「切完两边都不超 `cap`」的筛。筛没了就退回中点硬切——
    中点是安全的（总长 ≤ max_lines × cap 时，均分必然每行 ≤ cap），
    **宁可断在词中间，也不吐出一行过不了检查的字幕**。
    """
    limit = per_line if cap is None else cap
    total, parts, start = len(source), [], 0
    for index in range(max_lines - 1):
        remaining = max_lines - index
        ideal = start + round((total - start) / remaining)
        window = max(2, per_line // 3)
        best = -1
        for offset in range(window + 1):
            for candidate in (ideal + offset, ideal - offset):
                if not (start < candidate <= total):
                    continue
                if source[candidate - 1] not in _SUBTITLE_BREAKS:
                    continue
                # 这一行以及**剩下要分的每一行**都得装得下。
                if candidate - start > limit:
                    continue
                if (total - candidate) > limit * (remaining - 1):
                    continue
                best = candidate
                break
            if best > 0:
                break
        cut = best if best > 0 else min(total, ideal)
        parts.append(source[start:cut])
        start = cut
    parts.append(source[start:])
    return [x for x in parts if x]


def wrap_subtitle(text: str, *, per_line: int = SUBTITLE_LINE_CHARS,
                  max_lines: int = SUBTITLE_MAX_LINES,
                  reach: int = SUBTITLE_REACH) -> str:
    """按标点优先断行，返回 ASS 的 ``\\N`` 分隔串。

    **断行只许改换行位置，不许改一个字。** 第一版并入超长行时写成
    ``out[-2] += out.pop()``：增量赋值先取 ``out[-2]`` 的值，再执行会缩短列表的
    ``out.pop()``，最后按**已经变短的列表**重新算 ``-2`` 存回去——存到了上一格。
    结果首句被覆盖、次句被复制一遍，而 ffmpeg 退出码 0、字幕条数时长全对。

    所以合并前先把要并的那段取出来，再定位目标行。
    """
    source = str(text or "")
    if not source:
        raise VideoError("字幕文本为空——空字幕烧进去不会报错，只是那一段没有字")
    lines, current, index = [], "", 0
    while index < len(source):
        char = source[index]
        current += char
        index += 1
        # ``——`` 是两个字符。只看单个 ``—`` 就断，会把破折号劈成两半，
        # 第二行以孤零零一个 ``—`` 开头——成片抽帧才看见。
        if char == "—" and source[index:index + 1] == "—":
            current += "—"
            index += 1
        at_break = char in _SUBTITLE_BREAKS and len(current) >= per_line * 0.6
        if at_break:
            lines.append(current)
            current = ""
        elif len(current) >= per_line:
            # 够不着标点就硬断，会断出「一直在自己流进 / 来。」这种。
            # 先往前看 ``reach`` 个字：能够到标点就走过去，够不到才硬断。
            ahead = source[index:index + reach]
            hit = min((ahead.find(b) for b in _SUBTITLE_BREAKS if b in ahead),
                      default=-1)
            if hit >= 0:
                current += ahead[:hit + 1]
                index += hit + 1
            lines.append(current)
            current = ""
    if current:
        lines.append(current)
    if len(lines) > max_lines:
        # **不能贪心合并。** 原来是「弹出末行、并进上一行」，遇到三行文本就变成
        # 「14 字 / 30 字」——第二行突破了本函数自己声明的上限，
        # 1080p 下一行只放得下约 29 字，30 字正好压到边缘。
        # 而且不均衡的断行看起来像出了故障：一行很短、一行顶到两边。
        #
        # 改成在中点附近的标点处平分。找不到标点才退回按字数硬分。
        lines = _balance(source, max_lines, per_line, cap=per_line + reach)
    joined = "\\N".join(lines)
    if joined.replace("\\N", "") != source:
        raise VideoError(f"断行改动了字幕内容，拒绝输出：{joined!r}")
    return joined


# ── 素材来源路由（A9）──────────────────────────────────────────────────────
#
# 判定走哪条路是**业务判断**，规则写在 `write-video-script/references/scene-routing.md`。
# 这里只做判定之后的机械校验——两个反向错误都要拦：
#
# 一、**事实类镜头填 `ai_image`**：生图模型会编造数字。产出看着像模像样、
#    数值却是假的，比渲染失败难发现得多。
# 二、**隐喻类镜头填 `infographic`**：画成方框和文字。09 号视频 16 镜里
#    `ai_image` 只有 1 张，片头片尾隐喻镜全是方框，用户的评价是「很素」。
#
# 只有一条规则、没有校验器时，路由实际是「写脚本的人随手决定」——
# `scene-routing.md` 存在了很久，而 `SKILL.md` 从没引用过它。

#: 事实类：数值与结构关系来自输入，**绝不生图**。
FACT_INTENTS: frozenset[str] = frozenset({
    "relationship", "process", "comparison", "trend", "structure", "instruction"})
#: 隐喻类：概念、氛围、场景。这一类才该生图。
METAPHOR_INTENTS: frozenset[str] = frozenset({"concept", "scene"})
#: 证据类：必须能溯源——「有图」和「有依据」不是一回事。
EVIDENCE_INTENTS: frozenset[str] = frozenset({"evidence_capture"})

#: 确定性产出：数值只来自输入，由代码绘制。
DETERMINISTIC_METHODS: frozenset[str] = frozenset({"infographic", "raster", "reuse"})
ASSET_METHODS: frozenset[str] = DETERMINISTIC_METHODS | {"ai_image"}

#: 少于这个镜头数的片子，全走一条路是正常的，不告警。
VARIETY_MIN_SHOTS = 6


def _intent_family(intent: str) -> frozenset[str]:
    for family in (FACT_INTENTS, METAPHOR_INTENTS, EVIDENCE_INTENTS):
        if intent in family:
            return family
    raise VideoError(
        f"未知目标类型 {intent!r}。可用："
        f"{'、'.join(sorted(FACT_INTENTS | METAPHOR_INTENTS | EVIDENCE_INTENTS))}。"
        "拼错一个词会绕过全部路由规则，所以这里报错而不是放过。")


def check_asset_method(shots) -> list[str]:
    """校验每个镜头的 `asset_method` 与它的 `intent` 相称。

    未知取值**报错而非告警**：拼错一个词就绕过全部规则，比报错危险得多。
    缺 `intent` 只作为问题列出——那说明脚本还没走过路由这一步。
    """
    issues: list[str] = []
    for shot in shots or []:
        sid = shot.get("id", "?")
        visual = shot.get("visual") or {}
        method = str(visual.get("asset_method") or "").strip()
        if method not in ASSET_METHODS:
            raise VideoError(
                f"{sid} 的 asset_method {method!r} 不认识。可用："
                f"{'、'.join(sorted(ASSET_METHODS))}。")
        intent = str(visual.get("intent") or "").strip()
        if not intent:
            issues.append(
                f"{sid} 没写 visual.intent——没有目标类型就没有路由依据，"
                "等于回到「随手决定」")
            continue
        family = _intent_family(intent)
        if family is FACT_INTENTS and method == "ai_image":
            issues.append(
                f"{sid} 是事实类（{intent}）却走 ai_image——生图模型会编造数字，"
                "产出看着像模像样而数值是假的。改走 infographic / raster / reuse")
        elif family is METAPHOR_INTENTS and method in ("infographic", "raster"):
            # **两个方法都要拦。** 第一版只拦 infographic，拿 09 号视频跑只报出 1 条——
            # 而片头、片尾、隐喻对比三镜是 concept 配 raster（手写方框），
            # 症状与 infographic 完全相同：方框加文字，就是用户说的「很素」。
            issues.append(
                f"{sid} 是隐喻类（{intent}）却走 {method}——"
                "概念和氛围画成方框加文字就是「很素」的来源。"
                "改走 ai_image；需要出字就用 ai_image 底图 + 确定性文字层"
                "（byclaw_caps.raster text-layer），别让生图写中文")
        elif family is EVIDENCE_INTENTS:
            if method == "ai_image":
                issues.append(
                    f"{sid} 是证据类却走 ai_image——凭据是拍到的，不是画出来的")
            elif not str(visual.get("source") or "").strip():
                issues.append(
                    f"{sid} 是证据类但没写 visual.source——"
                    "「有图」和「有依据」不是一回事")
    return issues


def check_visual_variety(shots) -> list[str]:
    """全片只有一条来源，是路由没在工作的信号。

    这条是**告警不是错误**：确实有全片都该走信息图的内容。
    但 09 号视频 16 镜里 `ai_image` 只有 1 张，而片头、片尾、死循环
    本来都是隐喻镜——那不是内容决定的，是没人做路由。
    """
    items = list(shots or [])
    if len(items) < VARIETY_MIN_SHOTS:
        return []
    methods = {str(((s.get("visual") or {}).get("asset_method")) or "") for s in items}
    if len(methods) <= 1:
        only = next(iter(methods)) or "（空）"
        return [f"全片 {len(items)} 个镜头都走 {only}——"
                f"检查是否漏了隐喻镜（该走 ai_image）或已有配图（该走 reuse）"]
    return []


# ── 分镜脚本校验与出片门禁（A11）────────────────────────────────────────────
#
# `validate_video_script.py` 仍只认废弃的 `beats`，对现在的脚本全红——
# **说明它从没被跑过**。在这种状态下加任何新字段，新字段都只是文档。
#
# 出片门禁那条更要紧：契约写着「未确认不出图、不配音」，
# 而成片已经出了三版、`approval.status` 至今是 `pending_confirmation`。
# 纪律写在文档里三次都没拦住——所以它必须是出片这一步的**前置条件**。

#: 已废弃的顶层字段。`beats` 与 `storyboard` 并列时，
#: 5 段旁白摊到 2 张图上是合法的——那正是「画面讲着 A、旁白说到 B」的根因。
LEGACY_FIELDS: frozenset[str] = frozenset({"beats", "storyboard", "subtitle_draft"})

#: 五种表达。与 `byclaw_caps.tts` 的预设同源，写错一个词整段会变平铺直叙。
DELIVERIES: frozenset[str] = frozenset({
    "opening", "narration", "contrast", "question", "emphasis"})

#: 叙事角色。首镜必须 title、末镜必须 closing。
NARRATIVE_ROLES: frozenset[str] = frozenset({
    "title", "hook", "context", "problem", "turn", "mechanism", "payoff", "closing"})

#: 分步显示的取时方式。`by_narration` 匹配失败**直接阻断**，不退回均分——
#: 告警之后照样出片，交付的仍是那种机械动画。
BUILD_MODES: frozenset[str] = frozenset({"by_narration", "even", "at_ms"})

#: 渠道档位。这些阈值来自被替换掉的旧校验器——**它们与契约版本无关**，
#: 是我迁移时差点弄丢的一批规则：成片时长区间、单镜时长上下限、字幕行长。
#: 旧校验器只认废弃的 `beats`，但它守的这些口径仍然成立。
CHANNEL_PROFILES: dict[str, dict] = {
    "wechat_channels": {"min_target": 60, "max_target": 180,
                        "min_shot": 2, "max_shot": 30,
                        "max_subtitle_chars": 16, "label": "视频号",
                        "output_width": 1080, "output_height": 1920,
                        "fps": 30, "min_cpm": 300, "max_cpm": 340},
    "podcast": {"min_target": 300, "max_target": 1800,
                "min_shot": 3, "max_shot": 90,
                "max_subtitle_chars": 20, "label": "播客",
                "output_width": 1920, "output_height": 1080,
                "fps": 30, "min_cpm": 240, "max_cpm": 300},
}
DEFAULT_CHANNEL = "wechat_channels"
#: 规划总时长与各镜之和的允许偏差。
DURATION_TOLERANCE = 0.10


def check_output_spec(*, width: int, height: int, fps: float,
                      channel: str = DEFAULT_CHANNEL) -> list[str]:
    """成片规格是否符合渠道规范。

    这道门禁补的是一次真实失败：渠道规范写着 1080×1920 竖版，还画了三段式
    版式图，能力层也早有 `vertical_filter_complex`——但 `SKILL.md` 里
    「竖屏」二字出现 0 次，成片一路出成横屏，到发布前才被人眼看出来。

    **未知渠道抛错，不回落默认**：回落会让「这条片子发哪」悄悄消失，
    而画幅错了要到发布前才看得见。
    """
    profile = CHANNEL_PROFILES.get(str(channel))
    if profile is None:
        raise VideoError(
            f"未知渠道 {channel!r}。可用：{'、'.join(sorted(CHANNEL_PROFILES))}。")
    issues: list[str] = []
    want = (profile["output_width"], profile["output_height"])
    if (int(width), int(height)) != want:
        issues.append(
            f"{profile['label']}成片画幅应为 {want[0]}×{want[1]}，"
            f"实际 {int(width)}×{int(height)}——"
            f"横屏素材需经 `byclaw_caps.video vertical` 拼成三段式竖屏")
    if round(float(fps)) != profile["fps"]:
        issues.append(
            f"{profile['label']}帧率应为 {profile['fps']} fps，实际 {fps:g}")
    return issues



def _issue(items: list[str], condition: bool, message: str) -> None:
    if condition:
        items.append(message)


def validate_script(document, *, channel: str = DEFAULT_CHANNEL) -> dict:
    """校验分镜脚本。**不需要 session root**。

    原实现硬要 ``--session-root`` 形如 ``/by/.sessions/<数字ID>/``——本地给不出合法值，
    于是开发期永远跑不了它。只能在平台上跑的校验器，等于开发期没有校验器。
    """
    doc = document or {}
    issues: list[str] = []

    for legacy in sorted(LEGACY_FIELDS):
        _issue(issues, legacy in doc,
               f"顶层还有废弃字段 {legacy}——契约已改为 shots 一等公民，"
               "两套并存会让旁白重新脱离镜头")

    style = doc.get("visual_style")
    if style is not None:
        _issue(issues, not str((style or {}).get("id") or "").strip(),
               "visual_style 声明了却没有 id——没有 id 就无法校验三条来源是否同一基调")

    shots = doc.get("shots") or []
    if not shots:
        issues.append("shots 为空——没有镜头就没有视频")
        return {"ok": False, "issues": issues}

    seen: set[str] = set()
    for index, shot in enumerate(shots):
        sid = str(shot.get("id") or f"#{index + 1}")
        _issue(issues, sid in seen, f"{sid} 的 id 重复——「第 {sid} 镜」会指向两个地方")
        seen.add(sid)
        _issue(issues, int(shot.get("order") or 0) != index + 1,
               f"{sid} 的 order 是 {shot.get('order')}，应为 {index + 1}——"
               "漏号通常是删镜头时忘了重排，按序号取会取错")

        role = str(shot.get("narrative_role") or "").strip()
        _issue(issues, role not in NARRATIVE_ROLES,
               f"{sid} 的 narrative_role {role!r} 不在词表内")

        narration = shot.get("narration") or {}
        _issue(issues, not str(narration.get("text") or "").strip(),
               f"{sid} 没有旁白文本——空旁白会让这一镜变哑")
        delivery = str(narration.get("delivery") or "").strip()
        _issue(issues, delivery not in DELIVERIES,
               f"{sid} 的 delivery {delivery!r} 不在五种表达内")

        build = shot.get("build")
        if build is not None:
            mode = str(build.get("mode") or "").strip()
            _issue(issues, mode not in BUILD_MODES,
                   f"{sid} 的 build.mode {mode!r} 不在 {sorted(BUILD_MODES)} 内")
            layers = build.get("layers") or []
            _issue(issues, mode != "none" and not layers,
                   f"{sid} 声明了 build 却没有 layers——"
                   "空的分步等于没有分步，而画面看不出差别")

    # 首镜是 `title` 或 `hook` 都行。**只认 title 会与钩子曝光门禁互斥**：
    # title 至少 min_shot（视频号 2 秒），而钩子要在前 3 秒里占到 1.5 秒、
    # 即必须第 1.5 秒前开口——两条一凑，**任何脚本都过不了**。
    # 线上那次生成，助理反复试了十几轮才发现是门禁本身无解。
    #
    # 该让的是这条：`check_hook` 自己的补救话术、`hook-patterns.md` 和
    # `write-video-script/SKILL.md` 说的都是同一件事——
    # **标题不要单独占一镜，压在钩子的画面上，被看见而不是被念出来**。
    opening = str((shots[0] or {}).get("narrative_role") or "")
    _issue(issues, opening not in ("title", "hook"),
           f"首镜的 narrative_role 是 {opening!r}——应为 hook（推荐，标题压在画面上）"
           "或 title")
    _issue(issues, str((shots[-1] or {}).get("narrative_role") or "") != "closing",
           "末镜不是 closing——片尾缺失")

    profile = CHANNEL_PROFILES.get(str(channel) or DEFAULT_CHANNEL)
    if profile is None:
        raise VideoError(
            f"未知渠道 {channel!r}。可用：{'、'.join(sorted(CHANNEL_PROFILES))}。")

    # 单镜时长上下限。太短来不及看清，太长必然拖沓。
    for shot in shots:
        seconds = float(shot.get("estimated_duration_seconds") or 0)
        sid = str(shot.get("id") or "?")
        _issue(issues, seconds <= 0, f"{sid} 缺 estimated_duration_seconds")
        _issue(issues, 0 < seconds < profile["min_shot"],
               f"{sid} 规划 {seconds:g} 秒，短于 {profile['min_shot']} 秒——来不及看清")
        _issue(issues, seconds > profile["max_shot"],
               f"{sid} 规划 {seconds:g} 秒，超过 {profile['max_shot']} 秒——必然拖沓")

    # 总时长：既要落在渠道区间，也要和各镜之和对得上。
    target = float(doc.get("target_duration_seconds") or 0)
    if target:
        _issue(issues, not (profile["min_target"] <= target <= profile["max_target"]),
               f"target_duration_seconds {target:g} 超出{profile['label']}区间 "
               f"[{profile['min_target']}, {profile['max_target']}]")
        planned = sum(float(s.get("estimated_duration_seconds") or 0) for s in shots)
        if planned:
            drift = abs(planned - target) / target
            _issue(issues, drift > DURATION_TOLERANCE,
                   f"各镜之和 {planned:.1f} 秒与 target {target:g} 秒相差 {drift:.0%}，"
                   f"超过 {DURATION_TOLERANCE:.0%}——两个数里必有一个没更新")

    # 字幕行长：烧进画面才发现太长，就已经晚了。
    #
    # **阈值取断行自己的上限，不取渠道口径 ×1.6。**
    # 渠道表里的 `max_subtitle_chars` 是竖屏视频号的口径（16 字），
    # 而我们出的是横屏 1080p，断行按 22 + reach 4 走。
    # 用 16×1.6=25.6 去卡，比断行能产出的最小上限还严 0.4 字——
    # 一行顶到 26 必挂，而 26 本身是合法的。两个口径不能这么硬凑。
    line_cap = SUBTITLE_LINE_CHARS + SUBTITLE_REACH
    for shot in shots:
        text = str((shot.get("narration") or {}).get("text") or "")
        if text:
            longest = max((len(x) for x in wrap_subtitle(text).split(chr(92) + "N")),
                          default=0)
            _issue(issues, longest > line_cap,
                   f"{shot.get('id')} 字幕最长一行 {longest} 字，超过 {line_cap} 字上限"
                   f"（{profile['label']}竖屏口径 {profile['max_subtitle_chars']} 字仅作规划参考）")

    hook = doc.get("hook") or {}
    _issue(issues, not str(hook.get("narration") or "").strip(),
           "hook.narration 为空——没有钩子，开头就留不住人")

    # **acceptance 不得停在 pending。** 这条是旧校验器守着的，迁移时差点丢掉——
    # 而我自己出的三版成片，acceptance 全部是 pending。
    acceptance = doc.get("acceptance") or {}
    pending = sorted(k for k, v in acceptance.items() if str(v).strip() == "pending")
    _issue(issues, bool(pending),
           f"acceptance 还有 {len(pending)} 项是 pending：{'、'.join(pending)}"
           "——验收项没有结论，等于没有验收")

    payoff = str((doc.get("hook") or {}).get("payoff_shot_id") or "").strip()
    if payoff:
        _issue(issues, payoff not in seen,
               f"hook.payoff_shot_id 指向不存在的镜头 {payoff}——"
               "这个字段一直没人检查，指错了也不会有任何提示")

    issues.extend(check_asset_method(shots))
    issues.extend(check_visual_variety(shots))
    # 过渡必须在旁白里。这条不接进来的话，`connects_from` 非空就算过——
    # 而那句话在元数据里，观众耳朵里什么都没听到。
    issues.extend(check_transitions(shots, hook=str(hook.get("narration") or "")))
    # 逐镜衔接。check_transitions 只看段落边界，同段内的硬切它看不见——
    # 用户点名的三处里有两处正是同段。
    issues.extend(check_flow(shots))
    # 事实类画面被取景裁掉一半——那条片子交付之后才被用户看出来。
    issues.extend(check_framing_loss(shots))
    return {"ok": not issues, "issues": issues}


def check_render_gate(document, *, issues=None, palette=None) -> list[str]:
    """出片前的最后一道闸。返回阻断原因，空列表才可以渲染。

    **缺省是拦住，不是放行。** ``approval`` 整块缺失时也必须拦——
    缺省放行是最坏的默认，而这次正是它让三版成片绕过了唯一的人工门禁。

    阻断原因必须说清缺什么：只说「被拦下」的话，人只会想办法把门禁关掉。
    """
    doc = document or {}
    blocks: list[str] = []
    approval = doc.get("approval")
    if not isinstance(approval, dict):
        return ["缺 approval 块——没有确认记录就不能出片"]

    status = str(approval.get("status") or "").strip()
    if status != "confirmed":
        blocks.append(
            f"approval.status 是 {status or '（空）'}，不是 confirmed——"
            "分镜脚本未经确认，不出图、不配音、不合成")
    if not str(approval.get("confirmed_by") or "").strip():
        blocks.append("approval.confirmed_by 为空——缺确认人，等于自己给自己盖章")
    if not str(approval.get("confirmed_at") or "").strip():
        blocks.append("approval.confirmed_at 为空——缺确认时间，无法判断确认的是哪一版")

    for issue in list(issues or []):
        blocks.append(f"校验未过：{issue}")
    # 基调只把**硬检查**接进门禁。软告警（主色偏离）不阻断——
    # 局部协调只有人判得了值不值得重做，硬拦会让人学会关掉整条检查。
    for issue in list((palette or {}).get("errors") or []):
        blocks.append(f"基调不一致：{issue}")
    return blocks


# ── 分步显示的合成（A12）──────────────────────────────────────────────────
#
# **先合层，后运镜。** 第一版方案写反了：
#
#     [bg]（已含 push-in）→ [bg][l1] overlay(固定屏幕坐标)
#
# 底板在缩放而图层停在屏幕坐标，两者逐渐错位——画面会漂，比原来更像抖动。
#
# 正确顺序：底板 + 已出现图层 → 合成完整场景帧 → 对整个场景统一运镜 → 烧字幕。
# 字幕在运镜之后，它不该跟着画面缩放。

#: 图层淡入时长。太短像硬切，太长会拖过下一句旁白。
DEFAULT_FADE_MS = 350
#: 淡入时的上移距离（像素）。纯淡入偏平，带一点位移才有"进场"的感觉。
DEFAULT_RISE_PX = 12


# ── 全片基调一致（A13）────────────────────────────────────────────────────
#
# 用户看到的是「一会素白信息图、一会全黑生图」——三条来源各带各的配色。
#
# **必须分两层。** 单一的「全图主色」会误判两个方向：
# 暗色图里一大块白色主体会把主色拉亮；白底信息图因文字密集反而算成暗的。
# 所以硬检查只看**边缘背景**，软检查看主色与强调色、且只告警。

#: 背景采样：四角各取这么大一块。中央留给主体，不参与背景判定。
_PALETTE_CORNER = 96
#: 背景亮度与档内底色的最大允许偏差。
_PALETTE_BG_TOLERANCE = 60
#: 强调色的色相容差（0–180）。超出即告警，不阻断。
_PALETTE_HUE_TOLERANCE = 40


def _corner_rgb(path, size: int = _PALETTE_CORNER):
    """取四角的平均颜色。**不取整图**——中央的主体不代表基调。"""
    import subprocess as _subprocess

    out = []
    for x, y in ((0, 0), (f"iw-{size}", 0), (0, f"ih-{size}"),
                 (f"iw-{size}", f"ih-{size}")):
        done = _subprocess.run(
            ["ffmpeg", "-v", "error", "-i", str(path), "-vf",
             f"crop={size}:{size}:{x}:{y},scale=1:1", "-f", "rawvideo",
             "-pix_fmt", "rgb24", "-"], capture_output=True, timeout=60)
        if done.stdout:
            out.append(tuple(done.stdout[:3]))
    return out


def _dominant_rgb(path):
    import subprocess as _subprocess

    done = _subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(path), "-vf", "scale=1:1",
         "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
        capture_output=True, timeout=60)
    return tuple(done.stdout[:3]) if done.stdout else None


def _luma(rgb) -> float:
    return 0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]


def _hue(rgb) -> float:
    import colorsys

    h, _s, _v = colorsys.rgb_to_hsv(*(c / 255 for c in rgb))
    return h * 360.0


def check_palette(frames, *, pack: str) -> dict:
    """校验一批画面是否服从同一视觉基调。

    Returns:
        ``{"errors": [...], "warnings": [...]}``——
        ``errors`` 阻断出片，``warnings`` 只进报告。

        **分开是刻意的**：白底混进暗色片子是硬伤，
        而强调色偏一点只有人判得了值不值得重做。
    """
    from byclaw_caps.style import get_pack

    style = get_pack(pack)
    want_bg = _hex_rgb(style["background"])
    want_accent = _hex_rgb(style["accent"])
    errors: list[str] = []
    warnings: list[str] = []

    for item in frames or []:
        path = Path(item)
        if not path.is_file():
            errors.append(f"画面不存在：{path}")
            continue
        corners = _corner_rgb(path)
        if not corners:
            errors.append(f"{path.name} 读不出像素，无法判定基调")
            continue
        gap = abs(sum(_luma(c) for c in corners) / len(corners) - _luma(want_bg))
        if gap > _PALETTE_BG_TOLERANCE:
            errors.append(
                f"{path.name} 背景亮度与 {pack} 的底色相差 {gap:.0f}"
                f"（上限 {_PALETTE_BG_TOLERANCE}）——基调不一致，"
                "这正是「一会素白、一会全黑」的来源")
            continue
        dominant = _dominant_rgb(path)
        if dominant is None:
            continue
        # 主色与底色几乎一样时没有强调色可判——纯色底板，跳过软检查。
        if abs(_luma(dominant) - _luma(want_bg)) < 12:
            continue
        drift = abs(_hue(dominant) - _hue(want_accent))
        drift = min(drift, 360 - drift)
        if drift > _PALETTE_HUE_TOLERANCE:
            warnings.append(
                f"{path.name} 主色色相偏离强调色 {drift:.0f}°"
                f"（容差 {_PALETTE_HUE_TOLERANCE}°）——可能混进了档外颜色，请人工复核")
    return {"errors": errors, "warnings": warnings}


def _hex_rgb(value: str):
    text = str(value or "").strip().lstrip("#")
    if len(text) == 3:
        text = "".join(ch * 2 for ch in text)
    return tuple(int(text[i:i + 2], 16) for i in (0, 2, 4))


def check_layer_transparency(paths) -> list[str]:
    """图层的四角必须是透明的。

    不透明的图层叠上去会把下面整块擦掉——三个元素依次出现，
    实际变成三次替换，看着像元素在闪。**ffmpeg 退出码始终是 0。**

    这个坑踩过两次：``drawbox`` 在透明画布上画不写 alpha；
    ``pad`` 在无 alpha 的输入上补边，``color=black@0.0`` 补出的是不透明黑。
    所以检查的是**实际像素**，不是生成命令写了什么。
    """
    import subprocess as _subprocess
    from pathlib import Path as _Path

    issues: list[str] = []
    for item in paths or []:
        path = _Path(item)
        if not path.is_file():
            issues.append(f"图层不存在：{path}")
            continue
        header = path.read_bytes()[:33]
        if len(header) > 25 and header[25] not in (4, 6):
            issues.append(
                f"{path.name} 没有 alpha 通道——整幅不透明，会把下层全部盖住")
            continue
        done = _subprocess.run(
            ["ffmpeg", "-v", "error", "-i", str(path),
             "-vf", "crop=16:16:0:0,scale=1:1", "-f", "rawvideo",
             "-pix_fmt", "rgba", "-"], capture_output=True, timeout=60)
        raw = done.stdout
        if not raw:
            issues.append(f"{path.name} 读不出像素，无法判断透明度")
            continue
        if raw[3] > 8:
            issues.append(
                f"{path.name} 左上角 alpha={raw[3]}，不透明——"
                "叠上去会把下面那一层整块擦掉，而 ffmpeg 不会报错")
    return issues


def build_composite_filter(*, layers, duration: float, fps: int,
                           width: int, height: int, camera,
                           fade_ms: int = DEFAULT_FADE_MS,
                           rise_px: int = DEFAULT_RISE_PX,
                           supersample: int = SUPERSAMPLE) -> str:
    """构造 filter_complex：输入 0 是底板，输入 1..N 依次是各图层。

    Args:
        layers: ``[{"id", "at"}]``，``at`` 是该层出现的秒数。
        camera: ``{"type", "max_zoom"}``，来自 :data:`CAMERA_PROFILES`。

    Returns:
        filter_complex 串，输出标签 ``[v]``。
    """
    items = list(layers or [])
    if not items:
        raise VideoError("没有图层——空的分步等于没有分步，而画面看不出差别")
    fade = max(0.0, float(fade_ms) / 1000.0)
    # **底板也要转 rgba，且 overlay 要显式 format=auto。**
    # overlay 默认按 yuv420 处理，图层的透明区会被当成不透明黑——
    # 于是每叠一层就把前一层整块擦掉：三个元素依次出现，变成了三次替换。
    # 现象很像"元素在闪"，而 ffmpeg 退出码是 0。
    parts, current = ["[0:v]format=rgba[bg0]"], "bg0"
    for index, layer in enumerate(items, start=1):
        at = float(layer.get("at") or 0)
        if at >= float(duration):
            raise VideoError(
                f"图层 {layer.get('id')} 在第 {at:g} 秒出现，而镜头只有 {duration:g} 秒"
                "——这一层根本不会出现在画面上")
        tag = f"l{index}"
        # alpha 通道参与淡入，否则透明区会被当成黑色一起淡。
        parts.append(
            f"[{index}:v]format=rgba,fade=in:st={at:g}:d={fade:g}:alpha=1[{tag}]")
        out = f"c{index}"
        # 上移进场：起点低 rise_px，淡入结束时归位。纯淡入偏平，带一点位移才像"进场"。
        # 线性插值即可——这段只有 0.35 秒，缓动在这个尺度上看不出来。
        y = (f"{int(rise_px)}*(1-min(1,(t-{at:g})/{fade:g}))" if rise_px and fade
             else "0")
        parts.append(
            f"[{current}][{tag}]overlay=x=0:y='{y}':eval=frame:format=auto:"
            f"enable='gte(t,{at:g})'[{out}]")
        current = out

    kind = str((camera or {}).get("type") or "none")
    if kind == "none":
        parts.append(f"[{current}]format=yuv420p,setsar=1[v]")
        return ";".join(parts)

    motion = build_motion_filter(
        kind, duration=duration, fps=fps, width=width, height=height,
        max_zoom=float((camera or {}).get("max_zoom") or MAX_ZOOM),
        supersample=supersample)
    # 运镜作用在**合成之后的整帧**上，所以要剥掉 build_motion_filter 头部的取景，
    # 那一段是给单张素材做画幅归一的，合成帧已经是目标画幅了。
    motion = motion.split(f"crop={width}:{height},", 1)[-1]
    parts.append(f"[{current}]format=yuv420p,{motion}[v]")
    return ";".join(parts)


# ── 过渡（A15）────────────────────────────────────────────────────────────
#
# 用户听完成片说：「拆成三件事」与后面没有过渡；三件事讲完也没有过渡；
# 结尾突然冒出「知识要能自己生长」，很割裂。
#
# **我原来的做法错在哪。** 契约里有 `connects_from`，校验只查它非空——
# 于是写「承上启下」也能过，而那句话在元数据里，**观众耳朵里什么都没听到**。
#
# 衔接是听觉体验，只能对旁白本身提要求。三条都查**说出口的字**。

#: 宣告「N 件事／N 步」的说法。
_ANNOUNCE = re.compile(r"(?:拆成|分成|有|说)\s*([一二三四五六七八九两])\s*(?:件|步|条|点|个)")
_CN_NUM = {"一": 1, "两": 2, "二": 2, "三": 3, "四": 4, "五": 5,
           "六": 6, "七": 7, "八": 8, "九": 9}

#: 报序号的说法。只认「第一」太窄，「一是／其次／最后」也是报序号。
_ORDINALS = (
    re.compile(r"第\s*[一二三四五六七八九十]\s*[件步条点个]?"),
    re.compile(r"^[一二三四五六七八九]\s*是"),
    re.compile(r"(首先|其次|再次|然后|接着|最后|末了)"),
)

#: 段落过渡语。
_TRANSITIONS = re.compile(
    r"(好了|说完|讲完|聊完|至此|到这里|那么|接下来|回过头|回到|再来看|我们来看|看看效果"
    # 设问式转折同样是过渡：「那怎么办？」把上一段的问题接成下一段的答案。
    # 第一版漏了它们，于是一句正当的转折被判成硬切。
    r"|怎么办|该怎么|问题来了|于是|反过来|换句话说)")

#: 叙事段落。同段内逐条讲不需要每句都加过渡语，跨段才需要。
_SECTION_OF = {
    "title": "开场", "hook": "开场",
    "context": "铺垫", "problem": "铺垫",
    "turn": "转折",
    "mechanism": "机制",
    "payoff": "兑现", "closing": "收尾",
}
#: 显式回指的说法。
_CALLBACK_WORDS = re.compile(r"(回到|回头看|开头|最初|一开始|那个问题|前面问的|答案)")
#: 与钩子原样重叠多少字才算回指。
#:
#: **2 字太松。** 「而不只是等人来维护」和「可谁来维护」共用「来维护」，
#: 那是碰巧撞上常用词，不是回指——用它判会把「突然冒出来」的收尾放过去。
_CALLBACK_SPAN = 4


def _echoes(text: str, hook: str, *, span: int = _CALLBACK_SPAN) -> bool:
    """收尾是否真的回到了开场。

    两条任一成立：说了显式回指词，或与钩子有 ``span`` 字的原样重叠。
    长片段才有辨识度——「谁来维护」是回指，「来维护」只是同一个词。
    """
    body = re.sub(r"[^\w一-鿿]", "", str(text or ""))
    source = re.sub(r"[^\w一-鿿]", "", str(hook or ""))
    if _CALLBACK_WORDS.search(str(text or "")):
        return True
    if len(body) < span or len(source) < span:
        return False
    grams = {source[i:i + span] for i in range(len(source) - span + 1)}
    return any(body[i:i + span] in grams for i in range(len(body) - span + 1))


#: 句首连接词。**必须在开头几个字**——「还是露了怯」里的「还」在句尾，
#: 它不承接上一镜。第一版原型正是被这种词骗过去的。
_LINK_WORDS = re.compile(
    r"(好了|说完|讲完|聊完|至此|到这里|那么|接下来|回过头|回到|再来看|我们来看"
    r"|怎么办|该怎么|问题来了|于是|反过来|换句话说|其实|说到底|另外|而且|不过"
    r"|所以|因此|结果|这样|如此|这么|这一|这些|这三|至于|眼下|如今"
    r"|但|而|先|再|还|也|更)")
#: 连接词的有效位置：开头这么多个字以内。
_LINK_HEAD = 4

#: 回应宣告的枚举序号。**不认「第一个月」**——那是时间序号，
#: 它不是在回应任何宣告，却在上一版里拿到了免检。
_ENUM_ORDINAL = re.compile(r"第\s*[一二三四五六七八九十]\s*[件步条点]")

#: 虚词与数词。含它们的二元组是噪声：`了三`、`三个` 到处都有，
#: 算不上「讲同一件事」。上一版原型三处全部因此假通过。
_FUNCTION_CHARS = set("的了是在有和与但也还就都不一二三四五六七八九十"
                      "个们这那我你他其之为以从对把被所很更再又只让")


def _content_bigrams(text: str) -> set[str]:
    body = re.sub(r"[^一-鿿]", "", str(text or ""))
    return {body[i:i + 2] for i in range(len(body) - 1)
            if not (set(body[i:i + 2]) & _FUNCTION_CHARS)}


#: 决定完播的窗口。渠道规范：「前 3 秒决定完播。」
HOOK_DEADLINE_SECONDS = 3.0

#: 钩子必须在那个窗口里**占到**的秒数。
#:
#: 只查「钩子是否在 3 秒内开始」是不够的——实际那条片子钩子从第 2.9 秒起，
#: 形式上没超时，可观众在做决定的这 3 秒里听到的**全是标题朗读**，
#: 钩子只占到 0.1 秒。窗口是用来占的，不是用来踩线的。
MIN_HOOK_EXPOSURE_SECONDS = 1.5

#: 钩人的语言成分。缺全部四类时给警告——一句没有疑问词的陈述也可能很钩人，
#: 但那是例外，值得作者被提醒一次。
_HOOK_QUESTION = "？?"
_HOOK_NEGATION = ("不", "没", "别", "难道", "未必", "反而", "却")
_HOOK_SECOND_PERSON = ("你", "您", "咱")
_HOOK_DIGITS = re.compile(r"[0-9]|[一二三四五六七八九十百千万两]+(?=[个张天年月分秒次倍成])")


def narration_chars(shots) -> int:
    """分镜里可发音的旁白字数。

    复用 `byclaw_caps.tts.segments.spoken_length`，**不在这里另写一份剥离逻辑**：
    两份迟早分叉，而分叉的表现是「语速门禁数的字」和「配音切分对齐的字」
    不是同一批，两边都不报错。
    """
    from byclaw_caps.tts.segments import spoken_length

    return sum(spoken_length(str((s.get("narration") or {}).get("text") or ""))
               for s in (shots or []) if s)


def check_pace(*, chars: int, seconds: float,
               channel: str = DEFAULT_CHANNEL) -> list[str]:
    """口播语速是否在渠道区间内。按**实测**字/分判。

    ## 规范曾经抄错了表

    视频号档位原先写的是 220–260 字/分，实测这条片子 263 字/分——已经在上限
    之上，用户仍然听着慢。**220 字/分是新闻播报的节奏**；知识类短视频通常在
    300–360。规范抄的是新闻稿的语速表。

    ## 建议改脚本，不是改 speed 旋钮

    拉高 `speed` 会失真，而且换音色要重新标定。慢了就加内容、快了就删内容——
    这和「不得靠加速口播塞入超量信息」是同一条规则的两面。
    """
    profile = CHANNEL_PROFILES.get(str(channel))
    if profile is None:
        raise VideoError(
            f"未知渠道 {channel!r}。可用：{'、'.join(sorted(CHANNEL_PROFILES))}。")
    if float(seconds) <= 0:
        # 除零会得到 inf，而 inf 比任何上限都大——会被报成「语速太快」，
        # 把「没测到时长」误诊成语速问题。
        raise VideoError("时长为 0，无法计算语速——先确认音频已实测")
    cpm = float(chars) / float(seconds) * 60
    low, high = profile["min_cpm"], profile["max_cpm"]
    if cpm < low:
        return [f"{profile['label']}语速 {cpm:.0f} 字/分，低于 {low}——"
                f"听上去拖沓。**加内容把话说满，不要去调 speed 旋钮**："
                f"拉高倍速会失真，而且换音色还要重新标定"]
    if cpm > high:
        return [f"{profile['label']}语速 {cpm:.0f} 字/分，高于 {high}——"
                f"通常意味着信息塞太多。**删内容，不要靠加速硬塞**"]
    return []


def check_hook(shots) -> list[str]:
    """开场钩子：出现得够不够早，句子里有没有钩人的成分。

    ## 为什么补这条

    渠道规范只有一句「前 3 秒决定完播」，那是验收规则不是写作方法。
    于是 `hook_payoff_check` 查的是"钩子有没有兑现"，**平淡的钩子照样通过**。

    实际成片里 SH001 是一句标题朗读，占掉 2.9 秒，钩子从第 2.9 秒才开始——
    规范写着前 3 秒决定完播，流程却把这 3 秒给了文章标题。

    ## 判什么、不判什么

    「钩子好不好」是审美，机器判不了。能判的是**形式**：出现得够不够早
    （硬失败），句里有没有疑问、否定、第二人称或数字（警告）。
    """
    items = [s for s in (shots or []) if s]
    if not items:
        return []
    issues: list[str] = []

    elapsed = 0.0
    hook = None
    for item in items:
        if str(item.get("narrative_role") or "") == "hook":
            hook = item
            break
        elapsed += float(item.get("estimated_duration_seconds") or 0)

    if hook is None:
        return [f"开场没有 `narrative_role: hook` 的镜头——"
                f"前 {HOOK_DEADLINE_SECONDS:g} 秒决定完播，缺了钩子等于放弃这段"]

    exposure = HOOK_DEADLINE_SECONDS - elapsed
    if exposure < MIN_HOOK_EXPOSURE_SECONDS:
        issues.append(
            f"{hook['id']} 钩子从第 {elapsed:.1f} 秒才开始，在决定完播的前 "
            f"{HOOK_DEADLINE_SECONDS:g} 秒里只占到 {max(exposure, 0):.1f} 秒"
            f"（需 ≥ {MIN_HOOK_EXPOSURE_SECONDS:g} 秒）——把前面的标题镜删掉、缩短，"
            f"或与钩子合并成一镜（标题可以压在钩子的画面上，不必单独占时间）")

    text = str((hook.get("narration") or {}).get("text") or "")
    hooked = (any(ch in text for ch in _HOOK_QUESTION)
              or any(w in text for w in _HOOK_NEGATION)
              or any(w in text for w in _HOOK_SECOND_PERSON)
              or bool(_HOOK_DIGITS.search(text)))
    if not hooked:
        issues.append(
            f"{hook['id']} 钩子是一句平铺直叙——没有疑问、否定、第二人称，也没有数字。"
            f"参考 `hook-patterns.md` 的六类句式，最强的是「否定现状 + 点名观众」")
    return issues


def check_flow(shots) -> list[str]:
    """**每一对相邻镜头**都要接得上。

    与 :func:`check_transitions` 的分工：那个查的是段落边界与枚举、收尾回指；
    这个查的是**逐镜**——上一版把「同段不必每句加过渡语」写成了
    「同段不检查」，于是同段内的硬切全部漏掉。

    语义连贯机器判不了。但「与上一镜完全没有共同话题、也没有任何衔接标记」
    是可以判的，而那正是用户点名那三处的形状。

    三者满足其一即通过：句首连接词、回应宣告的枚举序号、实词重叠。
    """
    items = list(shots or [])
    issues: list[str] = []
    announced = False
    for previous, current in zip(items, items[1:]):
        before = str((previous.get("narration") or {}).get("text") or "")
        text = str((current.get("narration") or {}).get("text") or "")
        if _ANNOUNCE.search(before):
            announced = True
        if _LINK_WORDS.search(text[:_LINK_HEAD]):
            continue
        if announced and _ENUM_ORDINAL.search(text[:6]):
            continue
        if _content_bigrams(before) & _content_bigrams(text):
            continue
        issues.append(
            f"{current.get('id')} 与上一镜没有任何衔接——"
            "既没有句首连接词（好了／那么／所以／先…），"
            "也没有承接上一镜的实词。听感上是硬切，"
            "补一句交代「我们现在在讲什么」")
    return issues


def check_transitions(shots, *, hook: str = "") -> list[str]:
    """校验过渡是否真的说出了口。

    与 ``connects_from`` 的分工：那个字段记录**作者的理由**，
    这里查的是**观众听得到的字**。只有后者影响观感。
    """
    items = list(shots or [])
    issues: list[str] = []

    # ── 一、宣告了「N 件事」，随后 N 镜必须报序号 ──
    for index, shot in enumerate(items):
        text = str((shot.get("narration") or {}).get("text") or "")
        found = _ANNOUNCE.search(text)
        if not found:
            continue
        count = _CN_NUM.get(found.group(1))
        if not count:
            continue
        following = items[index + 1: index + 1 + count]
        numbered = [s for s in following
                    if any(p.search(str((s.get("narration") or {}).get("text") or ""))
                           for p in _ORDINALS)]
        if len(following) < count:
            issues.append(
                f"{shot.get('id')} 宣告了「{found.group(1)}件事」，"
                f"但后面只有 {len(following)} 个镜头——观众会一直等下一件")
        for candidate in following:
            if not any(p.search(str((candidate.get("narration") or {}).get("text") or ""))
                       for p in _ORDINALS):
                issues.append(
                    f"{candidate.get('id')} 承接「{found.group(1)}件事」却没报序号——"
                    "旁白里要有「第一件…」「第二件…」，"
                    "写在 connects_from 里观众听不到")
        del numbered

    # ── 二、跨段的第一镜必须有过渡语 ──
    for previous, current in zip(items, items[1:]):
        before = _SECTION_OF.get(str(previous.get("narrative_role") or ""))
        after = _SECTION_OF.get(str(current.get("narrative_role") or ""))
        if not before or not after or before == after:
            continue
        if before == "开场" or after == "收尾":
            continue        # 开场进正文、正文进收尾另有规则
        text = str((current.get("narration") or {}).get("text") or "")
        # 报了序号的镜头**不再要求过渡语**：序号本身就是过渡，
        # 再要一句「那么」会变成「那么第一件……那么第二件……」，反而啰嗦。
        if any(p.search(text) for p in _ORDINALS):
            continue
        if not _TRANSITIONS.search(text):
            issues.append(
                f"{current.get('id')} 从「{before}」进入「{after}」却没有过渡语——"
                "补一句「好了，三件事说完，我们来看看效果」这类，"
                "否则听起来是硬切")

    # ── 三、收尾必须回指开场 ──
    if hook:
        for shot in items:
            if str(shot.get("narrative_role") or "") != "closing":
                continue
            text = str((shot.get("narration") or {}).get("text") or "")
            if not _echoes(text, hook):
                issues.append(
                    f"{shot.get('id')} 收尾没有回指开场那个问题——"
                    "结论会像「突然冒出来」。先回到钩子，再给答案")
    return issues


def check_stillness(shots) -> list[str]:
    """找出超过静止上限的镜头。**有运镜就不算静止**——画面一直在变。"""
    issues = []
    for shot in shots:
        motion = (shot.get("motion") or {}).get("type", "none")
        duration = float(shot.get("duration") or 0)
        # **build 也算「画面在变」。** 信息图镜头改成 camera: none 之后，
        # 画面其实一直在变（元素在依次出现）。不认它的话，新策略一上线就全片告警，
        # 而人会学会忽略告警——那比没有告警更坏。
        # 但**空的 build 不算**：声明了却没有图层，画面确实一动不动。
        building = bool(((shot.get("build") or {}).get("layers")) or [])
        if motion == "none" and not building and duration > MAX_STILL_SECONDS:
            issues.append(
                f"{shot.get('id', '?')} 静止 {duration:g} 秒，超过 {MAX_STILL_SECONDS} 秒上限"
                "——加运镜或拆镜头")
    return issues


def shot_midpoints(shots) -> list[dict]:
    """逐镜头算中点抽样时刻。

    **抽中点不抽固定时间点。** 只抽开头、中间、结尾几个点会漏掉中间所有对不上的镜头，
    而那正是问题多发区——一张图扛了三段旁白时，坏的往往是第二、三段。

    中点是每个镜头信息最完整的时刻：转场已结束、运镜到位、字幕已出。

    **时间是累加的**：按各镜头自己的 0 点抽，会全部抽到片头去。
    """
    if not shots:
        raise VideoError("没有镜头可抽帧——空的分镜不该通过质检")
    out, cursor = [], 0.0
    for shot in shots:
        duration = float(shot.get("duration") or 0)
        if duration <= 0:
            raise VideoError(f"{shot.get('id', '?')} 时长必须为正，抽不出中点")
        start, end = cursor, cursor + duration
        out.append({
            "id": shot.get("id", "?"),
            "start": start, "end": end, "at": start + duration / 2,
            # 抽出来的帧要拿去核对什么，跟着一起带出来
            "must_show": list((shot.get("visual") or {}).get("must_show") or []),
        })
        cursor = end
    return out


#: 三档密度。**只控制密度，不控制正确性**——`must_show` 那条硬规则任何档位都成立。
SHOT_DENSITIES: frozenset[str] = frozenset({"economy", "standard", "premium"})


def check_density(density: str, shots) -> list[str]:
    """按档位校验镜头与图片的关系。

    没有校验器的话，`shot_density` 只是文档里的一个词——写着 `premium` 却复用图片，
    或写着 `economy` 却让两段旁白讲不同的东西，都不会被拦下。
    """
    if density not in SHOT_DENSITIES:
        # 默默按最宽松的档处理，等于档位形同虚设。
        raise VideoError(
            f"未知档位 {density!r}。可用：{'、'.join(sorted(SHOT_DENSITIES))}。")
    issues: list[str] = []
    seen: dict[str, list[dict]] = {}
    for shot in shots:
        visual = shot.get("visual") or {}
        seen.setdefault(str(visual.get("asset_id") or ""), []).append(shot)

    for asset, group in seen.items():
        if len(group) < 2:
            continue
        ids = "、".join(str(s.get("id", "?")) for s in group)
        if density == "premium":
            # 说好一句一图却复用，等于降级了却没人知道。
            issues.append(
                f"premium 档不得复用图片：{asset} 被 {ids} 共用。"
                "要复用请改成 standard 档，并给不同取景。")
        elif density == "standard":
            framings = [(s.get("visual") or {}).get("framing", "full") for s in group]
            if len(set(framings)) != len(framings):
                # 同图同取景配两镜，就是静止画面横跨两段旁白。
                issues.append(
                    f"standard 档复用图片时取景必须不同：{asset} 被 {ids} 共用，"
                    f"取景 {framings} 有重复。")
        else:  # economy
            shapes = {tuple(sorted((s.get("visual") or {}).get("must_show") or []))
                      for s in group}
            if len(shapes) > 1:
                # 说的不是同一个东西还共用，就是图文不符。
                issues.append(
                    f"economy 档共用图片时 must_show 必须完全相同：{asset} 被 {ids} 共用，"
                    "但它们要展示的对象不同——那就是图文不符。")
    return issues
