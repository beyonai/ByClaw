#!/usr/bin/env python3
"""视频合成能力 CLI。

`drawtext` 只有一个入口且恒带 expansion=none——`%` 被静默吞掉且退出码为 0，
靠人记得加开关迟早会漏。
"""
from __future__ import annotations

import argparse
import pathlib

from byclaw_caps._cli import UsageError, add_common, dispatch
from byclaw_caps.video import (
    check_asset_method, check_visual_variety, check_render_gate, validate_script,
    check_palette,
    LOUDNORM, NORMALIZE_HEIGHT, NORMALIZE_WIDTH, VideoError,
    build_drawtext, ffprobe_duration, is_intermediate, normalize_image,
    band_layout, vertical_ass_style, vertical_filter_complex,
    check_output_spec, probe_video, check_hook, check_pace, narration_chars,
    FRAMING_REGIONS, MOTION_TYPES, build_motion_filter, check_stillness,
    shot_midpoints,
)


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="byclaw_caps.video", description="视频合成")
    sub = parser.add_subparsers(dest="command", required=True)
    text = sub.add_parser("drawtext", help="构造 drawtext 滤镜串")
    text.add_argument("text")
    text.add_argument("--fontfile")
    text.add_argument("--fontsize", type=int, default=42)
    text.add_argument("--fontcolor", default="white")
    probe = sub.add_parser("probe", help="实测时长")
    probe.add_argument("path")
    classify = sub.add_parser("classify", help="判断是阶段产出还是过程中间件")
    classify.add_argument("name")
    specs = sub.add_parser("specs", help="输出固定规格")
    hk = sub.add_parser("hook", help="开场钩子门禁：是否占住前 3 秒、句里有没有钩人成分")
    hk.add_argument("script", help="含 shots 的分镜脚本 JSON")

    pace = sub.add_parser("pace", help="口播语速门禁：按实测字/分判")
    pace.add_argument("--script", help="分镜脚本 JSON；由它算可发音字数，"
                                      "比手工数可靠：手工容易把 <#0.3#> 与 (breath) 算进去")
    pace.add_argument("--chars", type=int, help="旁白字数。给了 --script 就不用它")
    pace.add_argument("--seconds", type=float, required=True,
                      help="**实测**总时长。估算值会让这道门禁变成自说自话")
    pace.add_argument("--channel", default="wechat_channels")

    acc = sub.add_parser("accept", help="成片规格门禁：按渠道判画幅与帧率")
    acc.add_argument("video", help="成片路径。**查文件，不查脚本字段**——"
                                  "脚本里写 9:16 而出成横屏，正是这次踩的坑")
    acc.add_argument("--channel", default="wechat_channels")

    norm = sub.add_parser("normalize", help="素材归一到视频画幅：等比缩放 + 白底补边")
    norm.add_argument("source")
    norm.add_argument("output")
    norm.add_argument("--width", type=int, default=NORMALIZE_WIDTH)
    norm.add_argument("--height", type=int, default=NORMALIZE_HEIGHT)
    norm.add_argument("--ffmpeg")
    vert = sub.add_parser("vertical", help="竖屏三段式布局：带划分、滤镜串、字幕样式")
    vert.add_argument("--pack", required=True,
                      help="风格档 id。**必填**——三段式底色从风格档取，"
                           "给默认值等于又写死一个白底")
    vert.add_argument("--duration", type=float)
    mot = sub.add_parser("motion", help="镜头运动滤镜串：一张图靠取景变化支撑多个镜头")
    mot.add_argument("--type", default="push-in", choices=sorted(MOTION_TYPES))
    mot.add_argument("--framing", default="full", choices=sorted(FRAMING_REGIONS))
    mot.add_argument("--duration", type=float, required=True)
    mot.add_argument("--fps", type=int, default=25)
    mot.add_argument("--width", type=int, default=1920)
    mot.add_argument("--height", type=int, default=1080)

    qc = sub.add_parser("qc", help="逐镜头中点抽帧时刻 + 静止上限检查")
    qc.add_argument("shots", help="分镜 JSON：[{id, duration, motion, visual}]")

    routing = sub.add_parser(
        "routing", help="校验每镜的 asset_method 与 intent 相称（事实类绝不生图）")
    routing.add_argument("shots", help="分镜 JSON：[{id, visual:{intent, asset_method}}]")

    val = sub.add_parser("validate", help="校验分镜脚本（schema 2.x，不需要 session root）")
    val.add_argument("script", help="video-script.yaml")

    gate = sub.add_parser(
        "gate", help="出片门禁：未确认 / 校验未过一律拒绝渲染")
    gate.add_argument("script", help="video-script.yaml")

    pal = sub.add_parser(
        "palette", help="基调一致性：硬检查背景（阻断），软检查主色（告警）")
    pal.add_argument("frames", nargs="+", help="抽好的帧图片")
    pal.add_argument("--pack", default="technical-dark-v1")

    for one in (text, probe, classify, specs, norm, vert, mot, qc, routing, acc,
                hk, pace,
                val, gate, pal):
        add_common(one)
    return parser


def handle(args: argparse.Namespace):
    if args.command == "motion":
        return {"ok": True, "filter": build_motion_filter(
            args.type, duration=args.duration, fps=args.fps,
            width=args.width, height=args.height, framing=args.framing)}, 0
    if args.command == "palette":
        result = check_palette(args.frames, pack=args.pack)
        return ({"ok": not result["errors"], **result},
                (0 if not result["errors"] else 1))
    if args.command in ("validate", "gate"):
        from pathlib import Path as _Path
        import yaml as _yaml
        doc = _yaml.safe_load(_Path(args.script).read_text(encoding="utf-8"))
        result = validate_script(doc)
        if args.command == "validate":
            return result, (0 if result["ok"] else 1)
        blocks = check_render_gate(doc, issues=result["issues"])
        return {"ok": not blocks, "may_render": not blocks, "blocked_by": blocks},                (0 if not blocks else 1)
    if args.command == "routing":
        import json as _json
        from pathlib import Path as _Path
        shots = _json.loads(_Path(args.shots).read_text(encoding="utf-8"))
        issues = check_asset_method(shots) + check_visual_variety(shots)
        return {"ok": not issues, "issues": issues}, (0 if not issues else 1)
    if args.command == "qc":
        import json as _json
        from pathlib import Path as _Path
        shots = _json.loads(_Path(args.shots).read_text(encoding="utf-8"))
        still = check_stillness(shots)
        return {"ok": not still, "samples": shot_midpoints(shots),
                "stillness_issues": still}, (0 if not still else 1)
    if args.command == "vertical":
        return {"ok": True, "bands": band_layout(),
                "filter_complex": vertical_filter_complex(pack=args.pack,
                                                          duration=args.duration),
                "ass_style": vertical_ass_style()}, 0
    if args.command == "hook":
        import json

        data = json.loads(pathlib.Path(args.script).read_text(encoding="utf-8"))
        found = check_hook(data.get("shots"))
        return {"ok": not found, "issues": found}, (0 if not found else 1)
    if args.command == "pace":
        import json

        if args.script:
            data = json.loads(pathlib.Path(args.script).read_text(encoding="utf-8"))
            chars = narration_chars(data.get("shots"))
        elif args.chars is not None:
            chars = args.chars
        else:
            raise UsageError("需要 --script 或 --chars 之一")
        found = check_pace(chars=chars, seconds=args.seconds,
                           channel=args.channel)
        return ({"ok": not found, "chars": chars, "issues": found},
                0 if not found else 1)
    if args.command == "accept":
        info = probe_video(args.video)
        issues = check_output_spec(width=info["width"], height=info["height"],
                                   fps=info["fps"], channel=args.channel)
        return ({"ok": not issues, "probed": info, "issues": issues},
                0 if not issues else 1)
    if args.command == "normalize":
        out = normalize_image(args.source, args.output, width=args.width,
                              height=args.height, ffmpeg=args.ffmpeg)
        return {"ok": True, "output": str(out),
                "canvas": [args.width, args.height]}, 0
    if args.command == "specs":
        return {"ok": True, "loudnorm": LOUDNORM}, 0
    if args.command == "classify":
        return {"ok": True, "name": args.name, "intermediate": is_intermediate(args.name)}, 0
    if args.command == "probe":
        return {"ok": True, "duration": ffprobe_duration(args.path)}, 0
    return {
        "ok": True,
        "filter": build_drawtext(
            args.text, fontfile=args.fontfile,
            fontsize=args.fontsize, fontcolor=args.fontcolor,
        ),
    }, 0


def main() -> int:
    """控制台入口点。

    `python -m byclaw_caps.<能力>` 与安装后的 `byclaw-<能力>` 走同一条路——
    两条路行为分叉的话，文档里写的那条迟早是错的。
    """
    return dispatch(build(), handle, usage_errors=(VideoError,))


if __name__ == "__main__":
    raise SystemExit(main())
