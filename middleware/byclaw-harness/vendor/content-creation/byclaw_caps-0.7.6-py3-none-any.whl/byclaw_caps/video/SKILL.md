---
name: video-compose
description: 当合成视频、烧录字幕或叠加文字时使用。drawtext 只有一个构造入口且恒带 expansion=none——不加这个开关时文案里的 % 会被 ffmpeg 静默吞掉、退出码照样是 0，产出一条文字残缺却"成功"的视频。响度统一 loudnorm I=-16:LRA=7:TP=-1.5。时长一律 ffprobe 实测，不用脚本估算。ffmpeg 退出码不可信，产出必须回验。
---

# 视频合成

## 调用

```bash
# 构造 drawtext 滤镜串（唯一入口，恒带 expansion=none）
python3 -m byclaw_caps.video drawtext "<文案>" [--fontfile <路径>] \
    [--fontsize 42] [--fontcolor white]

# 实测媒体时长
python3 -m byclaw_caps.video probe <媒体文件>

# 判断某产出是阶段成果还是过程中间件
python3 -m byclaw_caps.video classify <文件名>

# 输出固定规格（响度等）
python3 -m byclaw_caps.video specs
```

退出码：`0` 成功，`1` 业务失败，`2` 用法错误。

## 为什么 drawtext 必须走这个入口

`drawtext` 默认会把文案当模板展开，`%` 及 `{}` 被当作占位符**静默吞掉**，
ffmpeg **退出码 0**。产出是一条文字残缺的视频——"转化率提升 30%" 渲染成 "转化率提升 30"。

本能力恒带 `expansion=none`。**不要绕过它手写 drawtext**，靠人记得加开关迟早会漏。

## 响度

统一 `loudnorm=I=-16:LRA=7:TP=-1.5`。多段拼接时各段响度不一，观众要反复调音量。
`specs` 子命令输出当前值，**不要在各处硬编码**。

## 时长只测不算

`probe` 走 ffprobe 实测。**不接受按字数×语速估算**——曾因此出现字幕只覆盖 30% 旁白。
配音时长的实测值同时是字幕时间轴的唯一来源，见 `voice-over` 能力。

## ffmpeg 退出码不可信

编码失败、产出 0 字节、滤镜静默跳过，都可能伴随退出码 0。合成后**必须回验产出**：
文件存在、体积合理、`probe` 时长符合预期。

## 阶段产出 vs 过程中间件

`classify` 区分二者。中间件（分镜片段、临时音轨、concat 清单）可清理；阶段产出要保留，
因为重做某一环节时要从上一环节的产出接着走，而不是从头再来。

## 镜头运动：一张图支撑多个镜头

```bash
python3 -m byclaw_caps.video motion --type push-in --framing right-half --duration 4
python3 -m byclaw_caps.video qc <分镜.json>
```

分镜契约的 `standard` 档（默认）是「每段旁白一个镜头，但镜头可复用同一张图的不同取景」。
**没有运镜这一档就不成立**：同一张图配两个镜头会变成静止画面横跨两段旁白。

取景 `full` `left-half` `right-half` `top` `bottom` `center`；
运动 `none` `push-in` `pull-out` `pan`。

**两处会静默出错的地方：**

- `zoompan` 的 `d` 是**帧数不是秒数**。写成秒会得到瞬间结束的运镜，而退出码正常。
- 输出尺寸必须显式给 `s=`。不给的话按输入尺寸输出，一张 2736×1536 的生图会把整条视频
  拖成那个画幅。

**取景按输入图尺寸算，不是输出尺寸。** 曾把输出的 640×360 传进去，于是 `right-half`
只裁到 x=320 而源图 1920 宽——那个位置还在左半边。**ffmpeg 退出码 0、时长画幅全对，
只是画面裁错了地方**，抽帧比对才发现。

## 质检：逐镜头中点抽帧

`qc` 给出每个镜头的中点时刻与它的 `must_show`，并检查静止上限。

**抽中点不抽固定时间点。** 只抽开头、中间、结尾会漏掉中间所有对不上的镜头——
而那正是问题多发区：一张图扛三段旁白时，坏的往往是第二、三段。

**静止画面不超过 8 秒**，与档位无关。有运镜就不算静止。
