#!/usr/bin/env python3
"""工作流状态能力 CLI。

阶段校验的不符是**业务失败（退出码 1）而非错误**：调用方要据此换动作。
验收哈希不符同理——它是门禁生效，不是程序出问题。
"""
from __future__ import annotations

import argparse

from byclaw_caps._cli import add_common, business, dispatch
from byclaw_caps.workflow import (
    stage_paths,
    HANDOFF_STATUSES, ROLLBACK_TRANSITIONS, STAGES, TRANSITIONS, WorkflowError,
    bump_attempt, clear_attempt, handoff, init_workflow, load_state,
    record_acceptance, research_budget, rollback, spend_research, transition,
    validate_stage, verify_acceptance,
)


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="byclaw_caps.workflow", description="工作流状态")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="初始化工作流状态")
    init.add_argument("--root", default=".", help="会话根目录")
    init.add_argument("--employee", required=True)
    init.add_argument("--skill", required=True)

    show = sub.add_parser("show", help="读当前状态（含迁移所需的 revision 与 sha256）")
    show.add_argument("--root", default=".")

    validate = sub.add_parser("validate", help="校验当前阶段是否与预期相符")
    validate.add_argument("--root", default=".")
    validate.add_argument("--expected-stage", required=True)

    move = sub.add_parser("transition", help="迁移到下一阶段")
    move.add_argument("--root", default=".")
    # `--to` 与 `--next-stage` 是同一件事。`rollback` 收的是 `--to`，
    # 两个兄弟子命令用不同的名字指同一个概念，实测中 agent 在这里猜错过。
    # **不删 `--next-stage`**——它已经写进了几处文档与提示词，
    # 删了就是另一批 `unrecognized arguments`。
    move.add_argument("--next-stage", "--to", dest="next_stage", required=True,
                      help="迁到哪个阶段。`--to` 是同义写法，与 rollback 保持一致")
    move.add_argument("--expected-revision", type=int, required=True,
                      help="来自 show；与 --expected-sha256 一起防止覆盖他人已写状态")
    move.add_argument("--expected-sha256", required=True)
    move.add_argument("--employee", required=True)
    move.add_argument("--skill", required=True)

    accept = sub.add_parser("accept", help="记录文件的验收哈希")
    accept.add_argument("--root", default=".")
    accept.add_argument("--file", required=True)
    accept.add_argument("--accepted-by", required=True)

    verify = sub.add_parser("verify", help="校验文件自验收后是否被改动")
    verify.add_argument("--root", default=".")
    verify.add_argument("--file", required=True)

    stages = sub.add_parser("stages", help="列出封闭阶段集合与允许的迁移")

    # 产物写到哪。**全仓唯一的读法**——改之前每个 Skill 与工作规范各抄一份
    # （60 多处），改一处漏几处是必然的。
    where = sub.add_parser("paths", help="这个阶段的产物写到哪（不要自己拼路径）")
    where.add_argument("--stage", required=True, help="|".join(sorted(STAGES)))

    # 助理收工吐给组长的回执。**只有路径与哈希，没有产物正文**——
    # 回执一旦带上正文，组长的上下文就会和拆分前一样涨，拆了等于没拆。
    hand = sub.add_parser("handoff", help="生成交接回执（路径+哈希，不含产物正文）")
    hand.add_argument("--root", default=".")
    hand.add_argument("--status", default="ok",
                      help="|".join(sorted(HANDOFF_STATUSES)))
    hand.add_argument("--note", default="", help="给组长看的一句话，超长截断")
    hand.add_argument("--artifact", action="append", dest="artifacts", default=[],
                      help="本棒产物的相对路径，可重复；已验收的文件自动带上")
    hand.add_argument("--research-request",
                      help="status=needs_research 时必填：调研请求文件路径")

    # 回退**不并进 transition**：它不会清作废项，拼出来的回退是半个的。
    back = sub.add_parser("rollback", help="回到更早的阶段，并清掉因此作废的验收与产物")
    back.add_argument("--root", default=".")
    back.add_argument("--to", required=True, help="回到哪个阶段")
    back.add_argument("--reason", required=True, help="为什么回退；事后要说得清")
    back.add_argument("--expected-revision", type=int, required=True)
    back.add_argument("--expected-sha256", required=True)
    back.add_argument("--employee", required=True)
    back.add_argument("--skill", required=True)

    # 止损计数与检索预算：把「记忆」从上下文搬到磁盘。
    attempt = sub.add_parser("attempt", help="某个错误码又试了一次；连续 2 次即应停止")
    attempt.add_argument("--root", default=".")
    attempt.add_argument("--code", required=True)
    attempt.add_argument("--clear", action="store_true",
                         help="问题解决了就清掉；留着会让下一次同类错误第一下被判死")

    budget = sub.add_parser("budget", help="读或记检索花销；不给 --assistant 就是只读")
    budget.add_argument("--root", default=".")
    budget.add_argument("--assistant", help="谁花的；给了就是记一笔")
    budget.add_argument("--rounds", type=int, default=0)
    budget.add_argument("--pages", type=int, default=0)
    budget.add_argument("--sub-questions", type=int, default=0)

    for one in (init, show, validate, move, accept, verify, stages,
                hand, back, attempt, budget):
        add_common(one)
    return parser


def handle(args: argparse.Namespace):
    if args.command == "paths":
        return {"ok": True, **stage_paths(args.stage)}, 0
    if args.command == "stages":
        return {"ok": True, "stages": sorted(STAGES),
                "transitions": {k: sorted(v) for k, v in TRANSITIONS.items()},
                # 回退边单列：它们只有 `rollback` 认，`transition` 一律拒绝。
                "rollback_transitions": {k: sorted(v)
                                         for k, v in ROLLBACK_TRANSITIONS.items()}}, 0
    if args.command == "init":
        return init_workflow(args.root, employee=args.employee, skill=args.skill), 0
    if args.command == "show":
        state = load_state(args.root)
        return {"ok": True, "current_stage": state["current_stage"],
                "status": state["status"], "state_revision": state["state_revision"],
                "state_sha256": state["_sha256"],
                "allowed_next": sorted(TRANSITIONS[state["current_stage"]])}, 0
    if args.command == "validate":
        # 不符是业务失败，不是错误——调用方据此换动作。
        return business(validate_stage(args.root, args.expected_stage))
    if args.command == "transition":
        return transition(
            args.root, next_stage=args.next_stage,
            expected_revision=args.expected_revision,
            expected_sha256=args.expected_sha256,
            employee=args.employee, skill=args.skill,
        ), 0
    if args.command == "accept":
        return record_acceptance(args.root, args.file, accepted_by=args.accepted_by), 0
    if args.command == "handoff":
        # `blocked` 是回执的**内容**，不是命令失败——回执本身生成成功了。
        # 报非零会让组长以为 handoff 这条命令出了问题，转头去查命令怎么写。
        return handoff(args.root, status=args.status, note=args.note,
                       artifacts=args.artifacts,
                       research_request=args.research_request), 0
    if args.command == "rollback":
        return rollback(args.root, to=args.to, reason=args.reason,
                        expected_revision=args.expected_revision,
                        expected_sha256=args.expected_sha256,
                        employee=args.employee, skill=args.skill), 0
    if args.command == "attempt":
        if args.clear:
            return clear_attempt(args.root, args.code), 0
        return bump_attempt(args.root, args.code), 0
    if args.command == "budget":
        if not args.assistant:
            return {"ok": True, "budget": research_budget(args.root)}, 0
        found = spend_research(args.root, assistant=args.assistant,
                               rounds=args.rounds, pages=args.pages,
                               sub_questions=args.sub_questions)
        # **超预算是业务失败（1），不是用法错误（2）。** 报 2 会让助理去查
        # 命令怎么写；报 1 它才会去写调研请求交出去。
        return business({**found, "ok": not found["over_budget"],
                         "status": "OVER_BUDGET" if found["over_budget"] else "ok"})
    return business(verify_acceptance(args.root, args.file))


def main() -> int:
    """控制台入口点。

    `python -m byclaw_caps.<能力>` 与安装后的 `byclaw-<能力>` 走同一条路——
    两条路行为分叉的话，文档里写的那条迟早是错的。
    """
    return dispatch(build(), handle, usage_errors=(WorkflowError,))


if __name__ == "__main__":
    raise SystemExit(main())
