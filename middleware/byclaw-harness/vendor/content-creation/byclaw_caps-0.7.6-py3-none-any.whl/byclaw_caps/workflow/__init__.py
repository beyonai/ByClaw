"""工作流状态：阶段迁移、阶段校验、验收哈希。

`content-workflow-runtime` 的残余。那个 Skill 14 个脚本 3256 行，核心是不可变修订——
产物写进 `<content_id>/rNNNN/`，由它分配修订号、提交、记哈希、失败时从快照还原。
会话目录设计里阶段目录是平的，`rNNNN` 那一层不存在，整套失去对象。

留下来的只有两样，各有各的理由：

**阶段状态机 + 乐观并发。** 创作官写完、发布专员接手，两个数字员工共用一个会话，
中间谁都可能读到过期状态再覆盖回去。这与修订层无关。

**验收哈希。** 旧机制唯一买到的真东西是「验收与字节状态绑定」，但它为此付出整套提交
协议——实测自造的 `IMMUTABLE_ARTIFACT_CHANGED` 让 agent 连试 25 轮以上、最终仍只能
重建工作流。这里换成记一个 sha256，比一次。
"""

from __future__ import annotations

import hashlib
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

VERSION = "1.0.0"

STATE_RELATIVE = Path(".runtime") / "workflow-state.yaml"
SCHEMA_VERSION = "2.0"

#: 语义规划契约的版本。**由 `init_workflow` 盖在状态里**，
#: 新建会话才有；据此区分新任务与存量，而不是看调用方填没填字段。
CONTRACT_ERA = "1.0"

#: 阶段是封闭集合。写错阶段名比走错阶段更难查——前者会一路静默到下游。
TRANSITIONS: dict[str, frozenset[str]] = {
    "topic_pending": frozenset({"creative_pending", "blocked", "cancelled"}),
    "creative_pending": frozenset({"creative_validated", "blocked", "cancelled"}),
    "creative_validated": frozenset({"asset_validated", "package_pending", "blocked", "cancelled"}),
    # 图文走 package_pending 去发布；**视频走 delivered 直接完成**——
    # 发布线只收文章与贴图，收不了视频。少了这一条，5 号交接之后无路可走，
    # 工作流永远停在半路。
    "asset_validated": frozenset({"package_pending", "delivered",
                                  "blocked", "cancelled"}),
    "package_pending": frozenset({"package_validated", "blocked", "cancelled"}),
    "package_validated": frozenset({"draft_created", "package_pending", "blocked", "cancelled"}),
    # 草稿建好后仍可退回重排——公众号草稿可覆盖，排版返工是常态。
    "draft_created": frozenset({"package_pending", "publish_submitted", "published",
                                "failed", "cancelled"}),
    "publish_submitted": frozenset({"published", "failed"}),
    "blocked": frozenset({"topic_pending", "creative_pending", "creative_validated",
                          "asset_validated", "package_pending", "package_validated",
                          "draft_created", "publish_submitted", "failed", "cancelled"}),
    "published": frozenset(),
    #: 做完了，但不经渠道发布。**与 published 分开，不复用。**
    #: 两者的 status 都是 completed，含义却不同：published 是已投渠道，
    #: delivered 是已交付待人工发布。复用的话这两种状态无法区分，
    #: 而运营复盘、查重、系列衔接都要读它。
    "delivered": frozenset(),
    "failed": frozenset(),
    "cancelled": frozenset(),
}

#: 回退边**刻意不并进 `TRANSITIONS`**。
#:
#: 并进去的话普通 `transition` 也能走这条路，而它不会清作废项——
#: 于是出现「状态迁了但哈希没清」这种一半的回退，下游拿着失效的验收往下走。
#: 回退必须是原子动作，所以只有 `rollback()` 认这张表。
ROLLBACK_TRANSITIONS: dict[str, frozenset[str]] = {
    "package_pending": frozenset({"creative_pending"}),
    "package_validated": frozenset({"creative_pending"}),
    # 草稿已经在公众号后台了，回退会留下残留（见 `external_residue`）。
    # 仍然开放，是因为「发现草稿有问题」恰恰是最该允许改的时刻——
    # 不许改，人就会绕过系统直接去后台改，那才是真失控。
    "draft_created": frozenset({"creative_pending"}),
}

#: 回退到某个阶段时，**哪些目录下的验收作废**。
#:
#: 正文改一个字符，由它编译出来的东西全部作废。但配图不是从正文编译的——
#: 图片字节没变，验收仍然为真。**把仍然为真的东西标成未验证，
#: 会逼出一整轮无谓的重做。**
INVALIDATED_BY_ROLLBACK: dict[str, tuple[str, ...]] = {
    "creative_pending": ("20-creative/", "40-package/", "50-publish/"),
}

#: 不清、但要提醒人看一眼：正文改了，配图的位置与说明可能就不对了。
REVIEW_AFTER_ROLLBACK: dict[str, tuple[str, ...]] = {
    "creative_pending": ("30-assets/", "35-media/"),
}

#: 找外部残留的地方。清得掉本地登记，**清不掉公众号后台那一份**。
RESIDUE_GLOBS: tuple[str, ...] = ("50-publish/*.json", "50-publish/.meta/*.json")

STAGES: frozenset[str] = frozenset(TRANSITIONS)
TERMINAL_STAGES: frozenset[str] = frozenset({"published", "delivered",
                                             "failed", "cancelled"})

#: 回执允许的四种状态。
HANDOFF_STATUSES: frozenset[str] = frozenset(
    {"ok", "needs_user", "needs_research", "blocked"})

#: 回执里 `summary` 的上限。截 summary，**不截 artifacts**——
#: 路径丢了下一棒就找不到东西。
SUMMARY_LIMIT = 200

#: 同一错误码试到第几次就该停。
ATTEMPT_LIMIT = 2

#: 检索预算的默认上限。`limit` 受保护，计数不受保护。
DEFAULT_RESEARCH_LIMIT: dict[str, int] = {
    "rounds_per_sub_question": 3,   # 深度调研：每子问题
    "spot_check_rounds": 2,         # 单点核实：每个 fact_check
    "spot_check_pages": 3,
    "max_pages": 40,                # 全局
}

#: 只做单点核实的助理——受 `spot_check_*` 那两条更紧的上限约束。
SPOT_CHECK_ASSISTANTS: frozenset[str] = frozenset({"write-article", "discover-writing-topics"})

#: 迁移不得经 patch 改写的字段——它们是并发保护本身。
PROTECTED_FIELDS = frozenset({
    "schema_version", "workflow_id", "state_revision",
    "previous_state_sha256", "updated_at", "updated_by", "current_stage", "acceptance",
    # 上一阶段由 transition 自己写，patch 改它等于伪造来路。
    "previous_stage",
    # 回退痕迹与检索上限：**上限不许助理自己改，计数它们要更新**。
    "rollbacks", "last_rollback", "research_limit",
})

_IN_PROGRESS = "in_progress"
_STATUS_FOR_STAGE = {
    "published": "completed",
    "delivered": "completed",
    "failed": "failed",
    "cancelled": "cancelled",
    "blocked": "blocked",
}


#: 这些失败重读一次状态就能继续，属业务失败（退出码 1）。其余是输入或环境错了（2）。
#: 分错的后果很具体：提示词教 agent「退出码 2 是环境不具备，第一动作是报告不是重试」，
#: 而并发冲突的正确动作恰恰是重新 show 再来一次。
BUSINESS_CODES = frozenset({"STALE_WORKFLOW_STATE", "INVALID_TRANSITION"})


class WorkflowError(RuntimeError):
    def __init__(self, code: str, message: str, **detail: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.detail = detail

    @property
    def exit_code(self) -> int:
        return 1 if self.code in BUSINESS_CODES else 2

    def as_dict(self) -> dict[str, Any]:
        return {"ok": False, "status": self.code, "message": self.message, **self.detail}


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def state_path(root: Path | str) -> Path:
    return Path(root) / STATE_RELATIVE


def _dump(value: Any, indent: int = 0) -> str:
    """只写本模块自己产生的状态，故用最小 YAML 子集，不引入序列化分歧。"""
    pad = "  " * indent
    if isinstance(value, dict):
        if not value:
            return pad + "{}\n"
        out = ""
        for key, item in value.items():
            # **键一律加引号。** 不加的话纯数字键会在往返中变成整数：
            # `attempts["40164"] = 2` 写成 `40164: 2`，读回来是 `{40164: 2}`，
            # 于是 `attempts.get("40164")` 永远落空——**止损计数静默失效**。
            # 40164 正是这个仓库反复撞上的那个（公众号出口 IP 未加白名单）。
            name = _scalar(str(key))
            if isinstance(item, dict) and item:
                out += f"{pad}{name}:\n" + _dump(item, indent + 1)
            else:
                out += f"{pad}{name}: {_scalar(item)}\n"
        return out
    return pad + _scalar(value) + "\n"


def _scalar(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, dict) and not value:
        return "{}"
    text = str(value)
    return '"%s"' % text.replace("\\", "\\\\").replace('"', '\\"')


def _atomic_write(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(_dump(state))
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def load_state(root: Path | str) -> dict[str, Any]:
    """读状态，并附上文件实测 sha256 —— 迁移时要用它做并发保护。"""
    import yaml

    path = state_path(root)
    if not path.is_file():
        raise WorkflowError("WORKFLOW_NOT_FOUND", f"工作流状态不存在：{path}")
    state = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(state, dict):
        raise WorkflowError("WORKFLOW_MALFORMED", f"工作流状态不是对象：{path}")
    state["_sha256"] = sha256_file(path)
    state.setdefault("acceptance", {})
    return state


def init_workflow(root: Path | str, *, employee: str, skill: str,
                  workflow_id: str | None = None) -> dict[str, Any]:
    path = state_path(root)
    if path.exists():
        # 重新初始化会抹掉进度，而这里刻意没有快照可还原，只能拒绝。
        raise WorkflowError("WORKFLOW_EXISTS", f"工作流已存在，拒绝覆盖：{path}")
    state = {
        "schema_version": SCHEMA_VERSION,
        "workflow_id": workflow_id or "wf-" + hashlib.sha256(
            str(Path(root).resolve()).encode("utf-8")).hexdigest()[:12],
        "current_stage": "topic_pending",
        "status": _IN_PROGRESS,
        "state_revision": 1,
        "previous_state_sha256": "",
        "updated_at": _now(),
        "updated_by": {"employee": employee, "skill": skill},
        "acceptance": {},
        # **这个会话建于哪一版契约。** 新任务必须有排版计划、必须走语义规划，
        # 而"是不是新任务"要由工作流自己说，不能看调用方传没传参数——
        # 后者的意思是"省掉参数即可豁免"。
        # 建于本标记之前的会话没有这一项，按存量放行。
        "contract_era": CONTRACT_ERA,
    }
    _atomic_write(path, state)
    return {"ok": True, "status": "initialized", "workflow_id": state["workflow_id"],
            "current_stage": state["current_stage"], "state_path": STATE_RELATIVE.as_posix()}


def _require_stage(stage: str) -> str:
    if stage not in STAGES:
        # 不做模糊匹配：把 `creative` 当成 `creative_pending` 会让校验失去意义。
        raise WorkflowError("UNKNOWN_STAGE", f"阶段不在封闭集合内：{stage}",
                            known_stages=sorted(STAGES))
    return stage


def validate_stage(root: Path | str, expected: str) -> dict[str, Any]:
    _require_stage(expected)
    state = load_state(root)
    current = str(state["current_stage"])
    return {
        "ok": current == expected,
        "status": "ok" if current == expected else "STAGE_MISMATCH",
        "expected_stage": expected,
        "current_stage": current,
        "state_revision": state["state_revision"],
    }



def _check_entry_preconditions(root: Path, stage: str) -> None:
    """进入某阶段前的产物门禁。

    **为什么不能凭编译时留下的结果 JSON。** 那份 JSON 有三种方式给出假凭据，
    三种都实测复现过：

    * ``compile markdown --skip-validate`` 返回 ``ok=true`` 而 ``validated=false``
      ——没校验也说 ok；
    * ``compile preview`` 返回 ``ok=true, validated=true``，但它是**预览口径**，
      那份 HTML 按渠道包口径查有 7 个 ERROR（doctype、html、head、body、h1）；
    * 结果 JSON **不带文件哈希**，证明不了它对应的是当前这份文件——
      旧报告配新文件读不出来。

    所以这里**读实际文件、按 channel 口径重校验**。成本几十毫秒，
    而凭据造假的代价是群发不可撤回。
    """
    required = ENTRY_REQUIRED_FILES.get(stage, ())
    missing = [rel for rel in required if not (root / rel).is_file()]
    if missing:
        raise WorkflowError(
            "STAGE_ENTRY_ARTIFACT_MISSING",
            f"进 {stage} 之前这些产物必须在位，现在缺：{'、'.join(missing)}。\n"
            "排版没做完就迁移，下游会拿着一个不存在的文件去投递。\n"
            "先跑 `python3 -m byclaw_caps.compile markdown/preview` 产出两份，再迁移。",
            stage=stage, missing=missing)
    if stage == "asset_validated":
        # **配图的问题在配图这一格就要暴露。**
        #
        # 早先这一类检查只挂在 `package_validated`：清单漏盖章要等排版跑完
        # 才报，而那时配图已经交接出去了，得把人叫回来重走一遍。
        # 一次实测就是这样收的尾——回执写着"门禁全绿"，而清单根本没验收。
        _check_asset_manifest_closed(root, stage)
        return
    if stage != "package_validated":
        return

    channel = root / "40-package/渠道包.html"
    # 惰性导入：workflow 是流程层，不该为了一个渠道的红线在模块加载时就拖上渲染器。
    from byclaw_caps.compile import KIND_CHANNEL, validate_channel_html

    report = validate_channel_html(
        channel.read_text(encoding="utf-8", errors="replace"), kind=KIND_CHANNEL)
    errors = [f for f in report.get("findings", []) if f.get("level") == "ERROR"]
    if errors:
        codes = sorted({str(f.get("code")) for f in errors})
        raise WorkflowError(
            "CHANNEL_PACKAGE_RED_LINE",
            f"渠道包踩了平台红线，不能进 {stage}：{'、'.join(codes)}。\n"
            "**这是按渠道包口径现场重校验的结果，不是翻旧报告。**\n"
            "常见成因：把预览文档当成渠道包了（预览带 doctype/html/head/body/h1，"
            "按渠道包口径一律 ERROR），或编译时加了 --skip-validate。\n"
            "重新跑 `compile markdown`（不要加 --skip-validate），按报告改版式。",
            stage=stage, codes=codes,
            findings=[{k: f.get(k) for k in ("code", "line", "message")}
                      for f in errors[:5]])

    acceptance = (load_state(root).get("acceptance") or {}).get("40-package/渠道包.html")
    if not acceptance:
        raise WorkflowError(
            "CHANNEL_PACKAGE_NOT_ACCEPTED",
            f"渠道包还没登记验收，不能进 {stage}。\n"
            "跑 `python3 -m byclaw_caps.workflow accept --root <会话根> "
            "--file <会话根>/40-package/渠道包.html --accepted-by <验收人>`。\n"
            "**--file 要写绝对路径**：相对路径按当前工作目录解析，不会拼到 --root 上。",
            stage=stage)
    _check_artifact_records(root, stage)
    # **顺序有讲究：先跑"跟当前输入比"，再跑"产物自洽"。**
    # 同一件事（同路径换了 PNG）两边都能发现，但前者按资产 id 认得出是哪一张，
    # 报 `ASSET_VERSION_MISMATCH`；后者只知道"消费记录对不上"。
    # 反过来的话，30-assets 下换图这个最常见的场景会退化成更笼统的码。
    # 两个都要留着——前者只扫 `30-assets/`，正文目录下的配图归后者管。
    _check_against_current_inputs(root, stage)
    _check_assets_were_validated(root, stage)
    _check_typesetting_plan(root, stage)
    _check_consumption(root, stage)
    if sha256_file(channel) != acceptance.get("sha256"):
        raise WorkflowError(
            "CHANNEL_PACKAGE_CHANGED",
            f"渠道包在验收之后被改过，不能进 {stage}。\n"
            "**旧报告配新文件正是这道门禁要拦的。** 验收章盖的是当时那份字节，"
            "换了文件那枚章就不再代表任何东西。\n"
            "重新编译后重新 accept，不要手工凑哈希。",
            stage=stage, path="40-package/渠道包.html")

    _check_preview_acceptance(root, stage)


def _check_artifact_records(root: Path, stage: str) -> None:
    """两份产物的记录：输入一致、字节没被换、与当前实际输入相符。

    **只比「两份之间一致」是不够的**——计划已经改成 B、两份产物和记录都停在 A 时，
    A 和 A 当然一致。所以还要跟**当前磁盘上的实际输入**比。

    **也不能只比输入**——前面所有字段记的都是「消费了什么」，没有一个记「产出了什么」。
    于是这个反例成立：预览被旧 HTML 覆盖，`render_input` 与 `consumption`
    一个字节不变，所有输入比较照样通过。`artifact.output_sha256` 拦的就是它。

    **必须覆盖两份。** 此前只有渠道包有验收哈希保护（`CHANNEL_PACKAGE_CHANGED`），
    预览连这一层都没有。
    """
    from byclaw_caps.compile._records import read_record

    pairs = [("channel", root / "40-package/渠道包.html"),
             ("preview", root / "40-package/预览.html")]
    records = {}
    for kind, path in pairs:
        record = read_record(path)
        if record is None:
            raise WorkflowError(
                "ARTIFACT_RECORD_MISSING",
                f"{path.name} 旁边没有 .record.json，不能进 {stage}。\n"
                "记录由 `compile markdown` / `compile preview` 落盘——"
                "**重新编译一次**，不要手工补记录。",
                stage=stage, path=path.name, kind=kind)
        records[kind] = record

        artifact = record.get("artifact") or {}
        declared = artifact.get("output_sha256")
        actual = sha256_file(path)
        if declared != actual:
            raise WorkflowError(
                "ARTIFACT_CONTENT_CHANGED",
                f"{path.name} 的字节与它自己的记录对不上，不能进 {stage}。\n"
                "**输入没变不等于产物没被换。** 记录里全是「消费了什么输入」，"
                "只有这一项记「产出了什么」——它拦的正是"
                "「输入与消费记录都不动，只把 HTML 换掉」。\n"
                "重新编译，不要手工改记录。",
                stage=stage, path=path.name,
                declared=declared, actual=actual)

    channel_input = (records["channel"].get("render_input_sha256") or "")
    preview_input = (records["preview"].get("render_input_sha256") or "")
    if channel_input != preview_input:
        raise WorkflowError(
            "RENDER_INPUT_MISMATCH",
            f"渠道包与预览的编译输入不同，不能进 {stage}。\n"
            "**要求一致的是编译输入关系，不是两份 HTML 的字节**"
            "（一个是片段、一个是完整文档，本来就不同）。\n"
            "常见成因：两份用了不同主题、不同版式、不同 `--image-fit`、"
            "不同术语表，或只重编译了其中一份。\n"
            "用同一组参数把两份都重新编译一次。",
            stage=stage, channel=channel_input, preview=preview_input)


def _check_against_current_inputs(root: Path, stage: str) -> None:
    """拿**当前磁盘上的东西**重算一遍，不只是比两份记录彼此一致。

    这一条是前两条都替代不了的：

    * `_check_artifact_records` 比的是两份记录的指纹是否相同——
      **计划已经改成 B、两份产物和记录都停在 A 时，A 和 A 当然一致**；
    * `_check_consumption` 比的是记录与它自己的 HTML——
      同样不知道正文和计划现在是什么样子。

    所以这里重读正文、计划、术语表、映射与图片，重算一遍拿去对。
    实测中"编译后改正文"和"同路径换 PNG"就是从这个口子漏过去的。
    """
    from byclaw_caps.compile._records import read_record, read_image_map

    for rel in ("40-package/渠道包.html", "40-package/预览.html"):
        path = root / rel
        record = read_record(path)
        if record is None:
            continue
        inputs = record.get("inputs")
        if not inputs:
            raise WorkflowError(
                "STAGE_INPUT_UNTRACEABLE",
                f"{path.name} 的记录没有 `inputs`，无从重算当前输入，"
                f"不能进 {stage}。\n"
                "**「查不到」不等于「没变」**——按兼容放行的话，"
                "改了正文、改了计划、同路径换了 PNG 全都照样过。\n"
                "重新编译一次即可，新版编译器会记下输入位置。",
                stage=stage, path=path.name)
        recorded = record.get("render_input") or {}
        consumption = record.get("consumption") or {}

        for label, key, expected in (
                ("正文", "article", recorded.get("content_sha256")),
                ("计划", "plan", recorded.get("plan_sha256")),
                ("文章计划", "article_plan", recorded.get("article_plan_sha256")),
                ("组件计划", "component_plan", recorded.get("component_plan_sha256")),
                ("自定义主题", "theme_file", recorded.get("theme_file_sha256")),
                ("术语表", "terms", recorded.get("glossary_sha256")),
        ):
            declared = str(inputs.get(key) or "")
            if not declared:
                continue
            current = root / declared
            if not current.is_file():
                raise WorkflowError(
                    "STAGE_INPUT_MISSING",
                    f"{path.name} 记录它用了 {declared}，但那个文件现在不在，"
                    f"不能进 {stage}。",
                    stage=stage, path=path.name, missing=declared)
            if sha256_file(current) != str(expected or ""):
                raise WorkflowError(
                    "INPUT_FINGERPRINT_MISMATCH",
                    f"{label}在编译之后被改过，{path.name} 还是旧的，"
                    f"不能进 {stage}。\n"
                    "**两份产物彼此一致不等于它们还对应当前输入**——"
                    "它们可以一起停在旧版本上。\n"
                    "用同一组参数把两份重新编译一次。",
                    stage=stage, path=path.name, input=declared)

        image_map = str(inputs.get("image_map") or "")
        if image_map:
            current_map = root / image_map
            if not current_map.is_file():
                raise WorkflowError(
                    "STAGE_INPUT_MISSING",
                    f"{path.name} 记录它用了映射 {image_map}，但那个文件现在不在。",
                    stage=stage, path=path.name, missing=image_map)
            if read_image_map(current_map)[2] != \
                    str(consumption.get("image_map_sha256") or ""):
                raise WorkflowError(
                    "RENDER_INPUT_MISMATCH",
                    f"图片映射在编译之后被改过，{path.name} 还是旧的，"
                    f"不能进 {stage}。重新编译。",
                    stage=stage, path=path.name)

        for asset in recorded.get("assets") or ():
            asset_id = str(asset.get("id") or "")
            declared = _asset_file(root, path, inputs, consumption, asset_id,
                                   stage)
            if declared is None:
                continue
            if sha256_file(declared) != str(asset.get("sha256") or ""):
                raise WorkflowError(
                    "ASSET_VERSION_MISMATCH",
                    f"图片 {asset.get('id')} 在编译之后被换过，"
                    f"{path.name} 引用的是旧版本，不能进 {stage}。\n"
                    "**同路径换 PNG 时 HTML 一个字节都不动**——"
                    "只比 HTML 的话这件事查不出来。\n"
                    "重新编译，并重跑受影响的页面检查。",
                    stage=stage, path=path.name, asset=asset.get("id"))


def _check_typesetting_plan(root: Path, stage: str) -> None:
    """新会话必须有排版计划。

    **"是不是新任务"由工作流自己说。** 判据是 `init_workflow` 盖在状态里的
    `contract_era`：它出自工具链，调用方给不了也省不掉。

    早先这条只写在 skill 文档里（"不传也能编译，但那不是给流程开的口子"），
    而门禁一个字都没查——于是全新会话不传 `--plan` 照样进 `package_validated`，
    那句话等于没写。规矩写在文档里、执行点不存在，就是没有规矩。

    建于本标记之前的会话没有 `contract_era`，按存量整体放行。
    """
    from byclaw_caps.compile._records import read_record

    if not (load_state(root).get("contract_era") or ""):
        return
    for rel in ("40-package/渠道包.html", "40-package/预览.html"):
        path = root / rel
        record = read_record(path)
        if record is None:
            continue
        if not str((record.get("render_input") or {}).get("plan_sha256") or ""):
            raise WorkflowError(
                "TYPESETTING_PLAN_REQUIRED",
                f"这是本契约之后新建的会话，{path.name} 却是在没有排版计划的情况下"
                f"编译的，不能进 {stage}。\n"
                "**省掉 `--plan` 不构成豁免**：新任务要有显式的高亮计划"
                "（判断结果就是「不加」时，给一份整篇的空计划即可，"
                "不必逐节写理由）。\n"
                "补上计划后用同一组参数把两份重新编译一次。",
                stage=stage, path=path.name)


def _validated_assets(root: Path, stage: str) -> dict[str, dict] | None:
    """配图交出来的已验收清单：`asset_id → sha256`。

    清单不在（这条线没有配图，或还没走到那一步）时返回 `None`，
    与"清单在但这张图不在里面"区分开——后者要拦，前者不适用。

    **"文件在但读不出来"属于后者，不属于前者。**
    早先这里把解析失败也 `return None`，上层把 `None` 读成"没有配图清单，
    不适用"，于是整道检查被跳过。实测：清单验收的是 A、实际用的是 B 时正确阻断，
    **把清单截断成半截 JSON 之后，同一份产物反而放行**——
    等于损坏清单就能绕过配图验收，而这正是它要拦的事。

    所以解析失败当场报错：清单存在就说明这条线有配图，读不出来是**故障**，
    不是"不适用"。
    """
    import json as _json

    path = root / "30-assets" / "image-asset-manifest.json"
    if not path.is_file():
        return None
    try:
        manifest = _json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError) as failure:
        raise WorkflowError(
            "ASSET_MANIFEST_UNREADABLE",
            f"配图的已验收清单读不出来，不能进 {stage}：{failure}\n"
            "**清单在场就说明这条线有配图**，读不出来是故障，不是「不适用」——"
            "当成不适用的话，损坏清单就成了绕过配图验收的办法。\n"
            "回 `illustrate-article` 重新产出清单，不要手工补 JSON。",
            stage=stage, path=str(path.relative_to(root).as_posix())) from failure
    if not isinstance(manifest, dict):
        raise WorkflowError(
            "ASSET_MANIFEST_UNREADABLE",
            f"配图的已验收清单顶层不是对象（实际是 "
            f"{type(manifest).__name__}），不能进 {stage}。\n"
            "回 `illustrate-article` 重新产出清单。",
            stage=stage, path=str(path.relative_to(root).as_posix()))
    if str(manifest.get("status") or "") != "validated":
        return {}
    found: dict[str, dict] = {}
    for asset in manifest.get("assets") or []:
        if not isinstance(asset, dict):
            continue
        if str(asset.get("status") or "") != "validated":
            continue
        digest = str(((asset.get("validation") or {}).get("sha256")) or "").lower()
        if digest:
            found[str(asset.get("asset_id") or "")] = {
                "sha256": digest,
                # alt 一并带出来：它是**嵌入映射校验**的判据。
                # 语义哈希把图片引用归一成带 id 的槽位标记，看不见 alt 文案；
                # 那一项归这里查（方案 §3.2 的分工表）。
                "alt": str(asset.get("alt_text") or ""),
            }
    return found


#: 正文里的图片引用：`![alt](path)`。
_IMAGE_REF = re.compile(r"!\[([^\]]*)\]\(([^)\s]+)[^)]*\)")


#: 配图产出的资产落在这里。清单管的就是这个目录下的东西。
ILLUSTRATION_ASSET_DIR = "30-assets/"


def _ref_key(path: Path) -> str:
    """比对用的路径键。

    Windows 上大小写不敏感、分隔符两可，直接比字符串会把同一个文件
    当成两个；`normcase` + `normpath` 把这两件事抹平。
    """
    import os
    return os.path.normcase(os.path.normpath(str(path)))


def _article_image_refs(root: Path) -> list:
    """正文里所有指向配图目录的引用，**保留完整路径**。

    返回 `(文章名, alt, 原始写法, 解析后的绝对路径)`。

    **路径必须整条留着。** 早先这里把引用压成 `Path(target).stem`，
    只拿文件名主干去清单里查——目录和扩展名全丢了，于是两种写法都能蒙混：

    * `../30-assets/visual-001.jpg` —— 清单里登记的是 `.png`，
      检查却拿 stem 查到那条记录，再去验 `.png` 的文件与摘要，**全对**；
      而正文指的 `.jpg` 根本不存在。
    * `../30-assets/missing/visual-001.png` —— 多一层目录，同样被抹掉。

    两条都是「读者那里是一块空白，而工作流放行」。
    """
    from urllib.parse import unquote

    out = []
    asset_root = Path(_ref_key((root / ILLUSTRATION_ASSET_DIR).resolve()))
    asset_dirname = _ref_key(Path(ILLUSTRATION_ASSET_DIR))
    creative = root / "20-creative"
    if not creative.is_dir():
        return out
    for article in sorted(creative.glob("*.md")):
        try:
            text = article.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for alt, target in _IMAGE_REF.findall(text):
            raw = target.strip().lstrip("<").rstrip(">")
            raw = unquote(raw.split("#", 1)[0].split("?", 1)[0])
            raw = raw.replace("\\", "/")
            if not raw:
                continue
            if re.match(r"^(?:[a-zA-Z][a-zA-Z0-9+.-]*:)?//", raw):
                continue  # 远程 URL 不属于本地配图清单。
            path = (article.parent / raw).resolve()
            normalized = Path(_ref_key(path))
            # 先解析再判归属。保留错误相对路径中的资产目录，交给登记检查报错，
            # 例如 20-creative/30-assets/x.png，不能把它当成作者自带图而跳过。
            if not (normalized.is_relative_to(asset_root)
                    or asset_dirname in normalized.parts):
                continue
            out.append((article.name, alt, target, path))
    return out


def _owned_by_illustration(record: Mapping[str, Any],
                           asset: Mapping[str, Any]) -> bool:
    """这个资产是配图产出的吗——**看它落在哪**。

    记录里 `inputs.assets` 存着每个 id 当时的源文件位置。
    在 `30-assets/` 下的才归配图清单管；作者自带的插图不经 finalize-assets，
    对它们要求一份配图清单等于要求一件不存在的东西。
    """
    located = ((record.get("inputs") or {}).get("assets") or {})
    where = str(located.get(str(asset.get("id") or "")) or "")
    return where.startswith(ILLUSTRATION_ASSET_DIR)


#: 规范件是 JSON。YAML 是同内容的展示副本，不作判据。
ASSET_MANIFEST_JSON = "30-assets/image-asset-manifest.json"
ASSET_MANIFEST_YAML = "30-assets/image-asset-manifest.yaml"


def _illustration_required(root: Path) -> str:
    """这条线需不需要配图——**看计划和正文，不看清单在不在**。

    返回一句"凭什么这么判"的证据；不需要配图时返回空串。

    判据两条，任一成立即需要：

    * `30-assets/` 下有编译出来的 VisualPlan，且里面有资产项；
    * 正文里引用了 `30-assets/` 下的图片。

    两条都不成立才是"这条线没有配图"。**不能拿"清单文件不存在"当判据**——
    那会让"删掉清单"变成最省事的豁免方式。
    """
    import json as _json

    assets = root / "30-assets"
    if assets.is_dir():
        for plan_file in sorted(assets.glob("visual-plan-*.json")):
            try:
                plan = _json.loads(plan_file.read_text(encoding="utf-8"))
            except (ValueError, OSError):
                continue
            items = [i for i in (plan.get("items") or []) if isinstance(i, dict)]
            if items:
                return "%s 里有 %d 项资产" % (plan_file.name, len(items))

    refs = _article_image_refs(root)
    if refs:
        return "%s 引用了 30-assets/ 下的图片" % refs[0][0]
    return ""


def _check_asset_manifest_closed(root: Path, stage: str) -> None:
    """配图收尾：清单在不在、两份一致不一致、盖没盖章。

    **这三件事在配图这一格问，不留给排版。** 留给排版的代价是固定的：
    配图已经交接、人已经走了，报错却在下一个人手里出现。

    没有清单（这条线不配图）时什么也不做——**不能把"没有配图"判成"漏了配图"**。
    """
    import json as _json

    manifest = root / ASSET_MANIFEST_JSON
    required = _illustration_required(root)
    if not manifest.is_file():
        if (root / ASSET_MANIFEST_YAML).is_file():
            raise WorkflowError(
                "ASSET_MANIFEST_JSON_MISSING",
                f"只有 YAML 清单、没有 JSON，不能进 {stage}。\n"
                "**规范件是 JSON**：accept、verify 与下游门禁读的都是它；"
                "YAML 只供人看。重跑 finalize-assets 产出两份。",
                stage=stage, path=ASSET_MANIFEST_JSON)
        if required:
            # **"清单不在"不能等同于"不需要配图"。**
            #
            # 那样的话，删掉两份清单就是最省事的豁免方式——
            # 而这道门禁要拦的恰恰是"该交的图没交完"。
            # 需不需要配图由**计划与正文引用**说了算，不由清单在不在说了算。
            raise WorkflowError(
                "ASSET_MANIFEST_MISSING",
                f"这条线要配图（{required}），却没有资产清单，不能进 {stage}。\n"
                "**删掉清单不构成豁免。** 跑 finalize-assets 产出清单并盖章；"
                "确实不需要配图时，先把计划里的 visual_plan 与正文里的图片引用一起清掉。",
                stage=stage, evidence=required)
        return  # 计划没要图、正文也没引图：这条线确实没有配图

    yaml_path = root / ASSET_MANIFEST_YAML
    if yaml_path.is_file():
        # 两份内容必须一致——**不一致时验收谁都不对**：
        # 盖在 JSON 上而人看的是 YAML，等于验收了一份没人读过的东西。
        try:
            import yaml as _yaml

            same = _json.loads(manifest.read_text(encoding="utf-8")) == \
                _yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001 - 读不出来按不一致处理，下面给可执行修法
            same = False
        if not same:
            raise WorkflowError(
                "ASSET_MANIFEST_DESYNC",
                f"JSON 与 YAML 两份清单内容不一致，不能进 {stage}。\n"
                "**验收盖在 JSON 上，而人读的是 YAML**——不一致时那一章"
                "担保的不是任何人看过的东西。\n"
                "重跑 finalize-assets 让两份一起产出，不要手工改其中一份。",
                stage=stage)

    entry = (load_state(root).get("acceptance") or {}).get(ASSET_MANIFEST_JSON)
    if not entry:
        raise WorkflowError(
            "ASSET_MANIFEST_NOT_ACCEPTED",
            f"配图清单还没盖验收章，不能进 {stage}。\n"
            "**这一步漏了，问题会推迟到排版跑完才暴露**，而那时配图已经交接。\n"
            "跑 `python3 -m byclaw_caps.workflow accept --root <会话根> "
            f"--file <会话根>/{ASSET_MANIFEST_JSON} --accepted-by <验收人>`。",
            stage=stage, path=ASSET_MANIFEST_JSON)
    if not digests_match_safe(sha256_file(manifest), entry.get("sha256")):
        raise WorkflowError(
            "ASSET_MANIFEST_CHANGED",
            f"配图清单在盖章之后被改过，不能进 {stage}。\n"
            "重新 finalize 并重新盖章，不要手工凑哈希。",
            stage=stage, path=ASSET_MANIFEST_JSON)
    _check_assets_complete(root, stage, manifest)
    _check_article_references(root, stage, manifest)
    _check_article_alt(root, stage, manifest)


def _check_article_references(root: Path, stage: str, manifest: Path) -> None:
    """正文引用的每一张配图，**登记了吗、文件在吗、还是那一版吗**。

    这一条与 `_check_assets_complete` 是两个方向：那一条问"计划要的都交了吗"，
    这一条问"正文用的都登记了吗"。**两头都要问**——

    * 计划里没有、正文里有：替换占位时手写了一个 id，或者计划改过而正文没跟上。
      实测反例：计划、清单、磁盘都只有 `visual-001`，正文却引 `visual-002`，
      那张图既没登记也不存在，而工作流照样进了 `asset_validated`。
    * 更狠的一种：**没有 VisualPlan**、正文引了图、清单是已验收的空数组——
      "计划要的都交了"平凡成立（计划要零张），于是全程无人过问。

    早先 `_check_article_alt` 遇到清单里查不到的 id 直接 `continue`，
    理由是"不在清单里，由别处报"。而别处问的是计划，不是正文——
    **两道检查各自以为对方会管，中间那条缝就是这个反例。**
    """
    import json as _json

    refs = _article_image_refs(root)
    if not refs:
        return

    try:
        data = _json.loads(manifest.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return  # 读不出来由 _check_assets_complete 统一报
    listed = [a for a in (data.get("assets") or []) if isinstance(a, dict)]

    # **按路径认人，不按名字。** 清单登记的是"哪个文件"，
    # 正文写的也是"哪个文件"——要对上的就是这个，不是文件名主干。
    by_path: dict[str, Mapping[str, Any]] = {}
    for asset in listed:
        relative = str(asset.get("file_path") or "")
        if relative:
            by_path.setdefault(
                _ref_key((manifest.parent / relative).resolve()), asset)
    by_id = {str(a.get("asset_id") or ""): a for a in listed}

    seen: set[str] = set()
    for where, _alt, raw, path in refs:
        key = _ref_key(path)
        if key in seen:
            continue
        seen.add(key)
        asset = by_path.get(key)
        if asset is None:
            # 同名但不同文件时把差在哪说清楚，否则作者只会看见"没登记"，
            # 而目录里明明躺着一张同名的图。
            guess = by_id.get(Path(raw).stem)
            hint = ""
            if guess is not None:
                hint = ("\n清单里 %s 登记的是 %s——正文指的不是同一个文件。"
                        % (guess.get("asset_id"), guess.get("file_path")))
            raise WorkflowError(
                "ASSET_NOT_REGISTERED",
                f"{where} 里引用了 {raw}，而配图清单里没有这个文件，"
                f"不能进 {stage}。{hint}\n"
                "**正文引了一张没登记的图**——读者那边就是一块空白。\n"
                "要么把它做出来并跑 finalize-assets 登记，"
                "要么把正文里那处引用改对。",
                stage=stage, asset=Path(raw).stem, article=where)
        asset_id = str(asset.get("asset_id") or "")
        recorded = ((asset.get("validation") or {}).get("sha256"))
        if not recorded:
            raise WorkflowError(
                "ASSET_RECORD_INCOMPLETE",
                f"清单里 {asset_id} 缺 validation.sha256，"
                f"而 {where} 正在引用它，不能进 {stage}。",
                stage=stage, asset=asset_id, article=where)
        if not path.is_file():
            raise WorkflowError(
                "ASSET_FILE_MISSING",
                f"{where} 引用的 {raw} 已登记，但文件不在，"
                f"不能进 {stage}。",
                stage=stage, asset=asset_id, article=where)
        if not digests_match_safe(sha256_file(path), recorded):
            raise WorkflowError(
                "ASSET_VERSION_MISMATCH",
                f"{where} 引用的 {raw} 不是清单里验收过的那一版，"
                f"不能进 {stage}。",
                stage=stage, asset=asset_id, article=where)


def _check_article_alt(root: Path, stage: str, manifest: Path) -> None:
    """正文里写的图注，与清单里验收过的 `alt_text` 一致吗。

    **这一条必须在配图这一格问。** 排版那一侧有同名的一道
    （`_check_embedded_alt`），但等到那里才问，代价是固定的一轮跨阶段返工：

    实测过一次。三处图注是替换占位时自拟的，与清单差几个字；排版跑完、
    两份产物都编译并盖过章之后才被拦下。而 `30-assets/` 归配图阶段所有，
    在排版那一格改不了，`package_pending` 的回退边又只有 `creative_pending`——
    于是回退重走 creative_validated → asset_validated 补章、改正文、
    重跑校验、刷验收绑定、逐格迁回、两份产物重编译。**一轮，全为了几个字。**

    在这里问的时候，人还在配图这一格，改起来就是改一处文案。

    **语义哈希看不见 alt**：它把图片引用归一成带 `visual_id` 的槽位标记，
    正是为了让"替换占位"不失效——代价就是 alt 文案对它完全透明，要单独查。
    """
    import json as _json

    try:
        data = _json.loads(manifest.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return  # 读不出来由别的检查统一报

    # 与 _check_article_references 认的是同一个键：路径，不是文件名主干。
    expected: dict[str, tuple[str, str]] = {}
    for asset in (data.get("assets") or []):
        if not isinstance(asset, dict):
            continue
        alt = str(asset.get("alt_text") or "").strip()
        relative = str(asset.get("file_path") or "")
        if alt and relative:
            expected[_ref_key((manifest.parent / relative).resolve())] = (
                str(asset.get("asset_id") or ""), alt)
    if not expected:
        return  # 清单没记 alt，无从比对

    for where, alt, _raw, path in _article_image_refs(root):
        hit = expected.get(_ref_key(path))
        if hit is None:
            continue  # 对不上清单的引用由 _check_article_references 报
        asset_id, want = hit
        if alt.strip() == want:
            continue
        raise WorkflowError(
            "ASSET_ALT_MISMATCH",
            f"正文里 {asset_id} 的图片说明与清单里验收过的不一致，"
            f"不能进 {stage}。\n"
            f"  验收过的：{want}\n"
            f"  正文现在：{alt.strip()}\n"
            "**趁人还在配图这一格改**——拖到排版跑完才发现的话，"
            "`30-assets/` 已经不归那一格管，只能整轮回退重走。\n"
            "两条路：把正文图注改回验收过的那句，"
            "或者图注确实该改就重跑 finalize-assets 让清单跟着改，再重新盖章。",
            stage=stage, asset=asset_id,
            article=where, expected=want, actual=alt.strip())


def _planned_asset_ids(root: Path) -> list[str]:
    """计划要求哪几张图。读不到计划时返回空——那时由别处判需不需要配图。"""
    import json as _json

    assets = root / "30-assets"
    if not assets.is_dir():
        return []
    for plan_file in sorted(assets.glob("visual-plan-*.json")):
        # 只认一编/二编产出的那份；`.compiled.json` 优先，它才是最终规格。
        try:
            plan = _json.loads(plan_file.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            continue
        found = [str(i.get("asset_id") or "") for i in (plan.get("items") or [])
                 if isinstance(i, dict) and i.get("asset_id")]
        if found:
            return found
    return []


def _check_assets_complete(root: Path, stage: str, manifest: Path) -> None:
    """图交齐了吗、还是验收时那一张吗。

    **"清单盖过章"只证明清单没被改过，不证明图交完了。**
    盖章盖的是那份 JSON 的字节——里面写着 `status: pending` 照样能盖，
    图片文件被换掉也照样能盖。这一条补的就是那两件事：

    * 每一项的状态必须是 `validated`——**pending 的图不算交付完成**；
    * 每一项指向的文件要在，且当前摘要等于清单里记的那个。

    第二条与排版那一侧的 `ASSET_VERSION_MISMATCH` 判的是同一件事，
    只是提前到配图这一格问：那时人还在，改起来是一次重渲；
    等到排版结束才问，人已经走了。
    """
    import json as _json

    try:
        data = _json.loads(manifest.read_text(encoding="utf-8"))
    except (ValueError, OSError) as failure:
        # **读不出来不能当"无需检查"。**
        #
        # 早先这里 `return`，理由是"由别的检查统一报"——而那条检查只在
        # 另一条路径上跑。结果：把 JSON 弄坏、YAML 删掉，这份已盖章的清单
        # 反而一路放行。损坏的证据不是缺席的证据，更不是通过。
        raise WorkflowError(
            "ASSET_MANIFEST_UNREADABLE",
            f"配图清单读不出来，不能进 {stage}：{failure}\n"
            "**损坏的清单不是「没有清单」**，它已经盖过验收章。"
            "重跑 finalize-assets 产出两份，再重新盖章。",
            stage=stage, path=ASSET_MANIFEST_JSON) from failure
    if not isinstance(data, dict):
        raise WorkflowError(
            "ASSET_MANIFEST_UNREADABLE",
            f"配图清单顶层不是对象（实际是 {type(data).__name__}），不能进 {stage}。",
            stage=stage, path=ASSET_MANIFEST_JSON)

    # **要与计划要求的资产集合核对，不能只遍历清单自己列出来的那几项。**
    #
    # 只遍历清单的话，它列一张、少列一张，甚至 `assets: []`，
    # 都"每一项都合格"——因为要查的那几项根本不在被遍历的集合里。
    # 计划说要几张，就得有几张。
    required = _planned_asset_ids(root)
    listed = {str(a.get("asset_id") or "") for a in (data.get("assets") or [])
              if isinstance(a, dict)}
    absent = [one for one in required if one not in listed]
    if absent:
        raise WorkflowError(
            "ASSET_NOT_COMPLETE",
            f"计划要求的图没有全部登记，不能进 {stage}：缺 {'、'.join(absent)}。\n"
            "**清单里每一项都合格，不等于该有的都在清单里。**\n"
            "把剩下的图做完并跑 finalize-assets，再重新盖章。",
            stage=stage, missing=absent)

    pending = [str(a.get("asset_id") or "?")
               for a in (data.get("assets") or []) if isinstance(a, dict)
               and str(a.get("status") or "") != "validated"]
    if pending or str(data.get("status") or "") != "validated":
        raise WorkflowError(
            "ASSET_NOT_COMPLETE",
            f"配图还没做完，不能进 {stage}："
            + (f"{'、'.join(pending)} 仍是未验收状态。" if pending
               else "清单整体状态不是 validated。") + "\n"
            "**盖章盖的是清单的字节，不是图的完成度**——"
            "一份写着 pending 的清单照样盖得上章。\n"
            "把剩下的图做完并跑 finalize-assets，再重新盖章。",
            stage=stage, pending=pending)

    directory = manifest.parent
    for asset in (data.get("assets") or []):
        if not isinstance(asset, dict):
            continue
        asset_id = str(asset.get("asset_id") or "?")
        relative = str(asset.get("file_path") or "")
        recorded = ((asset.get("validation") or {}).get("sha256"))
        if not relative or not recorded:
            # **缺字段不是"这一项不用查"。**
            # 早先这里 `continue`，于是把 `file_path` 或 `validation.sha256`
            # 删掉就能让任意一张图免检——而这两个字段正是"图还是不是那一张"
            # 的全部判据。少了它们，这一项是**无从判断**，不是合格。
            raise WorkflowError(
                "ASSET_RECORD_INCOMPLETE",
                f"清单里 {asset_id} 缺 "
                + ("file_path" if not relative else "validation.sha256")
                + f"，无从判断它是不是验收过的那一张，不能进 {stage}。\n"
                "重跑 finalize-assets 产出完整记录，不要手工补字段。",
                stage=stage, asset=asset_id)
        path = directory / relative
        if not path.is_file():
            raise WorkflowError(
                "ASSET_FILE_MISSING",
                f"清单里登记的图片不在：{asset_id} → {relative}，不能进 {stage}。\n"
                "清单说它验收过，而文件已经不在了——**这两件事不能同时为真**。",
                stage=stage, asset=asset_id, path=relative)
        if not digests_match_safe(sha256_file(path), recorded):
            raise WorkflowError(
                "ASSET_VERSION_MISMATCH",
                f"图片 {asset_id} 与清单里验收过的那一版不是同一份，不能进 {stage}。\n"
                "**清单没动、图换了**——只查「清单有没有被改过」看不到这件事。\n"
                "要么换回验收过的那一版，要么重跑 finalize-assets 并重新盖章。",
                stage=stage, asset=asset_id, path=relative)


def digests_match_safe(left: Any, right: Any) -> bool:
    """摘要比较，大小写不算差异；格式不对按不匹配处理。

    这个仓库里 `file_sha256` 出大写、`sha256_file` 出小写，
    裸比字符串会把同一份文件判成被改过。
    """
    from byclaw_caps.shared.render_contract import DigestFormatError, digests_match

    try:
        return digests_match(left, right)
    except DigestFormatError:
        return False


def _check_manifest_acceptance(root: Path, stage: str) -> None:
    """清单本身**验收过吗、验收之后动过吗**。

    清单是这道门禁唯一的判据。它自己不受任何保护的话，改一行哈希就能让
    任意图片"变成验收过的"——**门禁的判据可以被它所判定的那一方改写**，
    那就不是门禁。所以按渠道包同样的办法：盖章，并比当时那份字节。
    """
    relative = "30-assets/image-asset-manifest.json"
    entry = (load_state(root).get("acceptance") or {}).get(relative)
    if not entry:
        raise WorkflowError(
            "ASSET_MANIFEST_NOT_ACCEPTED",
            f"配图的已验收清单没有盖验收章，不能进 {stage}。\n"
            "**没盖章的清单证明不了任何事**：它是这道门禁唯一的判据，"
            "而判据必须自己也被绑定。\n"
            "\n"
            "⛔ **不要在这一格直接 accept 它。** `package_pending` 不拥有 "
            "`30-assets/`，在这里盖会被 `CROSS_STAGE_ACCEPT` 拒掉——"
            "那等于替一份不归自己管的产物背书。\n"
            "\n"
            "**盖章要在 `creative_validated`**：那一格同时拥有 `20-creative/` "
            "与 `30-assets/`，是配图作业所在的地方。\n"
            "\n"
            "而 `package_pending` 的回退边只有 `creative_pending` 一条，"
            "所以要绕一圈回去补：\n"
            "  1. `workflow rollback --root <会话根> --to creative_pending`\n"
            "  2. `workflow transition --next-stage creative_validated …`\n"
            f"  3. `workflow accept --root <会话根> --file <会话根>/{relative} "
            "--accepted-by <验收人>`  ← **在这一格盖，不要等进了下一格**\n"
            "  4. `workflow transition --next-stage asset_validated …`\n"
            "  5. `workflow transition --next-stage package_pending …`，"
            "再重走排版\n"
            "（每步 transition 前都要重新 `show` 取 revision 与 sha256。）\n"
            "\n"
            "⚠️ **顺序不能换。** 先进 `asset_validated` 再盖章是走不通的："
            "那一格的入口门禁**正是要求清单已经验收**，第 4 步会当场被拦，"
            "照着做只会在同一个错误码上再撞一次。\n"
            "\n"
            "**这一趟本不该发生**：清单盖章是配图收尾的一步，"
            "`asset_validated` 入口现在会查它，新会话到不了这里。",
            stage=stage, path=relative,
            # 机器调用读的是这个字段——写错了它，自动化会照着死锁的顺序走。
            rollback_to="creative_pending", accept_at="creative_validated")
    if not digests_match_safe(sha256_file(root / relative), entry.get("sha256")):
        raise WorkflowError(
            "ASSET_MANIFEST_CHANGED",
            f"配图的已验收清单在盖章之后被改过，不能进 {stage}。\n"
            "**改一行哈希就能让任意图片「变成验收过的」**——"
            "这正是要拦的那件事。\n"
            "要么还原清单，要么让配图重新 finalize 并重新盖章。",
            stage=stage, path=relative)


def _check_embedded_alt(root: Path, stage: str, path: Path,
                        record: Mapping[str, Any],
                        validated: Mapping[str, Mapping[str, Any]]) -> None:
    """正文里写的 alt，与清单里验收过的 alt 一致吗。

    **语义哈希管不到 alt。** 它把图片引用归一成带 `visual_id` 的槽位标记，
    正是为了让"替换占位"不失效——代价是 alt 文案对它完全透明。

    而 alt 是会被读出来的内容：清单里验收的是「支持场景推演」，
    正文改成「不支持场景推演」，图没变、语义哈希没变、两份产物自洽，
    **读屏用户听到的是相反的意思**。这一项归嵌入映射校验（方案 §3.2）。
    """
    article = str((record.get("inputs") or {}).get("article") or "")
    if not article:
        return  # 存量记录没记输入位置，按兼容处理
    source = root / article
    if not source.is_file():
        return  # 缺文件由 _check_against_current_inputs 去说
    for alt, target in _IMAGE_REF.findall(source.read_text(encoding="utf-8")):
        asset_id = Path(target).stem
        entry = validated.get(asset_id)
        if entry is None:
            continue  # 不在清单里，由上面那条报
        expected = str(entry.get("alt") or "")
        if not expected:
            continue  # 清单没记 alt，无从比对
        if alt.strip() != expected.strip():
            raise WorkflowError(
                "ASSET_ALT_MISMATCH",
                f"正文里 {asset_id} 的图片说明与配图验收过的不一致，"
                f"不能进 {stage}。\n"
                f"  验收过的：{expected}\n"
                f"  正文现在：{alt}\n"
                "**语义哈希看不见 alt**——它把图片引用归一成槽位标记，"
                "好让替换占位不失效，代价就是这一项要单独查。\n"
                "\n"
                "⛔ **排版这一侧不要自己改正文。** 图注是配图阶段替换占位时写的，"
                "不是排版写的；而正文被验收哈希绑定，在这里动一个字符就\n"
                "`ACCEPTANCE_STALE`，接着是回退重走、刷验收绑定、两份产物重编译"
                "——**一整轮，全为了几个字**。实测过一次。\n"
                "\n"
                "正路：报 `blocked`，让组长 `workflow rollback --to creative_pending`，"
                "由配图那一侧决定是改正文图注还是重跑 finalize-assets 改清单。\n"
                "（这道检查现在也在 `asset_validated` 入口上跑，"
                "所以新会话里它应该在配图那一格就被拦住，到不了这里。）",
                stage=stage, path=path.name, asset=asset_id,
                validated=expected, referenced=alt,
                fix_owner="illustrate-article", typeset_action="blocked")


def _check_assets_were_validated(root: Path, stage: str) -> None:
    """渠道包引用的每一张图，**在配图那一侧验收过吗**。

    这是前面几层都答不上来的问题。它们只知道"这个文件现在是什么哈希"：

    * 把已验收的 A 换成没验收的 B，再重新编译一次，记录、HTML、
      两份产物全部自洽——**因为它们描述的就是 B**；
    * 验收章盖在正文和渠道包上，盖不到图片字节上。

    重新编译能让"输入一致性"重新成立，却不能让 B 变成验收过的图。
    所以要跨阶段问配图那份清单一次：**这张图的这一版，过没过那边的门禁。**
    """
    from byclaw_caps.compile._records import read_record

    validated = _validated_assets(root, stage)
    records = [(root / rel, read_record(root / rel))
               for rel in ("40-package/渠道包.html", "40-package/预览.html")]
    # **只管配图产出的那些资产。**
    #
    # 判据是它落在哪：`30-assets/` 归配图，清单说了算；作者自带的图
    # （`20-creative/` 下的插图、截图）从来不经 finalize-assets，
    # 拿配图清单去查它们只会把正常交付拦死。
    # 它们的完整性由「与当前磁盘重算」那一层负责，不由这一层。
    referenced = any(_owned_by_illustration(record, asset)
                     for _, record in records if record is not None
                     for asset in (record.get("render_input") or {}).get("assets") or ())
    if validated is None:
        if referenced:
            # **"没有清单"不等于"不适用"。**
            # 产物明明引用了图片，却查不到配图那一侧的验收结果——
            # 那是"无从判断"，不是"无需判断"。把它当成不适用的话，
            # 删掉清单就成了最省事的绕过方式：换一张没验过的图，
            # 顺手把清单删了，这道门禁自己就让开了。
            raise WorkflowError(
                "ASSET_MANIFEST_MISSING",
                f"渠道包引用了图片，却找不到配图的已验收清单"
                f"（30-assets/image-asset-manifest.json），不能进 {stage}。\n"
                "**清单缺失是无从判断，不是无需判断。**\n"
                "回 `illustrate-article` 走 finalize-assets 产出清单。",
                stage=stage)
        return  # 没有清单、产物也没引用图片：这条线确实没有配图
    _check_manifest_acceptance(root, stage)
    for path, record in records:
        if record is None:
            continue
        _check_embedded_alt(root, stage, path, record, validated)
        for asset in (record.get("render_input") or {}).get("assets") or ():
            asset_id = str(asset.get("id") or "")
            digest = str(asset.get("sha256") or "").lower()
            if not asset_id or not digest:
                continue
            if not _owned_by_illustration(record, asset):
                continue
            entry = validated.get(asset_id)
            accepted = str((entry or {}).get("sha256") or "")
            if entry is None:
                raise WorkflowError(
                    "ASSET_NOT_VALIDATED",
                    f"{path.name} 引用的图片 {asset_id} 不在配图的已验收清单里，"
                    f"不能进 {stage}。\n"
                    "**重新编译只能让记录与文件重新自洽，"
                    "不能让一张没验过的图变成验过的。**\n"
                    "回 `illustrate-article` 走 finalize-assets，再重新编译排版。",
                    stage=stage, path=path.name, asset=asset_id)
            if accepted != digest:
                raise WorkflowError(
                    "ASSET_VERSION_MISMATCH",
                    f"{path.name} 引用的 {asset_id} 不是配图验收过的那一版，"
                    f"不能进 {stage}。\n"
                    "验收章盖的是当时那份图片字节；同路径换一张图，"
                    "**排版这一侧的检查全都照样通过**，因为它们描述的就是新那张。\n"
                    "要么换回验收过的那一版，要么让配图重新验收。",
                    stage=stage, path=path.name, asset=asset_id,
                    validated=accepted, referenced=digest)


def _asset_file(root: Path, artifact: Path, inputs: Mapping[str, Any],
                consumption: Mapping[str, Any], asset_id: str,
                stage: str) -> Path | None:
    """资产 id 的**源图**现在在磁盘的哪里。

    返回 `None` 只有一个含义：**这条记录压根定位不到源图**（存量记录没记
    源图位置、而渲染地址是个远端 URL）。那种不可追溯由
    `STAGE_INPUT_UNTRACEABLE` 去说，不在这里假装查过。

    ⛔ **「记录说它在这儿、可它不在」不走这条路，当场抛 `STAGE_INPUT_MISSING`。**
    两者混成同一个 `None` 漏过一次：远程映射下把源图删掉，照样进
    `package_validated`。

    ## 问的是「源图在哪」，不是「渲染成了什么地址」

    这两件事分开，是因为它们的答案会分叉：上了远程映射之后渲染地址是
    `https://mmbiz.qpic.cn/…`，而源图仍然好端端躺在 `30-assets/` 下。

    合成一个查过一次，代价是个真漏洞：门禁拿 `consumption.assets[].src`
    去定位源文件，遇到 URL 就返回 `None`，调用方随即跳过哈希核验——
    **于是只要上了映射，「源图有没有被换过」就再也没人查**。
    实测：双方都用远程映射、编译验收完成后只替换 `30-assets/visual-001.png`，
    HTML、记录、映射一概不动，照样进 `package_validated`。
    上传回执证明的是「当时传的是哪一份」，它对「现在磁盘上那份还是不是那一份」
    一个字都没说。

    ## 优先读编译输入记录

    `inputs.assets` 是编译时算出来的源图位置，**跟传没传、传到哪无关**。
    存量记录没有这一段，退回按渲染地址找——那对本地引用仍然准确，
    对远程引用则返回 `None`（**它本来就定位不到源图**，
    该由 `STAGE_INPUT_UNTRACEABLE` 那条去说记录不可追溯，不是在这里假装查过）。

    两处都**不猜文件名**。早先按 `30-assets/<id>.*` 排序取第一个非 JSON，
    `.html` < `.jpg` < `.json` < `.png`，同目录留了张同名 HTML 或 JPG，
    门禁就去读那一份再跟 PNG 的哈希比——图一个字节没动，正常交付被拦。
    """
    if not asset_id:
        return None

    declared = (inputs.get("assets") or {}).get(asset_id)
    if declared:
        local = Path(declared)
        if not local.is_absolute():
            local = root / local
        if not local.is_file():
            # **「记录说它在这儿、可它不在」不是「不用查」。**
            # 早先这里返回 `None`，调用方把 `None` 读成「定位不到，跳过」——
            # 于是上了远程映射之后把源图删掉，HTML、记录、映射一概不动，
            # 照样进 `package_validated`。实测漏过。
            # 源图没了意味着这张图再也无法重出、无法复核，
            # 发布阶段要重传时也扑空；这是缺输入，当场说出来。
            raise WorkflowError(
                "STAGE_INPUT_MISSING",
                f"记录说图片 {asset_id} 的源文件在 {declared}，"
                f"但那个文件现在不在，不能进 {stage}。\n"
                "**上了远程映射也一样要有源图**——回执证明的是当时传了什么，"
                "它不能替代源文件：图没了就再也复核不了、重出不了。\n"
                "把源图找回来，或回 `illustrate-article` 重新产出后重新编译。",
                stage=stage, path=declared, asset=asset_id)
        return local

    for entry in consumption.get("assets") or ():
        if str(entry.get("id") or "") != asset_id:
            continue
        src = str(entry.get("src") or "")
        if not src or re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", src):
            return None
        local = Path(src) if Path(src).is_absolute() else artifact.parent / src
        # 本地引用而文件不在：**这里返回 `None` 是安全的，
        # 因为 `_verify_local_file` 会就同一件事报 `LOCAL_ASSET_MISSING`**。
        # 上面那条声明路径没有这样的兜底，所以必须自己抛。
        return local if local.is_file() else None
    return None


def _check_consumption(root: Path, stage: str) -> None:
    """第二层：每份产物与**它自己的 HTML** 对不对得上。

    第一层（`_check_artifact_records`）比的是「两份产物用的是不是同一套输入」，
    它**比不出**「这一份产物自己有没有过期」——两份可以一起停在旧地址上，
    互相一致、与实际 HTML 却都对不上。

    这里查的三件事，第一层一件都覆盖不到：

    * 记录里的图片地址，是不是真的出现在这份 HTML 里；
    * 每张图的本地文件还在不在、是不是还是验收过的那一份（`local_file` 绑定的
      全部证据就是这个，**记录跟自己比永远相等，必须去磁盘上读**）；
    * 地址与源文件的绑定证据（渠道包不收人工声明）。

    **映射文件的新旧不在这里查。** 那要拿当前映射文件重算，而门禁不知道它在哪；
    那一项由 `compile contract --image-map` 在编译侧查。
    """
    from byclaw_caps.compile._records import read_record
    from byclaw_caps.shared.render_contract import verify_consumption

    for kind, rel in (("channel", "40-package/渠道包.html"),
                      ("preview", "40-package/预览.html")):
        path = root / rel
        record = read_record(path)
        if record is None:
            continue  # 缺记录已由 _check_artifact_records 拦下
        consumption = record.get("consumption")
        if not consumption:
            continue  # 存量记录没有第二层，按兼容处理
        findings = verify_consumption(
            consumption, render_input=record.get("render_input") or {},
            html=path.read_text(encoding="utf-8", errors="replace"),
            # 记录里的映射版本原样带回：这一步不判映射新旧，只判产物自洽。
            current_image_map_sha256=str(consumption.get("image_map_sha256") or ""),
            # 本地图的相对地址相对这份 HTML 算，所以基准是它所在的目录。
            base_dir=path.parent)
        if findings:
            raise WorkflowError(
                "ARTIFACT_CONSUMPTION_MISMATCH",
                f"{path.name} 与它自己的消费记录对不上，不能进 {stage}：\n"
                + "\n".join("  - " + f.message for f in findings[:5])
                + "\n**两份产物一致不等于每一份都对**——"
                "它们可以一起停在旧地址上。\n"
                "重新编译，不要手工改记录。",
                stage=stage, path=path.name, kind=kind,
                findings=[{"code": f.code, "message": f.message}
                          for f in findings[:5]])


def _check_preview_acceptance(root: Path, stage: str) -> None:
    """预览也要有当前的验收章。

    **编译记录证明不了验收。** `artifact.output_sha256` 说的是
    「这份 HTML 与它自己的编译记录一致」——重新编译一次，记录跟着更新，
    这一项照样通过。实测：两份都验收后，只重出预览并换个标题、不重新验收，
    仍能进 `package_validated`。

    此前只有渠道包有这道（`CHANNEL_PACKAGE_CHANGED`），预览没有。
    """
    relative = "40-package/预览.html"
    preview = root / relative
    if not preview.is_file():
        return
    acceptance = (load_state(root).get("acceptance") or {}).get(relative)
    if not acceptance:
        raise WorkflowError(
            "PREVIEW_NOT_ACCEPTED",
            f"预览还没登记验收，不能进 {stage}。\n"
            "跑 `workflow accept --root <会话根> "
            "--file <会话根>/40-package/预览.html --accepted-by <验收人>`。\n"
            "**两份都要验收**——业务是照着预览做判断的。",
            stage=stage, path=relative)
    if sha256_file(preview) != acceptance.get("sha256"):
        raise WorkflowError(
            "PREVIEW_CHANGED",
            f"预览在验收之后被改过（或重新编译过），不能进 {stage}。\n"
            "**编译记录一致 ≠ 已验收**：重出一次，记录跟着更新，"
            "而那枚验收章盖的还是上一份字节。\n"
            "重新 accept，不要手工凑哈希。",
            stage=stage, path=relative)


def transition(root: Path | str, *, next_stage: str, expected_revision: int,
               expected_sha256: str, employee: str, skill: str,
               patch: dict[str, Any] | None = None) -> dict[str, Any]:
    _require_stage(next_stage)
    path = state_path(root)
    state = load_state(root)
    actual_sha = state.pop("_sha256")
    if int(state.get("state_revision") or 0) != int(expected_revision) or \
            actual_sha != str(expected_sha256).lower():
        # 两个数字员工共用会话：后手不能覆盖前手已经写下的状态。
        raise WorkflowError(
            "STALE_WORKFLOW_STATE", "工作流状态已经变化，拒绝覆盖",
            expected_revision=expected_revision, actual_revision=state.get("state_revision"),
            expected_sha256=str(expected_sha256).lower(), actual_sha256=actual_sha)
    current = str(state["current_stage"])
    if next_stage not in TRANSITIONS[current]:
        # 回退边单独指路。只报「不允许」而不说往哪走，agent 只会再试一遍别的阶段名。
        if next_stage in ROLLBACK_TRANSITIONS.get(current, frozenset()):
            raise WorkflowError(
                "INVALID_TRANSITION",
                f"{current} → {next_stage} 是回退，transition 不做回退——"
                "它不会清作废的验收哈希与下游产物。改用 "
                f"`workflow rollback --to {next_stage} --reason <为什么>`。",
                current_stage=current, use_instead="rollback")
        # 跳过阶段通常意味着上游没做完，不是想抄近路。
        raise WorkflowError("INVALID_TRANSITION", f"不允许从 {current} 迁移到 {next_stage}",
                            current_stage=current, allowed=sorted(TRANSITIONS[current]))
    # 产物门禁放在状态落盘**之前**：迁移成功了才发现渠道包不在，
    # 状态已经写出去，下一棒只能靠回退收拾。
    _check_entry_preconditions(Path(root), next_stage)
    for key in patch or {}:
        if key in PROTECTED_FIELDS:
            raise WorkflowError("PROTECTED_STATE_FIELD", f"patch 不得修改受保护字段：{key}")
    state.update(patch or {})
    state["state_revision"] = int(expected_revision) + 1
    state["previous_state_sha256"] = actual_sha
    state["updated_at"] = _now()
    state["updated_by"] = {"employee": employee, "skill": skill}
    # 回执要报「这一棒从哪来」。只看 current_stage 说不出来路。
    state["previous_stage"] = current
    state["current_stage"] = next_stage
    state["status"] = _STATUS_FOR_STAGE.get(next_stage, _IN_PROGRESS)
    _atomic_write(path, state)
    return {"ok": True, "status": "transitioned", "workflow_id": state["workflow_id"],
            "previous_stage": current, "current_stage": next_stage,
            "state_revision": state["state_revision"], "state_sha256": sha256_file(path)}


#: 工作区前缀。与 `byclaw_caps.cloud.WORKSPACE_MARKER` 同一个约定——
#: 这里只用来把报错说得更准，认不出也只是少一句提示，不影响拦截。
WORKSPACE_MARKER = "/.openclaw/workspace-baiying-agent-"


def _relative(root: Path | str, target: Path | str) -> str:
    root_path, file_path = Path(root).resolve(), Path(target).resolve()
    try:
        # 绝对路径含会话 ID，换机器或换会话就对不上。
        return file_path.relative_to(root_path).as_posix()
    except ValueError:
        # 报错要说清**该写哪儿**，不只是「不许」。
        # 这条替代的是散在 15 个文件里那句手抄的「禁止写工作区」——
        # 抄 15 遍不会让人更遵守，只会让改的时候漏掉几遍。
        hint = ""
        if WORKSPACE_MARKER in file_path.as_posix():
            hint = ("这是**工作区**（Skill 代码的所在地）。"
                    "写进去会随工作区回收而丢失，也无法在助理之间交接——"
                    "而且写的当时不报错，下一棒读不到时才发现。")
        raise WorkflowError(
            "OUTSIDE_SESSION",
            f"产物不在会话根之下：{file_path}。{hint}"
            f"产物一律写会话根 {root_path}；"
            "路径用 `python3 -m byclaw_caps.workflow paths --stage <阶段>` 查，"
            "**不要自己拼**。",
            path=str(file_path), session_root=str(root_path)) from None


#: 哪个阶段拥有哪些产物目录。**验收章只能在拥有它的阶段盖。**
#:
#: 2026-08-28 排版实测：排版阶段发现正文哈希与验收记录不符，
#: 于是**自己给正文重新盖了章**，然后在给用户的摘要里写「正文一字未改，
#: 哈希链校验通过」。它只知道哈希对不上，不知道正文被改成了什么。
#:
#: `verify_acceptance` 的注释写着「自动重算等于取消这道门禁」——
#: 手动重算的效果一模一样。
STAGE_ARTIFACTS: dict[str, tuple[str, ...]] = {
    # 选题产物原本不在表里，于是**跨阶段验收管不到 content-brief.yaml**——
    # 而它一写四读（3/4/5/11 号），是全流程唯一必经的那一棒。
    "topic_pending": ("10-topic/",),
    "creative_pending": ("20-creative/",),
    # 配图作业时阶段还是 creative_validated，所以它同时拥有 30-assets/：
    # 替换配图占位改了正文、需要重新验收，走的正是这一格。
    "creative_validated": ("20-creative/", "30-assets/", "35-media/"),
    "asset_validated": ("30-assets/", "35-media/"),
    "package_pending": ("40-package/",),
    "package_validated": ("40-package/",),
    "draft_created": ("40-package/", "50-publish/"),
    "publish_submitted": ("50-publish/",),
    "published": ("50-publish/",),
    # 视频线的终点。**不与 published 共用目录**——那样两种完成状态
    # 在产物归属上也分不开了。
    "delivered": ("35-media/",),
}

#: 每个阶段的产物文件名。**只列跨助理要读的那几个**——
#: 助理自己读自己写的（各阶段 `.meta/` 里的中间件）不在这里，
#: 那是弱契约，写它的人自己改自己的，列进来只会变成又一处要同步的手抄。
STAGE_FILES: dict[str, tuple[str, ...]] = {
    "topic_pending": ("选题决策.md", "content-brief.yaml",
                      "topic-decision-result.yaml"),
    "creative_pending": ("正文.md", "文章大纲.md"),
    "creative_validated": ("正文.md", "文章大纲.md"),
    # 排版产两份，各写各的：渠道包是正文**片段**（投递用的就是它），
    # 预览是完整文档（业务打开看效果）。两份都进表是因为**它们都要被检查**——
    # 见 `ENTRY_REQUIRED_FILES`：进 package_validated 时缺哪份都不放行。
    "package_pending": ("渠道包.html", "预览.html"),
    "package_validated": ("渠道包.html", "预览.html"),
    "delivered": ("成片.mp4",),
}

#: 进入某个阶段**之前**必须在位的文件（相对会话根）。
#:
#: **这张表以前不承重。** `STAGE_FILES` 只被 `stage_paths()` 读一次用于回显，
#: `validate_stage` 只比对阶段字符串，`transition` 连产物看都不看——于是
#: **渠道包目录不存在、验收记录为空，照样能进并通过 `package_validated` 校验**。
#: 「不到 package_validated 就不投」证明的只是有人调用过 transition。
#:
#: 现在它真的拦。文件不在就进不去这一格。
ENTRY_REQUIRED_FILES: dict[str, tuple[str, ...]] = {
    "package_validated": ("40-package/渠道包.html", "40-package/预览.html"),
}


def stage_paths(stage: str) -> dict:
    """这个阶段的产物写到哪。**全仓唯一的读法。**

    改之前每个 Skill 与工作规范各抄一份（60 多处），改一处漏几处是必然的。
    `STAGE_ARTIFACTS` 本来就是唯一可执行的定义——它拦跨阶段写入、管验收归属——
    只是没有对外的读法，于是每个人各抄一份。这个函数补的就是那个读法。

    **阶段名写错要报错，不能返回空。** 返回空的话，拼错一个阶段名会静默拿到
    「这个阶段没有产物」，然后把文件写到会话根下——而那正是要防的。
    """
    if stage not in STAGES:
        raise WorkflowError(
            "UNKNOWN_STAGE",
            f"阶段不在封闭集合内：{stage}。**不要自己拼路径**——"
            "拼错的路径写出去不会报错，只是下一个助理读不到。",
            stage=stage, known_stages=sorted(STAGES))
    dirs = list(STAGE_ARTIFACTS.get(stage, ()))
    return {
        "stage": stage,
        "dirs": dirs,
        # 机器契约收进 `.meta/`，人要审阅的直接放。取第一个目录：
        # 一个阶段有多个目录时（如 creative_validated），主目录是第一个。
        "meta": (dirs[0] + ".meta/") if dirs else None,
        "artifacts": list(STAGE_FILES.get(stage, ())),
        "terminal": stage in TERMINAL_STAGES,
    }


#: 受管辖的目录。不在这里面的路径不判归属——**不过度约束**。
_OWNED_PREFIXES: frozenset[str] = frozenset(
    prefix for prefixes in STAGE_ARTIFACTS.values() for prefix in prefixes)

#: 元数据。**任何阶段都可以重新验收**，但要留痕。
#:
#: 内容和元数据的差别不在「谁改的」，在**改的是什么**：
#:
#: - 正文与图片的**唯一**门禁就是那个哈希。绕过它，改动就再没人看得见。
#: - manifest／plan 的内容本来就有 `validate_article*.py` 在管，改错了那边会红。
#:
#: 2026-08-28 发布实测：文章创作助理两次在 `package_validated` 阶段被组长叫回来
#: 补 manifest（定稿标记、压缩摘要），两次都跑了校验器。按目录一刀切会把这条
#: 正常路径也拦死——而代价是为改一个 `summary` 字段 rollback 到 `creative_pending`，
#: 那会作废渠道包**和正文自己的验收**，正文根本没改过。
#:
#: 必须精确到 `.meta/`：写成整个阶段目录的话，正文就跟着漏出去了。
METADATA_PREFIXES: tuple[str, ...] = (
    "20-creative/.meta/", "30-assets/.meta/", "35-media/.meta/",
    "40-package/.meta/", "50-publish/.meta/",
)


def _is_metadata(relative: str) -> bool:
    return any(relative.startswith(prefix) for prefix in METADATA_PREFIXES)


def _check_accept_scope(stage: str, relative: str) -> bool:
    """内容归阶段管，元数据归它的主人管。

    返回是否属于「跨阶段的元数据补正」——调用方据此留痕。
    放行不等于不记账：补正发生在哪一阶段，事后要看得出来，
    否则「元数据可以随时改」就成了一句没有边界的话。

    **内容那一档不留任何开关。** 那道门禁的全部价值就是它不能自助。
    真有内容改动，`rollback` 就是那条路。
    """
    allowed = STAGE_ARTIFACTS.get(stage, ())
    if any(relative.startswith(prefix) for prefix in allowed):
        return False
    if _is_metadata(relative):
        return True
    if not any(relative.startswith(p) for p in _OWNED_PREFIXES):
        return False
    raise WorkflowError(
        "CROSS_STAGE_ACCEPT",
        f"当前阶段 {stage}，不能给 {relative} 盖验收章——那是别的阶段的**内容**产物。\n"
        "它的验收在此之前就失效了，**说明有人改过它**；"
        "在下游把章补上，等于替一份你没验过内容的文件背书。\n"
        f"正路是 workflow rollback --to <改动该被审的阶段>，"
        "让改动回到该被审的地方重新走一遍。\n"
        "（`.meta/` 下的元数据不受此限——那些有校验器在管，可以就地补正。）",
        stage=stage, path=relative,
        owns=sorted(STAGE_ARTIFACTS.get(stage, ())))


def record_acceptance(root: Path | str, target: Path | str, *,
                      accepted_by: str) -> dict[str, Any]:
    file_path = Path(target)
    if not file_path.is_file():
        raise WorkflowError("FILE_NOT_FOUND", f"待验收文件不存在：{file_path}")
    relative = _relative(root, file_path)
    state = load_state(root)
    stage = str(state["current_stage"])
    cross_stage = _check_accept_scope(stage, relative)
    state.pop("_sha256", None)
    entry = {"sha256": sha256_file(file_path), "accepted_at": _now(),
             "accepted_by": accepted_by}
    if cross_stage:
        # 留痕落进状态文件，不只是回执——回执看完就没了，状态文件才是下次能查的地方。
        entry["cross_stage_metadata_fix"] = True
        entry["fixed_at_stage"] = stage
    state["acceptance"][relative] = entry
    state["updated_at"] = _now()
    _atomic_write(state_path(root), state)
    return {"ok": True, "status": "accepted", "path": relative, **entry}


def verify_acceptance(root: Path | str, target: Path | str) -> dict[str, Any]:
    """比对，**从不重算**。

    自动重算等于取消这道门禁——它存在的全部意义就是让改动无法悄悄通过。
    """
    file_path = Path(target)
    relative = _relative(root, file_path)
    recorded = load_state(root)["acceptance"].get(relative)
    if not recorded:
        # 没验收过就返回"没验收过"，不能返回通过。
        return {"ok": False, "status": "NOT_ACCEPTED", "path": relative,
                "hint": "该文件没有验收记录，先完成人工验收再记录哈希。"}
    if not file_path.is_file():
        raise WorkflowError("FILE_NOT_FOUND", f"已验收文件不存在：{file_path}")
    actual = sha256_file(file_path)
    if actual == recorded["sha256"]:
        return {"ok": True, "status": "ok", "path": relative, "sha256": actual}
    return {"ok": False, "status": "ACCEPTANCE_STALE", "path": relative,
            "accepted_sha256": recorded["sha256"], "actual_sha256": actual,
            "accepted_at": recorded["accepted_at"],
            "hint": "文件在验收后被改动，验收已失效，需重新验收。"}


# ── 止损计数与检索预算 ────────────────────────────────────────────────
#
# 两条现有规则都靠「同一个上下文记得试过什么」：「同一错误码连续 2 次即停止」、
# 「每子问题最多 3 轮」。拆成多个助理之后**换了助理就忘了**，
# 于是每人把同一个错误再试两次，每次被叫起都把预算从零开始数。
#
# 检索预算尤其要紧：**它是花真钱的**，重新开始数等于取消上限。


def _save(root: Path | str, state: dict[str, Any]) -> None:
    state.pop("_sha256", None)
    state["updated_at"] = _now()
    _atomic_write(state_path(root), state)


def bump_attempt(root: Path | str, code: str) -> dict[str, Any]:
    """某个错误码又试了一次。计数跟着状态走，不跟着上下文走。"""
    state = load_state(root)
    attempts = dict(state.get("attempts") or {})
    count = int(attempts.get(code) or 0) + 1
    attempts[code] = count
    state["attempts"] = attempts
    _save(root, state)
    return {"ok": True, "status": "recorded", "code": code, "count": count,
            "should_stop": count >= ATTEMPT_LIMIT,
            "hint": (f"{code} 已连续 {count} 次未解决，停下来报告错误码、"
                     "已试动作、一个最小下一动作。") if count >= ATTEMPT_LIMIT else ""}


def clear_attempt(root: Path | str, code: str) -> dict[str, Any]:
    """问题真解决了就清掉。留着的话，下一次同类错误第一下就被判死。"""
    state = load_state(root)
    attempts = dict(state.get("attempts") or {})
    attempts.pop(code, None)
    state["attempts"] = attempts
    _save(root, state)
    return {"ok": True, "status": "cleared", "code": code}


def research_budget(root: Path | str) -> dict[str, Any]:
    """当前检索花销与上限。

    没花过钱的会话也要能读到上限——否则第一次调用无从判断还能花多少。
    """
    state = load_state(root)
    budget = dict(state.get("research_budget") or {})
    budget.setdefault("sub_questions", 0)
    budget.setdefault("rounds", 0)
    budget.setdefault("pages_fetched", 0)
    budget.setdefault("by_assistant", {})
    budget["limit"] = {**DEFAULT_RESEARCH_LIMIT,
                       **(state.get("research_limit") or {})}
    return budget


def spend_research(root: Path | str, *, assistant: str, rounds: int = 0,
                   pages: int = 0, sub_questions: int = 0) -> dict[str, Any]:
    """记一次检索花销，返回是否超预算。

    **一份预算，不是每人一份。** 单点核实与深度调研共用同一份计数——
    分开记的话，只做单点核实的助理可以每次只查 2 轮、查十次，把上限绕过去。
    ``by_assistant`` 只为审计，不各自算上限。

    **超预算不抛异常。** 它不是「用法错了」，是「该换个做法了」；
    抛异常会让助理跑去查命令怎么写，而正确动作是写调研请求交出去。
    """
    state = load_state(root)
    budget = dict(state.get("research_budget") or {})
    for key, delta in (("rounds", rounds), ("pages_fetched", pages),
                       ("sub_questions", sub_questions)):
        budget[key] = int(budget.get(key) or 0) + int(delta)
    per = dict(budget.get("by_assistant") or {})
    mine = dict(per.get(assistant) or {})
    mine["rounds"] = int(mine.get("rounds") or 0) + int(rounds)
    mine["pages"] = int(mine.get("pages") or 0) + int(pages)
    per[assistant] = mine
    budget["by_assistant"] = per
    state["research_budget"] = budget
    _save(root, state)

    limit = {**DEFAULT_RESEARCH_LIMIT, **(state.get("research_limit") or {})}
    exceeded = []
    if budget["pages_fetched"] > limit["max_pages"]:
        exceeded.append("max_pages")
    if assistant in SPOT_CHECK_ASSISTANTS:
        # 给只做单点核实的助理开的小门，门上有更紧的计数器。
        if mine["rounds"] > limit["spot_check_rounds"]:
            exceeded.append("spot_check_rounds")
        if mine["pages"] > limit["spot_check_pages"]:
            exceeded.append("spot_check_pages")
    return {"ok": True, "status": "recorded", "assistant": assistant,
            "budget": {**budget, "limit": limit},
            "over_budget": bool(exceeded), "exceeded": exceeded,
            "hint": ("检索预算已到顶。把剩下的问题写进 "
                     ".runtime/retrieval/research-request-<run_id>.yaml，"
                     "返回 needs_research。") if exceeded else ""}


# ── 交接回执 ──────────────────────────────────────────────────────────
#
# 多智能体拆分的全部收益，来自「助理把产物留在磁盘上，只把路径交出去」。
# **回执一旦带上产物正文，组长的上下文就会和拆分前一样涨。**


def _artifact_entry(root: Path | str, relative: str,
                    state: dict[str, Any]) -> dict[str, Any]:
    target = Path(root) / relative
    if not target.is_file():
        # 静默丢掉等于告诉组长「这一棒没产出」，而其实是路径写错了。
        raise WorkflowError("ARTIFACT_NOT_FOUND", f"回执登记的产物不存在：{relative}")
    recorded = (state.get("acceptance") or {}).get(relative) or {}
    return {
        "id": Path(relative).stem,
        "path": relative,
        # **自己算，不接受申报。** 助理能自己填哈希的话，
        # 「验收与字节状态绑定」就成了摆设——它拦的正是「改了却说没改」。
        "sha256": sha256_file(target),
        "accepted": bool(recorded),
    }


def handoff(root: Path | str, *, status: str = "ok", note: str = "",
            artifacts: list[str] | None = None,
            research_request: str | None = None) -> dict[str, Any]:
    """助理收工时吐给组长的那一份。**只有路径与哈希，没有产物正文。**"""
    if status not in HANDOFF_STATUSES:
        raise WorkflowError("UNKNOWN_HANDOFF_STATUS",
                            f"回执状态不在封闭集合内：{status}",
                            known=sorted(HANDOFF_STATUSES))
    state = load_state(root)
    state.pop("_sha256", None)

    declared = [_relative(root, Path(root) / item) for item in (artifacts or [])]
    # 已验收的文件是这一棒的既成产物，不该还要人再报一次。
    ordered = list(dict.fromkeys([*declared, *(state.get("acceptance") or {})]))
    entries = [_artifact_entry(root, rel, state) for rel in ordered]

    receipt: dict[str, Any] = {
        "ok": status in {"ok", "needs_user"},
        "stage_from": state.get("previous_stage") or None,
        "stage_to": str(state["current_stage"]),
        "status": status,
        "artifacts": entries,
        # 给人看和给机器读是两份名单。`.meta/` 下的机器契约只进 artifacts：
        # 把 ArticleManifest 摆给业务人员看，他打不开也不该打开。
        "user_visible": [{"label": Path(e["path"]).stem, "path": e["path"]}
                         for e in entries if "/.meta/" not in e["path"]],
        # 截 summary，**不截 artifacts**——路径丢了下一棒就找不到东西。
        "summary": str(note or "")[:SUMMARY_LIMIT],
        "attempts": dict(state.get("attempts") or {}),
        "state_revision": state["state_revision"],
    }
    if status == "needs_research":
        if not research_request:
            # 报「要调研」却不说查什么，组长转交不出去，只能回来再问一轮。
            raise WorkflowError(
                "MISSING_RESEARCH_REQUEST",
                "status=needs_research 必须给出 research_request 路径——"
                "组长只搬路径，回执里没有它就无从转交。")
        relative = _relative(root, Path(root) / research_request)
        if not (Path(root) / relative).is_file():
            raise WorkflowError("ARTIFACT_NOT_FOUND", f"调研请求文件不存在：{relative}")
        receipt["research_request"] = relative
    return receipt


# ── 回退与改稿 ────────────────────────────────────────────────────────


def _residue(root: Path | str) -> tuple[list[dict[str, Any]], list[str]]:
    """扫外部残留：已经建到公众号后台、系统删不掉的东西。

    坏 JSON 只登记告警**不中断回退**——回退是救火动作，
    它因为一个坏文件就失败，人就彻底卡住了。
    """
    import json

    found: list[dict[str, Any]] = []
    warnings: list[str] = []
    for pattern in RESIDUE_GLOBS:
        for path in sorted(Path(root).glob(pattern)):
            relative = path.relative_to(Path(root)).as_posix()
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception as exc:
                warnings.append(f"{relative} 读不出来（{type(exc).__name__}），"
                                "外部残留未能确认，请人工到后台核对")
                continue
            for blob in (data if isinstance(data, list) else [data]):
                if not isinstance(blob, dict):
                    continue
                media_id = blob.get("media_id") or blob.get("publish_id")
                if not media_id:
                    continue
                found.append({
                    "kind": "wechat_draft" if blob.get("media_id") else "wechat_publish",
                    "media_id": str(media_id),
                    "account": str(blob.get("account") or ""),
                    "source": relative,
                    "action_required": "请到公众号后台手动删除这份草稿",
                    "why": "系统没有删除草稿的能力；不删的话后台会有两份，容易发错版本",
                })
    return found, warnings


def rollback(root: Path | str, *, to: str, reason: str, expected_revision: int,
             expected_sha256: str, employee: str, skill: str) -> dict[str, Any]:
    """回到某个更早的阶段，并清掉因此作废的东西。

    **做成一个原子动作，不是让助理自己拼三条命令。** 拼的话迟早出现
    「状态迁了但哈希没清」这种一半的回退，下游拿着失效的验收往下走。
    """
    _require_stage(to)
    if not str(reason or "").strip():
        # 没有理由的回退，事后没人说得清那次改稿是为什么。
        raise WorkflowError("MISSING_ROLLBACK_REASON", "回退必须写明理由")

    path = state_path(root)
    state = load_state(root)
    actual_sha = state.pop("_sha256")
    if int(state.get("state_revision") or 0) != int(expected_revision) or \
            actual_sha != str(expected_sha256).lower():
        raise WorkflowError(
            "STALE_WORKFLOW_STATE", "工作流状态已经变化，拒绝覆盖",
            expected_revision=expected_revision,
            actual_revision=state.get("state_revision"),
            expected_sha256=str(expected_sha256).lower(), actual_sha256=actual_sha)

    current = str(state["current_stage"])
    if to not in ROLLBACK_TRANSITIONS.get(current, frozenset()):
        raise WorkflowError(
            "INVALID_ROLLBACK", f"不允许从 {current} 回退到 {to}",
            current_stage=current,
            allowed=sorted(ROLLBACK_TRANSITIONS.get(current, frozenset())),
            hint=("published / failed / cancelled 是终态：文章已经发出去了，"
                  "改本地状态没有意义——要改就是新一篇，走完整流程。")
            if current in TERMINAL_STAGES else "")

    residue, warnings = _residue(root)

    acceptance = dict(state.get("acceptance") or {})
    prefixes = INVALIDATED_BY_ROLLBACK.get(to, ())
    invalidated = [rel for rel in acceptance if rel.startswith(prefixes)]
    for rel in invalidated:
        acceptance.pop(rel)
    state["acceptance"] = acceptance

    review = [rel for rel in acceptance
              if rel.startswith(REVIEW_AFTER_ROLLBACK.get(to, ()))]

    state["state_revision"] = int(expected_revision) + 1
    state["previous_state_sha256"] = actual_sha
    state["updated_at"] = _now()
    state["updated_by"] = {"employee": employee, "skill": skill}
    state["previous_stage"] = current
    state["current_stage"] = to
    state["status"] = _STATUS_FOR_STAGE.get(to, _IN_PROGRESS)
    state["rollbacks"] = int(state.get("rollbacks") or 0) + 1
    state["last_rollback"] = {"at": _now(), "from": current, "to": to,
                              "reason": str(reason).strip()}
    _atomic_write(path, state)

    return {
        "ok": True, "status": "rolled_back", "workflow_id": state["workflow_id"],
        "previous_stage": current, "current_stage": to,
        "state_revision": state["state_revision"], "state_sha256": sha256_file(path),
        "invalidated": sorted(invalidated),
        # 不清，但也不能一声不吭——正文改了，配图的位置与说明可能就不对了。
        "review_recommended": sorted(review),
        "external_residue": residue,
        "warnings": warnings,
    }
