> 由 `content-workflow-runtime/references/state-transition-table.md` 迁入。**注意：修订分配、不可变提交、快照恢复已随该 Skill 一并废除**，本文件只保留仍然生效的阶段状态机部分；权威定义在 `TRANSITIONS`。

# 状态迁移表

`current_stage` 只允许以下迁移：

| 当前阶段 | 允许的下一阶段 |
|---|---|
| `topic_pending` | `creative_pending`、`blocked`、`cancelled` |
| `creative_pending` | `creative_validated`、`blocked`、`cancelled` |
| `creative_validated` | `asset_validated`、`package_pending`、`blocked`、`cancelled` |
| `asset_validated` | `package_pending`、`blocked`、`cancelled` |
| `package_pending` | `package_validated`、`partially_packaged`、`blocked`、`cancelled` |
| `partially_packaged` | `package_pending`、`package_validated`、`partially_published`、`failed`、`cancelled` |
| `package_validated` | `draft_created`、`blocked`、`cancelled` |
| `draft_created` | `package_pending`、`publish_submitted`、`published`、`failed`、`cancelled` |
| `publish_submitted` | `published`、`partially_published`、`failed` |
| `partially_published` | `publish_submitted`、`published`、`failed` |
| `blocked` | `topic_pending`、`creative_pending`、`creative_validated`、`asset_validated`、`package_pending`、`package_validated`、`draft_created`、`publish_submitted`、`failed`、`cancelled` |
| `published` | 无 |
| `failed` | 无 |
| `cancelled` | 无 |

阶段为 `blocked` 时工作流 `status=blocked`；`failed` 对应 `failed`；`cancelled` 对应 `cancelled`；`published` 对应 `completed`；其他阶段对应 `in_progress`。状态迁移脚本按该映射计算总状态，不接受调用方伪造不一致状态。
