---
name: workflow-state
description: 当需要确认当前处在哪个阶段、迁移到下一阶段、或校验文件自验收后有没有被改动时使用。阶段是封闭集合，不做模糊匹配——把 creative 当成 creative_pending 会让校验失去意义。迁移带乐观并发保护：两个数字员工共用一个会话，后手不能覆盖前手已写的状态。验收哈希只比对、从不自动重算，自动重算等于取消这道门禁。不含修订分配、不可变提交与快照恢复，那套机制已随修订目录一起废除。
---

# 工作流状态

## 调用

```bash
# 初始化（一个会话一次）
python3 -m byclaw_caps.workflow init --root <会话根> --employee 全媒体内容创作官 --skill write-article

# 读当前状态；迁移所需的 revision 与 sha256 都在这里
python3 -m byclaw_caps.workflow show --root <会话根>

# 确认位置——不靠回忆上下文
python3 -m byclaw_caps.workflow validate --root <会话根> --expected-stage creative_pending

# 迁移到下一阶段
python3 -m byclaw_caps.workflow transition --root <会话根> --next-stage creative_validated \
    --expected-revision 3 --expected-sha256 <来自 show> \
    --employee 全媒体内容创作官 --skill write-article

# 验收哈希
python3 -m byclaw_caps.workflow accept --root <会话根> --file 20-creative/正文.md --accepted-by 人工验收
python3 -m byclaw_caps.workflow verify --root <会话根> --file 20-creative/正文.md

# 列出封闭阶段集合与允许的迁移
python3 -m byclaw_caps.workflow stages
```

退出码：`0` 通过，`1` 业务失败（阶段不符、验收失效），`2` 用法错误（阶段名不在集合内、状态文件不存在）。

**阶段不符是业务失败不是错误**——调用方要据此换动作，不是当成崩溃处理。

## 状态文件的位置

`.runtime/workflow-state.yaml`。它是机器专用内容，按目录设计不占阶段目录。

## 阶段是封闭集合

`topic_pending` → `creative_pending` → `creative_validated` → `asset_validated` →
`package_pending` → `package_validated` → `draft_created` → `publish_submitted` → `published`

外加 `blocked`、`failed`、`cancelled`。`published` / `failed` / `cancelled` 是终态，没有出边。

**不做模糊匹配。** 传 `creative` 会报用法错误，不会被当成 `creative_pending`——猜错阶段
的校验比不校验更糟，它会给出一个看起来通过了的结论。

`draft_created` 可以退回 `package_pending`：公众号草稿可覆盖，排版返工是常态。

## 迁移必须带 revision 与 sha256

**这是防两个数字员工互相覆盖的唯一机制。** 创作官写完状态、发布专员接手，中间任何一方
读到过期状态再写回去，前一方的进度就没了。

先 `show` 拿到 `state_revision` 与 `state_sha256`，迁移时原样传回。任一不符则报
`STALE_WORKFLOW_STATE` 并拒绝写入——**此时应重新 `show` 再决定，不是重试**。

两个都要比：只比版本号，有人手改了状态文件却没动版本号就会被放行。

## 验收哈希：只比对，从不重算

`accept` 记录文件的 sha256；`verify` 比对当前内容。

- 未改动 → 通过
- 改动一个字符 → 失败，报「验收已失效，需重新验收」
- 从未验收过 → 返回 `NOT_ACCEPTED`，**不是通过**

**没有"自动重算哈希"这个选项，也不要用 `accept` 去绕过一次失败的 `verify`。**
自动重算等于取消这道门禁——它存在的全部意义就是让改动无法悄悄通过。文件真的该改，
就重新走人工验收再 `accept`。

记录用会话内相对路径。绝对路径含会话 ID，换机器或换会话就对不上。

## 不含什么

修订分配、不可变提交、快照恢复、阅读索引、旧文章导入——**全部不提供**。

这些是 `content-workflow-runtime` 的主体（14 个脚本 3256 行），核心是把产物写进
`<content_id>/rNNNN/` 再提交。会话目录的阶段目录是平的，`rNNNN` 那一层不存在，整套
失去对象。

代价说清楚：**会话内无法回退到文章的早先修订。** 一次会话即一件作品，会话内版本史
价值本就低；项目空间那侧有 git。

失败时不要试图找恢复路径——本能力的失败只有两种修法：重新 `show` 后再迁移，或重新验收。
