"""项目云盘适配层。

**全仓只有这个模块知道云盘 CLI 长什么样。**

云盘不是本包的能力，是平台底层能力 `project-cloud-knowledge`。它在 2026-09-01
被整个重写（Node → Python、命令改名、返回结构改了、新增检索），而我们那时有
**三处各自写死了旧契约**：`query` 的驱动、`writing-support` 的自检脚本、
归档脚本。三处一起失效，**而且是运行时才发现**——自检报「8 个目录全不存在」、
取材报「目录已不存在」，两者都是误报。

所以这一层的职责只有两件：

1. **定位并调起** CLI，把单行 JSON 拿回来
2. **归一形状**，让调用方拿到 `{"dirs": [...], "files": [...]}` 这类稳定结构，
   永远不碰对方的原始字段名

映射解析、去重、落盘复用、`MAPPING_STALE` 的分辨都**不在这里**——那些是 `query`
的活，换 CLI 时它们一行都不该动。

## 为什么归一这么要紧

旧适配层读的是 `payload["files"]` 与 `payload["directories"]`，而真实返回是
**一个扁平的 `items`，靠 `type` 区分**。两个键都恒为空，于是：

    取不到文件 → 乐观验证去 list 父目录（同样恒空）
                → 判定「父目录里没有这个子目录」→ 报 MAPPING_STALE

助理照着这条错误去改映射，而映射本来是对的。**云盘线从上线起就没通过，
测试却全绿**——因为假夹具是照我们的假设写的，跟真的用同一套错误字段名。

配套的 `tests/test_cloud_contract.py` 因此分两层：跑真实 CLI 的 `--help` 钉住命令名，
以及**从对方的测试文件抄来的**返回样例。
"""

from __future__ import annotations

import glob as _glob
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

#: 脚本在 skills 根下的相对位置。云盘 Skill 自己的目录结构，不是我们能改的。
CLI_RELATIVE = "project-cloud-knowledge/scripts/project_cloud_knowledge.py"

#: **平台的规范部署位置。** `bycli`、`bydc-object-action-runtime` 这些 Skill 的
#: 文档里一直写的是 `/app/skills/...`——只有我们这一侧没跟上，于是上线报
#: `CLOUD_CLI_NOT_FOUND`「本工作区没有部署云盘能力」，**而它部署得好好的**。
#: 这个错读起来像「平台少装了东西」，人会去找平台方要部署，而要不到。
APP_SKILLS_ROOT = "/app/skills"

#: 不改代码就能指路的口子。搬家没搬完、或本地开发时用。
SKILLS_ROOT_ENV = "BYCLAW_SKILLS_ROOT"

#: 工作区前缀，与 `space.WORKSPACE_MARKER` 同源。
WORKSPACE_MARKER = "/by/.openclaw/workspace-"

#: 旧约定，作回落。**工作区下那约五十份多半是旧的 Node 副本**，
#: 所以它必须排在规范位置之后——反过来的话，谁的工作区里碰巧留了一份旧的
#: 就会拿旧的去跑，而新旧两版连命令名都不一样。
DEFAULT_GLOB = WORKSPACE_MARKER + "*/skills/" + CLI_RELATIVE


#: 从路径里认出「这是哪个 agent 的工作区」。
_WORKSPACE_DIR = re.compile(r"(workspace-baiying-agent-\d+)")

DEFAULT_TIMEOUT_SECONDS = 180

#: `list` 里 `type` 的取值。**这些是词表，不是唯一写法。**
#: 云盘 CLI 只把后端的 `type` 原样透传，后端到底写哪个词——文档里没有，
#: 对方测试里也没有（它们只断言请求路径，不断言返回结构）。
#: 认不出时**不再静默丢弃**：曾经因为猜成 `"dir"` 而把每一个目录都丢掉，
#: 然后报「8 个目录全不存在」，而目录一个不缺。
DIR_TYPES = frozenset({"dir", "directory", "folder", "catalog"})
FILE_TYPES = frozenset({"file", "doc", "document"})

#: 兼容旧引用。
TYPE_DIR = "dir"
TYPE_FILE = "file"

Runner = Callable[..., "tuple[int, str, str]"]


class CloudError(RuntimeError):
    """调不动云盘，或云盘明确拒绝。

    带 `code` 是为了让上层分得开「够不着」与「没数据」。**只留一句人话会把两者
    压成同一种结果**，而它们的处置相反：一个去修部署，一个去补素材。
    """

    def __init__(self, message: str, *, code: str) -> None:
        super().__init__(message)
        self.code = code


# ── 定位 ──────────────────────────────────────────────────────────────────

def locate_cli(explicit: str | Path | None = None, *,
               relative: str = CLI_RELATIVE,
               app_root: str = APP_SKILLS_ROOT,
               glob_pattern: str | None = None, cwd=None) -> Path:
    """按顺序找：显式 → 环境变量 → 平台规范位置 → 工作区（旧约定）。

    `relative` 是**要找哪个 Skill 的脚本**（skills 根下的相对路径）。这个函数也被
    用来找 `project-context`，写死成云盘那条的话，找 project-context 会在
    `/app/skills` 命中云盘 CLI，然后拿它当 project-context 跑——参数对不上，
    报的错与「project-context」三个字毫无关系。

    `glob_pattern` 不传就按 `relative` 推出来。**两处各写一份的话，改一处漏一处**，
    而漏掉的那处会去另一个 Skill 的目录里找。

    **规范位置必须排在工作区之前。** 工作区下那约五十份多半是重写之前的 Node 副本，
    先看工作区的话，谁那里碰巧留了一份旧的就会拿旧的去跑。

    工作区那条保留是因为老环境还没搬完；多命中时**先看自己的工作区**——
    实测里每个 agent 都看得见所有工作区，不这么挑的话「命中多个就报错」永远触发，
    自动查找形同虚设。认不出自己是谁时**仍然不猜**，照旧报歧义。
    """
    if explicit:
        target = Path(str(explicit))
        if not target.is_file():
            raise CloudError(
                f"指定的云盘 CLI 不存在：{target}。"
                "路径写错时不回落到自动查找——回落会连到另一份上，"
                "而结果看起来完全正常。",
                code="CLOUD_CLI_NOT_FOUND")
        return target

    if glob_pattern is None:
        glob_pattern = WORKSPACE_MARKER + "*/skills/" + relative

    override = os.environ.get(SKILLS_ROOT_ENV, "").strip()
    for root in ([override] if override else []) + [app_root]:
        candidate = Path(root) / relative
        if candidate.is_file():
            return candidate

    matches = sorted(_glob.glob(glob_pattern))
    if not matches:
        searched = "、".join(
            ([f"${SKILLS_ROOT_ENV}={override}"] if override else [])
            + [f"{app_root}/{relative}", glob_pattern])
        name = relative.split("/")[0]
        raise CloudError(
            f"找不到 {name} 的脚本。找过这几处：{searched}。"
            f"它是平台底层能力 {name}。"
            f"**多半不是没部署**：平台的规范位置是 {app_root}，"
            f"装在别处时设环境变量 {SKILLS_ROOT_ENV}=<skills 根>，"
            "或显式传 --cloud-cli <绝对路径>。",
            code="CLOUD_CLI_NOT_FOUND")
    if len(matches) > 1:
        own = _WORKSPACE_DIR.search(
            str(cwd if cwd is not None else Path.cwd()).replace("\\", "/"))
        if own:
            mine = [m for m in matches
                    if own.group(1) in m.replace("\\", "/").split("/")]
            if len(mine) == 1:
                return Path(mine[0])
        raise CloudError(
            f"同时看到多个 {relative.split('/')[0]} 脚本：" + "、".join(matches) +
            "。不取第一个——它们版本可能不同，取错会跑在一个命令名都对不上的旧版上。"
            f"请设 {SKILLS_ROOT_ENV}，或显式传 --cloud-cli <绝对路径>。",
            code="CLOUD_CLI_AMBIGUOUS")
    return Path(matches[0])



# ── 调起 ──────────────────────────────────────────────────────────────────

def _default_runner(argv: Sequence[str], timeout: int | None = None) -> tuple:
    """**按字节收，按 UTF-8 解。**

    `universal_newlines=True` 用的是系统 locale 编码。云盘的路径全是中文，
    在 GBK 之类的非 UTF-8 环境里直接 `UnicodeDecodeError`——而它抛在
    subprocess 的读取线程里，错误信息与「云盘」毫无关系，查起来毫无线索。
    """
    done = subprocess.run(list(argv), stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, timeout=timeout)
    return (done.returncode,
            (done.stdout or b"").decode("utf-8", errors="replace"),
            (done.stderr or b"").decode("utf-8", errors="replace"))


def run(argv: Sequence[str], *, cli: str | Path, resource_id: str,
        session_id: str = "", runner: Runner | None = None,
        timeout: int = DEFAULT_TIMEOUT_SECONDS) -> dict:
    """调一次云盘 CLI，返回它那一行 JSON（已过错误检查）。

    `--resource-id` 由本函数统一追加：**它是每条命令都要的，交给调用方逐处拼
    早晚会漏一处**，而漏了之后云盘报的是参数错误，与业务失败混在一起。
    """
    identifier = str(resource_id or "").strip()
    if not identifier:
        # **只说「别猜」是不够的。** 上一版就是这么写的，结果调用方读完只知道
        # 不该做什么，不知道该去哪拿，于是停下来报「拿不到云盘 ID」——而它
        # 一直拿得到。差的就是下面这行命令。
        raise CloudError(
            "缺少项目云盘 resourceId（项目上下文的 cloudResourceId / cloud_resource_id）。\n"
            "**去这里取**：`node /app/skills/project-context/scripts/project-context.mjs "
            "basic --project-id <project_id>`，读返回里的 `cloudResourceId`。\n"
            "**不要猜 ID，也不要用普通知识库或本体库的 resourceId 冒充**——"
            "项目上下文的 `project_resources` 常常全是 `resourceType=ontology`，"
            "里面没有一个是项目云盘；拿它去查**不报错，只会静默查空**。",
            code="CLOUD_DISK_RESOURCE_ID_MISSING")

    command = [sys.executable, str(cli), *[str(a) for a in argv],
               "--resource-id", identifier]
    # 变更类命令传了会话 ID 才会向会话空间发文件变更通知；读取类命令不收这个参数。
    if session_id:
        command += ["--session-id", str(session_id)]

    call = runner or _default_runner
    try:
        code, stdout, stderr = call(command, timeout=timeout)
    except FileNotFoundError as exc:
        raise CloudError("找不到 python3。云盘 CLI 是 Python 脚本，缺运行时不是缺数据。",
                         code="PYTHON_MISSING") from exc
    except subprocess.TimeoutExpired as exc:
        raise CloudError(f"云盘 CLI 超时（{timeout}s）。",
                         code="CLOUD_DISK_BACKEND_TIMEOUT") from exc

    payload = _parse(stdout, code=code, stderr=stderr)
    raise_for_error(payload, exit_code=code, stderr=stderr)
    return payload


def _json_candidates(text: str):
    """按「最可能是那一份 JSON」的顺序给出候选切片。"""
    yield text
    brace = text.find("{")
    if brace > 0:
        yield text[brace:]
    yield text.splitlines()[-1]          # 旧的单行格式，留着兼容


def _parse(stdout: str, *, code: int, stderr: str) -> dict:
    """输出是单行 JSON。解析不了就报出来，**不要当成空结果**。

    当成空结果的话，`list` 返回 0 条与「这个目录真的是空的」无法区分，
    而后者会让调用方去补素材——补完还是 0 条。
    """
    text = (stdout or "").strip()
    if not text:
        raise CloudError(
            f"云盘 CLI 没有输出（退出码 {code}）：{(stderr or '').strip() or '无 stderr'}",
            code="CLOUD_RESPONSE_INVALID")

    # **输出是多行的**：真脚本用 `json.dumps(..., indent=2)`。取最后一行那个写法
    # 来自旧的 Node 版（单行 JSON），重写后没人重新对过——在多行上只会拿到一个
    # `}`，于是每一次调用都报「响应无效」。
    #
    # 先整体试，再从第一个 `{` 起试，把底层库偶尔打的 warning 跳过去。
    # **两次都不成就报出来，不吞。** 吞掉之后「没输出」与「目录是空的」分不开，
    # 而后者会让人去补素材——补完还是空。
    payload = None
    for candidate in _json_candidates(text):
        try:
            payload = json.loads(candidate)
        except ValueError:
            continue
        break
    if payload is None:
        raise CloudError(f"云盘 CLI 的输出不是 JSON（退出码 {code}）：{text[:200]}",
                         code="CLOUD_RESPONSE_INVALID")
    if not isinstance(payload, Mapping):
        raise CloudError(f"云盘 CLI 的输出不是对象：{text[:200]}",
                         code="CLOUD_RESPONSE_INVALID")
    return dict(payload)


def raise_for_error(payload: Mapping, *, exit_code: int = 0, stderr: str = "") -> None:
    """`{"ok": false, "error": "..."}` 时抛出，把对方的错误原样带上。"""
    if payload.get("ok") is False or exit_code not in (0, None):
        message = str(payload.get("error") or payload.get("message")
                      or stderr or "云盘命令失败")
        head = message.split(":", 1)[0].strip()
        code = head if head.startswith("CLOUD_") else "CLOUD_DISK_BACKEND_REJECTED"
        raise CloudError(message, code=code)


# ── 归一 ──────────────────────────────────────────────────────────────────

def normalise_list(payload: Mapping) -> dict:
    """`list` 的返回 → `{"dirs", "files", "names", "unknown"}`。

    真实返回是**一个扁平的 `items`**：

        {"items": [{"name": "人事", "type": "dir",  "fileName": "/制度/人事"},
                   {"name": "a.md", "type": "file", "fileName": "/制度/人事/a.md"}]}

    `fileName` **已含远端完整路径**（对方 SKILL.md 明写「不要自行拼接」）。
    但 CLI 用 `_compact` 丢掉空值——后端不给目录填 `fileName` 时那个键**整个不在**，
    所以取不到就回落到 `name`，**不能因此跳过整条**。

    四个口子各有各的用途：

    * `dirs` / `files` —— 要区分目录与文件时用（深度遍历）
    * `names` —— **只问「这层有哪些东西」时用，不碰 `type`**。
      判断「父目录下有没有叫 X 的子项」根本不需要知道它是目录还是文件，
      走 `names` 就与 `type` 的词表彻底无关了。
    * `unknown` —— 认得出名字、认不出类型的。**必须报出来**：
      静默丢弃的话，「有 8 个东西但我不认识」看起来和「一个都没有」一样。
    """
    dirs, files, names, unknown = [], [], [], []
    for item in payload.get("items") or []:
        if not isinstance(item, Mapping):
            continue
        name = str(item.get("name") or "").strip()
        path = str(item.get("fileName") or "").strip() or name
        if not path:
            continue
        if name:
            names.append(name)
        kind = str(item.get("type") or "").strip().lower()
        if kind in DIR_TYPES:
            dirs.append(path)
        elif kind in FILE_TYPES:
            files.append(path)
        else:
            unknown.append({"path": path, "type": item.get("type")})
    return {"dirs": dirs, "files": files, "names": names, "unknown": unknown}



def normalise_search(payload: Mapping) -> list:
    """`search`（切片检索）→ `[{"path", "chunk", "score", "lines"}…]`。"""
    found = []
    for item in payload.get("items") or []:
        if not isinstance(item, Mapping):
            continue
        found.append({
            "path": str(item.get("filePath") or ""),
            "chunk": item.get("chunkText"),
            "chunk_no": item.get("chunkNo"),
            "score": item.get("score"),
            "lines": (item.get("startLine"), item.get("endLine")),
        })
    return found


def normalise_search_files(payload: Mapping) -> list:
    """`search-file`（文件级检索）→ `[{"path", "score"}…]`。"""
    found = []
    for item in payload.get("items") or []:
        if isinstance(item, Mapping) and item.get("filePath"):
            found.append({"path": str(item["filePath"]), "score": item.get("score")})
    return found


def normalise_metadata_search(payload: Mapping) -> dict:
    """`metadata-search` 返回 → `{"total", "page_num", "page_size", "items"}`。

    items 每条：`{"path", "metadata"}`，metadata 是原始 dict（按请求的字段返回）。
    `total` 是后端真实条数，不是本页条数——调用方靠它判断是否要翻页。
    """
    total = int(payload.get("total") or 0)
    page_num = int(payload.get("pageNum") or payload.get("page_num") or 1)
    page_size = int(
        payload.get("pageSize") or payload.get("page_size")
        or len(payload.get("items") or [])
    )
    items = []
    for raw in (payload.get("items") or []):
        if not isinstance(raw, Mapping):
            continue
        path = str(
            raw.get("filePath") or raw.get("file_path") or raw.get("path") or ""
        )
        if not path:
            continue
        meta = raw.get("metadata") or {}
        items.append({"path": path, "metadata": dict(meta) if isinstance(meta, Mapping) else {}})
    return {"total": total, "page_num": page_num, "page_size": page_size, "items": items}


__all__ = [
    "APP_SKILLS_ROOT",
    "SKILLS_ROOT_ENV",
    "CLI_RELATIVE",
    "DEFAULT_GLOB",
    "WORKSPACE_MARKER",
    "DIR_TYPES",
    "FILE_TYPES",
    "TYPE_DIR",
    "TYPE_FILE",
    "CloudError",
    "locate_cli",
    "run",
    "raise_for_error",
    "normalise_list",
    "normalise_search",
    "normalise_search_files",
    "normalise_metadata_search",
]
