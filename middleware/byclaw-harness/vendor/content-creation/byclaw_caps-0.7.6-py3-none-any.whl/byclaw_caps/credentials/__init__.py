"""凭据：明文密钥门禁、引用解析、静态 Secret 扫描。

原 `byclaw_caps/configuration.py` 里通用的那几样搬到了这里。那个模块随
`integrations.yaml` 一起废除——两个 API KEY 拿走之后它只剩一个 `web_search` 开关，
而 searxng 由平台部署、不需要密钥。

**搬过来的不是文件格式，是规矩**：配置里不许出现明文密钥（`reject_plaintext_secrets`），
凭据只能按 `credential_ref → secret_env` 解析（`resolve_credential`）。
这两条与 `integrations.yaml` 无关，去掉那个文件之后仍然要有人守。

按 agentId 的运行时解析在 `credentials/resolve.py`。
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Optional

SENSITIVE_FIELDS = frozenset({
    "api_key", "apikey", "appsecret", "access_token", "password", "secret", "token",
})
REFERENCE_FIELDS = frozenset({"credential_ref", "secret_env"})


class ConfigurationError(ValueError):
    """非密钥配置非法。"""

    def __init__(self, message: str, *, status: str = "CONFIG_INVALID", **detail: Any):
        super().__init__(message)
        self.status = status
        self.detail = detail

    def as_dict(self) -> dict[str, Any]:
        return {"status": self.status, **self.detail}


class CredentialMissing(ConfigurationError):
    """声明了外部能力，但运行沙箱没有可用凭据。"""

    def __init__(self, capability: str, *, provider: str, expected_env: str = "",
                 credential_ref: str = ""):
        expected = f"，期望环境变量 {expected_env}" if expected_env else ""
        super().__init__(
            f"{capability} 缺少 {provider} 凭据{expected}。请在平台密钥管理中配置，"
            "不要在对话、YAML 或命令行中粘贴密钥。",
            status="credential_missing",
            capability=capability,
            provider=provider,
            expected_env=expected_env or None,
            credential_ref=credential_ref or None,
        )


def _reject_secrets(value: Any, *, path: str = "") -> None:
    if isinstance(value, Mapping):
        for raw_key, child in value.items():
            key = str(raw_key)
            location = f"{path}.{key}" if path else key
            if key.lower() in SENSITIVE_FIELDS:
                raise ConfigurationError(
                    f"{location} 是明文敏感字段；项目配置只能保存 credential_ref 或 secret_env。",
                    field=location,
                )
            _reject_secrets(child, path=location)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _reject_secrets(child, path=f"{path}[{index}]")


def reject_plaintext_secrets(value: Any, *, path: str = "") -> None:
    """公开门禁：任何工作区配置或请求对象都不得携带真实 Secret 字段。"""
    _reject_secrets(value, path=path)


SecretResolver = Callable[[str], Optional[str]]


def resolve_credential(capability: str, integration: Mapping[str, Any], *,
                       env: Mapping[str, str] | None = None,
                       secret_resolver: SecretResolver | None = None) -> dict[str, str]:
    """按 ``credential_ref → secret_env`` 解析，不接受明文配置字段。"""
    reject_plaintext_secrets(integration, path=f"integrations.{capability}")
    provider = str(integration.get("provider") or "").strip()
    if not provider:
        raise ConfigurationError(
            f"integrations.{capability}.provider 不能为空", capability=capability)
    credential_ref = str(integration.get("credential_ref") or "").strip()
    secret_env = str(integration.get("secret_env") or "").strip()
    if credential_ref and secret_resolver is not None:
        value = str(secret_resolver(credential_ref) or "").strip()
        if value:
            return {"value": value, "source": "credential_ref", "provider": provider,
                    "credential_ref": credential_ref, "secret_env": secret_env}
    environment = os.environ if env is None else env
    if secret_env:
        value = str(environment.get(secret_env) or "").strip()
        if value:
            return {"value": value, "source": "secret_env", "provider": provider,
                    "credential_ref": credential_ref, "secret_env": secret_env}
    raise CredentialMissing(
        capability, provider=provider, expected_env=secret_env,
        credential_ref=credential_ref)




_ASSIGNMENTS = (
    ("HARDCODED_DEFAULT_API_KEY", re.compile(
        r"\bDEFAULT_API_KEY\s*=\s*['\"][^'\"\r\n]{8,}['\"]", re.I)),
    ("HARDCODED_SECRET", re.compile(
        r"\b(?:APPSECRET|API_KEY|ACCESS_TOKEN|PASSWORD)\b\s*[:=]\s*['\"][^'\"\r\n]{12,}['\"]",
        re.I)),
)
_EXTENSIONS = frozenset({".py", ".js", ".ts", ".json", ".yaml", ".yml", ".md", ".env"})
_SKIP_PARTS = frozenset({".git", ".pytest_cache", ".ruff_cache", "__pycache__", "build"})


def scan_paths(root: str | Path) -> dict[str, Any]:
    """返回疑似硬编码 Secret 的文件和行号，绝不返回命中内容。"""
    base = Path(root).resolve()
    if not base.is_dir():
        raise ConfigurationError(f"扫描根目录不存在：{base}", status="CONFIG_NOT_FOUND")
    findings: list[dict[str, Any]] = []
    for path in sorted(base.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in _EXTENSIONS:
            continue
        if any(part in _SKIP_PARTS for part in path.parts):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for line_number, line in enumerate(text.splitlines(), 1):
            upper = line.upper()
            if any(marker in upper for marker in (
                    "YOUR-API-KEY", "YOUR_API_KEY", "PLACEHOLDER", "EXAMPLE-KEY")):
                continue
            for code, pattern in _ASSIGNMENTS:
                if pattern.search(line):
                    findings.append({
                        "code": code,
                        "path": str(path.relative_to(base)).replace("\\", "/"),
                        "line": line_number,
                    })
    return {"ok": not findings, "root": str(base), "findings": findings,
            "count": len(findings)}


__all__ = [
    "ConfigurationError",
    "CredentialMissing",
    "SENSITIVE_FIELDS",
    "REFERENCE_FIELDS",
    "reject_plaintext_secrets",
    "resolve_credential",
    "scan_paths",
]
