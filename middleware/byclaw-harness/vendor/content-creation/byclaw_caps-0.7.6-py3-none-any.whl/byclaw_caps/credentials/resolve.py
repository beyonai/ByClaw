"""按 agentId 解析生图／配音凭据。

`MINIMAX_API_KEY`、`ARK_API_KEY` 两个环境变量废除。密钥不再由部署方注入进程，
而是运行时按当前 agent 绑定的模型查出来：

    findDetailsById {"resourceId": <agentId>}  → imageModelId / ttsModelId
    getModelDetail  {"id": <modelId>}          → apiEndpoint / apiToken / providerName

三条不能含糊的：

**未绑定模型是正常状态**，报「该 agent 未配置文生图模型」而不是凭据错误——
前者让人去后台绑一个，后者让人去查一个根本不存在的密钥。

**空值有两种表示。** 平台样例里 `imageModelId` 是 `null`、`ttsModelId` 是 `""`。
只判 `None`，空串就会被当成合法 modelId 送进第二个接口。

**认不出的 `providerName` 直接报错，不回落默认客户端。** 回落会用错误的协议打
正确的地址，报出来的是网络错或鉴权错，而根因是选错了客户端——两者的排查方向相反。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Mapping, Optional
from urllib.parse import urlparse

#: 平台接口。第一跳查 agent 绑定了哪些模型，第二跳查那个模型的端点与令牌。
DETAILS_PATH = "/byaiService/digitalEmployeeController/findDetailsById"
MODEL_PATH = "/byaiService/new/model/getModelDetail"

#: 服务发现名。与 `image/format_preview_url.py` 保持一致——同一个后端，
#: 两处写不同的名字，换环境时只会改到一处。
SERVICE_ENV = "BE_DOMAINNAME"
SERVICE_FALLBACK = "ByaiService"

LANGUAGE = "zh-CN"

#: 用途 → agent 详情里的字段名与中文说法。
KINDS: dict[str, tuple[str, str]] = {
    "image": ("imageModelId", "文生图"),
    "tts": ("ttsModelId", "文生语音"),
}

#: 认得的供应商，**按用途分开**。
#:
#: 生图走 VOLCENGINE（火山引擎／方舟，豆包）与 QWEN（通义），配音走
#: MINIMAX 或 VOLCENGINE——
#: 各自的请求体、鉴权头、返回结构都不一样，本包也只实现了这几种。
#:
#: **取值以平台返回的 `providerName` 为准**，不按厂商的产品名自己起。
#: 火山引擎的生图 API 叫「方舟」（`ark.cn-beijing.volces.com`），
#: 但平台存的是 `VOLCENGINE`——**按 `ark` 判会永远认不出**。
#:
#: 分开列而不是合成一个集合，是为了认出「把配音模型绑成了文生图模型」这种配错：
#: 合成一个集合的话它会通过校验，然后用 MiniMax 的协议去打豆包的地址，
#: 报出来的是 400 或鉴权失败，与真正的原因隔了两层。
PROVIDERS: dict[str, frozenset] = {
    "image": frozenset({"VOLCENGINE", "QWEN"}),
    "tts": frozenset({"MINIMAX", "VOLCENGINE"}),
}

CACHE_DIR = ".runtime/credentials"

#: `(path, payload, service_name=...) -> dict`，测试可注入。
Post = Callable[..., "dict[str, Any]"]


class CredentialError(RuntimeError):
    """带 `code`：调用方据此判断该去绑模型、去修部署，还是去改参数。"""

    def __init__(self, message: str, *, code: str) -> None:
        super().__init__(message)
        self.code = code


def cache_path(session_root: str | Path, agent_id: str, kind: str) -> Path:
    return Path(str(session_root)) / CACHE_DIR / str(agent_id) / (kind + ".json")


def resolve_credentials(agent_id: str, *, kind: str,
                        session_root: str | Path | None = None,
                        refresh: bool = False,
                        post: Post | None = None) -> dict[str, Any]:
    """解析一次，会话内复用。

    缓存按 agentId + kind：配图五张、配音十几段共用同一份，
    不缓存就是几十次重复查同一个模型。
    """
    if kind not in KINDS:
        # 在任何请求之前拒绝
        raise CredentialError(
            f"未知用途 {kind!r}。可用：{'、'.join(sorted(KINDS))}。", code="KIND_UNKNOWN")
    identifier = str(agent_id or "").strip()
    if not identifier:
        raise CredentialError(
            "缺少 agentId。它在 agent 的运行上下文里，由 Skill 通过 --agent-id 传进来。",
            code="AGENT_ID_MISSING")

    cached = None if refresh else _read_cache(session_root, identifier, kind)
    if cached is not None:
        return cached

    field, label = KINDS[kind]
    call = post or _default_post
    details = _fetch(call, DETAILS_PATH, {"resourceId": identifier, "language": LANGUAGE})
    model_id = _text(details.get(field))
    if not model_id:
        # **两种空值都要认。** null 与 "" 在这里等价，都表示没绑。
        raise CredentialError(
            f"该 agent（{identifier}）未配置{label}模型。请在后台为它绑定一个模型，"
            "这不是密钥问题。",
            code="MODEL_NOT_BOUND")

    model = _fetch(call, MODEL_PATH, {"id": model_id, "language": LANGUAGE})
    instance_param = _object(model.get("instanceParam"))
    configured_provider = _text(
        model.get("providerName") or instance_param.get("providerName")
    )
    endpoint = _text(model.get("apiEndpoint") or model.get("url"))
    model_code = _text(model.get("modelCode"))
    resolved = {
        "agentId": identifier,
        "kind": kind,
        "modelId": model_id,
        "modelCode": model_code,
        "apiEndpoint": endpoint,
        "apiToken": _text(model.get("apiToken") or model.get("authToken")),
        "providerName": _provider_name(
            kind, configured_provider, endpoint=endpoint, model_code=model_code,
        ),
        "configuredProviderName": configured_provider,
        "voiceId": _voice_id(model, instance_param),
    }
    _validate(resolved, label=label, kind=kind)
    _write_cache(session_root, identifier, kind, resolved)
    return resolved


def redact(resolved: Mapping[str, Any]) -> dict[str, Any]:
    """能给人看的那一份。

    **CLI 默认输出这个**：agent 会把 stdout 抄进回执与日志，
    而回执是要交出去的。令牌只在 `--emit-token` 时才出现在 stdout 上。
    """
    return {
        "providerName": resolved.get("providerName"),
        "configuredProviderName": resolved.get("configuredProviderName"),
        "apiEndpoint": resolved.get("apiEndpoint"),
        "modelId": resolved.get("modelId"),
        "modelCode": resolved.get("modelCode"),
        "voiceId": resolved.get("voiceId"),
        "hasToken": bool(str(resolved.get("apiToken") or "").strip()),
    }


def _validate(resolved: Mapping[str, Any], *, label: str, kind: str) -> None:
    # `modelCode` 是**模型型号**（`speech-2.8-hd`、`doubao-seedream-5-0-260128`），
    # 原先在 `integrations.yaml` 的 `model` 字段。它与端点、令牌同等必要：
    # 缺了发出去的请求没有 model 参数，对面直接 400。
    #
    # **接口返参里没有 `modelName` 这个字段。** 一度按它取值，取到的恒是空串——
    # 生图会报「没有模型名」（还算响），配音会静默回落到硬编码的默认型号
    # （**换了模型也照样用旧的，不报错**）。所以这里当必填校验。
    missing = [name for name in ("apiEndpoint", "apiToken", "modelCode")
               if not resolved.get(name)]
    if missing:
        raise CredentialError(
            f"{label}模型 {resolved.get('modelId')} 的 {'、'.join(missing)} 是空的。"
            "模型记录不完整，请在后台补齐——这不是调用方能修的。",
            code="CREDENTIAL_INCOMPLETE")
    provider = str(resolved.get("providerName") or "")
    allowed = PROVIDERS[kind]
    if provider.upper() not in allowed:
        raise CredentialError(
            f"{label}认不出的供应商 {provider!r}（模型 {resolved.get('modelId')}）。"
            f"{label}支持：{'、'.join(sorted(allowed))}。"
            "**不回落到默认客户端**：那会用错误的协议打正确的地址，"
            "报出来的是网络错或鉴权错，而根因是选错了客户端。",
            code="PROVIDER_UNKNOWN")


def _fetch(call: Post, path: str, payload: dict[str, Any]) -> dict[str, Any]:
    import os

    service = os.environ.get(SERVICE_ENV, "").strip() or SERVICE_FALLBACK
    try:
        body = call(path, payload, service_name=service)
    except ModuleNotFoundError as exc:
        # 缺 by_framework 不是「没配模型」，是这台机器根本调不动平台。
        raise CredentialError(
            f"当前环境不具备平台运行时（{exc}），无法解析凭据。"
            "凭据解析要走内网服务发现与登录态，只能在平台沙箱内进行。",
            code="PLATFORM_UNREACHABLE") from exc
    except CredentialError:
        raise
    except Exception as exc:  # 传输层的异常形态由平台决定，这里只做归一
        raise CredentialError(f"调用 {path} 失败：{exc}", code="PLATFORM_UNREACHABLE") from exc

    data = body.get("data") if isinstance(body, Mapping) else None
    if not isinstance(data, Mapping):
        raise CredentialError(f"{path} 未返回 data 对象：{body}", code="PLATFORM_UNREACHABLE")
    return dict(data)


def _default_post(path: str, payload: dict[str, Any], service_name: str | None = None
                  ) -> dict[str, Any]:
    from byclaw_caps._platform_http import post_json

    return post_json(path, payload, service_name)


def _text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _object(value: Any) -> dict[str, Any]:
    """Decode platform object fields, including JSON encoded more than once.

    Model instance parameters have appeared both as objects and as JSON strings.
    Some records encode ``extendParam`` twice, so one ``json.loads`` returns
    another JSON string rather than the object itself.  Keep the decoder bounded
    and accept mappings only; malformed configuration still fails closed.
    """
    current = value
    for _ in range(3):
        if isinstance(current, Mapping):
            return dict(current)
        if not isinstance(current, str) or not current.strip():
            return {}
        try:
            current = json.loads(current)
        except (TypeError, ValueError):
            return {}
    return {}


def _voice_id(model: Mapping[str, Any],
              instance_param: Mapping[str, Any]) -> str:
    # `getModelDetail` 的真实返回会把 instanceParam 展平，extendParam 直接位于
    # data 顶层；保留嵌套读取以兼容旧返回与测试桩。
    extended = _object(model.get("extendParam"))
    if not extended:
        extended = _object(instance_param.get("extendParam"))
    return _text(extended.get("speaker"))


def _provider_name(kind: str, configured: str, *, endpoint: str,
                   model_code: str) -> str:
    """Normalize generic protocols without accepting arbitrary OpenAI TTS."""
    original = _text(configured)
    raw = original.upper()
    if kind != "tts" or raw != "OPENAI":
        return original
    host = (urlparse(endpoint).hostname or "").lower()
    if host == "openspeech.bytedance.com" and model_code in {
        "seed-tts-2.0", "seed-icl-2.0",
    }:
        return "VOLCENGINE"
    return original


def _read_cache(session_root: str | Path | None, agent_id: str, kind: str
                ) -> Optional[dict[str, Any]]:
    if not session_root:
        return None
    target = cache_path(session_root, agent_id, kind)
    if not target.is_file():
        return None
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        # 缓存坏了就重新解析。**不要在这里报错**——缓存是优化，
        # 让优化的失败变成功能的失败，是把一次多余的请求换成一次彻底的失败。
        return None
    return data if isinstance(data, dict) else None


def _write_cache(session_root: str | Path | None, agent_id: str, kind: str,
                 resolved: Mapping[str, Any]) -> None:
    if not session_root:
        return
    target = cache_path(session_root, agent_id, kind)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(dict(resolved), ensure_ascii=False, indent=2) + "\n",
                      encoding="utf-8")


__all__ = [
    "CredentialError",
    "DETAILS_PATH",
    "MODEL_PATH",
    "KINDS",
    "PROVIDERS",
    "cache_path",
    "redact",
    "resolve_credentials",
]
