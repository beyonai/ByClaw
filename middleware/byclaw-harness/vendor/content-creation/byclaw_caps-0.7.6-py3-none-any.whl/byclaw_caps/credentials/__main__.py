#!/usr/bin/env python3
"""凭据 CLI。

`validate` / `doctor` / `init` 三个子命令随 `integrations.yaml` 一起废除——
它们做的都是那个文件的校验、体检与生成。凭据现在按 agentId 运行时解析。
"""

from __future__ import annotations

import argparse

from byclaw_caps._cli import EXIT_BUSINESS, EXIT_OK, add_common, dispatch
from byclaw_caps.credentials import ConfigurationError, scan_paths
from byclaw_caps.credentials.resolve import (
    CredentialError, KINDS, redact, resolve_credentials,
)


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="byclaw_caps.credentials", description="凭据诊断")
    sub = parser.add_subparsers(dest="command", required=True)
    scan = sub.add_parser("scan", help="扫描源码中的疑似硬编码 Secret")
    scan.add_argument("--root", required=True)
    resolve = sub.add_parser("resolve", help="按 agentId 解析生图／配音凭据")
    resolve.add_argument("--agent-id", required=True, help="agent 运行上下文里的 agentId")
    resolve.add_argument("--kind", required=True, choices=sorted(KINDS))
    resolve.add_argument("--session-root", help="缓存落点；不给则每次都重新解析")
    resolve.add_argument(
        "--emit-token", action="store_true",
        help="把 apiToken 打到 stdout。**默认不打**——agent 会把 stdout 抄进回执与日志，"
             "而回执是要交出去的。只在确实需要把令牌传给外部进程时才加。")

    for one in (scan, resolve):
        add_common(one)
    return parser


def handle(args: argparse.Namespace):
    if args.command == "resolve":
        resolved = resolve_credentials(
            args.agent_id, kind=args.kind, session_root=args.session_root)
        payload = dict(resolved) if args.emit_token else redact(resolved)
        payload["ok"] = True
        return payload, EXIT_OK
    result = scan_paths(args.root)
    return result, EXIT_OK if result["ok"] else EXIT_BUSINESS


def main() -> int:
    # CredentialError 归到用法/环境错（退 2）：未绑模型、认不出供应商、平台够不着，
    # 三种都不是「跑了但没成功」，而是「压根没条件跑」。
    return dispatch(build(), handle, usage_errors=(ConfigurationError, CredentialError))


if __name__ == "__main__":
    raise SystemExit(main())
