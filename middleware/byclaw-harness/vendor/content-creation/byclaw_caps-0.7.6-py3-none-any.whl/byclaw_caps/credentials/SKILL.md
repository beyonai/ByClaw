---
name: credentials
description: 当需要生图或配音凭据、或要检查项目里有没有硬编码密钥时使用。凭据按 agentId 运行时解析——先查这个 agent 绑了哪个文生图／文生语音模型，再查那个模型的 apiEndpoint、apiToken、providerName，会话内缓存。MINIMAX_API_KEY、ARK_API_KEY 两个环境变量已废除。未绑模型报「未配置模型」而不是凭据错误：那要去后台绑，不是去查密钥。
---

# 凭据

## 调用

```bash
# 按 agentId 解析生图／配音凭据
python3 -m byclaw_caps.credentials resolve --agent-id <agentId> --kind image|tts \
    [--session-root <会话根>] [--emit-token]

# 扫描源码里的疑似硬编码 Secret（只报文件与行号，不报内容）
python3 -m byclaw_caps.credentials scan --root <目录>
```

退出码：`0` 成功，`1` 业务失败，`2` 用法错误或环境不具备。

**`resolve` 的失败一律是 2**：未绑模型、认不出供应商、平台够不着——
三种都不是「跑了但没成功」，而是「压根没条件跑」。

## 解析链路

```
--agent-id X
   ↓ 命中会话缓存 → 直接用
   ↓ 未命中
findDetailsById {"resourceId": X}   → imageModelId / ttsModelId
getModelDetail  {"id": <modelId>}   → apiEndpoint / apiToken / providerName / modelCode
   ↓
缓存到 <会话根>/.runtime/credentials/<agentId>/<kind>.json
```

模型详情也兼容实例配置使用的字段名：`url` / `authToken`。真实的 `getModelDetail`
会把实例参数展平，因此音色从顶层 `extendParam.speaker` 读取，同时兼容旧的
`instanceParam.extendParam.speaker`。若 TTS 配置的 `providerName=OpenAI`，只有端点严格为
`openspeech.bytedance.com` 且 `modelCode` 是支持的 Seed 语音型号时才归一为
`VOLCENGINE`；其他 OpenAI 协议模型仍然拒绝，不能按火山协议猜测调用。

**会话内按 agentId + kind 缓存。** 配图五张、配音十几段共用一次解析，
不缓存就是几十次重复查同一个模型。

## 三种失败，处置完全不同

| 错误码 | 含义 | 去做什么 |
|---|---|---|
| `MODEL_NOT_BOUND` | 该 agent 没绑这类模型 | **去后台绑一个**，不是去查密钥 |
| `PROVIDER_UNKNOWN` | 绑了，但供应商本包不支持 | 换一个支持的模型 |
| `CREDENTIAL_INCOMPLETE` | 模型记录里端点、令牌或**型号**（`modelCode`）是空的 | 后台补齐，调用方修不了 |
| `PLATFORM_UNREACHABLE` | 这台机器调不动平台内网 | 修部署；不是没配模型 |

**未绑模型是正常状态。** 报成凭据错误的话，人会去找一个根本不存在的密钥。

**空值有两种表示**：平台样例里 `imageModelId` 是 `null`、`ttsModelId` 是 `""`。
两种都认作未绑——只判 `None`，空串会被当成合法 modelId 送进第二个接口。

## 供应商按用途分开

| 用途 | 支持 |
|---|---|
| `image` | `VOLCENGINE`（火山引擎／方舟，豆包）、`QWEN`（通义） |
| `tts` | `MINIMAX`、`VOLCENGINE`（火山引擎豆包语音） |

**分开列不是为了整洁。** 合成一个集合的话，「把配音模型绑成了文生图模型」
会通过校验，然后用 MiniMax 的协议去打豆包的地址，报出来的是 400 或鉴权失败，
与真正的原因隔了两层。

认不出的供应商**直接报错，不回落到默认客户端**——同样的道理。

## 令牌不进任何要交出去的地方

**`resolve` 默认不打印 `apiToken`**：agent 会把 stdout 抄进回执与日志，而回执要交出去。
默认输出只有 `providerName`、`apiEndpoint`、`modelId`、`modelCode` 和一个 `hasToken` 布尔。

**型号取自返参的 `modelCode`**（`speech-2.8-hd`、`doubao-seedream-5-0-260128`），
原先在 `integrations.yaml` 的 `model` 字段。**接口没有 `modelName` 这个字段**——
按它取值取到的恒是空串。

要令牌得显式加 `--emit-token`。

缓存文件里**有**令牌，所以它只落会话根：不进云盘、不进 git、不进回执。
不给 `--session-root` 就不缓存，每次重新解析——**不会退化成写到别处**。
