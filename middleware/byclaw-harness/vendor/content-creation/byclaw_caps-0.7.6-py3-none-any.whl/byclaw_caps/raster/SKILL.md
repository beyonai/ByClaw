---
name: image-rasterize
description: 当需要把 SVG 或 HTML 确定性地渲染成 PNG 时使用。用系统 chromium/chrome/edge 无头截图，同一输入两次调用字节一致，适合流程图、对比图、架构图、矩阵、时间线、数据图这类事实结构图。渲染前会拦截 HTML 里引用但不存在的本地图片——浏览器遇到缺图会静默留白并照常返回成功，产出一张有标题有说明、中间整块空白的坏图。SVG 按根节点 viewBox 定画布，默认 2 倍出图。不含 AI 生图兜底：栅格化失败即失败，不改走生图。不支持 --selector 与 --full-page。
---

# 图像栅格化

SVG／HTML → PNG，确定性渲染。

## 调用

```bash
# SVG 转 PNG，按根 viewBox 定画布，默认 2 倍
python3 -m byclaw_caps.raster svg <源.svg> <出.png> [--scale 2] [--browser <路径>]

# HTML 转 PNG，指定视口
python3 -m byclaw_caps.raster html <源.html> <出.png> --width 1200 --height 800 [--scale 1]

# 只读 SVG 画布尺寸，不渲染
python3 -m byclaw_caps.raster canvas <源.svg>

# 报告将使用哪个浏览器
python3 -m byclaw_caps.raster browser
```

输出是 JSON。退出码：`0` 成功，`1` 业务失败，`2` 用法错误或环境不具备。
加 `--result-file <路径>` 可同时落盘，供重放与比对。

## 为什么默认 2 倍

公众号正文图按约 677px 宽显示，1 倍出图在高分屏上会糊。

## 三条硬约束

**一、事实结构图只能走栅格化，不得改用 AI 生图。** 流程图、对比图、架构图、矩阵、时间线、
数据图——**生图模型会编造数字**。产出看着像模像样、数值却是假的，比渲染失败难发现得多。

本能力**不含 AI 兜底**。渲染报错要修 HTML 或修环境，不是换条路。

**二、渲染前拦缺图。** 线上出现过「卡片有标题有说明、中间配图区整块空白」：HTML 渲染成功、
退出码正常，但 `<img>` 指向的文件不存在，浏览器**静默留白**，产物被当作成功。

确需渲染带占位引用的页面时传 `--allow-missing-assets` 显式豁免，结果里会标出来。

**三、SVG 取根节点的 viewBox，不是文档里第一个 width／height。** 内部元素也带这两个属性；
按第一个匹配取值会得到 280×260 这种荒唐尺寸，而真实画布是 680×360。

## 不支持的选项

`--selector`（按 CSS 选择器截元素）与 `--full-page`（整页滚动截图）**不提供**。它们需要
Patchright 或 Playwright 运行时，本环境未安装；沿用旧脚本调用这两个选项同样会硬失败。

需要只截页面一部分时，改在 HTML 里做：把不想入镜的内容移出，或用容器宽高把捕获区域框成
整个视口。这样走的仍是确定性渲染，不必引入额外运行时。

## 环境

需要 chromium、chrome 或 edge 之一；先搜 PATH，再查平台标准安装路径。

容器内需设 `HTML_IMAGE_NO_SANDBOX=1`，否则渲染直接失败——**这是环境问题不是 HTML 问题**，
不要因此改 HTML。

冷启动实测在 2–15 秒间波动，个别超过 60 秒，故默认超时放宽到 120 秒。曾试图用
`--no-first-run`、`--disable-background-networking` 一类参数压低方差，**实测无效**，
根因未定位，因此没有加那些参数。

字体缺失时 chromium **不会报错**，直接渲出方块。部署前用
`python3 prereqs/check-prereqs.py` 自检。

## 公众号不显示 SVG

正文里直接放 `.svg` 会**整张不出图**。发布前必须转 PNG——这正是本能力存在的直接动因：一篇文章的 6 张配图全是 SVG，公众号一张也显示不了。

红线校验的 `IMG_SVG` 会拦住它，但拦住不等于解决。
