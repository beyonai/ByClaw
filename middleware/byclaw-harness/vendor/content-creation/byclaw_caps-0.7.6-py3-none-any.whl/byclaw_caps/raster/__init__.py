#!/usr/bin/env python3
"""图像栅格化：SVG／HTML → PNG。

**直接动因：文章的 6 张配图全是 SVG，公众号一张也显示不了。** 红线校验会拦住
（``IMG_SVG`` ERROR），但拦住不等于解决——得有人把 SVG 变成 PNG，那就是本能力。

与视频合成分开而非合并，因为三个维度都不同：依赖不同（chromium 对 ffmpeg）、调用者不同
（文章／图文／视频全都依赖它，视频合成只服务视频）、失败模式不同（渲染超时与字体缺失，
对编码失败与音画不同步）。

两处必须做对：

一、**取根节点的 viewBox，不是文档里第一个 width／height。** 实测那 6 个文件里
   ``width="280"``、``height="16"`` 这类属性属于内部元素；按第一个匹配取尺寸会得到
   280×260 这种荒唐值，而真实画布是 680×360。

二、**不静默降级。** 结果里必须写明实际走了哪条渲染路径。既有
   ``render_html_to_image.py`` 里「失败再 LLM 兜底」是条静默降级——栅格化失败时改用
   大模型出图，产物形态完全不同却不告诉调用方。
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote

VERSION = "1.0.0"

# 与 prereqs 共用一套发现规则，避免两处各写一份最终漂移
from byclaw_caps.prereqs import browser_candidates  # noqa: E402

_BROWSER_NAMES = (
    "chromium", "chromium-browser", "google-chrome",
    "google-chrome-stable", "chrome", "msedge", "microsoft-edge",
)

#: 容器内 Chromium 需要无沙箱，否则渲染直接失败。
#: 这是**环境问题不是 HTML 问题**——渲染报错时不要去改 HTML，也不要改走生图兜底。
ENV_NO_SANDBOX = "HTML_IMAGE_NO_SANDBOX"

#: 某些 Chromium 镜像在全新 ``--user-data-dir`` 上首次启动会挂起，调用方可指定
#: 一个已经预热的固定目录。默认仍使用每次调用独占的临时目录，避免并发任务争锁。
ENV_PROFILE_DIR = "HTML_IMAGE_USER_DATA_DIR"

#: 同一 profile 首次挂起、第二次成功是线上 Chrome for Testing 151 的稳定复现。
#: 前两次用较短的启动窗口，最后一次仍尊重调用方原始超时，兼顾冷启动与真实慢页面。
CHROMIUM_MAX_ATTEMPTS = 3
CHROMIUM_RETRY_TIMEOUT = 30


def chromium_common_flags() -> list[str]:
    """返回所有 ``byclaw_caps`` Chromium 调用必须共用的启动参数。

    DSH 沙箱里的 ``/dev/shm`` 默认只有 64MB。Chromium 的字体服务会在页面稍复杂时
    因共享内存耗尽以 134 退出，stderr 只留下 ``No space left on device``。让 Chrome
    把共享内存文件落到普通临时目录，可避免把容器容量问题误报成 HTML 渲染失败。

    这组参数集中在这里，是为了让截图、高度探测与画面检查看到完全相同的运行环境；
    新增 Chromium 调用时也必须复用它。
    """
    flags = ["--disable-gpu", "--disable-dev-shm-usage"]
    if os.environ.get(ENV_NO_SANDBOX):
        flags.append("--no-sandbox")
    return flags


def chromium_profile_dir(default: str | Path) -> str:
    """返回 Chromium profile 目录；显式目录不可用时响亮失败。

    不静默退回临时目录，否则调用方以为自己在复用预热 profile，实际仍会不断触发
    首次启动问题，故障会重新变成偶发。
    """
    raw = (os.environ.get(ENV_PROFILE_DIR) or "").strip()
    if not raw:
        return str(default)
    path = Path(raw).expanduser()
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RasterError(f"无法创建 Chromium profile 目录：{path}（{exc}）") from None
    if not path.is_dir():
        raise RasterError(f"Chromium profile 路径不是目录：{path}")
    return str(path)


def run_chromium_with_retries(
    argv: list[str],
    *,
    timeout: int,
    accept: Callable[[subprocess.CompletedProcess[str]], bool],
    runner: Callable[..., subprocess.CompletedProcess[str]] | None = None,
) -> subprocess.CompletedProcess[str]:
    """运行 Chromium，并对已证实的首次启动挂起／空输出做有限重试。

    ``accept`` 必须验证调用点真正需要的产物：截图检查文件，高度探测与画面探针检查
    DOM 标记。仅凭退出码 0 不够——线上故障的一种表现正是 0 字节输出。
    """
    invoke = runner or subprocess.run
    last_done: subprocess.CompletedProcess[str] | None = None
    last_error: BaseException | None = None
    for attempt in range(CHROMIUM_MAX_ATTEMPTS):
        attempt_timeout = (timeout if attempt == CHROMIUM_MAX_ATTEMPTS - 1
                           else min(timeout, CHROMIUM_RETRY_TIMEOUT))
        try:
            done = invoke(
                argv, capture_output=True, text=True,
                encoding="utf-8", errors="replace",
                timeout=attempt_timeout, check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            last_error = exc
            continue
        last_done = done
        if accept(done):
            return done
    if last_done is not None:
        return last_done
    assert last_error is not None
    raise last_error

#: 默认超时。实测本机冷启动在 **2–15 秒**间剧烈波动，个别一次超过 60 秒。
#: 曾怀疑是首次运行的后台网络请求，加了 --no-first-run／--disable-background-networking
#: 一类参数实测**未见收益**，方差由别处主导，故不加那些参数——没证据的改动是噪音。
#: 既然查不出根因，就把超时留够：宁可等，不要在偶发慢启动上假失败。
DEFAULT_TIMEOUT = 120

_SVG_TAG = re.compile(r"<svg\b[^>]*>", re.I | re.S)
_VIEWBOX = re.compile(r'viewBox\s*=\s*["\']\s*([-\d.]+)[,\s]+([-\d.]+)[,\s]+([-\d.]+)[,\s]+([-\d.]+)', re.I)
_ATTR = re.compile(r'\b(width|height)\s*=\s*["\']\s*([\d.]+)', re.I)


class RasterError(RuntimeError):
    """源文件不可读、尺寸无法确定，或浏览器不可用。"""


#: chromium 没配 sandbox 时 stderr 里的特征词。宁可漏认也不要错认——
#: 每种失败都糊上同一句提示，提示就等于噪声，然后没人看。
_SANDBOX_MARKERS = ("no-sandbox", "namespace", "sandbox")


def sandbox_hint(stderr: str) -> str:
    """sandbox 失败时给出路；其余情况返回空串。

    出路本来写在本能力的 SKILL.md「环境」一节。但 2026-08-28 实测里，
    配图助理读的是 `illustrate-article` 的文档，**没理由打开这一份**；
    它在失败点上能看到的只有一行「未产出 PNG：…浏览器输出：…」。
    于是它转头用 playwright 自己拼了一条渲染链——图出来了，
    但画幅、字节、哈希全都没经过本能力的校验。

    **文档写对了不等于答案送到了。** 一个 agent 只读得到失败点上的那行字，
    所以出路必须在那行字里。
    """
    import os

    if os.environ.get(ENV_NO_SANDBOX):
        # 已经设了还失败，说明是别的原因。这时再劝设一遍是误导。
        return ""
    lowered = (stderr or "").lower()
    if not any(marker in lowered for marker in _SANDBOX_MARKERS):
        return ""
    return (f"提示：容器内需设 {ENV_NO_SANDBOX}=1 再重试。"
            "**这是环境问题，不是 HTML 或 SVG 的问题**——不要改源文件，"
            "也不要自己起浏览器绕过去：不是本能力出的图，画幅与哈希都没经过校验。"
            "设了仍失败就报 blocked。")


def find_browser(explicit: str | None = None) -> str:
    """先按名搜 PATH，再查平台标准路径。规则与 prereqs 一致。"""
    if explicit:
        if Path(explicit).is_file():
            return explicit
        raise RasterError(f"指定的浏览器不存在：{explicit}")
    for name in _BROWSER_NAMES:
        found = shutil.which(name)
        if found:
            return found
    for path in browser_candidates(sys.platform):
        if Path(path).is_file():
            return path
    raise RasterError(
        "未找到可用的 chromium／chrome／edge。"
        "请安装其一，或以 --browser 指定绝对路径；"
        "Linux 上：apt-get install -y chromium。"
    )


class _LocalAssetParser(HTMLParser):
    """收集 HTML 里引用的本地资源。"""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.references: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "img":
            return
        for name, value in attrs:
            if name.lower() == "src":
                self.references.append((value or "").strip())
                return
        self.references.append("")


def _is_remote(reference: str) -> bool:
    lowered = reference.lower()
    return (
        lowered.startswith(("http://", "https://", "//", "data:", "blob:"))
    )


def find_missing_local_assets(html_path: str | Path) -> list[str]:
    """返回 HTML 引用但实际不存在的本地图片。

    线上出现过「卡片有标题有说明、中间配图区整块空白」：HTML 渲染成功，但 ``<img>`` 指向的
    文件不存在，**浏览器静默留白**，产物还被当作成功。

    这与缺字体渲染出方块、``%`` 被 drawtext 吞掉是同一类：**看起来正常的坏产物**，比报错
    难发现得多。浏览器不会替我们报，只能渲染前先扫一遍。
    """
    target = Path(html_path)
    if not target.is_file():
        raise RasterError(f"HTML 不存在：{target}")

    parser = _LocalAssetParser()
    parser.feed(target.read_text(encoding="utf-8", errors="replace"))
    parser.close()

    base = target.parent
    missing: list[str] = []
    seen: set[str] = set()
    for reference in parser.references:
        if reference in seen:
            continue
        seen.add(reference)
        if not reference:
            missing.append("<img src> 为空")
            continue
        if _is_remote(reference):
            # 外链不在本地，无从校验，也不该拦
            continue
        candidate = Path(reference)
        resolved = candidate if candidate.is_absolute() else base / candidate
        if not resolved.is_file():
            missing.append(f"{reference}（解析为 {resolved}）")
    return missing


# ── 环形箭头（A14）────────────────────────────────────────────────────────
#
# 「于是有了那个死循环」那一页箭头是乱的：有的指回起点，有的悬在框外。
#
# 根因是一行数学。圆周参数化用的是
#
#     x = cx + r·sin(θ)
#     y = cy − r·cos(θ)
#
# 于是 dx/dθ = r·cos(θ)、dy/dθ = r·sin(θ)，**切线角就是 θ**。
# 而当时写成 `θ + π/2`——用成了法线，整整偏 90°。
#
# 这类错**字符串断言查不出来**：数量对、位置也在弧端点上，只有朝向是错的。
# 所以配套的测试断言「箭尖沿朝向延伸后必须更靠近下一个节点」。


#: 箭尖与节点框之间留的余量倍数。正好相切看起来仍像顶在框上。
ARROW_CLEARANCE_MARGIN = 1.08


def ring_node(cx: float, cy: float, r: float, index: int, count: int):
    """环上第 index 个节点的坐标。从正上方开始，顺时针。"""
    import math as _math

    angle = 2 * _math.pi * index / count
    return cx + r * _math.sin(angle), cy - r * _math.cos(angle)


def ring_arrows(cx: float, cy: float, r: float, count: int, *,
                gap: float = 0.34, clearance: float | None = None):
    """算出闭环上每一段弧的起点、箭尖与**朝向**。

    Args:
        clearance: 每个节点周围要空出的半径（通常取节点框的外接半径）。
            给了它就**由它反算间隙**，不再用固定的 ``gap``。

    **为什么需要 clearance。** 方向修对之后，顶部那个箭尖仍然看不见——
    它落进了节点方框里，而方框在箭头之后绘制，直接盖住了。
    固定角度间隙管不了这件事：同样的角度，在宽框那一侧的弦长不够。

    Returns:
        ``[{start_x, start_y, tip_x, tip_y, heading, radius}]``，
        ``heading`` 是箭头该指的方向（弧度，屏幕坐标系 y 向下）。
    """
    import math as _math

    if int(count) < 3:
        raise RasterError(
            f"{count} 个节点画不成环——两个节点只会得到两段重叠的弧")
    if clearance is not None:
        # 弦长 c 与圆心角 Δ 的关系：c = 2r·sin(Δ/2)
        #
        # **乘一点余量。** 正好等于外接半径等于贴着框角画，
        # 视觉上仍像顶在框上；而且浮点相等在边界上不稳定。
        wanted = float(clearance) * ARROW_CLEARANCE_MARGIN
        ratio = wanted / (2.0 * float(r))
        if ratio >= 1.0:
            raise RasterError(
                f"节点框外接半径 {clearance:g} 相对环半径 {r:g} 太大，挤不下箭头——"
                "把环放大或把框缩小，别画一堆看不见的箭头")
        gap = 2.0 * _math.asin(ratio)
        sector = 2.0 * _math.pi / int(count)
        if gap * 2.0 >= sector * 0.92:
            raise RasterError(
                f"{count} 个节点、环半径 {r:g}、框外接半径 {clearance:g}——"
                f"每段弧只剩 {_math.degrees(sector - 2 * gap):.1f}°，画不出箭头。"
                "把环放大或把框缩小")
    out = []
    for index in range(int(count)):
        start_angle = 2 * _math.pi * index / count + gap
        end_angle = 2 * _math.pi * (index + 1) / count - gap
        sx = cx + r * _math.sin(start_angle)
        sy = cy - r * _math.cos(start_angle)
        tx = cx + r * _math.sin(end_angle)
        ty = cy - r * _math.cos(end_angle)
        # **切线，不是法线。** 参数角就是切线角。
        out.append({"start_x": sx, "start_y": sy, "tip_x": tx, "tip_y": ty,
                    "heading": end_angle, "radius": r})
    return out


def ring_arrow_svg(cx: float, cy: float, r: float, count: int, *,
                   colour: str = "#c8956c", width: float = 3.0,
                   head: float = 13.0, gap: float = 0.34,
                   clearance: float | None = None) -> str:
    """环形箭头的 SVG 片段：每段一条弧 + 一个箭头三角。

    给了 ``clearance`` 就由它反算间隙，保证箭尖落在节点框外。
    """
    import math as _math

    parts = []
    for arc in ring_arrows(cx, cy, r, count, gap=gap, clearance=clearance):
        parts.append(
            f'<path d="M{arc["start_x"]:.1f} {arc["start_y"]:.1f} '
            f'A {r:.1f} {r:.1f} 0 0 1 {arc["tip_x"]:.1f} {arc["tip_y"]:.1f}" '
            f'stroke="{colour}" stroke-width="{width:g}" fill="none"/>')
        angle = arc["heading"]
        tipx, tipy = arc["tip_x"], arc["tip_y"]
        back_x, back_y = tipx - head * _math.cos(angle), tipy - head * _math.sin(angle)
        half = head * 0.5
        parts.append(
            f'<polygon points="{tipx:.1f},{tipy:.1f} '
            f'{back_x + half * _math.sin(angle):.1f},{back_y - half * _math.cos(angle):.1f} '
            f'{back_x - half * _math.sin(angle):.1f},{back_y + half * _math.cos(angle):.1f}" '
            f'fill="{colour}"/>')
    return "".join(parts)


# ── AI 底图 + 确定性文字层（A10）──────────────────────────────────────────
#
# **AI 生图不负责中文文字。** 上一版有一镜的四个字渲染对了是运气——短、手写风、单行。
# 多几个字或要求排版位置就会出错字、糊字、少笔画，而且**不报错**：
# 产出一张构图漂亮、字是错的图。
#
# 所以分工写死：生图只画画面，文字由这里确定性地叠上去。
# 叠加复用同一条 SVG → chromium 链路（底图以 data URI 内嵌），
# **不引第二个渲染器**——两个渲染器就有两套字体行为。

#: 安全区。与 `shot-contract.md` 同源：上 8% 是运镜裕量，下 22% 是字幕带。
TEXT_SAFE_TOP = 0.08
TEXT_SAFE_BOTTOM = 0.78
#: 文字与底图的最小亮度差（0–255）。低于此值渲染成功但字看不见。
MIN_LUMA_GAP = 40

_MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
         ".webp": "image/webp"}


def _xml_escape(value: str) -> str:
    """`&` 未转义会让整份 SVG 解析失败，chromium 渲出空白且退出码为 0。"""
    return (str(value).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _hex_luma(color: str) -> float:
    value = str(color or "").strip().lstrip("#")
    if len(value) == 3:
        value = "".join(ch * 2 for ch in value)
    if len(value) != 6:
        raise RasterError(f"颜色 {color!r} 不是 #rrggbb —— 猜一个会让对比度检查失去意义")
    r, g, b = (int(value[i:i + 2], 16) for i in (0, 2, 4))
    return 0.299 * r + 0.587 * g + 0.114 * b


def _base_luma(path: Path) -> float:
    """把底图缩成 1×1 取灰度均值。

    均值会掩盖局部反差（亮底上有一块暗区），但**能抓住整体同色**这一类，
    而那正是实际发生过的：透明底进视频变黑、深色字压在深色底上。
    局部对比只能靠人看，所以这里只拦最粗的那一档，不假装能判所有情况。
    """
    import subprocess as _subprocess

    done = _subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(path), "-vf", "scale=1:1",
         "-f", "rawvideo", "-pix_fmt", "gray", "-"],
        capture_output=True, timeout=60)
    if not done.stdout:
        raise RasterError(f"读不出底图亮度：{path}——无法判断文字会不会看不见")
    return float(done.stdout[0])


def build_text_layer(base, texts, *, width: int = 1920, height: int = 1080,
                     font: str = "Microsoft YaHei") -> str:
    """把底图内嵌进 SVG，并在其上画确定性文字，返回 SVG 源码。

    Args:
        base: AI 生成的底图（应当**不含文字**）。
        texts: 每项 ``{text, y, size?, fill?, x?, weight?}``；
            ``y``/``x``/``size`` 都是相对画面的比例，便于换画幅时不用重算。

    Raises:
        RasterError: 底图缺失、文字为空、越出安全区，或与底图亮度差不足。
    """
    src = Path(base)
    if not src.is_file():
        raise RasterError(f"底图不存在：{src}")
    items = list(texts or [])
    if not items:
        raise RasterError(
            "文字层为空——那意味着这一镜白生成了一张图。"
            "静默通过会产出一个没有信息的哑镜头")

    luma = _base_luma(src)
    parts = []
    for item in items:
        text = str(item.get("text") or "").strip()
        if not text:
            raise RasterError("文字层里有空条目——空 <text> 渲染成功但什么都没有")
        y = float(item.get("y"))
        if not (TEXT_SAFE_TOP <= y <= TEXT_SAFE_BOTTOM):
            raise RasterError(
                f"文字 {text!r} 的 y={y:g} 越出安全区 "
                f"[{TEXT_SAFE_TOP}, {TEXT_SAFE_BOTTOM}]——"
                "上方会被运镜切出画框，下方会被字幕黑底压住，而渲染照样成功")
        fill = str(item.get("fill") or "#1a1a1a")
        if abs(_hex_luma(fill) - luma) < MIN_LUMA_GAP:
            raise RasterError(
                f"文字 {text!r} 的颜色 {fill} 与底图亮度差不足 "
                f"（{abs(_hex_luma(fill) - luma):.0f} < {MIN_LUMA_GAP}）——"
                "渲染会成功，但字看不见")
        size = round(float(item.get("size") or 0.06) * height)
        x = round(float(item.get("x") if item.get("x") is not None else 0.5) * width)
        weight = str(item.get("weight") or "700")
        parts.append(
            f'<text x="{x}" y="{round(y * height)}" text-anchor="middle" '
            f'font-size="{size}" font-weight="{weight}" fill="{fill}">'
            f'{_xml_escape(text)}</text>')

    mime = _MIME.get(src.suffix.lower())
    if mime is None:
        raise RasterError(f"底图格式 {src.suffix!r} 不支持内嵌，请转成 png/jpg/webp")
    import base64 as _base64

    blob = _base64.b64encode(src.read_bytes()).decode("ascii")
    # 底图**内嵌**而非引用本地路径：引用的话 SVG 换个目录就渲成空白，而且不报错。
    return (f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'xmlns:xlink="http://www.w3.org/1999/xlink" '
            f'viewBox="0 0 {width} {height}" width="{width}" height="{height}">'
            f'<image x="0" y="0" width="{width}" height="{height}" '
            f'preserveAspectRatio="xMidYMid slice" '
            f'xlink:href="data:{mime};base64,{blob}"/>'
            f'<g font-family="{font}">{"".join(parts)}</g></svg>')


def svg_canvas(path: str | Path) -> tuple[int, int]:
    """取 SVG 的画布尺寸。

    **只看根 ``<svg>`` 标签内的属性**——文档内部元素也带 width／height，
    按第一个匹配取值会得到荒唐的尺寸。
    """
    target = Path(path)
    if not target.is_file():
        raise RasterError(f"文件不存在：{target}")
    text = target.read_text(encoding="utf-8", errors="replace")
    tag = _SVG_TAG.search(text)
    if not tag:
        raise RasterError(f"不是 SVG：{target}")
    root = tag.group(0)

    attrs = {key.lower(): float(value) for key, value in _ATTR.findall(root)}
    if "width" in attrs and "height" in attrs:
        return int(round(attrs["width"])), int(round(attrs["height"]))

    box = _VIEWBOX.search(root)
    if box:
        width, height = float(box.group(3)), float(box.group(4))
        if width > 0 and height > 0:
            return int(round(width)), int(round(height))

    raise RasterError(
        f"无法确定画布尺寸：{target}。根 <svg> 上既无 width／height，也无可用的 viewBox。"
    )


def rasterize_svg(
    source: str | Path,
    output: str | Path,
    *,
    scale: int = 2,
    browser: str | None = None,
    timeout: int = DEFAULT_TIMEOUT,
) -> dict[str, Any]:
    """用 headless 浏览器把 SVG 截成 PNG。

    ``scale=2`` 是默认：公众号正文图按约 677px 宽显示，2 倍出图在高分屏上才不糊。
    """
    src = Path(source)
    if not src.is_file():
        # 先查文件再起浏览器——启动一次要几百毫秒，没必要为必失败的调用付这个代价
        raise RasterError(f"源文件不存在：{src}")

    width, height = svg_canvas(src)
    result = _screenshot(
        src, output, width=width, height=height, scale=scale,
        browser=browser, timeout=timeout,
    )
    result["canvas"] = (width, height)
    return result


def _screenshot(
    src: Path,
    output: str | Path,
    *,
    width: int,
    height: int,
    scale: int,
    browser: str | None,
    timeout: int,
    wait: int = 0,
    transparent: bool = True,
) -> dict[str, Any]:
    """SVG 与 HTML 共用的截图路径，避免两条路各自演化。"""
    import os

    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    executable = find_browser(browser)

    with tempfile.TemporaryDirectory() as profile:
        user_data_dir = chromium_profile_dir(profile)
        # PNG 的宽度不代表页面的布局宽度：Chrome 可把 420px 窗口钳到
        # 500px，再裁成 420px PNG。与探测共用 iframe，固定真正的布局视口。
        frame = Path(profile) / "viewport.html"
        frame.write_text(viewport_frame_html(
            src.resolve(), width=width, height=height, receiver_js=""),
            encoding="utf-8")
        argv = [
            executable,
            "--headless",
            *chromium_common_flags(),
            "--hide-scrollbars",
            "--force-device-scale-factor=%d" % scale,
            *(["--default-background-color=00000000"] if transparent else []),
            *(["--virtual-time-budget=%d" % (wait * 1000)] if wait else []),
            "--window-size=%d,%d" % (width, height),
            "--user-data-dir=%s" % user_data_dir,
            # **必须给绝对路径。** 浏览器按自己的工作目录解析相对路径，
            # 而那通常不是调用方的工作目录——落点找不到时它报的是
            # 「系统找不到指定的路径」，与「你给的路径是对的，只是基准不同」
            # 隔了一层。out 本身保持原样，回执里仍回显调用方写的那个值。
            "--screenshot=%s" % out.resolve(),
            frame.as_uri(),
        ]
        try:
            done = run_chromium_with_retries(
                argv, timeout=timeout, accept=lambda _done: out.is_file(),
                runner=subprocess.run,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            raise RasterError(f"浏览器启动失败：{executable}（{exc}）") from None

    if not out.is_file():
        raw = (done.stderr or done.stdout or "").strip()
        detail = raw[:300]
        # 出路要在失败点上就看得到，不能只写在 SKILL.md 里——
        # 调用方读不到那份文档，只读得到这一行。
        hint = sandbox_hint(raw)
        raise RasterError(
            f"未产出 PNG：{out}。浏览器输出：{detail or '（无）'}"
            + (f"{chr(10)}{hint}" if hint else ""))

    from byclaw_caps.image import read_dimensions

    return {
        # 必须写明实际走了哪条路：产物形态若不同，调用方要知道
        "renderer": "chromium",
        "browser": executable,
        "source": str(src),
        "output": str(out),
        "scale": scale,
        "size": read_dimensions(out),
    }


def rasterize_html(
    source: str | Path,
    output: str | Path,
    *,
    width: int = 1200,
    height: int = 800,
    scale: int = 1,
    browser: str | None = None,
    timeout: int = DEFAULT_TIMEOUT,
    wait: int = 0,
    transparent: bool = False,
    allow_missing_assets: bool = False,
    check_truncation: bool = True,
    content_height: int | None = None,
) -> dict[str, Any]:
    """用 headless 浏览器把 HTML 截成 PNG。

    **渲染前先拦缺失的本地图片。** 浏览器遇到不存在的 ``<img>`` 会静默留白并照常返回成功，
    产出一张有标题有说明、中间整块空白的图。确需渲染带占位引用的页面时用
    ``allow_missing_assets=True`` 显式豁免——**且结果里会标出来**，不静默放行。

    **不含 AI 生图兜底。** 那违反「事实类图形不得走 AI 生图」这条业务约束（生图模型会编造
    数字），且按架构生图是另一项能力。栅格化失败就该响亮地失败，由调用方决定下一步。

    ## 截不全要说出来

    `--window-size` 截的是固定视口。页面比它高时，**超出的部分直接丢掉，
    浏览器不报错、退出码是 0**，而回执里的 `size` 是 PNG 尺寸——
    正好等于请求的尺寸，看不出少了什么。

    实测过这个洞的代价：一篇 12995px 高的长文按 12000px 截，末尾 995px 没了；
    看图的人据此判定「结尾被截断、句子没说完」，**建议换版式重排**。
    主 Agent 花了十几次调用才证明是截图没截全、正文完好。
    一个会让下游做出错误决定的静默失真。

    所以默认多跑一次探测，把页面真实高度问出来，结果里给 `content_height`、
    `truncated` 与 `missing_px`。批量渲小图时可以 `check_truncation=False` 省掉；
    已经知道高度的调用方（比如刚跑过 `inspect`）直接传 `content_height`，不再探。
    """
    src = Path(source)
    if not src.is_file():
        raise RasterError(f"源文件不存在：{src}")

    missing = find_missing_local_assets(src)
    if missing and not allow_missing_assets:
        raise RasterError(
            "HTML 引用了不存在的本地图片，渲染会产出静默留白的坏图：\n  "
            + "\n  ".join(missing)
            + "\n补齐这些文件，或确认无碍后显式传 allow_missing_assets。"
        )

    result = _screenshot(
        src, output, width=width, height=height, scale=scale,
        browser=browser, timeout=timeout, wait=wait, transparent=transparent,
    )
    result["missing_assets"] = missing

    if check_truncation:
        actual = content_height
        if actual is None:
            # **视口与真实截图一致。** 探测环境一旦与截图环境不同，
            # 量出来的数就和实际渲染出来的东西无关——而调用方拿它判"截全了没有"。
            actual, viewport_matched = page_height_detail(
                src, width=width, height=height,
                browser=browser, timeout=timeout, wait=wait)
            result["viewport_matched"] = viewport_matched
        result["content_height"] = actual
        if actual is not None and not result.get("viewport_matched", True):
            # 响应式布局的高度不一定随宽度单调变化；视口不一致时，
            # 无论测得高度大于还是小于画布，都不能判定是否截断。
            result["truncated"] = None
            result["truncation_checked"] = False
        elif actual is None:
            # **量不到 ≠ 没截断。**
            #
            # 早先这里落进 `else` 报 `truncated=False`——探测失败反而成了
            # 「确认完整」。那是这条链上最坏的一种回答：调用方据此认为图是全的，
            # 而实际上没有任何人看过页面到底多高。
            #
            # `truncated=None` 表示「没确认」，由调用方决定拦还是放；
            # CLI 默认拦，理由见 `raster/__main__.py`。
            result["truncated"] = None
            result["truncation_checked"] = False
        else:
            result["truncation_checked"] = True
            result["truncated"] = actual > height
            if result["truncated"]:
                # **说出来，不要留给下游去发现。**
                result["missing_px"] = actual - height
    return result


def page_height(source: str | Path, *, width: int, height: int,
                browser: str | None = None, timeout: int = DEFAULT_TIMEOUT,
                wait: int = 0) -> int | None:
    """这张页面在 `width`×`height` 视口下有多高。取不到返回 `None`。"""
    measured, _ = page_height_detail(
        source, width=width, height=height, browser=browser,
        timeout=timeout, wait=wait)
    return measured



#: 页面把结果递给外层取景框用的前缀。
FRAME_MESSAGE_PREFIX = "__byclaw_frame__:"

#: 探针页在 iframe 里时，把结果发给外层；不在 iframe 里就什么也不做。
FRAME_FORWARD_JS = (
    "try{if(window.parent&&window.parent!==window){"
    "window.parent.postMessage(%r+String(__BYCLAW_PAYLOAD__),'*');}}"
    "catch(e){}" % FRAME_MESSAGE_PREFIX)


def frame_forward_js(payload_expr: str) -> str:
    """把 `payload_expr` 求出的字符串递给外层取景框的那段 JS。"""
    return FRAME_FORWARD_JS.replace("__BYCLAW_PAYLOAD__", payload_expr)


def viewport_frame_html(src_name: str | Path, *, width: int, height: int,
                        receiver_js: str) -> str:
    """截图和探测共用固定尺寸的 iframe，不依赖浏览器的最小窗口宽度。

    Chrome 的 PNG 尺寸可以是 420×800，页面的 innerWidth 却是 500。
    固定 100px 的元素也不能证明布局视口正确，必须验证媒体查询或 innerWidth。
    两条路径都在相同尺寸的 iframe 里打开页面，折行、媒体查询和 vh 才一致。

    字符串是未经 URL 编码的同目录文件名；Path 转为绝对 file URI，供放在
    临时目录里的截图框使用。原页面的位置不变，因此相对 CSS/图片仍按原目录解析。
    """
    source_url = (src_name.resolve().as_uri() if isinstance(src_name, Path)
                  else quote(src_name, safe=""))
    return (
        '<!doctype html><html><head><meta charset="utf-8">'
        '<style>html,body{margin:0;padding:0;overflow:hidden}'
        'iframe{border:0;display:block}</style></head><body>'
        '<script>window.addEventListener("message",function(e){'
        'var s=String(e.data||"");'
        'if(s.indexOf(%r)!==0)return;'
        'var v=s.slice(%d);'
        '%s'
        '});</script>'
        '<iframe src="%s" width="%d" height="%d" scrolling="no"></iframe>'
        '</body></html>'
    ) % (FRAME_MESSAGE_PREFIX, len(FRAME_MESSAGE_PREFIX), receiver_js,
         escape(source_url, quote=True), max(int(width), 1), max(int(height), 1))

def page_height_detail(source: str | Path, *, width: int, height: int,
                       browser: str | None = None,
                       timeout: int = DEFAULT_TIMEOUT,
                       wait: int = 0) -> tuple[int | None, bool]:
    """这张页面在 `width` 宽下实际有多高。取不到返回 `None`。

    实现是复制一份 HTML、在末尾追加一行脚本把 `scrollHeight` 写进
    `<title>`，再 `--dump-dom` 把它读回来。多一次浏览器启动，
    换的是「截图到底截全了没有」这个事实。
    """
    src = Path(source).resolve()
    marker = "__BYCLAW_H__"
    # **量的是内容边界，不是 `scrollHeight`。**
    #
    # `documentElement.scrollHeight` 至少等于视口高度：一张只有 200px 内容的页面
    # 在 800px 窗口里也会报 704。拿它当"实际内容高度"，短页面会被判成截断——
    # 实测请求 400px 截图的 200px 内容，报 `truncated=true, missing_px=304`，
    # 而那张图本来是完整的。
    #
    # 改成取 `body` 的滚动边界，再落到每个元素的 `getBoundingClientRect().bottom`
    # 上取最大值：**视口留白不算内容**。
    #
    # ⛔ **不要再加「怪异模式补偿项」。**
    #
    # 曾经写成 `e.scrollHeight - (e.clientHeight - b.clientHeight)`。
    # 那个式子默认 `b.clientHeight` 就是视口高——只有在**怪异模式**下成立。
    # 页面带 `<!doctype html>` 时 `b.clientHeight` 是正文自己的高度，
    # 式子就变成「正文高 + (正文高 − 视口高)」，**把正文高度算了两遍**。
    #
    # 实测：一张 2000px 的标准模式页面，请求 2000px 截图（本来一点没少），
    # 报 `content_height=3998, missing_px=1998`，CLI 退出码 1——
    # 于是代理去扩画布、重截，一轮白跑。去掉 DOCTYPE 同一份内容量出来正好 2000，
    # 这正是「补偿项只在怪异模式下成立」的证据。
    #
    # ── 什么时候量 ────────────────────────────────────────────────
    #
    # **要等图片和字体落位，不能在解析到这一行时就量。**
    # `<img>` 不写 width/height 时，加载完成前它的布局高度是 0。
    # 实测：一张高 2000px 的本地图，只截 800px，却量出 `content_height=0`、
    # `truncated=false`、`ok=true`——**被截掉的 1200px 无人发现**。
    #
    # 所以挂在 `load` 上（它等图片），字体可用时再在 `fonts.ready` 之后补量一次。
    # 标题只在量过之后才写，所以**读不到标记就等于没量成**——
    # 那种情况返回 `None`，由调用方报「无法确认」，不是「没截断」。
    # ── 量哪些东西 ────────────────────────────────────────────────
    #
    # 两样取最大值：**子元素的 `rect.bottom`**，加上**文本节点的 range 边界**。
    #
    # 文本节点那一样不能省。长文**直接写在 `<body>` 里**、或者末尾那段裸文本
    # 不属于任何子元素时，只看元素会量出 0——实测：body 里一段长文只截 400px，
    # 报 `content_height=0`、`truncated=false`、`ok=true`，
    # **被截掉的部分无人发现**。
    #
    # ⛔ **不要拿 `body.scrollHeight` 当兜底。** 它至少等于视口高：
    # 一张只有 200px 内容的页面在 800px 窗口里会报 704，
    # 于是短页面被判成截断，代理去扩画布重截，一轮白跑。
    # 这两件事只能靠「逐个量真实边界」同时满足，不能靠任何一个整体属性。
    #
    # ⛔ **也不要写成 `els.length ? … : …` 的二选一。** 探针自己就是一个
    # `<script>` 子元素，`els.length` 恒非零，于是另一支永远走不到——
    # 裸文本那种坏法正是这么漏过去的。
    probe = (
        "<script>(function(){"
        "function h(){var d=document,b=d.body,bottom=0;"
        "var els=d.querySelectorAll('body *');"
        "for(var i=0;i<els.length;i++){var el=els[i];"
        "var cs=window.getComputedStyle(el);"
        "if(cs&&cs.position==='fixed')continue;"
        "var r=el.getBoundingClientRect();"
        "var y=r.bottom+(window.scrollY||0);if(y>bottom)bottom=y;}"
        "try{var w=d.createTreeWalker(b,NodeFilter.SHOW_TEXT,null),n;"
        "while((n=w.nextNode())){if(!n.nodeValue||!n.nodeValue.trim())continue;"
        "var rg=d.createRange();rg.selectNodeContents(n);"
        "var tr=rg.getBoundingClientRect();"
        "var ty=tr.bottom+(window.scrollY||0);if(ty>bottom)bottom=ty;}}"
        "catch(e){}"
        "return Math.ceil(bottom);}"
        # marker 用 repr 拼进去，不走 %%-格式化：这段 JS 里到处是百分号，
        # 而且中间要 + 一段函数生成的代码，%% 模板会绑到错的那一段。
        "function done(){var m=" + repr(marker) + "+h()+'v'+window.innerWidth"
        "+'x'+window.innerHeight;document.title=m;"
        + frame_forward_js("m") +
        "}"
        "if(document.readyState==='complete'){done();}"
        "else{window.addEventListener('load',done);}"
        "try{if(document.fonts&&document.fonts.ready&&document.fonts.ready.then)"
        "{document.fonts.ready.then(done);}}catch(e){}"
        "})();</script>")

    # **探针写在原页面旁边，不搬到临时目录。**
    #
    # 搬过去之后，`<link href=\"style.css\">` 这类相对引用就指向了临时目录——
    # CSS 加载不到，量出来的是无样式的高度。实测同一份 2000px 的内容：
    # 内联 CSS 量到 2000，改成相对路径引用只量到 704，
    # 于是请求 1000px 截图时报 `truncated=false`，**被截掉的部分无人发现**。
    #
    # 探测必须与真实截图在同一个资源解析基准下进行，否则量的不是同一张页面。
    # **独占创建一个唯一名字，只删自己建的那个。**
    #
    # 上一版用固定名 `__byclaw_probe__<源文件名>` 写在源目录，写时不问
    # 那个文件在不在、完事无条件删除。于是两件事都会发生：
    # 预先存在的同名文件被覆盖并删掉；两次并发探测同一页面时互相覆盖，
    # 先结束的那个把后一个正在读的文件删了。
    #
    # `mkstemp` 在同目录建（保住相对资源的解析基准），`O_EXCL` 保证是我们建的。
    try:
        source_text = src.read_text(encoding="utf-8", errors="replace")
        handle, created = tempfile.mkstemp(
            dir=str(src.parent), prefix=".byclaw-probe-", suffix=src.suffix or ".html")
        probe_path = Path(created)
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            stream.write(source_text + probe)
    except OSError:
        # **必须返回二元组。** 这个函数的约定是 `(高度, 视口是否对上)`，
        # 而这一支曾经裸返 `None`——调用方 `actual, matched = …` 当场
        # `TypeError: cannot unpack non-iterable NoneType`。
        #
        # 于是「源目录不可写」这种本该好好报成「无法确认完整性」的情况，
        # 变成一个从渲染深处冒出来的类型错误。**失败路径也要守同一份约定**，
        # 它恰恰是最少被走到、因而最容易写错的那条。
        return None, False
    # ── 视口靠取景框，不靠 `--window-size` ─────────────────────────
    #
    # 与截图共用固定尺寸的 iframe。外层窗口可以不同，页面的布局视口必须相同。
    want_w, want_h = max(int(width), 1), max(int(height), 1)
    frame_path: Path | None = None
    try:
        try:
            handle, created = tempfile.mkstemp(
                dir=str(src.parent), prefix=".byclaw-frame-", suffix=".html")
            frame_path = Path(created)
            with os.fdopen(handle, "w", encoding="utf-8") as stream:
                stream.write(viewport_frame_html(
                    probe_path.name, width=want_w, height=want_h,
                    receiver_js="document.title=v;"))
        except OSError:
            return None, False

        with tempfile.TemporaryDirectory() as work:
            try:
                executable = browser or find_browser()
            except RasterError:
                return None, False
            argv = [
                executable, "--headless", *chromium_common_flags(),
                "--hide-scrollbars",
                # **必须给时间预算。** 量在 `load` 之后才发生（要等图片落位），
                # 再经 postMessage 递到外层；不给的话 `--dump-dom` 可能在这之前
                # 就把 DOM 拿走了，每次都返回「量不到」。
                "--virtual-time-budget=%d" % max(wait * 1000, 3000),
                # 外层窗口只要装得下取景框的加载即可，**它的尺寸不参与版面计算**。
                # 实测 iframe 比窗口大（1600×1200、750×20000）时视口照样精确。
                "--window-size=1280,900",
                "--user-data-dir=%s" % chromium_profile_dir(Path(work) / "profile"),
                "--dump-dom", frame_path.as_uri(),
            ]
            try:
                done = run_chromium_with_retries(
                    argv, timeout=timeout,
                    accept=lambda result: bool(re.search(
                        marker + r"(\d+)v(\d+)x(\d+)", result.stdout or "")),
                    runner=subprocess.run,
                )
            except (OSError, subprocess.SubprocessError):
                return None, False

        found = re.search(marker + r"(\d+)v(\d+)x(\d+)", done.stdout or "")
        if not found:
            return None, False
        measured, got_w, got_h = (int(found.group(1)), int(found.group(2)),
                                  int(found.group(3)))
        # 对不上就标明没对上——**不猜，也不替调用方判定"反正一样"**。
        return measured, (got_w, got_h) == (want_w, want_h)
    finally:
        probe_path.unlink(missing_ok=True)
        if frame_path is not None:
            frame_path.unlink(missing_ok=True)


__all__ = [
    "VERSION",
    "ENV_NO_SANDBOX",
    "ENV_PROFILE_DIR",
    "chromium_common_flags",
    "chromium_profile_dir",
    "run_chromium_with_retries",
    "RasterError",
    "sandbox_hint",
    "find_browser",
    "page_height",
    "page_height_detail",
    "viewport_frame_html",
    "frame_forward_js",
    "FRAME_MESSAGE_PREFIX",
    "find_missing_local_assets",
    "svg_canvas",
    "rasterize_svg",
    "build_text_layer",
    "ring_node",
    "ring_arrows",
    "ring_arrow_svg",
    "rasterize_html",
]
