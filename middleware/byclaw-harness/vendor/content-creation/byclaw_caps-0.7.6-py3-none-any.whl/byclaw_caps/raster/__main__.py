#!/usr/bin/env python3
"""图像栅格化能力 CLI：SVG／HTML → PNG。

直接动因：文章的 6 张配图全是 SVG，公众号一张也显示不了。
"""
from __future__ import annotations

import argparse

from byclaw_caps._cli import EXIT_BUSINESS, add_common, dispatch
from byclaw_caps.raster import (
    RasterError, build_text_layer, find_browser, rasterize_html,
    rasterize_svg, svg_canvas,
)


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="byclaw_caps.raster", description="栅格化")
    sub = parser.add_subparsers(dest="command", required=True)
    svg = sub.add_parser("svg", help="SVG 转 PNG")
    svg.add_argument("source")
    svg.add_argument("output")
    svg.add_argument("--scale", type=int, default=2,
                     help="默认 2 倍：公众号正文图按约 677px 宽显示，1 倍在高分屏上会糊")
    svg.add_argument("--browser", help="浏览器绝对路径；不给则自动发现")
    html = sub.add_parser("html", help="HTML 转 PNG")
    html.add_argument("source")
    html.add_argument("output")
    html.add_argument("--width", type=int, default=1200)
    html.add_argument("--height", type=int, default=800)
    html.add_argument("--scale", type=int, default=1)
    html.add_argument("--wait", type=int, default=0, help="渲染前等待秒数")
    html.add_argument("--transparent", action="store_true")
    html.add_argument(
        "--allow-truncated", action="store_true",
        help="页面比 --height 高时照常产出。**默认不产出**——"
             "截掉一段却报成功，看图的人会把缺的那段当成页面本来的样子")
    html.add_argument(
        "--no-truncation-check", action="store_true",
        help="跳过高度探测（省一次浏览器启动）。批量渲小图时可用；"
             "**长页面别用**，那正是会截掉的场合")
    html.add_argument("--browser")
    html.add_argument(
        "--allow-missing-assets", action="store_true",
        help="放行引用了不存在本地图片的页面。默认拦截——浏览器遇到缺图会静默留白"
             "并照常返回成功，产出一张有标题有说明、中间整块空白的坏图",
    )
    canvas = sub.add_parser("canvas", help="读 SVG 画布尺寸")
    canvas.add_argument("source")
    where = sub.add_parser("browser", help="报告将使用哪个浏览器")
    layer = sub.add_parser(
        "text-layer",
        help="AI 底图 + 确定性文字层 → 自包含 SVG。生图不画中文，文字叠上去。"
             "**公众号封面不要用它**——那条走 illustrate-article 的 "
             "scripts/compose_cover.py：它有 14 字上限、中文字体的可执行报错，"
             "以及 drawbox（overlay 会把 383 静默压成 382）")
    layer.add_argument("base", help="AI 生成的底图（应当不含文字）")
    layer.add_argument("texts", help="文字层 JSON：[{text, y, size?, x?, fill?, weight?}]")
    layer.add_argument("output", help="产出的 SVG；再用 `raster svg` 栅格化")
    layer.add_argument("--width", type=int, default=1920)
    layer.add_argument("--height", type=int, default=1080)
    layer.add_argument("--font", default="Microsoft YaHei")
    for one in (svg, html, canvas, where, layer):
        add_common(one)
    return parser


def handle(args: argparse.Namespace):
    if args.command == "browser":
        return {"ok": True, "browser": find_browser()}, 0
    if args.command == "text-layer":
        import json as _json
        from pathlib import Path as _Path
        texts = _json.loads(_Path(args.texts).read_text(encoding="utf-8"))
        source = build_text_layer(args.base, texts, width=args.width,
                                  height=args.height, font=args.font)
        out = _Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(source, encoding="utf-8")
        return {"ok": True, "output": str(out), "texts": len(texts),
                "canvas": [args.width, args.height]}, 0
    if args.command == "canvas":
        width, height = svg_canvas(args.source)
        return {"ok": True, "canvas": [width, height]}, 0
    if args.command == "html":
        result = rasterize_html(
            args.source, args.output,
            width=args.width, height=args.height, scale=args.scale,
            wait=args.wait, transparent=args.transparent,
            browser=args.browser, allow_missing_assets=args.allow_missing_assets,
            check_truncation=not args.no_truncation_check,
        )
        # **截不全是业务失败，不是一张小一点的图。**
        # 交出去的话，看图的人会把「被裁掉的那一段」当成「页面本来就这样」——
        # 实测过一次：末尾 995px 没截到，读图结论是「结尾没说完，建议换版式重排」。
        #
        # `truncated` 有三个值：`True` 截了、`False` 没截、**`None` 没确认**。
        # 第三种同样要拦：量不到高度时没有任何人看过页面多高，
        # 而「没人看过」与「看过了是全的」之间差着这道检查的全部价值。
        #
        # ⛔ **但「没查」与「查了没查出来」不是一回事。**
        #
        # `--no-truncation-check` 是调用方明说「这一项我不要」，
        # 那时结果里压根没有 `truncated` 字段。早先拿 `result.get("truncated")`
        # 取出 `None`，与探测失败混成同一种——于是**传了这个参数仍然退 1，
        # 而错误提示还在劝你传同一个参数**。实测过，一个无解的循环。
        #
        # 所以先看这一项到底跑没跑：没跑就不判。
        if args.no_truncation_check:
            truncated = False
        else:
            truncated = result.get("truncated")
        if truncated is not False and not args.allow_truncated:
            result["ok"] = False
            result["size"] = list(result["size"])
            if truncated is None:
                result["error"] = (
                    "**量不到页面实际多高，无法确认这张图是否截全。**\n"
                    "浏览器没能在时限内报回高度（页面太大、资源加载不完、"
                    "或探测被环境挡住）。\n"
                    "重试，或 --no-truncation-check 明确放弃这项检查；"
                    "确认只要这一屏就传 --allow-truncated。"
                    "**不要把「没确认」当成「没截断」。**")
            else:
                result["error"] = (
                    "只截到 %dpx，页面实际 %dpx，**末尾 %dpx 没进图**。\n"
                    "把 --height 调到 %d 以上重截；"
                    "确实只要上半部分就传 --allow-truncated，"
                    "那时结果里仍会标 truncated。"
                    % (args.height, result["content_height"],
                       result["missing_px"], result["content_height"]))
            return result, EXIT_BUSINESS
    else:
        result = rasterize_svg(
            args.source, args.output, scale=args.scale, browser=args.browser
        )
        result["canvas"] = list(result["canvas"])
    result["ok"] = True
    result["size"] = list(result["size"])
    return result, 0


def main() -> int:
    """控制台入口点。

    `python -m byclaw_caps.<能力>` 与安装后的 `byclaw-<能力>` 走同一条路——
    两条路行为分叉的话，文档里写的那条迟早是错的。
    """
    return dispatch(build(), handle, usage_errors=(RasterError,))


if __name__ == "__main__":
    raise SystemExit(main())
