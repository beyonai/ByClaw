#!/usr/bin/env python3
"""空间寻址：会话空间与项目空间的路径解析与写入守卫。

**本模块是唯一的源。** 它以构建期源码注入的方式进入各交付包，而非被 subprocess 调用——
路径解析在一次工作流中调用数十至上百次，每次起进程不成立。七项能力全部走 CLI，只有它例外，
分界不在频率而在调用方：能力由 agent 调用，它由代码调用。

注入而非各自维护副本，是为了把「各副本一致」从纪律变成机制。此前 7 份 session_paths.py
md5 全等靠的是人；两份 wechat_runtime.py 至今一致靠的是源码里一条「修改公共函数时必须
同步两侧」的注释。纪律能维持一时，构建期单一源才是机制。

三块职责：

一、会话根解析。平台沙箱**不注入任何会话环境变量**，会话 ID 只出现在 Agent 的系统提示中，
   因此实际生效的只有显式传参。三者都不可得时**硬失败**——不提供"拿不到就放行"的宽松模式，
   那会让相对路径回落到当前工作目录（即工作区），正是本模块要根治的问题。

二、阶段目录构造。阶段名是**封闭集合**，直挂会话根，不设中间层。拼错一个字符必须报错，
   否则会静默写到别处。

三、项目空间寻址。会话空间装一次工作，项目空间装需要沉淀的东西；根不同、生命周期不同，
   解析必须分开。把沉淀物写进会话会随会话回收而丢失。
"""

from __future__ import annotations

import os
import re
from pathlib import PurePosixPath
from typing import Iterable, Mapping

VERSION = "2.0.0"

# ── 会话空间 ──────────────────────────────────────────────────────────────
SESSION_ROOT_PATTERN = re.compile(r"^/by/\.sessions/(\d+)/?$")
SESSION_ROOT_PREFIX = "/by/.sessions/"

# ── 项目空间 ──────────────────────────────────────────────────────────────
# `PROJECT_ROOT_PATTERN` / `PROJECT_ROOT_MARKER` / `ENV_PROJECT_ROOT` 与
# `resolve_project_root` / `project_path` 一起删掉了：项目空间
# `/by/projects/{projectId}` 作废，素材与成品都在项目云盘上，落点由
# `/.user_settings/` 下的两份映射决定。
#
# **留着比删掉更坏**：一个还在校验 `/by/projects/<id>` 形状的函数，
# 会让人以为那条路还通。

# 工作区前缀；写入这里的产物会随工作区回收而丢失。
WORKSPACE_MARKER = "/by/.openclaw/workspace-"

ENV_SESSION_ROOT = "BAIYING_SESSION_ROOT"
ENV_SESSION_ID = "BAIYING_SESSION"

#: 会话内的阶段目录，封闭集合，顺序即流程顺序。
#: 十位编号预留插入空间——35-media 正是用掉的那一格（视频链路在配图与打包之间）。
STAGES: tuple[str, ...] = (
    "10-topic",
    "20-creative",
    "30-assets",
    "35-media",
    "40-package",
    "50-publish",
)

#: `.runtime/` 下不按阶段划分的保留区。
RUNTIME_AREAS: tuple[str, ...] = ("retrieval", "validation", "scratch")

META_DIRNAME = ".meta"
RUNTIME_DIRNAME = ".runtime"

_SESSION_GUIDANCE = (
    "请从当前系统提示中查找「Session Root」或「会话根目录」所在行，"
    f"提取形如 {SESSION_ROOT_PREFIX}<数字ID>/ 的绝对路径，"
    "并以 --session-root 显式传入。"
)

class SessionPathError(ValueError):
    """会话／项目根目录缺失、非法，或写入路径逃逸出根目录。"""


# ── 内部工具 ──────────────────────────────────────────────────────────────


def _normalise(raw: str, guidance: str) -> str:
    value = str(raw or "").strip()
    if not value:
        raise SessionPathError(f"根目录为空。{guidance}")
    if "\\" in value:
        raise SessionPathError(
            f"根目录必须是 POSIX 绝对路径，不得包含反斜杠：{raw}。{guidance}"
        )
    return value.rstrip("/") or "/"


def _reject_workspace(value: str, what: str) -> None:
    if value.startswith(WORKSPACE_MARKER) or WORKSPACE_MARKER in value:
        raise SessionPathError(
            f"{what}指向工作区 {WORKSPACE_MARKER}*，产物不得写入工作区。"
        )


def _first_non_empty(
    explicit: str | None, environment: Mapping[str, str], keys: Iterable[str]
) -> tuple[str | None, str]:
    if str(explicit or "").strip():
        return explicit, "显式参数"
    for key in keys:
        value = environment.get(key)
        if str(value or "").strip():
            return value, key
    return None, "显式参数"


def _contain(path: str | PurePosixPath, root: PurePosixPath, label: str) -> PurePosixPath:
    """把写入路径解析到根目录下；逃逸或指向工作区时拒绝。

    相对路径按根目录解析；绝对路径必须已经位于根目录内。手工消解 `.` 与 `..`，
    不触碰文件系统——校验必须在任何 IO 之前完成。
    """
    raw = str(path or "").strip()
    if not raw:
        raise SessionPathError("写入路径为空")
    _reject_workspace(raw.replace("\\", "/"), "写入路径")
    if "\\" in raw:
        raise SessionPathError(f"写入路径不得包含反斜杠：{path}")
    if root is None:
        raise SessionPathError(f"缺少{label}，无法校验写入路径。")

    candidate = PurePosixPath(raw)
    combined = candidate if candidate.is_absolute() else root / candidate

    parts: list[str] = []
    for part in combined.parts:
        if part == ".":
            continue
        if part == "..":
            if not parts or parts[-1] == combined.anchor:
                raise SessionPathError(f"写入路径逃逸出{label}：{path}")
            parts.pop()
            continue
        parts.append(part)
    resolved = PurePosixPath(*parts)

    if not resolved.is_relative_to(root):
        raise SessionPathError(
            f"写入路径 {resolved} 不在{label} {root} 内；所有产物必须写入其中。"
        )
    return resolved


# ── 会话空间 ──────────────────────────────────────────────────────────────


def resolve_session_root(
    explicit: str | None = None, *, env: Mapping[str, str] | None = None
) -> PurePosixPath:
    """按 显式参数 → BAIYING_SESSION_ROOT → BAIYING_SESSION 的顺序解析会话根目录。"""
    environment = os.environ if env is None else env
    candidate, source = _first_non_empty(
        explicit, environment, (ENV_SESSION_ROOT, ENV_SESSION_ID)
    )
    if source == ENV_SESSION_ID and candidate is not None:
        session_id = str(candidate).strip()
        if not session_id.isdigit():
            raise SessionPathError(
                f"{ENV_SESSION_ID}={session_id} 不是数字会话 ID，无法推导会话根目录。"
                f"{_SESSION_GUIDANCE}"
            )
        candidate = f"{SESSION_ROOT_PREFIX}{session_id}"
    if not str(candidate or "").strip():
        raise SessionPathError(f"未提供 Session Root。{_SESSION_GUIDANCE}")

    value = _normalise(candidate, _SESSION_GUIDANCE)
    _reject_workspace(value, f"{source} 的值")
    if not SESSION_ROOT_PATTERN.match(value + "/"):
        raise SessionPathError(
            f"{source} 的值 {candidate} 不是合法会话根目录，"
            f"必须形如 {SESSION_ROOT_PREFIX}<数字ID>/。{_SESSION_GUIDANCE}"
        )
    return PurePosixPath(value)


def assert_within_session(
    path: str | PurePosixPath, session_root: PurePosixPath
) -> PurePosixPath:
    return _contain(path, session_root, "会话根目录")


def session_path(session_root: PurePosixPath, *parts: str) -> PurePosixPath:
    if not parts:
        return session_root
    return assert_within_session(PurePosixPath(*parts).as_posix(), session_root)


# ── 阶段目录 ──────────────────────────────────────────────────────────────


def _require_stage(stage: str) -> str:
    value = str(stage or "").strip()
    if value not in STAGES:
        raise SessionPathError(
            f"未知阶段 {stage!r}；合法阶段为 {'、'.join(STAGES)}。"
            "阶段名是封闭集合，拼错会静默写到别处，故此处硬失败。"
        )
    return value


def stage_dir(session_root: PurePosixPath, stage: str) -> PurePosixPath:
    """阶段目录，直挂会话根。

    不设 ``deliverables/`` 中间层——一次会话即一件作品，会话 ID 本身就是命名空间；
    且该名称与实际内容不符（``.runtime/``、未采用的候选图、各阶段 ``.meta/`` 都不是交付物）。
    """
    return session_root / _require_stage(stage)


def meta_dir(session_root: PurePosixPath, stage: str) -> PurePosixPath:
    """阶段的机器契约目录。其中的内容**同属阶段产出**，只是机器读，不可当中间件清理。"""
    return stage_dir(session_root, stage) / META_DIRNAME


def runtime_dir(
    session_root: PurePosixPath, area: str | None = None
) -> PurePosixPath:
    """机器专用区。``area`` 可为阶段名（按阶段分，便于定向清理）或保留区名。

    阶段产出**不得置于此处**——否则清理中间件时会连带删除重做下游的依据。
    """
    base = session_root / RUNTIME_DIRNAME
    if area is None:
        return base
    value = str(area or "").strip()
    if value in RUNTIME_AREAS:
        return base / value
    return base / _require_stage(value)


# ── 项目空间 ──────────────────────────────────────────────────────────────


__all__ = [
    "VERSION",
    "STAGES",
    "RUNTIME_AREAS",
    "SessionPathError",
    "resolve_session_root",
    "assert_within_session",
    "session_path",
    "stage_dir",
    "meta_dir",
    "runtime_dir",
]
