"""四个业务 Skill 的统一请求门禁。"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

import yaml

from byclaw_caps.credentials import ConfigurationError, reject_plaintext_secrets


MODES = {
    "self-media-article": frozenset({"intent_task"}),
    "discover-writing-topics": frozenset({"discover", "evaluate", "series_plan"}),
    "write-article": frozenset({"plan_only", "full_article", "revise_article"}),
    "write-image-text-post": frozenset({"create", "derive", "revise"}),
    "write-video-script": frozenset({"create", "revise"}),
}
WEB_MODES = frozenset({"disabled", "on_demand", "required"})
ARTICLE_CONTENT_KINDS = frozenset({"analysis", "story_marketing", "short_fiction"})
ARTICLE_TRUTH_MODES = frozenset({"real_case", "adapted_case", "fictional_scenario"})


class SkillRequestError(ValueError):
    def __init__(self, message: str, *, field: str = ""):
        super().__init__(message)
        self.field = field

    def as_dict(self) -> dict[str, Any]:
        return {"status": "REQUEST_INVALID", "field": self.field or None}


def _load_brief(value: Any, *, base_dir: str | Path | None) -> Mapping[str, Any] | None:
    if isinstance(value, Mapping):
        return value
    if not str(value or "").strip() or base_dir is None:
        return None
    path = Path(str(value))
    if not path.is_absolute():
        path = Path(base_dir) / path
    if not path.is_file():
        raise SkillRequestError(f"ContentBrief 不存在：{path}", field="content_brief")
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, Mapping):
        raise SkillRequestError("ContentBrief 必须是对象", field="content_brief")
    return data


def validate_skill_request(request: Mapping[str, Any], *,
                           base_dir: str | Path | None = None) -> dict[str, Any]:
    if not isinstance(request, Mapping):
        raise SkillRequestError("SkillRequest 必须是对象")
    try:
        reject_plaintext_secrets(request, path="request")
    except ConfigurationError as exc:
        raise SkillRequestError(str(exc), field=str(exc.detail.get("field") or "")) from exc
    skill = str(request.get("skill") or "").strip()
    if skill not in MODES:
        raise SkillRequestError(
            f"未知 skill {skill!r}。可用：{'、'.join(MODES)}", field="skill")
    mode = str(request.get("mode") or "").strip()
    if mode not in MODES[skill]:
        raise SkillRequestError(
            f"{skill} 不支持 mode={mode!r}。可用：{'、'.join(sorted(MODES[skill]))}",
            field="mode")
    root_text = str(request.get("session_root") or "").strip()
    root = Path(root_text)
    if not (root.is_absolute() or root_text.startswith("/")):
        raise SkillRequestError("session_root 必须是绝对路径", field="session_root")
    normalized = str(root).replace("\\", "/")
    if "/by/.openclaw/workspace-" in normalized:
        raise SkillRequestError("session_root 不能指向工作区", field="session_root")

    content_brief = request.get("content_brief")
    if skill == "self-media-article":
        from byclaw_caps.article import validate_request
        try:
            return validate_request(dict(request))
        except ValueError as exc:
            raise SkillRequestError(str(exc), field="intents") from exc
    if skill != "discover-writing-topics" and not content_brief:
        raise SkillRequestError(f"{skill} 必须提供 content_brief 引用或对象",
                                field="content_brief")
    brief = _load_brief(content_brief, base_dir=base_dir)
    if skill != "discover-writing-topics" and brief is not None:
        status = str(brief.get("selection_status") or "")
        if status not in {"selected", "approved"}:
            raise SkillRequestError(
                "下游创作只接受 selection_status=selected|approved",
                field="content_brief.selection_status")

    inputs = request.get("input") or {}
    if not isinstance(inputs, Mapping):
        raise SkillRequestError("input 必须是对象", field="input")
    if skill == "write-article":
        kind = str(request.get("content_kind") or "analysis")
        if kind not in ARTICLE_CONTENT_KINDS:
            raise SkillRequestError("content_kind 必须为 analysis|story_marketing|short_fiction",
                                    field="content_kind")
        if kind != "analysis" and str(request.get("truth_mode") or "") not in ARTICLE_TRUTH_MODES:
            raise SkillRequestError("故事请求必须明确 truth_mode: real_case|adapted_case|fictional_scenario",
                                    field="truth_mode")
    if skill == "write-article" and mode == "revise_article" and not inputs.get(
            "existing_article"):
        raise SkillRequestError("revise_article 必须提供 input.existing_article",
                                field="input.existing_article")
    if skill == "write-image-text-post":
        if not str(inputs.get("channel") or "").strip():
            raise SkillRequestError("图文创作必须提供已解析的 input.channel",
                                    field="input.channel")
        if mode in {"derive", "revise"} and not inputs.get("derived_from"):
            raise SkillRequestError(f"{mode} 必须提供 input.derived_from",
                                    field="input.derived_from")
    if skill == "write-video-script":
        if not str(inputs.get("channel") or "").strip():
            raise SkillRequestError("视频脚本必须提供已解析的 input.channel",
                                    field="input.channel")
        try:
            duration = int(inputs.get("duration_seconds") or 0)
        except (TypeError, ValueError) as exc:
            raise SkillRequestError("input.duration_seconds 必须是正整数",
                                    field="input.duration_seconds") from exc
        if duration <= 0:
            raise SkillRequestError("input.duration_seconds 必须是正整数",
                                    field="input.duration_seconds")
        if mode == "revise" and not inputs.get("existing_script"):
            raise SkillRequestError("revise 必须提供 input.existing_script",
                                    field="input.existing_script")

    policy = request.get("retrieval_policy") or {}
    if not isinstance(policy, Mapping):
        raise SkillRequestError("retrieval_policy 必须是对象", field="retrieval_policy")
    web = policy.get("web_search") or {}
    if not isinstance(web, Mapping):
        raise SkillRequestError("retrieval_policy.web_search 必须是对象",
                                field="retrieval_policy.web_search")
    web_mode = str(web.get("mode") or "disabled")
    if web_mode not in WEB_MODES:
        raise SkillRequestError(
            "web_search.mode 只允许 disabled|on_demand|required",
            field="retrieval_policy.web_search.mode")
    rounds = int(web.get("max_rounds") or 0)
    if not 0 <= rounds <= 3:
        raise SkillRequestError("web_search.max_rounds 必须在 0—3",
                                field="retrieval_policy.web_search.max_rounds")
    if web_mode == "disabled" and rounds:
        raise SkillRequestError("联网禁用时 max_rounds 必须为 0",
                                field="retrieval_policy.web_search.max_rounds")

    result = dict(request)
    result["schema_version"] = str(request.get("schema_version") or "1.0")
    result["skill"] = skill
    result["mode"] = mode
    result["session_root"] = root_text
    result["input"] = dict(inputs)
    result["retrieval_policy"] = dict(policy)
    result["retrieval_policy"]["web_search"] = {**web, "mode": web_mode,
                                                  "max_rounds": rounds}
    return result


__all__ = ["MODES", "SkillRequestError", "validate_skill_request"]
