#!/usr/bin/env python3
"""SkillRequest 校验 CLI。"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml

from byclaw_caps._cli import EXIT_OK, add_common, dispatch
from byclaw_caps.skill_request import SkillRequestError, validate_skill_request


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="byclaw_caps.skill_request")
    sub = parser.add_subparsers(dest="command", required=True)
    validate = sub.add_parser("validate", help="校验四个业务 Skill 的统一请求")
    validate.add_argument("request")
    add_common(validate)
    return parser


def handle(args: argparse.Namespace):
    path = Path(args.request)
    if not path.is_file():
        raise SkillRequestError(f"请求文件不存在：{path}", field="request")
    text = path.read_text(encoding="utf-8")
    data = json.loads(text) if path.suffix.lower() == ".json" else yaml.safe_load(text)
    normalized = validate_skill_request(data, base_dir=path.resolve().parent)
    return {"ok": True, "request": normalized}, EXIT_OK


def main() -> int:
    return dispatch(build(), handle, usage_errors=(SkillRequestError, ValueError))


if __name__ == "__main__":
    raise SystemExit(main())
