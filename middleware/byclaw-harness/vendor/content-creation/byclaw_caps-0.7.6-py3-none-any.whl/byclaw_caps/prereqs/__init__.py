#!/usr/bin/env python3
"""部署前置自检：系统二进制与字体的三级降级。

图像栅格化要 chromium，视频合成要 ffmpeg，两者共用 CJK 字体。whl 与源码注入都解决不了
二进制，故单列为部署前置。

三级降级，**一律报出，不静默**：

    1  平台已装        首选
    2  工程自带件      启用并报出，建议平台预装
    3  都没有          明确错误码与安装命令，中止

第 2 级不静默是刻意的：自带件能救急，但版本与平台预装的未必一致，用户该知道跑在哪一级。

两处最容易漏：

一、**系统装了 ffmpeg 但没编译 libass。** `which ffmpeg` 通过，而 `ass=` 滤镜在代码中
   用了 352 处，字幕烧录全废。因此二进制存在不足以放行，必须验滤镜。
二、**字体缺失不报错。** 二进制装上了、字体没装，chromium 与 ffmpeg 都渲染方块，却都
   返回成功——产出的是看起来正常的坏图与坏视频。这是唯一一种「缺了不报错」的依赖，
   故单列一项校验。

探针（``which``／``run``）可注入，便于在不具备这些二进制的机器上测试全部分支。
"""

from __future__ import annotations

import hashlib
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

VERSION = "1.0.0"

STATUS_OK = "ok"
STATUS_BUNDLED = "bundled"
STATUS_MISSING_BINARY = "MISSING_BINARY"
STATUS_MISSING_FEATURE = "MISSING_FFMPEG_FEATURE"
STATUS_FEATURE_FALLBACK = "FFMPEG_FEATURE_FALLBACK"
STATUS_MISSING_FONT = "MISSING_CJK_FONT"
STATUS_MISSING_ENV = "MISSING_ENV"
STATUS_UNUSABLE_ENV = "UNUSABLE_ENV"
STATUS_MISSING_DIR = "MISSING_DIRECTORY"
STATUS_READONLY_DIR = "READONLY_DIRECTORY"
#: 被 ``--for`` 过滤掉的项。**显示成「本链路不需要」而不是消失**——
#: 消失了用户会以为漏检。
STATUS_NOT_NEEDED = "not_needed"
#: 平台注入的变量缺失。**不进填空表**——用户没有入口去配它。
STATUS_MISSING_PLATFORM = "MISSING_PLATFORM_ENV"

_PASSING = {STATUS_OK, STATUS_BUNDLED, STATUS_FEATURE_FALLBACK,
            STATUS_NOT_NEEDED}


class PrereqError(RuntimeError):
    """前置件缺失、损坏，或清单不可读。"""


# ── 清单 ──────────────────────────────────────────────────────────────────


def load_manifest(path: str | Path) -> dict[str, Any]:
    import yaml  # 延迟导入：清单读取之外的分支不需要它

    target = Path(path)
    if not target.is_file():
        raise PrereqError(f"前置清单不存在：{target}")
    data = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
    for section in ("binaries", "fonts"):
        if section not in data:
            raise PrereqError(f"前置清单缺少 {section} 段：{target}")
    return data


def _install_hint(spec: Mapping[str, Any]) -> str:
    install = spec.get("install") or {}
    apt = install.get("apt")
    if not apt:
        return "请参考 prereqs/install-prereqs.sh 安装。"
    return f"安装命令（Debian／Ubuntu）：apt-get install -y {apt}"


# ── 探针 ──────────────────────────────────────────────────────────────────


def _default_run(argv: Sequence[str]) -> str:
    try:
        done = subprocess.run(
            list(argv), capture_output=True, text=True, timeout=20, check=False
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return done.stdout or ""


# 浏览器在 Windows 与 macOS 上**不在 PATH 里**，只搜 PATH 会得到假阴性——
# 本机实测：Chrome 与 Edge 都装了，检查器却报 MISSING_BINARY。
# 假阴性比漏报更伤：开发机上天天报缺，人就不再看它，等真上生产也不会信。
_BROWSER_PATHS: dict[str, tuple[str, ...]] = {
    "win32": (
        "C:/Program Files/Google/Chrome/Application/chrome.exe",
        "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
        "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
        "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
    ),
    "darwin": (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    ),
}

#: 常见 CJK 字体文件名片段。Windows 自带前四种，Linux 通常是 Noto／思源。
CJK_FONT_PATTERNS: tuple[str, ...] = (
    "msyh*", "simhei*", "simsun*", "Deng*",
    "NotoSansCJK*", "NotoSerifCJK*", "SourceHanSans*", "SourceHanSerif*",
    "PingFang*", "Hiragino*",
)

_FONT_DIRS: dict[str, tuple[str, ...]] = {
    "win32": ("C:/Windows/Fonts",),
    "darwin": ("/System/Library/Fonts", "/Library/Fonts"),
    "linux": ("/usr/share/fonts", "/usr/local/share/fonts"),
}


def browser_candidates(platform: str) -> list[str]:
    """该平台上浏览器的标准安装路径。Linux 只靠 PATH，故返回空。"""
    return list(_BROWSER_PATHS.get(platform, ()))


def cjk_font_files(platform: str, glob: Callable[[str], list[str]]) -> list[str]:
    """扫平台字体目录找 CJK 字体。

    不能只靠 ``fc-list``——Windows 根本没这个命令，却装着微软雅黑与黑体。
    """
    found: list[str] = []
    for directory in _FONT_DIRS.get(platform, ()):
        for pattern in CJK_FONT_PATTERNS:
            found.extend(glob(f"{directory}/{pattern}"))
    return found


def _default_glob(pattern: str) -> list[str]:
    from glob import glob as _g

    return _g(pattern)


def _find(
    candidates: Iterable[str],
    which: Callable[[str], str | None],
    *,
    extra_paths: Iterable[str] = (),
    exists: Callable[[str], bool] | None = None,
) -> str | None:
    """先按名搜 PATH，再查平台标准路径。顺序与现有发现逻辑保持一致。"""
    for name in candidates:
        found = which(name)
        if found:
            return found
    probe = exists if exists is not None else (lambda p: Path(p).is_file())
    for path in extra_paths:
        if probe(path):
            return path
    return None


def _missing_filters(
    executable: str, required: Iterable[str], run: Callable[[Sequence[str]], str]
) -> list[str]:
    output = run([executable, "-filters"])
    tokens = set()
    for line in output.splitlines():
        parts = line.split()
        # `ffmpeg -filters` 每行形如 " T.. name  in->out  描述"，取第二列
        if len(parts) >= 2:
            tokens.add(parts[1])
    return [name for name in required if name not in tokens]


# ── 逐项校验 ──────────────────────────────────────────────────────────────


def _check_binary(
    name: str,
    spec: Mapping[str, Any],
    *,
    which: Callable[[str], str | None],
    run: Callable[[Sequence[str]], str],
    bundled: set[str],
    platform: str = "linux",
    exists: Callable[[str], bool] | None = None,
) -> dict[str, Any]:
    item: dict[str, Any] = {"name": name, "used_by": spec.get("used_by")}
    has_bundle = bool(spec.get("bundled")) and name in bundled
    # 浏览器另查平台标准路径；ffmpeg 一类仍只靠 PATH
    extra = browser_candidates(platform) if name == "chromium" else ()
    resolved = _find(
        spec.get("candidates") or [name], which, extra_paths=extra, exists=exists
    )

    if resolved is None:
        if has_bundle:
            item.update(
                status=STATUS_BUNDLED,
                note=f"系统未安装 {name}，已启用工程自带件；建议平台预装以统一版本。",
            )
        else:
            item.update(status=STATUS_MISSING_BINARY, hint=_install_hint(spec))
        return item

    required = spec.get("required_filters") or []
    if not required:
        item.update(status=STATUS_OK, resolved=resolved)
        return item

    # 二进制存在不足以放行：精简版 ffmpeg 常缺 libass／libfreetype
    missing = _missing_filters(resolved, required, run)
    if not missing:
        item.update(status=STATUS_OK, resolved=resolved)
        return item

    item["missing_filters"] = missing
    item["resolved"] = resolved
    if has_bundle:
        item.update(
            status=STATUS_FEATURE_FALLBACK,
            note=(
                f"系统 {name} 缺滤镜 {'、'.join(missing)}，已切换到工程自带件；"
                "不能因为二进制存在就放行。"
            ),
        )
    else:
        item.update(
            status=STATUS_MISSING_FEATURE,
            hint=(
                f"系统 {name} 存在但缺滤镜 {'、'.join(missing)}，需带 libass／libfreetype "
                f"编译的版本。{_install_hint(spec)}"
            ),
        )
    return item


def _check_font(
    name: str,
    spec: Mapping[str, Any],
    *,
    which: Callable[[str], str | None],
    run: Callable[[Sequence[str]], str],
    bundled: set[str],
    platform: str = "linux",
    glob: Callable[[str], list[str]] | None = None,
) -> dict[str, Any]:
    item: dict[str, Any] = {"name": name, "used_by": spec.get("used_by")}
    has_bundle = bool(spec.get("bundled")) and name in bundled
    lang = spec.get("lang") or "zh"

    fc_list = which("fc-list")
    listed = run([fc_list, f":lang={lang}"]).strip() if fc_list else ""
    if listed:
        item.update(status=STATUS_OK, sample=listed.splitlines()[0])
        return item

    # fc-list 不存在或无结果时再扫平台字体目录——Windows 没有 fc-list，
    # 却装着微软雅黑与黑体，只问 fc-list 会得到假阴性
    files = cjk_font_files(platform, glob or _default_glob)
    if files:
        item.update(status=STATUS_OK, sample=files[0])
        return item

    reason = "系统未安装 fc-list，且平台字体目录未见 CJK 字体" if not fc_list else f"系统无 lang={lang} 字体"
    if has_bundle:
        payload = spec.get("payload") or ""
        item.update(
            status=STATUS_BUNDLED,
            font_path=f"~/by/.prereqs/fonts/{payload}",
            note=f"{reason}，已启用工程自带字体；缺字体不会报错，只会渲染出方块。",
        )
    else:
        item.update(
            status=STATUS_MISSING_FONT,
            hint=(
                f"{reason}。缺字体时 chromium 与 ffmpeg 均**不报错**，直接产出满屏方块的"
                f"图像与成片，故此处硬失败。{_install_hint(spec)}"
            ),
        )
    return item


# ── 入口 ──────────────────────────────────────────────────────────────────


def check_all(
    manifest: Mapping[str, Any],
    *,
    which: Callable[[str], str | None] | None = None,
    run: Callable[[Sequence[str]], str] | None = None,
    bundled: set[str] | None = None,
    platform: str | None = None,
    exists: Callable[[str], bool] | None = None,
    glob: Callable[[str], list[str]] | None = None,
) -> dict[str, Any]:
    """逐项校验，返回结构化结果。

    ``bundled`` 是当前可用的自带件名集合，由调用方按 ``~/by/.prereqs/`` 的实际内容给出。
    ``platform``／``exists``／``glob`` 可注入，便于在任一平台上测全部分支。
    """
    probe_which = shutil.which if which is None else which
    probe_run = _default_run if run is None else run
    available = set() if bundled is None else set(bundled)
    host = sys.platform if platform is None else platform

    items: list[dict[str, Any]] = []
    for name, spec in (manifest.get("binaries") or {}).items():
        items.append(
            _check_binary(
                name, spec, which=probe_which, run=probe_run, bundled=available,
                platform=host, exists=exists,
            )
        )
    for name, spec in (manifest.get("fonts") or {}).items():
        items.append(
            _check_font(
                name, spec, which=probe_which, run=probe_run, bundled=available,
                platform=host, glob=glob,
            )
        )

    return {
        "ok": all(item["status"] in _PASSING for item in items),
        "items": items,
        "degraded": [i["name"] for i in items if i["status"] != STATUS_OK],
    }



# ── 环境变量与目录 ────────────────────────────────────────────────────────
#
# 原先的自检只有二进制与字体。一次真实失败：要重新标定语速时
# `MINIMAX_API_KEY` 不在环境里，**没有任何东西提前说**，脚本跑到一半才
# `KeyError`。换成数字员工在平台上跑，它会在第 10 步配音时崩，
# 而第 8 步出图的钱已经花掉了。


def _known_skills(manifest: Mapping[str, Any]) -> set[str]:
    names: set[str] = set()
    for spec in (manifest.get("env") or {}).values():
        names.update(spec.get("required_by") or ())
    return names


def check_env(
    manifest: Mapping[str, Any],
    *,
    environ: Mapping[str, str],
    skill: str | None = None,
    live: bool = False,
    probe: Callable[[str, str], bool] | None = None,
) -> list[dict[str, Any]]:
    """环境变量是否配了（离线），以及能不能用（``live=True``）。

    **两档必须分开。** 配了但过期的 key 是最常见的一种，离线查不出来；
    而合成一档的话，日常自检就得联网且花钱。

    **值本身绝不进入返回结果**，连前几位也不行——回显前缀看着无害，
    但足以把密钥泄进日志再拼回去。数字员工提示词里那条
    「完整环境变量不进入日志、结果文件或回复」在这里最容易被违反。
    """
    specs = dict(manifest.get("env") or {})
    if skill is not None and skill not in _known_skills(manifest):
        # 写错 skill 名会让整份检查静默变成「什么都不需要」，全绿。
        raise PrereqError(
            f"未知 skill {skill!r}。清单里出现过的："
            f"{'、'.join(sorted(_known_skills(manifest))) or '（无）'}。")

    items: list[dict[str, Any]] = []
    for name, spec in specs.items():
        needed_by = list(spec.get("required_by") or ())
        item: dict[str, Any] = {
            "kind": "env", "name": name,
            "used_by": spec.get("used_by", ""),
            "required_by": needed_by,
            "hint": spec.get("hint", ""),
        }
        if skill is not None and skill not in needed_by:
            item["status"] = STATUS_NOT_NEEDED
            item["detail"] = f"{skill} 这条链路不需要它"
            items.append(item)
            continue

        value = str(environ.get(name) or "").strip()
        if not value:
            # `FOO=` 写在 .env 里看着像配了，实际取到空串，调用时才 401。
            item["status"] = STATUS_MISSING_ENV
            item["detail"] = "未配置"
        elif not live:
            item["status"] = STATUS_OK
            item["detail"] = "已配置"
        else:
            # 三态：True 通、False 不通、**None 表示这一项没有探活方式**。
            # 把 None 当成通过，会让 `--live` 报「全部可用」而其实只探了一半——
            # 比不探更坏：用户据此以为环境没问题，真正的失败推迟到跑任务时。
            verdict = probe(name, value) if probe is not None else None
            if verdict is False:
                item["status"] = STATUS_UNUSABLE_ENV
                item["detail"] = "已配置但调不通——多半是过期、额度用尽或出口 IP 未加白"
            elif verdict is True:
                item["status"] = STATUS_OK
                item["detail"] = "已配置，探活通过"
                item["probed"] = True
            else:
                item["status"] = STATUS_OK
                item["detail"] = "已配置；本项无探活方式，**未验证**可用性"
        items.append(item)
    return items


# `_PROVIDER_HINTS` 与 `provider_hint` 删掉了：它们的唯一调用方是
# `integrations.yaml` 的凭据折叠，那段随配置文件一起废除。留着就是死代码——
# 而本仓库栽过五次的正是反过来的那种（写了没接进去）。
#
# 公众号那条提示（含出口 IP 白名单）在 `check_wechat_connector` 里，
# 它本来就是自带的，不经过这张表。

#: 项目就绪的四种状态。取代原来的 `PROJECT_*`——项目空间作废之后，
#: 「目录在不在、是不是空的、有没有 integrations.yaml」三个问题全都不成立了。
CLOUD_OK = "ok"
CLOUD_NO_RESOURCE_ID = "no_resource_id"
CLOUD_UNREACHABLE = "unreachable"
CLOUD_NO_MAPPING = "no_mapping"


def check_wechat_connector(*, environ=None, live: bool = False, probe=None,
                          already=()) -> list[dict]:
    """公众号连接器：两个环境变量，由 ByClaw 后台的「微信公众号 API」连接器注入。

    **这一项非查不可。** 它替掉的是原来的 `check_channel_accounts`——那套按
    `account.yaml` 逐账号推导变量名的多账号设计，随 `byclaw_caps.deliver` 一起作废。
    删掉它的时候差点把公众号凭据自检一起带走了：清单的 `platform` 段里没有这两个变量，
    没人再声明它们，**自检会报「全部就绪」而连接器根本没配**——
    而那正是自检存在的意义。

    探活的价值在这一项上最高：出口 IP 没加白名单时凭据完全正确却一律 40164，
    离线检查永远发现不了。
    """
    import os

    env = os.environ if environ is None else environ
    # 清单里已经声明过的不重复报。同一个变量出现两次，读报告的人会以为
    # 有两处要配，而 `probed` 也会多数一次。
    seen = set(already)
    hint = ("在 ByClaw 后台配置「微信公众号 API」连接器；"
            "**别忘了把平台出口 IP 加进公众号后台的白名单**——"
            "没加时凭据完全正确却一律 40164")
    items = []
    for name in ("WECHAT_APPID", "WECHAT_APPSECRET"):
        if name in seen:
            continue
        value = str(env.get(name) or "")
        item = {
            "kind": "env",
            "name": name,
            "used_by": "渠道发布助理（bycli weixin 建草稿、群发、查状态）",
            "required_by": [],
            "hint": hint,
            "status": STATUS_OK if value else STATUS_MISSING_ENV,
            "detail": "已配置" if value else "未配置——连接器没配或没注入到本沙箱",
        }
        # 只有 appsecret 能探活：探活要拿 appid + secret 一起去换 token。
        items.append(_apply_probe(item, value, live=live, probe=probe)
                     if value and name == "WECHAT_APPSECRET" else item)
    return items


def cloud_status(*, resource_id: str, probe=None, mapping=None) -> tuple:
    """项目就绪 = 拿得到 cloudResourceId + 云盘可达 + 两份映射在。

    **三样分开报。** 它们的处置完全不同：第一样是上下文没取到（去核对会话上下文），
    第二样是部署或权限（去修部署），第三样是初始化没跑完（去让平台生成映射）。
    合成一句「项目没准备好」，人只能挨个试。

    这是原 `project_root_status` 的位置。那套判据（目录存在／非空／有
    integrations.yaml）随项目空间一起作废——素材只在云盘上，本地没有目录可看。
    """
    if not str(resource_id or "").strip():
        return CLOUD_NO_RESOURCE_ID, (
            "取不到项目云盘的 cloudResourceId（会话上下文里的 cloud_resource_id）。"
            "**不要猜 ID，也不要拿普通知识库的 resourceId 冒充**——"
            "那会读到另一个知识库并当作项目云盘用。")
    if probe is not None and not probe():
        return CLOUD_UNREACHABLE, (
            "项目云盘够不着。检查 node 是否可用、project-cloud-knowledge 是否部署、"
            "当前用户有没有这个云盘的权限。")
    # 够不着就不去查映射：映射也在云盘上，必然一起读不到，
    # 再报一条「映射缺失」是噪音，而且会把人引去改映射。
    if mapping is not None and not mapping():
        return CLOUD_NO_MAPPING, (
            "云盘上没有 /.user_settings/_project.yaml 或 <工号>.yaml。"
            "映射由平台在项目创建、成员加入时生成，读不到说明初始化没跑完——"
            "请让平台补齐，**不要手工遍历云盘代替它**。")
    return CLOUD_OK, ""


#: 团队公共映射的模板。**`${...}` 一律块状写**——YAML 的流式序列 `[ ]` 里
#: `{` 是保留字符，`[/知识/发布渠道/${APP_ID}]` 直接是解析错误，
#: 而那意味着每一次读映射都失败。
_PROJECT_MAPPING = """# 团队公共映射：域名 → 云盘目录。项目创建时生成，人可以改。
#
# 键是**受控知识域名**，不是目录名——两者不必同名，这个文件就是它们之间的翻译。
# 带 ${{...}} 的值必须块状写：流式序列 [ ] 里 {{ 是 YAML 保留字符。
素材:        [/素材/公共]
# 子域必须各自映射。**父域映射不会自动覆盖子域**——查 `素材.事件` 时
# 映射里没有它，返回的是 NO_SOURCE_FOR_DOMAIN，而那按约定「不算故障」，
# 于是助理会得出「没有这类素材」并接着写。**静默，且方向全错。**
素材.产品:    [/素材/公共/产品]
素材.事件:    [/素材/公共/事件]
素材.会议纪要:  [/素材/公共/会议纪要]
# 实体域：`/KnowledgeEntity` 是系统从素材抽出来的实体，一个概念一个文件。
# **只读**——云盘 CLI 禁止往这里 upload/move/mkdir，只有 entity-discovery 能写。
# 它回答「有什么、彼此怎么连」；**要原话仍回 `素材`**——实体的定义段是综合改写的。
素材.实体:    [/KnowledgeEntity]
写法:        [/知识/写法模板, /知识/写法参考, /知识/写法资产]
写法.模板:    [/知识/写法模板]
写法.参考:    [/知识/写法参考]
写法.资产:    [/知识/写法资产]
# 领域地图与术语表：本号的知识结构，L3。地图是只读的三列词表，
# 打标、检索词转换、覆盖率反查都读它；术语表定口径与禁用别名。
#
# **新增一个领域不用改这里**——在 /知识/领域知识/ 下建子目录即可，目录递归是自动的。
# 不要写 `领域.数据本体论` 这类子域：映射里没有就是 NO_SOURCE_FOR_DOMAIN，而那不算故障。
#
# ⚠️ /知识/领域知识/ 根目录**不要放文件**。取数是「当层没有匹配文件才往下」，
#    根目录一旦有 md，查询可能停在那层，取不到各领域的地图。
领域:        [/知识/领域知识]
渠道:        [/知识/发布渠道]
渠道.账号档案:
  - /知识/发布渠道/${{APP_ID}}
# 成品底下是 <合集>/<作品名>/正文.md，隔着两层——**映射指到 APP_ID 这层就行**，
# 取数会往下走（当层没有匹配文件才往下，见 query 的 cloud 驱动）。
成品:
  - /成品/{channel}/${{APP_ID}}
运营:
  - /运营/{channel}/${{APP_ID}}
"""

#: 个人映射的模板。**只放按规则能定的那一条**——助理推断出来的位置不写进去，
#: 一次猜错就永久污染映射，下次还会被当成用户说过的直接用。
_USER_MAPPING = """# 个人映射：只覆盖这个人特有的域。公共那份作基底，这里**按域整条覆盖**。
#
# 整条覆盖而不是逐项合并——否则「我想去掉公共那条」做不到。
素材:
  - /素材/个人/${USER_CODE}
  - /素材/公共
"""


def render_project_mapping(*, channel: str = "微信公众号") -> str:
    """团队公共映射的内容。`channel` 进 `成品`／`运营` 的路径。"""
    return _PROJECT_MAPPING.format(channel=channel)


def render_user_mapping() -> str:
    """个人映射的内容。规则化生成，不需要问人。"""
    return _USER_MAPPING


def check_cloud_mapping(*, reader, user_code: str = "") -> tuple:
    """两份映射在不在、能不能解析。返回 `(状态, 人话, 缺的路径列表)`。

    **点名缺的是哪一份。** 只说「映射缺失」，人不知道该补公共那份还是自己那份——
    前者是平台初始化没跑完，后者是这个成员加入时漏生成，处置不同。

    **能读到但解析不了，与读不到一样算缺**：两种情况都卡住取材，
    报「就绪」等于把问题推到第一次取材时才炸。
    """
    from byclaw_caps.query.mapping import MAPPING_DIR, PROJECT_MAPPING, parse_mapping

    wanted = [PROJECT_MAPPING]
    if str(user_code or "").strip():
        wanted.append(str(user_code).strip() + ".yaml")

    absent, broken = [], []
    for name in wanted:
        path = MAPPING_DIR + "/" + name
        try:
            text = reader(path)
        except Exception:
            absent.append(path)
            continue
        try:
            parse_mapping(text, label=path)
        except Exception as exc:
            # **「没有」与「有但坏了」必须分开。** 坏了多半是人手改错了一行，
            # 拿模板覆盖过去等于把他的改动删掉，而他不会知道——
            # 下次发现「我改的怎么没了」时已经没有原文可对。
            broken.append((path, str(exc).split("：")[-1][:80]))
    if not absent and not broken:
        return CLOUD_OK, "", []

    parts = []
    if absent:
        parts.append("缺这几份：" + "、".join(absent))
    if broken:
        parts.append("这几份在但解析不了（**多半是手改错了一行，不会被自动覆盖**）："
                     + "；".join(f"{p} — {why}" for p, why in broken))
    return CLOUD_NO_MAPPING, (
        "；".join(parts) + "。映射决定知识域落到哪个云盘目录，"
        "缺了取材直接报 MAPPING_MISSING。**不要手工遍历云盘代替它**。"), absent


def check_bound_models(agent_id: str, *, kinds=None, resolve=None,
                       session_root=None) -> list:
    """**某个数字员工**绑没绑文生图／文生语音模型。

    **删掉 `MINIMAX_API_KEY` 与 `ARK_API_KEY` 之后不能只删不补。** 删掉之后
    「有没有绑模型」就没人检查了，而自检会照样报「全部就绪」，一路跑到生图那步才炸。

    检查对象从「环境变量在不在」变成「模型绑没绑」——**那才是实际会失败的东西**。

    ## `agent_id` 是「查谁」，不是「谁在查」

    生图与配音由具体的创作员工执行，凭据按各自的 agentId 解析。而自检通常由
    写作支持助理跑——**它自己不生图不配音**。拿它的 id 来查必然「未绑定」，
    报告却会说「到后台给这个数字员工绑模型」，指向一个根本不需要模型的员工。

    ## `kinds` 也要能收窄

    只做文章配图的员工不配音，两类都查会给它挂一条假的「配音未绑定」。
    不给 `kinds` 时两类都查（不知道该查哪些时，宁可多报也不漏报）。
    """
    from byclaw_caps.credentials.resolve import KINDS, CredentialError

    if resolve is None:
        from byclaw_caps.credentials.resolve import resolve_credentials as resolve

    wanted = tuple(KINDS) if kinds is None else tuple(kinds)
    unknown = [k for k in wanted if k not in KINDS]
    if unknown:
        # 在任何请求之前拒绝：拼错的 kind 静默跳过，等于漏检而没人知道
        raise ValueError(
            f"未知的模型用途 {unknown}。可用：{'、'.join(sorted(KINDS))}。")

    items = []
    for kind, (field, label) in sorted((k, KINDS[k]) for k in set(wanted)):
        item = {
            "kind": "model", "name": field, "required_by": [],
            "used_by": f"{label}（数字员工 {agent_id or '?'}；按 agentId 运行时解析）",
        }
        if not str(agent_id or "").strip():
            # 报「查不了」而不是「都好」：报「都好」的话，真正没绑模型的 agent
            # 会一路跑到生图那一步才失败。
            items.append(dict(item, status=STATUS_MISSING_ENV,
                              hint="把 agent 上下文里的 agentId 传进来再查",
                              detail="没有 agentId，无法检查模型绑定"))
            continue
        try:
            resolved = resolve(agent_id, kind=kind, session_root=session_root)
        except CredentialError as exc:
            hint = (f"到 ByClaw 后台给数字员工 {agent_id} 绑定一个{label}模型"
                    if exc.code == "MODEL_NOT_BOUND" else "")
            items.append(dict(item, status=STATUS_MISSING_ENV, hint=hint,
                              detail=f"[{exc.code}] {exc}",
                              # **把「这个 id 是你传进来的」写进输出里。** 只写在提示词里
                              # 不够：实测跑自检的助理传了自己的 id，于是报告说
                              # 「给数字员工 X 绑模型」——而 X 根本不生图。
                              # 规则放进工具输出，念报告的人才会自己发现指错了人。
                              checked_agent=agent_id,
                              note=("这是调用方传进来的 agentId。生图由文章创作／图文创作／"
                                    "视频创作助理执行，配音只有视频创作助理执行——"
                                    "**先确认它是其中之一**，别的员工本来就不需要绑模型")))
            continue
        items.append(dict(item, status=STATUS_OK, hint="",
                          detail=f"已绑定 {resolved.get('providerName')} "
                                 f"{resolved.get('modelCode') or resolved.get('modelId')}"))
    return items


def _apply_probe(item: dict, value: str, *, live: bool, probe) -> dict:
    """对一个已配置的条目做探活。三条路（清单 env、平台注入、集成派生）共用。

    `--live` 曾经只挂在清单 `env:` 那一条路上。`env:` 被清空、凭据改走另外
    两条之后，探活**什么都探不到了**——`probed: 0`。诚实，但功能已死，
    而报告读起来像「探活跑过了」。**一个探不到东西的探活，比没有探活更危险。**

    三态：True 通、False 不通、None 表示这一项没有探活方式（不算通过）。
    """
    if not live or probe is None:
        return item
    verdict = probe(item["name"], value)
    if verdict is False:
        # 探过了，只是没通过。**失败也要计入 probed**——否则「全探过全不通」
        # 和「一项都没探」长得一样，而这两件事的处置完全相反。
        item["probed"] = True
        item["status"] = STATUS_UNUSABLE_ENV
        item["detail"] = "已配置但调不通——多半是过期、额度用尽或出口 IP 未加白"
    elif verdict is True:
        item["detail"] = item.get("detail", "已配置") + "，探活通过"
        item["probed"] = True
    else:
        item["detail"] = item.get("detail", "已配置") + "；本项无探活方式，**未验证**"
    return item


def check_platform(manifest, *, environ, live: bool = False, probe=None) -> list[dict]:
    """平台注入的变量：**只报不填**。

    这些由运行沙箱注入，用户没有配置入口。缺了照样跑不动，但该找的是平台方。

    让人去填一个填了也没用的东西，比不提示更坏——他会以为自己配错了，反复试。
    所以它们出现在报告里，**不出现在填空表里**。
    """
    items = []
    for name, spec in (manifest.get("platform") or {}).items():
        value = str(environ.get(name) or "").strip()
        item = {
            "kind": "platform", "name": name,
            "used_by": spec.get("used_by", ""),
            "status": STATUS_OK if value else STATUS_MISSING_PLATFORM,
            "detail": "已注入" if value else
                      "**平台未注入**——这一项由运行沙箱提供，不是你能配的，请联系平台方",
        }
        items.append(_apply_probe(item, value, live=live, probe=probe)
                     if value else item)
    return items


def check_directories(
    manifest: Mapping[str, Any],
    *,
    environ: Mapping[str, str],
    is_dir: Callable[[str], bool] | None = None,
    is_writable: Callable[[str], bool] | None = None,
) -> list[dict[str, Any]]:
    """目录映射：不只是存在，**还要可写**。

    只读挂载是最坏的一种：目录在、看着正常，等到写产物时才失败——
    那时图已经出了、音已经配了。
    """
    import os

    exists = (lambda p: Path(p).is_dir()) if is_dir is None else is_dir
    writable = ((lambda p: os.access(p, os.W_OK))
                if is_writable is None else is_writable)

    items: list[dict[str, Any]] = []
    for name, spec in (manifest.get("directories") or {}).items():
        source = spec.get("from", "")
        item: dict[str, Any] = {
            "kind": "directory", "name": name, "from": source,
            "used_by": spec.get("used_by", ""),
            "hint": spec.get("hint", ""),
        }
        value = str(environ.get(source) or "").strip()
        if not value:
            item["status"] = STATUS_MISSING_DIR
            item["detail"] = f"环境变量 {source} 未设置"
        elif not exists(value):
            item["status"] = STATUS_MISSING_DIR
            item["detail"] = f"{source} 指向的目录不存在"
        elif spec.get("writable") and not writable(value):
            item["status"] = STATUS_READONLY_DIR
            item["detail"] = f"{source} 指向的目录不可写——产物会在写盘时才失败"
        else:
            item["status"] = STATUS_OK
            item["detail"] = "存在且可写" if spec.get("writable") else "存在"
        items.append(item)
    return items


def readiness_report(
    manifest: Mapping[str, Any],
    *,
    environ: Mapping[str, str],
    skill: str | None = None,
    live: bool = False,
    probe: Callable[[str, str], bool] | None = None,
    agent_id: str = "",
    model_kinds=None,
    session_root=None,
    **binary_kwargs: Any,
) -> dict[str, Any]:
    """完整就绪报告。

    **按依赖顺序排：先二进制与字体，再环境变量，最后目录。**
    顺序反了会出现「配了 key 但 ffmpeg 没装」这种白配——
    用户照着报告一步步做，顺序就是他做事的顺序。

    结果分成 ``blocking`` 与 ``ready`` 两份：已就绪的折叠，只展开缺的。
    """
    items: list[dict[str, Any]] = []
    if manifest.get("binaries") or manifest.get("fonts"):
        items.extend(check_all(manifest, **binary_kwargs)["items"])
    for item in items:
        item.setdefault("kind", "binary")
    env_items = check_env(manifest, environ=environ, skill=skill,
                          live=live, probe=probe)

    # 模型绑定折进同一份报告。原先这里折的是 `integrations.yaml` 的凭据诊断，
    # 那个文件废除了；**折叠这个动作要保留**——分成两条命令各报一半，
    # 正是这个仓库反复栽的跟头。
    if agent_id:
        env_items.extend(check_bound_models(
            agent_id, kinds=model_kinds, session_root=session_root))

    items.extend(env_items)
    items.extend(check_platform(manifest, environ=environ,
                                live=live, probe=probe))
    items.extend(check_directories(manifest, environ=environ))

    blocking = [i for i in items if i["status"] not in _PASSING]
    ready = [i for i in items if i["status"] in _PASSING]
    return {"ok": not blocking, "items": items,
            "probed": sum(1 for i in items if i.get("probed")),
            "blocking": blocking, "ready": ready,
            "summary": (f"{len(ready)} 项就绪，{len(blocking)} 项待配置"
                        if blocking else f"{len(ready)} 项全部就绪")}



# ── 探活 ──────────────────────────────────────────────────────────────────
#
# 三态返回：True 通、False 不通、**None 表示这一项没有探活方式**。
# None 不能当成通过——见 `check_env` 里的说明。


def _probe_tavily(value: str) -> bool | None:
    import httpx

    try:
        got = httpx.post("https://api.tavily.com/search",
                         json={"api_key": value, "query": "ok", "max_results": 1},
                         timeout=30)
    except Exception:
        return False
    return got.status_code == 200


def _probe_wechat(value: str) -> bool | None:
    """公众号凭据。**这一项探活的价值最高**：

    出口 IP 没加白名单时，凭据本身完全正确，却一律 40164——
    离线检查永远发现不了，而它是最常见的一种部署失败。
    """
    import os

    import httpx

    appid = os.environ.get("WECHAT_APPID")
    if not appid:
        return None
    try:
        got = httpx.get("https://api.weixin.qq.com/cgi-bin/token",
                        params={"grant_type": "client_credential",
                                "appid": appid, "secret": value},
                        timeout=30).json()
    except Exception:
        return False
    return "access_token" in got


_LIVE_PROBES: dict[str, Callable[[str], bool | None]] = {
    # MINIMAX / ARK 的探针随那两个环境变量一起删掉了。凭据现在按 agentId
    # 运行时解析，「能不能用」由 check_bound_models 查绑定关系回答。
    "TAVILY_API_KEY": _probe_tavily,
    "WECHAT_APPSECRET": _probe_wechat,
}


def probe_for(name: str) -> Callable[[str], bool | None] | None:
    """取某个环境变量的探活方式。没有就返回 ``None``，**不要伪造一个恒真的**。

    公众号密钥按账号命名（``WECHAT_PUBLIC_ACCOUNT_APPSECRET__<账号>``），
    所以不能只做精确匹配——改名那次把探活悄悄弄断了：`--live` 从 3 项掉到 2 项，
    漏掉的正是最值钱的那条（出口 IP 未加白名单时凭据完全正确却一律 40164）。

    前缀匹配只认 ``WECHAT_``+``_APPSECRET``，不会把 ``SOME_APPSECRET`` 也算进来。
    """
    key = str(name)
    direct = _LIVE_PROBES.get(key)
    if direct is not None:
        return direct
    if key.startswith("WECHAT_") and "_APPSECRET" in key:
        return _probe_wechat
    return None


def default_probe(name: str, value: str) -> bool | None:
    probe = probe_for(name)
    return None if probe is None else probe(value)


# ── 自带件校验 ────────────────────────────────────────────────────────────


def verify_payload(path: str | Path, expected_sha256: str) -> bool:
    """校验自带件完整性。

    不存在返回 ``False``（交由调用方决定下载或降级）；存在但哈希不符**抛错而非覆盖**——
    覆盖会掩盖「分发件被篡改或截断」这类问题，而它正是解压幂等最该拦住的。
    """
    target = Path(path)
    if not target.is_file():
        return False
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    if digest != expected_sha256:
        raise PrereqError(
            f"自带件哈希不符：{target}\n  期望 {expected_sha256}\n  实际 {digest}\n"
            "不覆盖已有文件——请确认分发件来源后手动删除再重试。"
        )
    return True


# ── 开局上下文 ────────────────────────────────────────────────────────────
#
# 平台实测的两次会话各跑了 64、65 次工具调用，其中 9 次是同一批探路：
# 项目在哪、是哪个项目号、有哪些数据域、发哪个号、有没有 audience.md、
# 能力文档在哪、现在几点。**答案每次都一样，却每次都重新问**，最后那条
# 还是 `find /` 全盘扫描。
#
# 三条不可退让的性质：不回显密钥、不起子进程、项目根不存在时给候选而不是报错。


def capability_docs() -> dict[str, str]:
    """各能力 SKILL.md 的真实路径。

    实测里 agent 用 `find / -path "*workflow*SKILL.md"` 找它——全盘扫描，
    而这个包自己就知道自己装在哪。**能靠 import 拿到的东西不该去搜。**
    """
    import byclaw_caps

    base = Path(byclaw_caps.__file__).parent
    return {child.name: str(child / "SKILL.md")
            for child in sorted(base.iterdir())
            if child.is_dir() and (child / "SKILL.md").is_file()}


def _clock(now) -> dict[str, str]:
    """时间的三种形态。

    agent 要 `date` 是为了填 `fact_checks[].verified_at`（带时区 ISO 8601）与
    `source_date`（YYYY-MM-DD）。**报出来的必须是能直接抄进 YAML 的形态**，
    否则它还得自己转一次，等于没省。
    """
    from datetime import datetime, timezone

    moment = now or datetime.now(timezone.utc)
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    utc = moment.astimezone(timezone.utc)
    local = moment.astimezone()
    return {
        # 截到秒。微秒对 `verified_at` 没有意义，只是噪声。
        "utc": utc.isoformat(timespec="seconds").replace("+00:00", "Z"),
        "local": local.isoformat(timespec="seconds"),
        "date": utc.date().isoformat(),
    }


def _session_of(session_root) -> dict:
    """会话目录里用户刚上传了什么。

    只报**可见文件**：`.runtime/`、`10-topic/` 这些是工作流自己建的，
    混进「用户上传了什么」里会让 agent 去读自己刚写的东西。
    """
    if session_root is None:
        return {"path": None, "uploads": [], "note": "未传 --session-root"}
    root = Path(str(session_root))
    if not root.is_dir():
        return {"path": str(root), "uploads": [],
                "note": f"会话目录 {root} 不存在"}
    uploads = sorted(child.name for child in root.iterdir()
                     if child.is_file() and not child.name.startswith("."))
    return {"path": str(root), "uploads": uploads, "note": ""}


def session_context(*, session_root=None, environ=None, now=None) -> dict:
    """一条命令回答「我在哪、有什么、几点了」。

    **纯本地，不打云盘。** 这是它与 `check` 分开的全部理由：`check` 回答
    「环境配好了吗」（可能联网、可能很慢），`context` 回答「我在哪」，每次开局都跑。
    合成一条会让每次开局都付探活的代价。

    原先它还扒项目空间列受众、数据域、已发作品——**那三样随项目空间一起没了**。
    素材只在云盘上，要列就得发请求，那就不再是「纯本地必须快」的命令了。
    现在改由 `query search --domain 成品` 之类按需去查。

    这里只报**本地就能知道的**：几点了、会话目录里用户上传了什么、
    能力文档在哪、平台上下文取到了哪几个值。
    """
    import os

    env = os.environ if environ is None else environ
    # 只报「取到没取到」，**不报值**：这份输出会进 agent 的上下文与回执。
    context = {name: bool(str(env.get(name) or "").strip()) for name in (
        "USER_CODE", "WECHAT_APPID", "WECHAT_APPSECRET")}
    return {
        "ok": True,
        "now": _clock(now),
        "session_root": _session_of(session_root),
        "platform_context": context,
        "capability_docs": capability_docs(),
    }


__all__ = [
    "check_env", "check_platform", "check_directories", "readiness_report",
    "cloud_status", "check_bound_models", "check_cloud_mapping",
    "render_project_mapping", "render_user_mapping",
    "CLOUD_OK", "CLOUD_NO_RESOURCE_ID", "CLOUD_UNREACHABLE", "CLOUD_NO_MAPPING",
    "session_context", "capability_docs",
    "STATUS_MISSING_PLATFORM",
    "probe_for", "default_probe",
    "STATUS_MISSING_ENV", "STATUS_UNUSABLE_ENV", "STATUS_MISSING_DIR",
    "STATUS_READONLY_DIR", "STATUS_NOT_NEEDED",
    "VERSION",
    "STATUS_OK",
    "STATUS_BUNDLED",
    "STATUS_MISSING_BINARY",
    "STATUS_MISSING_FEATURE",
    "STATUS_FEATURE_FALLBACK",
    "STATUS_MISSING_FONT",
    "PrereqError",
    "load_manifest",
    "check_all",
    "verify_payload",
]
