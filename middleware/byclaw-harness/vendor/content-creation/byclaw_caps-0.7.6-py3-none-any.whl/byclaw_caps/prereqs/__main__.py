#!/usr/bin/env python3
"""环境就绪自检 CLI。

原先这项只有库函数和一个仓库外的脚本，**没有 CLI、没有 SKILL.md**——
于是用户说「帮我检查一下环境是否就绪」时，agent 既发现不了它，也没有命令可跑。
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path

from byclaw_caps._cli import add_common, dispatch
from byclaw_caps.prereqs import (
    PrereqError, default_probe, load_manifest,
    readiness_report, session_context,
)

#: 随包分发的清单。放进包里是刻意的——原先它在轮子外面，
#: 装完包的机器上根本没有这个文件，自检也就无从谈起。
DEFAULT_MANIFEST = Path(__file__).with_name("prereqs.manifest.yaml")


def build() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="byclaw_caps.prereqs", description="环境就绪自检")
    sub = parser.add_subparsers(dest="command", required=True)

    check = sub.add_parser(
        "check", help="检查二进制、字体、环境变量、目录映射是否就绪")
    check.add_argument("--manifest", default=str(DEFAULT_MANIFEST))
    check.add_argument(
        "--live", action="store_true",
        help="联网探活：验凭据能不能用。**配了但过期的 key 离线查不出来**，"
             "而那是最常见的一种。会发少量真实请求")
    check.add_argument(
        "--agent-id", default="",
        help="**要检查哪个数字员工**（不是「谁在跑自检」）。生图与配音由创作员工执行，"
             "凭据按各自的 agentId 解析；拿跑自检那个员工的 id 来查，"
             "查到的必然是「未绑定」，而它本来就不需要模型")
    check.add_argument(
        "--model-kind", dest="model_kinds", action="append", choices=("image", "tts"),
        help="只查这类模型，可重复。只做配图不配音的员工要收窄，"
             "否则会挂一条假的「配音未绑定」")
    check.add_argument("--session-root", help="凭据缓存落点")
    check.add_argument(
        "--for", dest="skill",
        help="只验这条链路要的东西。只做图文的用户不该被「缺配音密钥」挡住")

    show = sub.add_parser("manifest", help="打印清单里声明了哪些前置件")
    show.add_argument("--manifest", default=str(DEFAULT_MANIFEST))

    # 开局那 9 条探路命令合成的一条。和 `check` 分开是刻意的：
    # `check` 回答「环境配好了吗」（可能联网、可能很慢），
    # `context` 回答「我在哪、有什么」（纯本地、必须快）。
    # 合成一条会让每次开局都付探活的代价。
    context = sub.add_parser(
        "context", help="当前时间、会话上传、平台上下文取到没、能力文档路径（纯本地）")
    context.add_argument(
        "--session-root", help="会话目录；给了就报出用户上传了哪些文件")

    for one in (check, show, context):
        add_common(one)
    return parser


def handle(args: argparse.Namespace):
    if args.command == "context":
        return session_context(session_root=args.session_root, environ=os.environ), 0

    manifest = load_manifest(args.manifest)

    if args.command == "manifest":
        return {"ok": True, "sections": {
            name: sorted((manifest.get(name) or {}))
            for name in ("binaries", "fonts", "env", "directories")}}, 0

    report = readiness_report(
        manifest, environ=os.environ, skill=args.skill, live=args.live,
        probe=default_probe if args.live else None,
        agent_id=args.agent_id, model_kinds=args.model_kinds,
        session_root=args.session_root)

    # 一步一步照着做：按依赖顺序给出待办。顺序反了会出现
    # 「配了 key 但 ffmpeg 没装」这种白配。
    steps = []
    for index, item in enumerate(report["blocking"], 1):
        steps.append({
            "step": index,
            "kind": item["kind"],
            "name": item["name"],
            "why": item.get("used_by") or item.get("detail", ""),
            "problem": item.get("detail", ""),
            "do": item.get("hint") or item.get("install") or "",
        })

    return ({"ok": report["ok"],
             "summary": report["summary"],
             "live": bool(args.live),
             "probed": report["probed"],
             "next_steps": steps,
             # 已就绪的折叠成名字列表，只展开缺的。
             "ready": [i["name"] for i in report["ready"]]},
            0 if report["ok"] else 1)


def main() -> int:
    return dispatch(build(), handle, usage_errors=(PrereqError,))


if __name__ == "__main__":
    raise SystemExit(main())
