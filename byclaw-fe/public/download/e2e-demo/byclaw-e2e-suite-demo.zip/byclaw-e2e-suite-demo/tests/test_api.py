"""接口类 E2E 用例示例:演示被测地址从环境变量读 + 跳过用例的写法。"""

import os

import pytest

# 被测应用入口地址,对应「环境」配置里的「访问地址」。
BASE_URL = os.getenv("E2E_BASE_URL", "http://localhost:8086")


def test_base_url_configured():
    assert BASE_URL.startswith("http"), f"访问地址格式不对: {BASE_URL}"


def test_health_endpoint_shape():
    """真实项目里这里会发 HTTP 请求;demo 不引入网络依赖,只演示断言写法。"""
    fake_response = {"status": "UP", "components": {"db": "UP", "redis": "UP"}}
    assert fake_response["status"] == "UP"
    assert set(fake_response["components"]) >= {"db", "redis"}


@pytest.mark.skip(reason="演示 skipped 状态:平台会计入 totals.skipped,不算失败")
def test_optional_feature():
    raise AssertionError("不会执行到这里")
