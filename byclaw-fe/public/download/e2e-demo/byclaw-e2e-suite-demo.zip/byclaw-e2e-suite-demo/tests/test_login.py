"""登录相关 E2E 用例示例。

演示两件事:
1. 业务测试账号从环境变量读,不写死在代码里(平台按「环境」配置注入,前缀 = envPrefix)。
2. 故意留一条失败用例,让你跑一次就能看到 失败 -> 截图 -> 归集 整条链路真的通了。
"""

import os

# 平台按环境配置里的 envPrefix 注入,例:前缀 E2E_ADMIN -> E2E_ADMIN_USER / E2E_ADMIN_PASS。
# 本地跑 demo 没注入时给个占位值,避免 KeyError 让 demo 跑不起来。
ADMIN_USER = os.getenv("E2E_ADMIN_USER", "demo-admin")
ADMIN_PASS = os.getenv("E2E_ADMIN_PASS", "demo-pass")


def test_login_success():
    """通过用例:账号密码从环境变量拿到即算登录前置就绪。"""
    assert ADMIN_USER, "E2E_ADMIN_USER 未注入:检查「环境」里的测试账号配置"
    assert ADMIN_PASS, "E2E_ADMIN_PASS 未注入:检查「环境」里的测试账号配置"


def test_login_with_expired_token():
    """【故意失败】用来演示失败证据链路。

    跑完后你会看到:
      - report/junit.xml 里这条是 <failure>
      - artifacts/test_login_with_expired_token.png 自动生成(conftest.py 的钩子干的)
      - 平台按文件名把这张图挂到这条失败用例上

    验证完请删掉本用例,或改成真实断言。
    """
    expected_status = 200
    actual_status = 401  # 模拟过期 token 被拒
    assert actual_status == expected_status, "过期 token 应当刷新后重试,当前直接 401"
