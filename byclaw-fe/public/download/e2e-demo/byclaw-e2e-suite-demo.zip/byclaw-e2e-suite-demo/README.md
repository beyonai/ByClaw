# ByClaw 测试用例集 Demo(pytest)

开箱可跑的参考实现。**你只负责这一个测试工程**:产出 JUnit 报告 + 用退出码表达成败。
整轮的目录、状态机、`status.json` 由编排层统一维护,**不用你写**。

## 先跑一遍(看到失败截图链路)

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
./run.sh          # 退出码为 1 —— demo 故意留了一条失败用例
```

跑完检查产物:

```
report/junit.xml                              # 5 用例:3 通过 / 1 失败 / 1 跳过
artifacts/test_login_with_expired_token.png   # 失败用例自动截图,文件名 = 用例ID
```

看到这张图,说明「失败 → 截图 → 按用例ID归集」整条链路通了。这正是平台把证据挂到失败用例上的依据。

## 你必须满足的 4 条契约

### ① JUnit XML 报告
平台读它汇总通过率、判断哪条用例挂了。路径必须和平台「测试用例集」里填的**报告路径**一致。

```bash
pytest -q --junitxml=report/junit.xml
```

平台会收集到 `$BYCLAW_E2E_RESULT_DIR/reports/<suiteId>.xml`。

### ② 退出码语义
```
0     = 全部通过
非 0  = 有失败 / 运行错误
```
别用 `|| true` 吞掉退出码,否则平台会把失败判成通过。见 [run.sh](run.sh)。

### ③ 标准输出即日志
平台收集到 `$BYCLAW_E2E_RESULT_DIR/logs/<suiteId>.log`,无需自己写文件。

### ④ 失败证据(E2E 建议必留截图)
**文件名 = 用例ID**,平台按名字挂到 JUnit 里对应的失败用例。实现见 [conftest.py](conftest.py)。

接真实项目时替换截图那一行即可:

```python
# Selenium
driver.save_screenshot(path)
# Playwright
page.screenshot(path=path)
```

Playwright 也可直接用配置项自动留证:

```js
use: { screenshot: 'only-on-failure', video: 'retain-on-failure', trace: 'retain-on-failure' }
```

## 业务测试账号怎么拿

**不要把账号密码写死在代码里。** 平台按「环境」配置里的测试账号注入环境变量,前缀 = 你配的 `envPrefix`:

```python
ADMIN_USER = os.getenv("E2E_ADMIN_USER")
ADMIN_PASS = os.getenv("E2E_ADMIN_PASS")
```

密码不入库,只存凭据引用,运行时由编排层注入。见 [tests/test_login.py](tests/test_login.py)。

## 文件说明

| 文件 | 作用 |
|---|---|
| `run.sh` | 运行入口,平台「运行命令」填这条 |
| `pytest.ini` | 固定 `junit_family=xunit2`,平台按该格式解析 |
| `conftest.py` | 失败自动截图钩子(契约④的正确实现) |
| `tests/test_login.py` | 账号从环境变量读 + **1 条故意失败**用例 |
| `tests/test_api.py` | 断言写法 + skipped 状态示例 |

## 接到平台上

1. 把本工程推到 Git 仓库。
2. 平台 → 研发项目 → 测试 → 配置 → 新增测试用例集。
3. 运行器选 `pytest`,来源填仓库地址+分支。
4. 运行命令 `./run.sh`(或 `pytest -q --junitxml=report/junit.xml`)。
5. 报告路径填 `report/junit.xml` —— **必须和 ① 里的 `--junitxml` 完全一致**。

## 上线前记得

删掉 `test_login_with_expired_token`(那条故意失败的),否则你的套件永远是失败态。
