#!/usr/bin/env bash
# 用例集运行入口。平台「测试用例集」里的「运行命令」填的就是这条(或直接填下面的 pytest 命令)。
#
# 契约要点:
#   - --junitxml 的路径必须和平台「报告路径」字段一致,平台按此收集 JUnit XML。
#   - 退出码直接透传 pytest 的:0 = 全通过,非 0 = 有失败。不要 || true 吞掉。
set -uo pipefail

REPORT_PATH="${REPORT_PATH:-report/junit.xml}"
mkdir -p "$(dirname "$REPORT_PATH")"

pytest -q --junitxml="$REPORT_PATH"
# 显式回传 pytest 退出码,平台据此判定本套件成败。
exit $?
