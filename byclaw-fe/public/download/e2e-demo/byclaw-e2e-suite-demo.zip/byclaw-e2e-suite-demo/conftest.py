"""失败自动截图钩子。

平台契约第 4 条要求:失败用例必须留截图,且文件名 = 用例ID。
平台按文件名把截图挂回 JUnit 里对应的失败用例,所以命名不能随意改。

这里用「写占位 PNG」模拟真实浏览器截图,保证 demo 无需装浏览器也能跑通整条链路。
接真实项目时,把 _save_screenshot 换成 driver.save_screenshot(path) /
page.screenshot(path=path) 即可,其余逻辑不用动。
"""

import os

import pytest

# 截图落点:平台会把该目录归集到 $BYCLAW_E2E_RESULT_DIR/artifacts/<suiteId>/
ARTIFACTS_DIR = os.path.join(os.path.dirname(__file__), "artifacts")

# 1x1 透明 PNG。真实项目请替换为浏览器截图,这里只为让 demo 免依赖跑通。
_PLACEHOLDER_PNG = bytes.fromhex(
    "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4"
    "890000000a49444154789c63000100000500010d0a2db40000000049454e44ae426082"
)


def _save_screenshot(case_id: str) -> str:
    os.makedirs(ARTIFACTS_DIR, exist_ok=True)
    # 文件名必须等于用例ID,平台靠它把证据挂到失败用例上。
    path = os.path.join(ARTIFACTS_DIR, f"{case_id}.png")
    with open(path, "wb") as fp:
        fp.write(_PLACEHOLDER_PNG)
    return path


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_makereport(item, call):
    """只在「执行阶段真的失败」时截图:setup/teardown 报错不算用例失败证据。"""
    outcome = yield
    report = outcome.get_result()
    if report.when != "call" or not report.failed:
        return
    # item.name 即用例函数名,与 JUnit 里的 case name 一致,作为用例ID使用。
    _save_screenshot(item.name)
