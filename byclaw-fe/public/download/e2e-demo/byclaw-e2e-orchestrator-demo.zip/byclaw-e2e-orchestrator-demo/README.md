# ByClaw 集成测试编排脚本 Demo

开箱可跑的参考实现。**编排层负责整轮**:建目录 → 写 meta → 逐个跑用例集 → 汇总 JUnit → 原子写 `status.json`。
平台只认 `status.json` 判断状态,**不靠「文件在不在」猜测**。

## 先跑一遍

```bash
BYCLAW_E2E_RESULT_DIR=/tmp/e2e-run-1 ./orchestrate.sh
```

只依赖 `bash` + `python3`。若同级存在 `byclaw-e2e-suite-demo/`,会真去跑那个用例集;
否则用 `sample/suite-sample.xml` 演示汇总链路,单独下载本 zip 也能跑通。

跑完看产物:

```bash
cat /tmp/e2e-run-1/status.json
find /tmp/e2e-run-1 -type f
```

退出码与整轮状态一致(passed → 0,其余 → 1)。demo 用例集含一条故意失败用例,所以正常会得到 `failed`。

## 结果目录结构

```
$BYCLAW_E2E_RESULT_DIR/        # 平台注入,按分支+轮次唯一
├── status.json      # 状态真相源:状态机 + 心跳 + 汇总(最后原子写入)
├── meta.json        # 不变信息:分支/commit/环境/触发时间/轮次
├── reports/<suiteId>.xml      # 各用例集的 JUnit
├── logs/<suiteId>.log         # 拉码/构建/部署/各套件日志
└── artifacts/<suiteId>/       # 失败证据,按套件分目录避免重名
    └── <caseId>.png           # 文件名 = 用例ID
```

## 三个最容易踩的坑

### ① status.json 必须原子写
直接 `>` 覆盖,平台可能读到半截 JSON,把正常运行误判成 error。先写 `.tmp` 再 `mv`(同目录 rename 是原子操作):

```bash
write_status() {
    printf '%s\n' "$2" > "$1/status.json.tmp"
    mv "$1/status.json.tmp" "$1/status.json"
}
```
见 [lib/write_status.sh](lib/write_status.sh)。

### ② failed 和 error 不是一回事
```
failed  = 跑到用例了,有用例没过   -> 打回「编码」环节
error   = 没跑到用例(拉码/构建/部署/环境炸了) -> 打回编码或运维介入
```
准备阶段失败写 `error`,别写 `failed`,否则会冤枉研发。一份报告都没有也算 `error` —— 见 [lib/merge_junit.py](lib/merge_junit.py)。

### ③ 异常退出也要落终态
脚本被 kill 或中途报错不写终态,平台只能等心跳超时才发现。用 `trap` 兜底:

```bash
trap on_error ERR INT TERM
```
注意 `on_error` 要先检查是否已写过终态,避免覆盖掉正常的 `failed`。见 [orchestrate.sh](orchestrate.sh)。

## status 状态枚举(封闭取值)

| 状态 | 含义 |
|---|---|
| `pending` | 未开始(或 status.json 尚不存在) |
| `preparing` | 准备中:拉码 / 构建镜像 / 部署 |
| `running` | 测试进行中(`finishedAt` 为 null;心跳超时未刷新判为崩溃) |
| `passed` | 全部通过 → 进入「提交 PR」 |
| `failed` | 有用例失败 → 打回「编码」 |
| `error` | 构建/部署/环境错误,未跑到用例 |
| `timeout` | 超过最大时长被终止 |
| `cancelled` | 人工取消 |

## 心跳

运行中定期刷新 `updatedAt`,平台据此判活。长时间不刷新会被判崩溃:

```bash
heartbeat "$DIR"   # 只改 updatedAt,保留其余字段
```

长跑套件建议每 30–60s 刷一次(如套件间隙或后台循环)。

## 业务测试账号

平台按「环境」配置注入环境变量,前缀 = 你配的 `envPrefix`。密码不入库,只存凭据引用:

```bash
"$E2E_ADMIN_USER" / "$E2E_ADMIN_PASS"
```

编排层直接透传给用例进程即可,不要落盘、不要打进日志。

## 平台注入的环境变量

| 变量 | 说明 |
|---|---|
| `BYCLAW_E2E_RESULT_DIR` | 本次运行结果根目录(必用) |
| `BYCLAW_E2E_BRANCH` | 被测分支 |
| `BYCLAW_E2E_COMMIT` | 被测提交 |
| `BYCLAW_E2E_ENV_NAME` | 环境名 |
| `BYCLAW_E2E_ROUND` | 第几轮(打回重测会递增) |

## 文件说明

| 文件 | 作用 |
|---|---|
| `orchestrate.sh` | 编排主流程,平台在「环境 → 环境准备」里配置执行它 |
| `lib/write_status.sh` | 原子写 + 心跳(含跨平台 `iso_now`) |
| `lib/merge_junit.py` | 汇总多套件 JUnit → `totals` + `suites` + `failedCases` |
| `sample/` | 内置样例 JUnit 与截图,供独立试跑 |

## 接到平台上

1. 把本工程推到 Git 仓库(或直接贴脚本内容)。
2. 平台 → 研发项目 → 测试 → 配置 → 新增/编辑集成测试环境。
3. 编排方式选「脚本型」,配好 SSH 连接与工作目录。
4. 在「环境准备」里把 `orchestrate.sh` 作为阶段脚本。
5. 在「测试账号」里配业务账号,`envPrefix` 与用例里读的变量名对齐。

## 注意

`date -Is` 是 GNU 扩展,BSD/macOS 上会报错导致时间戳变空串。本 demo 统一用 `iso_now()`(python3 实现),Linux 构建机和本地 Mac 都能跑。
