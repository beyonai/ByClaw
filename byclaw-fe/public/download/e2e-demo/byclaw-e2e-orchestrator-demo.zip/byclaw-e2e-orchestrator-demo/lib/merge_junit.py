#!/usr/bin/env python3
"""汇总多套件 JUnit XML,产出 status.json 的 totals + suites 字段。

用法:
    merge_junit.py <result_dir> [--reason "打回原因"]

读取 <result_dir>/reports/*.xml,按文件名(去扩展名)作为 suiteId,
输出完整 status.json 到 stdout。调用方负责原子写入。

状态判定规则(与平台封闭枚举对齐):
    有 failure/error 的用例 -> 该套件 failed,整轮 failed
    全部通过               -> passed
"""

import argparse
import glob
import json
import os
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone


def _local_now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _iter_testsuites(root: ET.Element):
    """JUnit 根节点可能是 <testsuites> 也可能直接是 <testsuite>,两种都要吃下。"""
    if root.tag == "testsuites":
        yield from root.iter("testsuite")
    elif root.tag == "testsuite":
        yield root


def _collect_artifacts(result_dir: str, suite_id: str, case_name: str) -> list:
    """按「文件名 = 用例ID」的契约找证据文件,找到多少给多少。"""
    base = os.path.join(result_dir, "artifacts", suite_id)
    found = []
    for ext in ("png", "webm", "zip"):
        path = os.path.join(base, f"{case_name}.{ext}")
        if os.path.exists(path):
            # status.json 里存相对 result_dir 的路径,便于平台直接拼 URL。
            found.append(os.path.relpath(path, result_dir))
    return found


def parse_suite(result_dir: str, xml_path: str) -> dict:
    suite_id = os.path.splitext(os.path.basename(xml_path))[0]
    tree = ET.parse(xml_path)

    total = passed = failed = skipped = 0
    failed_cases = []

    for testsuite in _iter_testsuites(tree.getroot()):
        for case in testsuite.iter("testcase"):
            total += 1
            name = case.get("name", "")
            # error 与 failure 都按失败计:平台只关心「这条用例没过」。
            is_failed = case.find("failure") is not None or case.find("error") is not None
            is_skipped = case.find("skipped") is not None
            if is_failed:
                failed += 1
                failed_cases.append(
                    {
                        "case": name,
                        "artifacts": _collect_artifacts(result_dir, suite_id, name),
                    }
                )
            elif is_skipped:
                skipped += 1
            else:
                passed += 1

    suite = {
        "id": suite_id,
        "status": "failed" if failed else "passed",
        "report": os.path.join("reports", os.path.basename(xml_path)),
        "totals": {"total": total, "passed": passed, "failed": failed, "skipped": skipped},
    }
    if failed_cases:
        suite["failedCases"] = failed_cases
    return suite


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("result_dir")
    parser.add_argument("--reason", default="")
    parser.add_argument("--started-at", default="")
    args = parser.parse_args()

    reports = sorted(glob.glob(os.path.join(args.result_dir, "reports", "*.xml")))
    if not reports:
        # 一份报告都没有 = 没跑到用例,属于 error(构建/环境问题),不是 failed。
        print(
            json.dumps(
                {
                    "schemaVersion": 1,
                    "status": "error",
                    "finishedAt": _local_now_iso(),
                    "reason": "未找到任何 JUnit 报告:检查用例集运行命令的 --junitxml 路径",
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0

    suites = [parse_suite(args.result_dir, path) for path in reports]
    totals = {"total": 0, "passed": 0, "failed": 0, "skipped": 0}
    for suite in suites:
        for key in totals:
            totals[key] += suite["totals"][key]

    has_failure = totals["failed"] > 0
    reason = args.reason
    if has_failure and not reason:
        names = [c["case"] for s in suites for c in s.get("failedCases", [])]
        reason = f"{totals['failed']} 条用例失败: {', '.join(names[:5])}"

    status = {
        "schemaVersion": 1,
        "status": "failed" if has_failure else "passed",
        "startedAt": args.started_at or _local_now_iso(),
        "updatedAt": _local_now_iso(),
        "finishedAt": _local_now_iso(),
        "totals": totals,
        "suites": suites,
        "reason": reason,
    }
    print(json.dumps(status, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
