#!/usr/bin/env bash
# status.json 原子写工具。
#
# 为什么必须原子写:平台会周期性读 status.json 判断状态。若直接 > 覆盖,
# 读者可能读到半截 JSON 导致解析失败、把正常运行误判成 error。
# 先写 .tmp 再 mv(同目录 rename 是原子操作),读者永远只能读到完整文件。

# 带时区偏移的 ISO8601 时间戳。
# 不用 `date -Is`:那是 GNU 扩展,BSD/macOS date 会报 invalid argument,
# 本地试跑时所有时间戳会变成空串。python3 本来就是本 demo 的依赖(merge_junit.py)。
iso_now() {
    python3 -c "from datetime import datetime,timezone; print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"
}

# write_status <result_dir> <json>
write_status() {
    local dir="$1"
    local json="$2"
    printf '%s\n' "$json" > "$dir/status.json.tmp"
    mv "$dir/status.json.tmp" "$dir/status.json"
}

# 运行中心跳:只刷新 updatedAt,保留其余字段。
# 平台靠 updatedAt 判活 —— 长时间不刷新会被判为崩溃。
# heartbeat <result_dir>
heartbeat() {
    local dir="$1"
    local status_file="$dir/status.json"
    [ -f "$status_file" ] || return 0
    local now
    now="$(iso_now)"
    # 用 python3 改单个字段,避免 sed 破坏 JSON 结构。
    python3 - "$status_file" "$now" <<'PY'
import json
import os
import sys

path, now = sys.argv[1], sys.argv[2]
with open(path) as fp:
    data = json.load(fp)
data["updatedAt"] = now
tmp = path + ".tmp"
with open(tmp, "w") as fp:
    json.dump(data, fp, ensure_ascii=False, indent=2)
os.replace(tmp, path)
PY
}
