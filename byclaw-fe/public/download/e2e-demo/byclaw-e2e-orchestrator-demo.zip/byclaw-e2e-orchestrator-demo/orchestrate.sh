#!/usr/bin/env bash
# ByClaw 集成测试编排脚本 Demo —— 可直接运行。
#
# 职责(编排层):建目录 -> 写 meta -> 逐个跑用例集 -> 汇总 JUnit -> 原子写 status.json。
# 平台只认 status.json 判断状态,不靠「文件在不在」猜测。
#
# 本地试跑(不接平台):
#   BYCLAW_E2E_RESULT_DIR=/tmp/e2e-run-1 ./orchestrate.sh
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/write_status.sh
. "$SCRIPT_DIR/lib/write_status.sh"

# 平台注入本次运行的结果根目录(按分支+轮次唯一)。本地试跑时给个默认值。
DIR="${BYCLAW_E2E_RESULT_DIR:-/tmp/byclaw-e2e-demo-run}"
mkdir -p "$DIR/reports" "$DIR/logs" "$DIR/artifacts"

STARTED_AT="$(iso_now)"

# 任何未预期的中断都要落一个终态,否则平台只能等心跳超时才判失败。
on_error() {
    local code=$?
    # 已经写过终态就不覆盖(比如用例失败已写 failed)。
    if grep -q '"status": *"\(passed\|failed\|error\|timeout\|cancelled\)"' "$DIR/status.json" 2>/dev/null; then
        exit "$code"
    fi
    write_status "$DIR" "$(printf '{\n  "schemaVersion": 1,\n  "status": "error",\n  "startedAt": "%s",\n  "finishedAt": "%s",\n  "reason": "编排脚本异常退出(exit %s),未跑到用例汇总"\n}' "$STARTED_AT" "$(iso_now)" "$code")"
    exit "$code"
}
trap on_error ERR INT TERM

# ---------- ① meta.json:不变信息,平台可预写,这里兜底补齐 ----------
if [ ! -f "$DIR/meta.json" ]; then
    printf '{\n  "branch": "%s",\n  "commit": "%s",\n  "env": "%s",\n  "round": %s,\n  "triggeredAt": "%s"\n}\n' \
        "${BYCLAW_E2E_BRANCH:-unknown}" \
        "${BYCLAW_E2E_COMMIT:-unknown}" \
        "${BYCLAW_E2E_ENV_NAME:-demo}" \
        "${BYCLAW_E2E_ROUND:-1}" \
        "$STARTED_AT" > "$DIR/meta.json"
fi

# ---------- ② preparing:拉码 / 构建 / 部署 ----------
write_status "$DIR" "$(printf '{\n  "schemaVersion": 1,\n  "status": "preparing",\n  "startedAt": "%s",\n  "updatedAt": "%s"\n}' "$STARTED_AT" "$(iso_now)")"

echo "[prepare] 拉取代码 / 构建镜像 / 部署到测试环境" | tee "$DIR/logs/prepare.log"
# 真实场景在此执行 git clone / docker build / kubectl set image 等。
# 准备阶段失败要写 error(不是 failed):没跑到用例,不该打回编码。

# ---------- ③ running:逐个跑用例集 ----------
write_status "$DIR" "$(printf '{\n  "schemaVersion": 1,\n  "status": "running",\n  "startedAt": "%s",\n  "updatedAt": "%s",\n  "finishedAt": null\n}' "$STARTED_AT" "$(iso_now)")"

# 业务测试账号由平台按「环境」配置注入,用例直接读,不落明文:
#   "$E2E_ADMIN_USER" / "$E2E_ADMIN_PASS"  (前缀 = 环境配置里的 envPrefix)

# 套件清单:真实场景由平台按项目配置生成。这里演示用内置样例套件。
run_suite() {
    local suite_id="$1"
    local workdir="$2"
    local command="$3"

    echo "[run] $suite_id: $command" | tee "$DIR/logs/$suite_id.log"
    mkdir -p "$DIR/artifacts/$suite_id"

    (
        cd "$workdir" || exit 1
        # 用例集自己产 JUnit 到本地 report/,编排层负责搬到 reports/<suiteId>.xml
        eval "$command"
    ) >> "$DIR/logs/$suite_id.log" 2>&1
    local suite_code=$?

    # 收集该套件的 JUnit 报告到统一位置(平台按 reports/<suiteId>.xml 找)。
    if [ -f "$workdir/report/junit.xml" ]; then
        cp "$workdir/report/junit.xml" "$DIR/reports/$suite_id.xml"
    fi
    # 收集失败证据:用例集按「文件名=用例ID」产出,这里按套件分目录避免重名打架。
    if [ -d "$workdir/artifacts" ]; then
        cp -R "$workdir/artifacts/." "$DIR/artifacts/$suite_id/" 2>/dev/null || true
    fi

    echo "[run] $suite_id 退出码 $suite_code" >> "$DIR/logs/$suite_id.log"
    # 单套件失败不中断整轮:其他套件也要跑完,汇总时统一判定。
    return 0
}

# 演示套件:指向同级的用例集 demo(若存在)。真实场景替换成你的用例工程路径。
SAMPLE_SUITE_DIR="${SAMPLE_SUITE_DIR:-$SCRIPT_DIR/../byclaw-e2e-suite-demo}"
if [ -d "$SAMPLE_SUITE_DIR" ]; then
    run_suite "suite-demo" "$SAMPLE_SUITE_DIR" "pytest -q --junitxml=report/junit.xml"
else
    # 没有用例集时造一份合规 JUnit,保证 demo 独立也能跑通汇总链路。
    echo "[run] 未找到用例集 demo,使用内置样例报告演示汇总" | tee "$DIR/logs/suite-sample.log"
    cp "$SCRIPT_DIR/sample/suite-sample.xml" "$DIR/reports/suite-sample.xml"
    mkdir -p "$DIR/artifacts/suite-sample"
    cp "$SCRIPT_DIR/sample/test_checkout.png" "$DIR/artifacts/suite-sample/" 2>/dev/null || true
fi

# 心跳示范:长时间运行的套件之间刷新 updatedAt,平台据此判活。
heartbeat "$DIR"

# ---------- ④ 汇总 JUnit 并原子写终态 ----------
FINAL_STATUS="$(python3 "$SCRIPT_DIR/lib/merge_junit.py" "$DIR" --started-at "$STARTED_AT")"
write_status "$DIR" "$FINAL_STATUS"

# 退出码与整轮状态一致,方便上层 CI 感知。
STATUS_VALUE="$(python3 -c "import json,sys; print(json.load(open(sys.argv[1]))['status'])" "$DIR/status.json")"
echo "[done] 整轮状态: $STATUS_VALUE -> $DIR/status.json"
[ "$STATUS_VALUE" = "passed" ] && exit 0 || exit 1
