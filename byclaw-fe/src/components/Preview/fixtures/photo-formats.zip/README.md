# 照片/图像常用格式样例对照

所有样例**来自同一张基准图** `base.png` (800×600)，便于直观对比体积、画质、透明、动图等差异。


## 基准图说明
- 平滑对角渐变 + 余弦扰动背景 → 便于观察有损压缩的色带/块效应
- 6 个高饱和度色块（红/绿/蓝/黄/白/黑）→ 便于观察色彩还原
- 细线条网格 + 1px 小点阵 → 便于观察细节/清晰度损失
- 角落中文「格式示例 800×600」（`/usr/share/fonts/truetype/wqy/wqy-microhei.ttc`） → 便于观察字体可读性
- 全部由 `make_formats.py` 用 Pillow（外加 `pillow-heif` 支持 HEIF）一次性生成

## 失败/未尝试的格式
无。本次生成环境检测到的能力：
- Pillow 12.3.0，已通过 `PIL.features.check()` 验证支持：`jpg / jpg_2000 / webp / avif / libtiff / libjpeg_turbo / freetype2 / zlib`
- 已安装 `pillow-heif 1.8.1`（提供 HEIF/HEIC 编解码）
- 上表 12 种格式 + 透明 PNG 全部成功生成并通过 PIL 读回校验。

## 对照表

| # | 格式 | 扩展名 | 文件 | 大小 | 有无损/有损 | 支持透明 | 支持动图 | 生成状态 | 备注 |
|---|------|--------|------|------|-------------|---------|---------|---------|------|
| 1 | JPEG | jpg | `sample.jpg` | 46.0 KB (47,074 B) | 有损 | 否 | 否 | 成功 ✅ | 质量 85 |
| 2 | PNG | png | `sample.png` | 127.7 KB (130,717 B) | 无损 | 是 | 是 (APNG) | 成功 ✅ | 无损 + optimize |
| 3 | GIF | gif | `sample.gif` | 83.9 KB (85,956 B) | 有损 (256 色调色板) | 是 (1-bit 透明) | 是 | 成功 ✅ | 256 色调色板 |
| 4 | BMP | bmp | `sample.bmp` | 1.37 MB (1,440,054 B) | 无损 (可 RLE) | 是 | 否 | 成功 ✅ | 未压缩位图 |
| 5 | TIFF | tiff | `sample.tiff` | 456.7 KB (467,700 B) | 无损 (LZW) | 是 | 多页 | 成功 ✅ | LZW 压缩 |
| 6 | WebP | webp | `sample.webp` | 26.8 KB (27,420 B) | 有损 / 无损 (本例有损) | 是 | 是 | 成功 ✅ | 质量 80, method=4 |
| 7 | ICO | ico | `sample.ico` | 46.7 KB (47,784 B) | 无损 (内嵌 PNG) | 是 (内嵌 PNG) | 否 | 成功 ✅ | 6 尺寸 (16/32/48/64/128/256) |
| 8 | PPM | ppm | `sample.ppm` | 1.37 MB (1,440,015 B) | 无损 (未压缩) | 否 | 否 | 成功 ✅ | 未压缩便携位图 |
| 9 | TGA | tga | `sample.tga` | 1.37 MB (1,440,044 B) | 无损 (可 RLE) | 是 | 否 | 成功 ✅ | 未压缩 |
| 10 | JPEG 2000 | jp2 | `sample.jp2` | 215.3 KB (220,464 B) | 有损 (本例) / 也可无损 | 是 | 否 | 成功 ✅ | quality_layers=[0.5] |
| 11 | AVIF | avif | `sample.avif` | 15.4 KB (15,728 B) | 有损 / 无损 (本例有损) | 是 | 是 | 成功 ✅ | 质量 80, speed=6 |
| 12 | HEIF | heic | `sample.heic` | 66.2 KB (67,837 B) | 有损 / 无损 (本例有损) | 是 | 是 | 成功 ✅ | 质量 80, pillow-heif |
| 13 | PNG (RGBA) | alpha | `sample.png.alpha` | 28.0 KB (28,662 B) | 无损 | 是 | 否 | 成功 ✅ | 演示 RGBA 透明通道 |

## 体积直观对比
按文件大小升序：
-    15.4 KB  AVIF       (sample.avif)
-    26.8 KB  WebP       (sample.webp)
-    28.0 KB  PNG (RGBA) (sample.png.alpha)
-    46.0 KB  JPEG       (sample.jpg)
-    46.7 KB  ICO        (sample.ico)
-    66.2 KB  HEIF       (sample.heic)
-    83.9 KB  GIF        (sample.gif)
-   127.7 KB  PNG        (sample.png)
-   215.3 KB  JPEG 2000  (sample.jp2)
-   456.7 KB  TIFF       (sample.tiff)
-    1.37 MB  PPM        (sample.ppm)
-    1.37 MB  TGA        (sample.tga)
-    1.37 MB  BMP        (sample.bmp)

## 工具链
- `make_formats.py`：一次性生成 `base.png` 与所有 `sample.*` 的脚本
- 所有样例用 PIL 重新 `Image.open(...).load()` 读回，确认解码正常（除 ICO 按多尺寸格式说明）

## 已知/已说明的特殊情况
- **ICO**：内含 6 个缩放尺寸，最大 256×192（PIL 按源图 4:3 比例缩放，非 256×256 正方形）
- **GIF**：调色板模式 256 色；透明仅支持 1-bit（索引透明）
- **JPEG**：有损；不支持透明
- **PPM/TGA/BMP**：未压缩或可选 RLE；体积最大；PPM 不支持透明，PPM/PNG/BMP/TIFF/TGA 文件 1.4MB+ 与像素数 800×600×3 直接对应
- **HEIF**：通过 `pillow-heif` 插件写入
