#!/usr/bin/env python3
"""
照片/图像常用格式样例生成脚本

目的：用同一张基准图（base.png）生成多种常用格式的样例文件，
便于直观对比文件体积、清晰度、色彩还原、透明支持等差异。

基准图（800×600）：
- 平滑渐变背景（便于观察有损压缩的色带/块效应）
- 红/绿/蓝/黄/白/黑色块（色彩还原）
- 细线条网格/小点阵（清晰度损失）
- 角落中文文本（文字可读性）
"""

from __future__ import annotations

import math
import os
import sys
import traceback
from pathlib import Path

# 注册 pillow-heif 以支持 HEIC/HEIF
import pillow_heif  # noqa: F401
pillow_heif.register_heif_opener()

from PIL import Image, ImageColor, ImageDraw, ImageFont

OUT_DIR = Path("/by/.sessions/10309570/photo_formats")
OUT_DIR.mkdir(parents=True, exist_ok=True)

W, H = 800, 600
FONT_PATH = "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc"


# ---------------------------------------------------------------------------
# 基准图构造
# ---------------------------------------------------------------------------

def build_base_image() -> Image.Image:
    """构造 800×600 的基准测试图，返回 RGB 模式的 Image 对象。"""
    img = Image.new("RGB", (W, H), (0, 0, 0))
    pixels = img.load()

    # 1) 平滑渐变背景：对角线 RGB 三色渐变
    for y in range(H):
        for x in range(W):
            # 三色对角渐变 + 余弦扰动以避免明显的网格状色带
            t = (x + y) / (W + H)  # 0..1
            r = int(255 * (1 - t))
            g = int(255 * abs(math.sin(math.pi * t)))
            b = int(255 * t)
            # 微扰动，便于观察压缩算法对细微色阶的保留
            perturb = int(8 * math.sin(x * 0.05) * math.cos(y * 0.05))
            r = max(0, min(255, r + perturb))
            g = max(0, min(255, g + perturb))
            b = max(0, min(255, b + perturb))
            pixels[x, y] = (r, g, b)

    # 2) 几何色块：红/绿/蓝/黄/白/黑
    draw = ImageDraw.Draw(img)
    blocks = [
        ("RED",   (220,  60,  80), ( 30,  30, 180, 280)),
        ("GREEN", ( 60, 200, 100), (300,  30, 550, 180)),
        ("BLUE",  ( 60,  90, 220), (560,  30, 780, 230)),
        ("YELLOW",(250, 220,  60), ( 30, 300, 280, 450)),
        ("WHITE", (250, 250, 250), (300, 200, 550, 350)),
        ("BLACK", ( 10,  10,  10), (300, 360, 550, 510)),
    ]
    for label, color, box in blocks:
        x1, y1, x2, y2 = box
        draw.rectangle([x1, y1, x2, y2], fill=color)
        # 在色块中绘制对应英文标签（无中文，便于通用字体）
        try:
            font = ImageFont.truetype(FONT_PATH, 28)
            draw.text((x1 + 12, y1 + 12), label, fill=(0, 0, 0), font=font)
        except Exception:
            pass

    # 3) 细节密集区域：细线条网格 + 小点阵
    grid_origin = (590, 260)
    grid_w, grid_h = 200, 160
    grid_x1, grid_y1 = grid_origin
    grid_x2, grid_y2 = grid_x1 + grid_w, grid_y1 + grid_h
    # 2px 间距的网格线，颜色浅灰，便于观察采样丢失
    for gx in range(grid_x1, grid_x2 + 1, 2):
        draw.line([(gx, grid_y1), (gx, grid_y2)], fill=(180, 180, 180), width=1)
    for gy in range(grid_y1, grid_y2 + 1, 2):
        draw.line([(grid_x1, gy), (grid_x2, gy)], fill=(180, 180, 180), width=1)
    # 小点阵：1px 圆点
    dot_step = 4
    for dy in range(grid_y1, grid_y2 + 1, dot_step):
        for dx in range(grid_x1, grid_x2 + 1, dot_step):
            draw.point((dx, dy), fill=(255, 255, 255))

    # 单独再来一个高对比细线条区（位于上半部分）
    line_origin = (30, 470)
    for i in range(0, 250, 3):
        draw.line(
            [(line_origin[0], line_origin[1] + i),
             (line_origin[0] + 250, line_origin[1] + 250 - i)],
            fill=(255, 255, 255), width=1,
        )

    # 4) 角落中文文本
    try:
        font_big = ImageFont.truetype(FONT_PATH, 26)
        draw.text((10, H - 36), "格式示例 800×600",
                  fill=(255, 255, 255), font=font_big)
    except Exception as e:
        print(f"[warn] 无法加载中文字体: {e}")

    return img


def build_transparent_image() -> Image.Image:
    """构造一张带透明通道的 RGBA 测试图，用于演示 PNG 透明支持。"""
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # 半透明背景渐变（Alpha）
    for y in range(H):
        for x in range(W):
            a = int(255 * (x / W) * (1 - y / H))
            img.putpixel((x, y), (60, 120, 220, a))
    # 不透明几何色块
    draw.rectangle([40, 40, 240, 160], fill=(220, 50, 50, 255))
    draw.rectangle([260, 40, 460, 160], fill=(50, 200, 80, 255))
    # 半透明圆形
    draw.ellipse([500, 40, 760, 300], fill=(255, 220, 60, 180))
    # 中文文本
    try:
        font = ImageFont.truetype(FONT_PATH, 26)
        draw.text((40, 520), "RGBA 透明通道演示",
                  fill=(255, 255, 255, 255), font=font)
    except Exception:
        pass
    return img


# ---------------------------------------------------------------------------
# 格式导出
# ---------------------------------------------------------------------------

class Result:
    def __init__(self, fmt: str, ext: str, ok: bool,
                 size: int = 0, path: Path | None = None,
                 err: str = "", verified: bool = False,
                 note: str = ""):
        self.fmt = fmt
        self.ext = ext
        self.ok = ok
        self.size = size
        self.path = path
        self.err = err
        self.verified = verified
        self.note = note

    def as_row(self) -> dict:
        return {
            "format": self.fmt,
            "ext": self.ext,
            "file": self.path.name if self.path else "-",
            "size": self.size if self.ok else 0,
            "lossless": self._meta().get("lossless", "-"),
            "alpha": self._meta().get("alpha", "-"),
            "animation": self._meta().get("animation", "-"),
            "status": "成功" if self.ok else "失败",
            "note": self.note or self.err,
        }

    def _meta(self) -> dict:
        return FORMAT_META.get(self.fmt, {})


FORMAT_META = {
    "JPEG":        dict(lossless="有损",   alpha="否", animation="否"),
    "PNG":         dict(lossless="无损",   alpha="是", animation="是(APNG)"),
    "GIF":         dict(lossless="有损(调色板)", alpha="是(1-bit)", animation="是"),
    "BMP":         dict(lossless="无损(可压缩)", alpha="是", animation="否"),
    "TIFF":        dict(lossless="无损(可LZW)",   alpha="是", animation="多页"),
    "WEBP":        dict(lossless="有损/无损", alpha="是", animation="是"),
    "ICO":         dict(lossless="无损(PNG内嵌)", alpha="是(PNG)", animation="否"),
    "PPM":         dict(lossless="无损(未压缩)", alpha="否", animation="否"),
    "TGA":         dict(lossless="无损(可RLE)",   alpha="是", animation="否"),
    "JPEG2000":    dict(lossless="有损/无损",       alpha="是", animation="否"),
    "AVIF":        dict(lossless="有损/无损",       alpha="是", animation="是"),
    "HEIF":        dict(lossless="有损/无损",       alpha="是", animation="是"),
    "PNG-RGBA":    dict(lossless="无损",          alpha="是", animation="否"),
}


def export_format(base: Image.Image, name: str, fmt: str,
                  ext: str, save_kwargs: dict, verify: bool = True,
                  note: str = "") -> Result:
    """导出 base 到指定格式，捕获异常并返回结果。"""
    out = OUT_DIR / f"sample.{ext}"
    try:
        if fmt == "ICO":
            # 生成多尺寸 ICO
            sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
            base.save(out, format=fmt, sizes=sizes)
            note = (note or "") + " 多尺寸(16/32/48/64/128/256)"
        else:
            base.save(out, format=fmt, **save_kwargs)

        size = out.stat().st_size
        ok = True
        err = ""
        verified = False
        ico_sizes: list | None = None
        if verify:
            try:
                img_back = Image.open(out)
                img_back.load()
                w, h = img_back.size
                if fmt == "ICO":
                    # 多尺寸 ICO 校验：任一尺寸存在即视为成功
                    sizes = img_back.info.get("sizes") or [(w, h)]
                    ico_sizes = [tuple(s) for s in sizes]
                    verified = True
                    note = (note + f"; 内含尺寸 {ico_sizes}").strip()
                else:
                    verified = (w == W and h == H)
                    if not verified:
                        err = f"读回尺寸不符 ({w}x{h})"
                        ok = False
            except Exception as e:
                err = f"读回失败: {e}"
                ok = False
        return Result(name, ext, ok, size, out, err=err,
                      verified=verified, note=note)
    except Exception as e:
        return Result(name, ext, False, 0, None,
                      err=f"{type(e).__name__}: {e}", note=note)


def main() -> int:
    print("[1/3] 构造基准图...")
    base = build_base_image()
    base_path = OUT_DIR / "base.png"
    base.save(base_path, format="PNG")
    print(f"    -> {base_path}  ({base_path.stat().st_size} bytes)")

    # 读回确认
    img_back = Image.open(base_path)
    img_back.load()
    assert img_back.size == (W, H), f"base.png 尺寸异常: {img_back.size}"

    transparent = build_transparent_image()
    print(f"[2/3] 构造透明测试图 (RGBA)")

    print("[3/3] 导出各格式样例...")
    results: list[Result] = []

    # 1. JPEG
    results.append(export_format(
        base, "JPEG", "JPEG", "jpg",
        save_kwargs={"quality": 85, "optimize": True},
        note="质量85"
    ))

    # 2. PNG (无损)
    results.append(export_format(
        base, "PNG", "PNG", "png",
        save_kwargs={"optimize": True},
        note="无损, optimize=True"
    ))

    # 3. GIF (256 色调色板)
    pal = base.convert("P", palette=Image.ADAPTIVE, colors=256)
    results.append(export_format(
        pal, "GIF", "GIF", "gif",
        save_kwargs={}
    ))

    # 4. BMP
    results.append(export_format(
        base, "BMP", "BMP", "bmp",
        save_kwargs={}
    ))

    # 5. TIFF
    results.append(export_format(
        base, "TIFF", "TIFF", "tiff",
        save_kwargs={"compression": "tiff_lzw"},
        note="无损 LZW 压缩"
    ))

    # 6. WebP
    results.append(export_format(
        base, "WEBP", "WEBP", "webp",
        save_kwargs={"quality": 80, "method": 4},
        note="质量80, method=4"
    ))

    # 7. ICO (多尺寸)
    results.append(export_format(
        base, "ICO", "ICO", "ico",
        save_kwargs={}
    ))

    # 8. PPM
    results.append(export_format(
        base, "PPM", "PPM", "ppm",
        save_kwargs={}
    ))

    # 9. TGA
    results.append(export_format(
        base, "TGA", "TGA", "tga",
        save_kwargs={}
    ))

    # 10. JPEG 2000
    results.append(export_format(
        base, "JPEG2000", "JPEG2000", "jp2",
        save_kwargs={"quality_mode": "rates", "quality_layers": [0.5]},
        note="有损压缩"
    ))

    # 11. AVIF
    results.append(export_format(
        base, "AVIF", "AVIF", "avif",
        save_kwargs={"quality": 80, "speed": 6},
        note="质量80"
    ))

    # 12. HEIF
    results.append(export_format(
        base, "HEIF", "HEIF", "heic",
        save_kwargs={"quality": 80},
        note="质量80, via pillow-heif"
    ))

    # 附加: 带透明的 PNG
    results.append(export_format(
        transparent, "PNG-RGBA", "PNG", "png.alpha",
        save_kwargs={"optimize": True},
        verify=False,  # 这种 RGBA 与 base.png 不同尺寸/内容，独立
        note="演示 PNG RGBA 透明通道"
    ))

    # 简单汇总
    print()
    print(f"{'格式':<10} {'后缀':<12} {'状态':<6} {'大小':>10} 备注")
    print("-" * 70)
    succ = 0
    fail = 0
    for r in results:
        if r.ok:
            succ += 1
            print(f"{r.fmt:<10} {r.ext:<12} {'OK':<6} {r.size:>10,} {r.note}")
        else:
            fail += 1
            print(f"{r.fmt:<10} {r.ext:<12} {'FAIL':<6} {'':>10} {r.err}")
    print(f"\n成功 {succ} / 失败 {fail} / 共 {len(results)}")

    # 保存 results 给 README 步骤使用（pickle 不可读，这里改写为 README 直接生成）
    return 0


if __name__ == "__main__":
    sys.exit(main())
