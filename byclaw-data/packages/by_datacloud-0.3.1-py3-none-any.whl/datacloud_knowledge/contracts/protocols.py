"""公共协议 — 术语读取、搜索召回、术语写入。

定义数据中心知识服务的三层协议接口：
- TermReader: 无状态纯查询操作（术语检索、别名消歧、属性查询）
- TermSearchEngine: 文本/向量多路召回策略（BM25、子串、向量）
- TermWriter: 有状态持久化操作（创建术语、名称、词汇）
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Protocol, Self

from .term_provider_types import (
    EnumeratedObjectInstances,
    FilterSpec,
    ImportResult,
    LabelCondition,
    LabelFilter,
    QueryResult,
    QueryType,
    TermCreate,
    TermDetail,
    TermItem,
    TermUpdate,
)
from .text import Tokenizer
from .types import (
    BM25Result,
    DimensionValueItem,
    FieldResolutionResult,
    NameItem,
    PropItem,
    SearchTermsResult,
    ShortestPathNode,
    SubstringResult,
    TagFilter,
    TermNameCreate,
    UserScopedNameItem,
    ValueResolutionResult,
    ValueWithAliases,
    VectorResult,
)


class TermReader(Protocol):
    """术语读取接口。所有查询操作，无副作用。

    每个方法回答一个问题，一次 DB 往返。实现方负责 DB session 管理和 SQL 组装。
    编排逻辑（降级、多路召回融合）由调用方负责，不在此协议内。
    """

    def search_terms_exact(
        self,
        *,
        term_type_code: str,
        keyword: str | None = None,
        tags: Sequence[TagFilter] | None = None,
        limit: int = 20,
        offset: int = 0,
        order_by: str = "relevance",
    ) -> SearchTermsResult:
        """按术语类型精确检索术语列表（原子查询，无 BM25 兜底）。

        仅执行精确匹配（term_name == keyword 或 term_code == keyword）。
        无匹配时返回空结果，由调用方决定是否降级到 BM25。

        Args:
            term_type_code: 术语类型编码（支持驼峰简写映射，如 ONTOLOGY_VIEW→view）。
            keyword: 可选关键词搜索（精确匹配 term_name/term_code）。
            tags: 可选标签过滤条件列表。
            limit: 返回条数（1..200）。
            offset: 分页偏移（>=0）。
            order_by: 排序方式（relevance/updated_time/created_time/term_name）。

        Returns:
            分页搜索结果，包含 total 和 items。无匹配时 total=0。
        """
        ...

    def search_terms(
        self,
        *,
        term_type_code: str,
        keyword: str | None = None,
        tags: Sequence[TagFilter] | None = None,
        limit: int = 20,
        offset: int = 0,
        order_by: str = "relevance",
    ) -> SearchTermsResult:
        """按术语类型检索术语列表（含 BM25 兜底）。

        .. deprecated::
            此方法包含编排逻辑（精确匹配无结果时 BM25 兜底）。
            新代码应使用 :meth:`search_terms_exact`，编排逻辑由调用方负责。

        Args:
            term_type_code: 术语类型编码（支持驼峰简写映射，如 ONTOLOGY_VIEW→view）。
            keyword: 可选关键词搜索（精确匹配 term_name/term_code，BM25 兜底）。
            tags: 可选标签过滤条件列表。
            limit: 返回条数（1..200）。
            offset: 分页偏移（>=0）。
            order_by: 排序方式（relevance/updated_time/created_time/term_name）。

        Returns:
            分页搜索结果，包含 total 和 items。
        """
        ...

    def get_term_by_ids(
        self, *, keys: Sequence[tuple[str, str, str]]
    ) -> dict[tuple[str, str, str], str]:
        """批量根据 (library_id, term_type_code, term_code) 三元组查询 term_id。

        Args:
            keys: (library_id, term_type_code, term_code) 三元组列表。

        Returns:
            {(library_id, term_type_code, term_code) → term_id} 映射。
        """
        ...

    def get_term_names(
        self,
        *,
        term_ids: Sequence[str],
        scope_filter: dict[str, object] | None = None,
    ) -> dict[str, list[NameItem]]:
        """批量查询术语的所有名称（标准名 + 别名）。

        Args:
            term_ids: 术语 ID 列表。
            scope_filter: 可选的作用域过滤条件（如 {"scope": "view", "code": "xxx"}）。

        Returns:
            {term_id → [NameItem]} 映射。
        """
        ...

    def resolve_field_aliases(
        self,
        *,
        terms: Sequence[str],
        scope_code: str,
        library_id: str | None = None,
        resolve_values: bool = False,
        value_terms: Sequence[str] | None = None,
    ) -> FieldResolutionResult:
        """轻量级字段 + 值别名精确消歧。

        .. deprecated::
            此方法绑定对象/字段领域概念（scope_code），违反术语协议通用设计。
            请使用 ``query_terms`` 按 term_type_code + parent_term_code 过滤，
            再结合 ``list_term_names`` 自行编排别名匹配逻辑。

        Args:
            terms: 待解析的字段中文名/别名列表。
            scope_code: 视图或对象 code。
            library_id: 预留参数。
            resolve_values: 是否对 value_terms 追加值级别消歧。
            value_terms: 待值消歧的过滤值列表。

        Returns:
            FieldResolutionResult，包含 resolved/ambiguous/unresolved 三类结果。
        """
        ...

    def resolve_value_aliases(
        self, *, terms: Sequence[str], scope_code: str
    ) -> ValueResolutionResult:
        """轻量级属性值精确消歧。

        .. deprecated::
            此方法绑定对象/属性领域概念（scope_code），违反术语协议通用设计。
            请使用 ``query_terms`` 按 parent_term_code 过滤，再结合
            ``list_term_names`` 自行编排值别名匹配逻辑。

        Args:
            terms: 待匹配的值列表。
            scope_code: 视图或对象 code。

        Returns:
            ValueResolutionResult，包含 matched（已知值）和 unmatched（未知值）。
        """
        ...

    def get_object_props(self, *, source_term_ids: Sequence[str]) -> dict[str, list[PropItem]]:
        """批量查询对象/视图下的属性（通过 term_relation HAS_FIELD）。

        .. deprecated::
            此方法绑定对象/属性领域概念，违反术语协议通用设计。
            将在未来版本移除，请使用通用的 ``query_terms`` 或 ``get_term``
            配合 term_type_code 过滤实现等价查询。

        Args:
            source_term_ids: 源术语 ID 列表（view/object 的 term_id）。

        Returns:
            {source_term_id → [PropItem]} 映射。
        """
        ...

    def get_object_props_by_code(self, *, scope_code: str) -> list[PropItem]:
        """根据对象 code 查询其所有属性。

        .. deprecated::
            此方法绑定对象/属性领域概念，违反术语协议通用设计。
            请使用 ``query_terms(term_type_code="prop", parent_term_code=scope_code)`` 替代。

        Args:
            scope_code: 对象/视图编码。

        Returns:
            PropItem 列表，按属性编码排序。
        """
        ...

    def get_prop_values_with_aliases(
        self, *, source_term_ids: Sequence[str]
    ) -> dict[str, list[ValueWithAliases]]:
        """批量查询对象下属性的值术语及其别名。

        .. deprecated::
            此方法绑定属性/对象领域概念，违反术语协议通用设计。
            请使用 ``query_terms`` 按 parent_term_code + term_type_code 过滤替代。

        Args:
            source_term_ids: 源术语 ID 列表。

        Returns:
            {source_term_id → [ValueWithAliases]} 映射。
        """
        ...

    def get_prop_enum_values(
        self, *, scope_code: str, field_codes: Sequence[str]
    ) -> dict[str, list[str]]:
        """查询指定 prop 的枚举值（child term_name + 别名）。

        .. deprecated::
            此方法绑定属性/对象领域概念，违反术语协议通用设计。
            请使用 ``query_terms(parent_term_code=field_code)`` 替代。

        Args:
            scope_code: 视图或对象 code。
            field_codes: 待查询的 prop term_code 列表。

        Returns:
            {field_code → [枚举值列表]}，去重保序。
        """
        ...

    def get_bfs_distance(
        self,
        *,
        source_term_id: str,
        target_term_id: str,
        max_depth: int = 4,
    ) -> int | None:
        """计算两个术语在图谱中的 BFS 最短距离。

        .. deprecated::
            此方法实现图遍历/本体推理逻辑，应由上层分析模块编排
            ``query_term_relations`` 实现，不应下沉到术语 Reader 协议。

        Args:
            source_term_id: 源术语 ID。
            target_term_id: 目标术语 ID。
            max_depth: 最大搜索深度（0 表示不搜索，返回 None）。

        Returns:
            最短距离（非负整数），不可达时返回 None。
        """
        ...

    def get_shortest_path_tree(
        self,
        *,
        target_term_id: str,
        source_term_type_codes: Sequence[str],
        max_depth: int = 6,
    ) -> Sequence[ShortestPathNode]:
        """查询从限定类型根节点到目标术语的最短路径树。

        .. deprecated::
            此方法实现图遍历/本体推理逻辑，应由上层分析模块编排
            ``query_term_relations`` 实现，不应下沉到术语 Reader 协议。

        Args:
            target_term_id: 目标术语 ID（消歧候选项）。
            source_term_type_codes: 限定根节点的术语类型编码列表。
            max_depth: 最大搜索深度。

        Returns:
            ShortestPathNode 列表，每个节点代表一条从根到目标的完整路径。
            无满足条件的根节点时返回空序列。
        """
        ...

    def get_dimension_values(self) -> Sequence[DimensionValueItem]:
        """查询所有 cat=2 维度枚举值（全量加载到内存）。

        .. deprecated::
            此方法绑定维度领域概念，违反术语协议通用设计。
            请使用 ``query_terms`` 按 term_type_code + type_category 过滤实现。

        Returns:
            DimensionValueItem 列表，按 term_name 排序。
        """
        ...

    def get_user_scoped_names(self, *, user_id: str) -> Sequence[UserScopedNameItem]:
        """查询指定用户作用域下的术语别名记录。

        .. deprecated::
            用户作用域查询应由上层模块编排，不应作为 Reader 协议的专用方法。
            请使用 ``list_term_names(term_id=...)`` 配合 scope 过滤替代。

        Args:
            user_id: 用户 ID。

        Returns:
            UserScopedNameItem 列表。
        """
        ...

    def get_type_codes_by_category(self, *, categories: set[int]) -> set[str]:
        """按 term_type 的 type_category 加载 type_code 集合。

        .. deprecated::
            此方法暴露内部 type_category 概念。请使用 ``list_term_types``
            获取全量 term_type 后自行过滤。

        Args:
            categories: type_category 整数值集合（1=列表, 2=字典, 3=本体, 4=文档）。

        Returns:
            type_code 字符串集合。
        """
        ...

    def get_matching_objects(
        self,
        *,
        ontology_code: str,
        field_codes: Sequence[str],
        limit: int = 2,
    ) -> Sequence[tuple[str, int]]:
        """查询与指定字段集最佳匹配的对象 term_code。

        .. deprecated::
            此方法绑定对象/字段/本体领域概念，违反术语协议通用设计。
            请使用 ``query_terms`` + ``query_term_relations`` 由上层编排实现。

        Args:
            ontology_code: 视图或对象编码。
            field_codes: 已确认的字段编码列表。
            limit: 返回对象数量上限。

        Returns:
            (object_term_code, matched_count) 元组列表。
        """
        ...

    def get_global_name_index(
        self,
    ) -> dict[str, list[tuple[str, str, str]]]:
        """构建全局术语名称索引（公共 term_name，不含用户专属记录）。

        Returns:
            {name_text → [(term_id, term_type_code, match_type), ...]} 索引。
        """
        ...

    def get_name_ids_by_word(
        self,
        *,
        word: str,
        term_ids: Sequence[str],
        user_id: str | None = None,
    ) -> dict[str, str]:
        """按单词+术语ID查询 name_id，用户专属记录优先。

        Returns:
            {term_id → name_id} 映射。
        """
        ...

    def get_term(
        self,
        *,
        term_code: str,
        term_type_code: str,
        library_id: str | None = None,
    ) -> str | None:
        """根据 term_code + term_type_code 查询 term_name。

        内部通过 get_term_by_ids 获取 term_id，再用 get_term_names 获取名称。
        返回第一个名称（标准名优先），不存在则返回 None。

        Args:
            term_code: 术语编码。
            term_type_code: 术语类型编码。
            library_id: 可选术语库 ID，传入 None 则由实现方按默认策略处理。

        Returns:
            术语名称字符串，不存在时返回 None。
        """
        ...

    def term_exists(
        self,
        *,
        term_code: str,
        term_type_code: str,
        library_id: str | None = None,
    ) -> bool:
        """检查指定 term_code + term_type_code 的术语是否存在。

        内部通过 get_term_by_ids 判空。

        Args:
            term_code: 术语编码。
            term_type_code: 术语类型编码。
            library_id: 可选术语库 ID，传入 None 则由实现方按默认策略处理。

        Returns:
            True 如果存在，否则 False。
        """
        ...

    # ── TermProvider 协议新增方法 ──────────────────────────────────────

    def query_terms(
        self,
        *,
        dataset_ids: list[str] | None = None,
        keyword: str | None = None,
        term_name: str | None = None,
        term_type: str | None = None,
        query_type: QueryType = "fulltext",
        parent_term_code: str | None = None,
        label_filters: list[LabelFilter] | None = None,
        label_condition: LabelCondition = "and",
        term_ids: list[str] | None = None,
        ext_attrs: dict[str, Any] | None = None,
        query_vector: list[float] | None = None,
        top_k: int = 20,
        offset: int = 0,
    ) -> QueryResult:
        """检索术语。

        映射到 POST /core/term/queryStandardTerm。

        Args:
            dataset_ids:      术语库 ID 列表。None/空 = 不限制。
            keyword:          检索关键词（模糊匹配 term_name/term_code）。
            term_name:        术语名称精确匹配。与 keyword 互斥。
            term_type_codes:  术语类型编码列表。None = 不限制类型，空列表 = 返回空。
            query_type:       检索策略（fulltext/exact/embedding/mixed）。
            parent_term_code: 父术语编码过滤。None = 不限制。
            label_filters:    标签过滤条件列表。
            label_condition:  多标签组合方式（and/or）。
            term_ids:         按 ID 列表精确查询。传入时忽略 keyword/query_type。
            ext_attrs:        扩展属性键值过滤。None = 不限制。
            query_vector:     查询向量（仅 embedding/mixed 需要）。None = 不启用向量检索。
            top_k:            返回条数（1..200）。
            offset:           分页偏移（>=0）。

        Returns:
            QueryResult，包含 total 和 items（TermItem 列表）。
        """
        ...

    def query_terms_batch(
        self,
        *,
        keywords: list[str],
        dataset_ids: list[str] | None = None,
        term_type_codes: list[str] | None = None,
        query_type: QueryType = "fulltext",
        parent_term_code: str | None = None,
        label_filters: list[LabelFilter] | None = None,
        label_condition: LabelCondition = "and",
        ext_attrs: dict[str, Any] | None = None,
        query_vectors: list[list[float]] | None = None,
        top_k: int = 20,
        offset: int = 0,
    ) -> list[QueryResult]:
        """批量检索术语 — 每个 keyword 返回独立的 QueryResult。

        内部为每个 keyword 执行独立的检索 + 元数据过滤。
        不支持 term_ids/term_name（精确匹配走 query_terms 单次调用）。

        Args:
            keywords:         搜索关键词列表。
            dataset_ids:      术语库 ID 列表。None/空 = 不限制。
            term_type_codes:  术语类型编码列表。None = 不限制类型，空列表 = 返回空。
            query_type:       检索策略（exact/fulltext/embedding/mixed）。
            parent_term_code: 父术语编码过滤。None = 不限制。
            label_filters:    标签过滤条件列表。
            label_condition:  多标签组合方式（and/or）。
            ext_attrs:        扩展属性键值过滤。None = 不限制。
            query_vectors:    查询向量列表（仅 embedding/mixed 需要，长度与 keywords 一致）。
            top_k:            返回条数（1..200）。
            offset:           分页偏移（>=0）。

        Returns:
            list[QueryResult]，与 keywords 一一对应。
        """
        ...

    def query_terms_by_labels(
        self,
        *,
        label_filters: list[LabelFilter] | None = None,
        label_condition: LabelCondition = "or",
        term_type_codes: list[str] | None = None,
        filters: list[FilterSpec] | None = None,
        top_k: int = 200,
    ) -> list[TermItem]:
        """按标签过滤术语，不需要关键词。"""
        ...

    def get_term_detail(
        self,
        *,
        dataset_id: str = "",
        library_id: str = "",
        term_id: str,
    ) -> TermDetail | None:
        """查询单条术语完整详情。

        映射到 POST /core/term/queryTermDetail。

        Args:
            dataset_id: 术语库 ID（**已弃用**，请使用 ``library_id``）。
            library_id: 术语库 ID（新名称）。
            term_id:    术语 ID。

        Returns:
            TermDetail，不存在返回 None。
        """

        ...

    def enumerate_object_instances(
        self,
        *,
        object_codes: list[str],
        kb_resource_ids: list[str],
        filters: list[dict[str, Any]] | None = None,
        sort: dict[str, Any] | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> EnumeratedObjectInstances:
        """枚举带度数的对象实例（filters 条件框架版）。

        枚举型接口：确定性条件过滤 → 集合确定 → total 诚实 → offset/limit 分页安全。
        单条 SQL 完成「范围过滤 + 度数聚合 + 条件过滤 + 稳定排序 + 分页」。

        Args:
            object_codes: 对象类型编码范围（与 kb_resource_ids 为 AND，尊重输入不校验）。
            kb_resource_ids: 知识库资源 ID 范围（ext_attrs->>'kb_resource_id'）。
            filters: 条件数组 = [{"type": <注册表 key>, "params": {...}}, ...]，
                     v1 只 AND；type 不在注册表 → ValueError。
            sort: 排序规格 = {"by": "similarity", "params": {...}}（与 filters
                  同构：单一 key + params）。目前仅 "similarity"；未知 by → ValueError。
                  None = 默认排序（term_id ASC 稳定序）。本层仅签名，实际排序
                  （EmbeddingService 形态）落地。
            page: 页码（>=1，1-based）。
            page_size: 每页条数（>=1）。

        Returns:
            items（含 out_degree/in_degree）+ 诚实 total。object_codes 与
            kb_resource_ids 全空时返回空（即使 filters 有值）。
        """
        ...

    def list_terms(
        self,
        *,
        dataset_id: str = "",
        library_id: str = "",
        domain_code: str | None = None,
        keyword: str | None = None,
        term_type: str | None = None,
        term_type_no_eq: str | None = None,
        page_index: int = 1,
        page_size: int = 50,
    ) -> QueryResult:
        """分页列出术语（每条含完整详情：parentName、synonyms、labelInfo）。

        映射到 POST /core/terms/pageList。返回的 items 为 TermDetail 列表，
        包含 ``parent_term_name``、``synonym_list``、``label_info`` 等
        ``query_terms`` 不返回的完整字段。

        典型用途：
        - 加载某个类型下的全部术语（构建 name index / dimension cache）
        - 无需并发，一个请求替代 N 个 ``get_term_detail``

        Args:
            dataset_id:      术语库 ID。
            term_type:       术语类型编码。None = 不限。
            term_type_no_eq: 排除的术语类型编码。传 ``"-1"`` 表示排除术语类型本身，
                             只返回实例。None = 不过滤。
            page_index:      页码（从 1 开始）。
            page_size:       每页条数。

        Returns:
            QueryResult，其中 items 为 TermDetail 列表。
        """
        ...

    # ── Domain ─────────────────────────────────────────────────────

    def list_domains(self, *, parent_id: str | None = None) -> list[dict[str, Any]]: ...

    def get_domain(self, *, domain_id: str) -> dict[str, Any] | None: ...

    def list_domain_term_types(self, *, domain_id: str) -> list[dict[str, Any]]: ...

    # ── TermLibrary ─────────────────────────────────────────────────

    def list_term_libraries(
        self,
        *,
        library_code: str | None = None,
        library_name: str | None = None,
    ) -> list[dict[str, Any]]: ...

    def get_term_library(self, *, library_id: str) -> dict[str, Any] | None: ...

    # ── TermType ────────────────────────────────────────────────────

    def list_term_types(self, *, type_category: int | None = None) -> list[dict[str, Any]]: ...

    def get_term_type(self, *, type_code: str) -> dict[str, Any] | None: ...

    # ── TermRelation ────────────────────────────────────────────────

    def list_term_relations(
        self,
        *,
        source_term_id: str | None = None,
        target_term_id: str | None = None,
        relation_category: str | None = None,
        relation_code: str | None = None,
        keyword: str | None = None,
        page_index: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]: ...

    def get_term_relation(self, *, relation_id: str) -> dict[str, Any] | None: ...

    # ── TermName ────────────────────────────────────────────────────

    def list_term_names(
        self,
        *,
        term_id: str | None = None,
        name_text: str | None = None,
    ) -> list[dict[str, Any]]: ...

    def get_term_name(self, *, name_id: str) -> dict[str, Any] | None: ...

    # ── TermKnowledge ───────────────────────────────────────────────

    def list_term_knowledges(
        self,
        *,
        term_id: str | None = None,
        ext_system: str | None = None,
    ) -> list[dict[str, Any]]: ...

    def get_term_knowledge(self, *, knowledge_id: str) -> dict[str, Any] | None: ...

    # ── Term ────────────────────────────────────────────────────────

    def query_term_relations(
        self,
        *,
        term_id: str,
        relation_category: str | None = None,
        direction: str = "both",
        depth: int = 1,
        term_type_codes: list[str] | None = None,
    ) -> dict[str, Any]: ...

    # ── TermVocabulary ──────────────────────────────────────────────

    def list_vocabulary(self) -> list[str]:
        """读取 term_vocabulary 全量去重词表（TermName 主名+别名投影）。

        与写入侧 :meth:`TermWriter.batch_create_vocabulary` 对称的读取通道，
        作为 AC 文本锚定的词典数据源。数据由触发器 ``trg_term_name_vocab``
        在 term_name INSERT 时自动去重维护，读取侧无需实时 DISTINCT。

        Returns:
            全量词表（word 列表）。
        """
        ...


class TermSearchEngine(Protocol):
    """文本召回引擎。每种策略独立暴露，由调用方控制策略组合和 RRF 融合。

    三路核心召回策略：
    - BM25: PostgreSQL tsvector + ts_rank_cd 全文搜索
    - Substring: 双向子串匹配（术语名⊆查询 OR 查询⊆术语名）
    - Vector: pgvector HNSW 余弦相似度搜索
    """

    def search_bm25(
        self,
        *,
        query_text: str,
        top_k: int = 10,
        min_score: float = 0.01,
        tokenizer: Tokenizer,
        term_type_codes: Sequence[str] | None = None,
        partitioned: bool = False,
        per_type_limit: int = 3,
    ) -> list[BM25Result]:
        """使用 BM25 文本匹配搜索术语名称。

        Args:
            query_text: 查询文本（原始输入，由 tokenizer 分词后构建 tsquery）。
            top_k: 返回结果数量上限。
            min_score: 最小 BM25 分数阈值。
            tokenizer: 分词器实例（负责分词和 tsquery 构建）。
            term_type_codes: 可选术语类型白名单过滤。
            partitioned: 是否按 term_type_code 分区取 top-N。
            per_type_limit: 分区模式下每个类型的 top-N 数量。

        Returns:
            BM25Result 列表，按 score 降序。
        """
        ...

    def search_substring(
        self,
        *,
        query_text: str,
        top_k: int = 20,
        term_type_codes: Sequence[str] | None = None,
        partitioned: bool = False,
        per_type_limit: int = 3,
    ) -> list[SubstringResult]:
        """执行双向子串匹配召回。

        匹配逻辑：
        1. 术语名是查询文本的子串（term_name IN query_text）
        2. 查询文本是术语名的子串（query_text IN term_name）

        Args:
            query_text: 用户输入的查询文本。
            top_k: 最大返回数量。
            term_type_codes: 可选术语类型白名单过滤。
            partitioned: 是否按 term_type_code 分区取 top-N。
            per_type_limit: 分区模式下每个类型的 top-N 数量。

        Returns:
            SubstringResult 列表，按名称长度降序。
        """
        ...

    def search_vector(
        self,
        *,
        query_vector: Sequence[float],
        top_k: int = 10,
        min_similarity: float = 0.5,
    ) -> list[VectorResult]:
        """使用预计算的向量进行语义搜索。

        Args:
            query_vector: 查询文本向量。
            top_k: 返回结果数量上限。
            min_similarity: 最小余弦相似度阈值（0-1）。

        Returns:
            VectorResult 列表，按 similarity 降序。
        """
        ...


class TermWriter(Protocol):
    """术语写入接口。所有持久化操作。

    每个方法一次原子写入。多实体级联写入由调用方编排。
    实现方负责 DB session 管理、事务控制和幂等性保证。

    支持上下文管理器协议：``with create_writer() as writer:``。
    """

    def __enter__(self) -> Self: ...

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None: ...

    def insert_term(
        self,
        *,
        term_name: str,
        term_type_code: str,
        term_code: str | None = None,
        library_id: str | None = None,
        domain_ids: list[str],
        parent_term_id: str | None = None,
        term_tags: dict[str, object] | None = None,
        user_id: str | None = None,
    ) -> str:
        """原子插入术语记录（不含知识和别名）。

        Args:
            term_name: 术语标准名称。
            term_type_code: 术语类型编码。
            term_code: 术语编码（业务唯一标识）。None 时自动生成 ``UD_xxx``。
            library_id: 术语库 ID（可选）。
            domain_ids: 所属领域 ID 列表。
            parent_term_id: 父术语 ID（可选）。
            term_tags: 术语标签属性（JSONB，可选）。
            user_id: 创建用户 ID（可选）。

        Returns:
            生成的 term_id。
        """
        ...

    def insert_term_knowledge(
        self,
        *,
        term_id: str,
        desc_summary: str,
        desc: str,
    ) -> str:
        """原子插入术语知识记录。

        Args:
            term_id: 归属术语 ID。
            desc_summary: 知识摘要。
            desc: 知识原文。

        Returns:
            生成的 knowledge_id。
        """
        ...

    def create_term_name(
        self,
        *,
        term_id: str,
        name_text: str,
        search_scope: dict[str, object],
        user_id: str | None = None,
    ) -> str:
        """创建用户级术语别名。

        Args:
            term_id: 归属术语 ID。
            name_text: 别名文本。
            search_scope: 搜索作用域（JSONB 格式，含 user_id/score/use_count 等）。
            user_id: 创建用户 ID。

        Returns:
            生成的 name_id。
        """
        ...

    def batch_create_term_names(self, *, items: Sequence[TermNameCreate]) -> list[str]:
        """批量创建术语别名。

        Args:
            items: 别名创建项列表。

        Returns:
            生成的 name_id 列表，与 items 顺序对应。
        """
        ...

    def create_term_with_knowledge(
        self,
        *,
        term_name: str,
        term_type_code: str,
        library_id: str,
        domain_ids: list[str],
        knowledge_desc: str | None = None,
        parent_term_id: str | None = None,
        term_tags: dict[str, object] | None = None,
        user_id: str | None = None,
    ) -> str:
        """创建新术语及其关联知识（级联写入）。

        .. deprecated::
            此方法包含多实体级联逻辑（INSERT term → knowledge → name）。
            新代码应使用 :meth:`insert_term` + :meth:`insert_term_knowledge`
            + :meth:`create_term_name`，编排逻辑由调用方负责。

        Args:
            term_name: 术语标准名称。
            term_type_code: 术语类型编码。
            library_id: 术语库 ID。
            domain_ids: 所属领域 ID 列表。
            knowledge_desc: 关联知识描述文本。
            parent_term_id: 父术语 ID（可选，用于实例-概念关系）。
            term_tags: 术语标签属性（JSONB）。
            user_id: 创建用户 ID。

        Returns:
            创建的 term_id。
        """
        ...

    def batch_create_vocabulary(self, *, words: Sequence[str]) -> None:
        """批量写入分词词典（TermVocabulary 表）。

        用于 jieba 自定义词典数据源，将 TermName 去重后写入。

        Args:
            words: 词汇文本列表。
        """
        ...

    def update_term_co_occurrence(self, *, term_id: str, patch: dict[str, int]) -> None:
        """更新 term_tags.co_occurrence（计数版伙伴集合，JSONB 原地合并）。

        独立新写路径：**禁止经 update_term**——其 ext_attrs 分支把
        ext_attrs 拼入 desc_summary（OpenGauss 无独立 ext_attrs 列的遗留怪癖）、
        term_tags 整列替换。本方法单条 UPDATE 原子执行，无读改写竞态。

        语义（首选原地拼接方案）：
        - 已存在伙伴 key 计数累加（patch 中该 key 的 count 累加，非 || 覆盖）
        - 新伙伴 key 插入
        - Top-50 固定上限：合并后按 count 降序取前 50（自然衰减近似）

        Args:
            term_id: 归属 term_id。
            patch: ``{partner_term_id: count}`` 增量。
        """
        ...

    def get_name_search_scope(self, *, name_id: str) -> dict[str, object] | None:
        """读取 term_name 记录上的 search_scope JSONB 字段。

        Args:
            name_id: 术语名称记录 ID。

        Returns:
            search_scope 字典，无记录或字段为 NULL 时返回 None。
        """
        ...

    def update_name_search_scope(
        self,
        *,
        name_id: str,
        search_scope: dict[str, object],
        updated_time: object,
    ) -> None:
        """原子更新 term_name 的 search_scope 和 updated_time。

        Args:
            name_id: 术语名称记录 ID。
            search_scope: 新的搜索作用域负载。
            updated_time: 更新时间（datetime 对象或 ISO 字符串）。
        """
        ...

    # ── TermProvider 协议新增方法 ──────────────────────────────────────

    def import_terms(
        self,
        *,
        dataset_id: str = "",
        library_id: str = "",
        terms: list[TermCreate],
    ) -> ImportResult:
        """批量新增术语（含同义词、标签、扩展属性）。

        映射到 POST /file/importMultipleTerm。

        Args:
            dataset_id: 目标术语库 ID。
            terms:      待新增术语列表。

        Returns:
            ImportResult，含创建数和 term_id 列表。
        """
        ...

    def upsert_term(
        self,
        *,
        term_code: str,
        term_name: str,
        term_type_code: str,
        library_id: str | None = None,
        domain_ids: list[str] | None = None,
        search_scope: dict[str, Any] | None = None,
        backfill_vectors: bool = True,
    ) -> str:
        """UPSERT 单个术语（按 term_code + term_type_code），含 term_name 和向量回填。

        写入流程：
        1. UPSERT term 行（INSERT 或 ON CONFLICT UPDATE）
        2. UPSERT term_name 行
        3. 提交事务
        4. 回填 tsvector（best-effort，失败不抛异常）
        5. 回填 embedding（best-effort，30s 超时，失败写 shell 脚本到 /tmp）

        Args:
            term_code: 术语编码（业务唯一标识）。
            term_name: 术语标准名称。
            term_type_code: 术语类型编码。
            library_id: 术语库 ID。
            domain_ids: 所属领域 ID 列表。
            search_scope: 搜索作用域（JSONB，写入 term_name.search_scope）。
            backfill_vectors: 是否回填 tsvector + embedding。

        Returns:
            term_id（UUID）。
        """
        ...

    def update_term(
        self,
        *,
        dataset_id: str,
        term_id: str,
        updates: TermUpdate,
    ) -> None:
        """更新术语。仅更新非 None 字段。

        映射到 POST /core/terms/updateTerm。

        Args:
            dataset_id: 术语库 ID。
            term_id:    术语 ID。
            updates:    更新字段（None = 不修改）。

        Raises:
            ValueError: 术语不存在。
        """
        ...

    # ── Domain ─────────────────────────────────────────────────────

    def create_domain(self, *, domain: dict[str, Any]) -> dict[str, Any]: ...

    def update_domain(
        self, *, library_id: str, domain_code: str, updates: dict[str, Any]
    ) -> None: ...

    def delete_domain(self, *, library_id: str, domain_code: str) -> None: ...

    # ── TermLibrary ─────────────────────────────────────────────────

    def create_term_library(self, *, library: dict[str, Any]) -> dict[str, Any]: ...

    def update_term_library(self, *, library_id: str, updates: dict[str, Any]) -> None: ...

    def delete_term_library(self, *, library_id: str) -> None: ...

    # ── TermType ────────────────────────────────────────────────────

    def create_term_type(self, *, library_id: str, term_type: dict[str, Any]) -> dict[str, Any]: ...

    def update_term_type(
        self, *, library_id: str, type_code: str, updates: dict[str, Any]
    ) -> None: ...

    def delete_term_type(self, *, library_id: str, type_code: str) -> None: ...

    # ── TermRelation ────────────────────────────────────────────────

    def create_term_relation(self, *, relation: dict[str, Any]) -> dict[str, Any]: ...

    def update_term_relation(self, *, relation_id: str, updates: dict[str, Any]) -> None: ...

    def delete_term_relation(self, *, relation_id: str) -> None: ...

    # ── TermName ────────────────────────────────────────────────────

    def create_term_name_wrapper(self, *, name: dict[str, Any]) -> dict[str, Any]: ...

    def update_term_name(self, *, name_id: str, updates: dict[str, Any]) -> None: ...

    def delete_term_name(self, *, name_id: str) -> None: ...

    # ── TermKnowledge ───────────────────────────────────────────────

    def create_term_knowledge(self, *, knowledge: dict[str, Any]) -> dict[str, Any]: ...

    def update_term_knowledge(self, *, knowledge_id: str, updates: dict[str, Any]) -> None: ...

    def delete_term_knowledge(self, *, knowledge_id: str) -> None: ...

    # ── Term ────────────────────────────────────────────────────────

    def delete_term(self, *, term_id: str) -> None: ...

    # ── Bulk operations ────────────────────────────────────────────

    def bulk_upsert_terms_no_library(
        self,
        *,
        terms: list[tuple[str, str, str]],
    ) -> list[str]:
        """批量 UPSERT term 行（无 library_id 场景）。

        1 次 SELECT 分组 → executemany INSERT 新行 → executemany UPDATE 旧行。

        Args:
            terms: (term_code, term_name, term_type_code) 元组列表。

        Returns:
            term_id 列表，与 terms 顺序对应。
        """
        ...

    def bulk_create_term_names_no_scope(
        self,
        *,
        items: list[tuple[str, str]],
    ) -> None:
        """批量创建 term_name，幂等跳过已存在。

        Args:
            items: (term_id, name_text) 元组列表。
        """
        ...
