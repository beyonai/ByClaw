"""Assemble the DataCloud analysis StateGraph.

V0.3 architecture: intend → llm_call → (Send) per-tool-node → llm_call → ... → finish_react → respond
V0.4 architecture（feature flag DATACLOUD_USE_PREBUILT_REACT=true）:
    intend → agent → HookAwareToolNode(tools) → finish_react_node / analyze_clarify → respond
"""

from __future__ import annotations

import logging
import os
from collections.abc import Callable, Mapping
from typing import Any, Literal, cast

from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.runnables import RunnableConfig
from langgraph.graph import END, START, StateGraph
from langgraph.types import Send

from datacloud_analysis.i18n.prompts import (
    _build_ontology_rules_zh,
    get_execution_prompt,
    get_system_prompt,
)
from datacloud_analysis.orchestration.clarification.analyze_clarify_node import (
    analyze_clarify_node,
)
from datacloud_analysis.orchestration.clarification.user_clarify_node import user_clarify_node
from datacloud_analysis.orchestration.execution.finish_react_node import finish_react_node
from datacloud_analysis.orchestration.execution.llm_call_node import make_llm_call_node
from datacloud_analysis.orchestration.execution.make_tool_node import make_tool_node
from datacloud_analysis.orchestration.execution.node import _build_tools_list
from datacloud_analysis.orchestration.execution.tool_dispatcher_node import (
    make_tool_dispatcher_node,
)
from datacloud_analysis.orchestration.intend.node import intend_node
from datacloud_analysis.orchestration.respond.node import respond_node
from datacloud_analysis.orchestration.state import AgentState

try:
    from datacloud_analysis.tools.anchor_tools import make_anchor_tools
    from datacloud_analysis.tools.tool_pool import is_anchor_mode
except Exception:  # pragma: no cover
    make_anchor_tools = None  # type: ignore[assignment]
    is_anchor_mode = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

_DEFAULT_MAX_ROUNDS = int(os.getenv("DATACLOUD_REACT_MAX_ROUNDS", "10"))


# ── V0.4 路由函数（feature flag 新路径）────────────────────────────────────────


def should_continue(state: AgentState) -> str:
    """agent 节点出口：决定是否继续调用工具。

    L1: agent_abort=True → __end__（bad checkpoint 激活，直接终止该路径）
    L2: AIMessage 无 tool_calls → respond（LLM 直接文字回答）
    L3: execution_status=max_rounds_exceeded 或 react_round_idx >= max_rounds → respond
    其他: → tools（finish_react 也必须走 tools 节点执行工具体）
    """
    if state.get("agent_abort"):
        logger.info("[should_continue] agent_abort=True → __end__ (bad checkpoint activation)")
        return "__end__"

    # dead_end 全覆盖兜底：所有节点均为 dead_end 且 findings 为空 → 强制 respond
    rg = state.get("reasoning_graph") or {}
    nodes = rg.get("nodes") or {}
    if nodes:
        all_dead = all(n.get("is_dead_end", False) for n in nodes.values())
        has_findings = bool(rg.get("findings"))
        if all_dead and not has_findings:
            logger.warning("[should_continue] all nodes dead_end and no findings, forcing respond")
            return "respond"

    status = str(state.get("execution_status") or "")
    if status == "max_rounds_exceeded":
        return "respond"

    messages = list(state.get("messages") or [])
    last_ai = next((m for m in reversed(messages) if isinstance(m, AIMessage)), None)
    if last_ai is None or not (last_ai.tool_calls or []):
        return "respond"

    if int(state.get("react_round_idx") or 0) >= _DEFAULT_MAX_ROUNDS:
        return "respond"

    return "tools"


def after_tools_route(state: AgentState) -> Literal["agent", "finish_react_node"]:
    """tools 节点出口（正常执行路径）。

    L1: 本轮 ToolMessage 中含 finish_react → finish_react_node
    L2: target_tool 模式 → finish_react_node（不让 LLM 重试其他工具）
    其他: → agent（继续下一轮 LLM 推理）

    ClarificationNeededError 由 HookAwareToolNode 返回 Command 直接路由，不经过此函数。
    """
    messages = list(state.get("messages") or [])
    for msg in reversed(messages):
        if isinstance(msg, AIMessage):
            break
        if isinstance(msg, ToolMessage) and msg.name == "finish_react":
            return "finish_react_node"
    if str(state.get("target_tool") or ""):
        return "finish_react_node"
    return "agent"


def _route_after_user_clarify(state: AgentState) -> str:
    """user_clarify 完成后的条件路由。

    clarify_abort=True → END（DUPLICATE GUARD 触发的重复路径，防止产生多余 respond）
    otherwise → continue（交由调用方映射到 tools / tool_dispatcher）
    """
    if state.get("clarify_abort"):
        logger.info("[_route_after_user_clarify] clarify_abort=True → END (duplicate path aborted)")
        return "__end__"
    return "continue"


def _route_after_intend(state: AgentState) -> str:
    status = str(state.get("execution_status") or "llm_call")
    if status == "command_done":
        return "command_done"
    if status == "target_tool_direct":
        return "tool_dispatcher"
    return "llm_call"


def _route_after_tool_node(state: AgentState) -> str:
    """Per-tool 节点执行后的路由：澄清 → analyze_clarify；否则回到 llm_call。"""
    status = str(state.get("execution_status") or "")
    if status == "clarify_needed":
        return "analyze_clarify"
    return "llm_call"


def _route_after_tool_dispatcher(state: AgentState) -> str:
    status = str(state.get("execution_status") or "")
    if status == "finish_react":
        return "finish_react"
    if status == "clarify_needed":
        return "analyze_clarify"
    # target_tool 模式：工具执行完后直接走 finish_react，不让 LLM 重试其他工具
    if str(state.get("target_tool") or ""):
        return "finish_react"
    return "llm_call"


def _route_after_analyze(state: AgentState) -> str:
    analyze_result = state.get("clarification_analyze_result") or {}
    if str(analyze_result.get("interrupt_type") or "") == "operation_form":
        return "user_clarify"
    paradigm_list = list(analyze_result.get("paradigm_list") or [])
    if paradigm_list:
        return "user_clarify"
    return "tool_dispatcher"


def _make_per_tool_wrapper(
    fn: Callable[..., Any],
    name: str,
    as_state_update: Callable[[Any, str], dict[str, Any]],
) -> Callable[[AgentState, RunnableConfig], Any]:
    """工厂：为每个工具节点创建包装闭包，捕获 fn / name 避免循环变量泄漏。"""

    async def _wrapper(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await fn(state, config)
        return as_state_update(result, name)

    return _wrapper


def _as_state_update(value: object, *, node_name: str) -> dict[str, Any]:
    """Normalize node output into a concrete state update mapping."""
    if isinstance(value, Mapping):
        return dict(cast(Mapping[str, Any], value))
    msg = f"{node_name} node must return a mapping, got {type(value).__name__}"
    raise TypeError(msg)


def build_analysis_graph(
    prompts_overwrite: dict[str, Any] | None = None,
    tools: dict[str, Any] | None = None,
    loader: Any = None,
    redirect_tools: dict[str, Any] | None = None,
    is_sub_agent: bool = False,
    tool_context: Any = None,
    mounted_objects: list[str] | None = None,
) -> StateGraph[AgentState]:
    """Return an uncompiled StateGraph.

    路由由 DATACLOUD_USE_PREBUILT_REACT 环境变量控制：
    - true（默认）：V0.4 prebuilt ToolNode 图拓扑（当前生产路径）
    - false：V0.3 自研图拓扑（旧路径，已废弃）

    Args:
        is_sub_agent: True 时为分身模式，不追加 sub_agent 工具（防递归）。
        tool_context: 请求级 RequestToolContext，用于替代全局 TOOL_POOL。
    """
    use_prebuilt = os.getenv("DATACLOUD_USE_PREBUILT_REACT", "true").strip().lower() == "true"
    if use_prebuilt:
        logger.info("build_analysis_graph: V0.4 prebuilt path (DATACLOUD_USE_PREBUILT_REACT=true)")
        return _build_prebuilt_graph(
            prompts_overwrite=prompts_overwrite,
            tools=tools,
            loader=loader,
            redirect_tools=redirect_tools,
            is_sub_agent=is_sub_agent,
            tool_context=tool_context,
            mounted_objects=mounted_objects,
        )
    return _build_legacy_graph(
        prompts_overwrite=prompts_overwrite,
        tools=tools,
        loader=loader,
        redirect_tools=redirect_tools,
    )


def _build_legacy_graph(
    prompts_overwrite: dict[str, Any] | None = None,
    tools: dict[str, Any] | None = None,
    loader: Any = None,
    redirect_tools: dict[str, Any] | None = None,
) -> StateGraph[AgentState]:
    """V0.3 自研 StateGraph（旧路径，现有生产代码不修改）。"""
    logger.warning(
        "build_analysis_graph: V0.3 legacy path activated "
        "(DATACLOUD_USE_PREBUILT_REACT=false) — "
        "此路径已废弃，请将 DATACLOUD_USE_PREBUILT_REACT 设为 true 切换到 V0.4"
    )
    builder = StateGraph(AgentState)

    # ── 构建 system prompt（stable 部分，供 Prompt Caching）──────────────────────
    overwrite = prompts_overwrite or {}
    locale = str(overwrite.get("locale") or os.getenv("DATACLOUD_AGENT_LOCALE", "zh_CN"))
    custom_system = str(overwrite.get("system_prompt") or "").strip()
    custom_task = str(overwrite.get("task_prompt") or "").strip()
    base_system = get_system_prompt(locale)
    base_execution = get_execution_prompt(locale)
    system_parts = [custom_system if custom_system else base_system, base_execution]
    if custom_task:
        system_parts.append(custom_task)
    # available_skills XML 注入已废弃：Skill 通过 search_ontology + TOOL_POOL 动态发现
    stable_system_prompt = "\n\n".join(p for p in system_parts if p)

    # ── 构建 tools_list ──────────────────────────────────────────────────────────
    tools_list = _build_tools_list(tools)

    # ── redirect_tools_map ───────────────────────────────────────────────────────
    from langchain_core.tools import BaseTool  # noqa: PLC0415

    redirect_tools_map: dict[str, BaseTool] | None = None
    if redirect_tools:
        redirect_tools_map = {
            name: t for name, t in redirect_tools.items() if isinstance(t, BaseTool)
        }

    # ── 构建 per-tool 节点名集合（用于路由）──────────────────────────────────────
    _tool_node_names: frozenset[str] = frozenset(t.name for t in tools_list)

    # ── 创建节点闭包 ─────────────────────────────────────────────────────────────
    llm_call_fn = make_llm_call_node(
        tools_list=tools_list,
        system_prompt=stable_system_prompt,
        stable_system_prompt=stable_system_prompt,
    )
    tool_dispatcher_fn = make_tool_dispatcher_node(
        tools_list=tools_list,
        loader=loader,
        redirect_tools_map=redirect_tools_map,
    )

    # ── llm_call 路由（V0.3 Send API：路由到 per-tool 节点）─────────────────────
    def _route_after_llm_call(state: AgentState) -> str | list[Send]:  # type: ignore[return]
        status = str(state.get("execution_status") or "")
        if status == "max_rounds_exceeded":
            return "finish_react"

        messages = list(state.get("messages") or [])
        last_ai: AIMessage | None = None
        for msg in reversed(messages):
            if isinstance(msg, AIMessage):
                last_ai = msg
                break

        if last_ai is None:
            return "finish_react"

        calls = list(getattr(last_ai, "tool_calls", None) or [])
        if not calls:
            return "finish_react"

        non_finish = [tc for tc in calls if tc.get("name") != "finish_react"]
        if not non_finish:
            return "finish_react"

        # Per-tool Send 路由（各工具并行执行）
        # 这里必须把“当前 tool_call”连同 state 一起传下去：如果只传 state，
        # make_tool_node 会退回按工具名找第一条同名 call，同一轮多个同名工具时会把
        # 第二个 call 吃成第一个，最终写出错误的 tool_call_id，触发前面的配对问题。
        # Send(node, arg) 中 arg 是目标节点的完整 input state，必须传当前 state 而非 {}
        if _tool_node_names:
            sends = [
                Send(tc["name"], _state_for_tool_call(state, tc))
                for tc in non_finish
                if tc.get("name") in _tool_node_names
            ]
            if sends:
                return sends  # type: ignore[return-value]

        return "tool_dispatcher"

    # ── 注册节点 ─────────────────────────────────────────────────────────────────
    async def _intend(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await intend_node(state, config)
        return _as_state_update(result, node_name="intend")

    async def _llm_call(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await llm_call_fn(state, config)
        return _as_state_update(result, node_name="llm_call")

    async def _tool_dispatcher(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await tool_dispatcher_fn(state, config)
        return _as_state_update(result, node_name="tool_dispatcher")

    async def _finish_react(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await finish_react_node(state, config)
        return _as_state_update(result, node_name="finish_react")

    async def _analyze_clarify(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await analyze_clarify_node(state, config)
        return _as_state_update(result, node_name="analyze_clarify")

    async def _user_clarify(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await user_clarify_node(state, config)
        return _as_state_update(result, node_name="user_clarify")

    async def _respond(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await respond_node(state, config)
        return _as_state_update(result, node_name="respond")

    builder.add_node("intend", _intend)
    builder.add_node("llm_call", _llm_call)
    builder.add_node("tool_dispatcher", _tool_dispatcher)
    builder.add_node("finish_react", _finish_react)
    builder.add_node("analyze_clarify", _analyze_clarify)
    builder.add_node("user_clarify", _user_clarify)
    builder.add_node("respond", _respond)

    # ── 注册 per-tool 节点（每个工具一个独立 LangGraph 节点）────────────────────
    for _tool_fn in tools_list:
        _per_tool_node_fn = make_tool_node(
            _tool_fn.name,
            _tool_fn,
            loader=loader,
            redirect_tools_map=redirect_tools_map,
        )
        _per_tool_wrapper_fn = cast(
            Any,
            _make_per_tool_wrapper(
                _per_tool_node_fn,
                _tool_fn.name,
                lambda r, n: _as_state_update(r, node_name=n),
            ),
        )
        builder.add_node(
            _tool_fn.name,
            _per_tool_wrapper_fn,
        )
        builder.add_conditional_edges(
            _tool_fn.name,
            _route_after_tool_node,
            {"llm_call": "llm_call", "analyze_clarify": "analyze_clarify"},
        )

    # ── 边 ───────────────────────────────────────────────────────────────────────
    builder.add_edge(START, "intend")
    builder.add_conditional_edges(
        "intend",
        _route_after_intend,
        {"command_done": END, "llm_call": "llm_call", "tool_dispatcher": "tool_dispatcher"},
    )
    builder.add_conditional_edges(
        "llm_call",
        _route_after_llm_call,
        {"finish_react": "finish_react", "tool_dispatcher": "tool_dispatcher"},
    )
    builder.add_conditional_edges(
        "tool_dispatcher",
        _route_after_tool_dispatcher,
        {
            "finish_react": "finish_react",
            "llm_call": "llm_call",
            "analyze_clarify": "analyze_clarify",
        },
    )
    builder.add_conditional_edges(
        "analyze_clarify",
        _route_after_analyze,
        {"user_clarify": "user_clarify", "tool_dispatcher": "tool_dispatcher"},
    )
    builder.add_conditional_edges(
        "user_clarify",
        _route_after_user_clarify,
        {"continue": "tool_dispatcher", "__end__": END},
    )
    builder.add_edge("finish_react", "respond")
    builder.add_edge("respond", END)

    tool_keys = sorted((tools or {}).keys())
    redirect_tool_keys = sorted((redirect_tools or {}).keys())
    logger.info(
        "build_analysis_graph: V0.3 pipeline wired — tools count=%d keys=%s "
        "redirect_tools count=%d keys=%s",
        len(tool_keys),
        tool_keys,
        len(redirect_tool_keys),
        redirect_tool_keys,
    )

    return builder


def _state_for_tool_call(state: AgentState, tool_call: dict[str, Any]) -> AgentState:
    """复制图状态，并为 per-tool Send 节点附上当前的具体 tool_call。

    这样每个并行工具节点都能拿到自己对应的 call，避免仅靠 tool_name 回退时
    把多个同名工具错误配对成同一个 tool_call_id。
    """
    next_state = dict(state)
    next_state["react_current_tool_call"] = dict(tool_call)
    return next_state  # type: ignore[return-value]


# ── V0.4 prebuilt 图构建（feature flag 新路径）────────────────────────────────


def _build_prebuilt_graph(
    prompts_overwrite: dict[str, Any] | None = None,
    tools: dict[str, Any] | None = None,
    loader: Any = None,
    redirect_tools: dict[str, Any] | None = None,
    is_sub_agent: bool = False,
    tool_context: Any = None,
    mounted_objects: list[str] | None = None,
) -> StateGraph[AgentState]:
    """V0.4 新图拓扑：intend → agent → HookAwareToolNode(tools) → respond。

    新增节点：
    - agent：复用 make_llm_call_node（与旧路径相同的 LLM 调用逻辑）
    - tools：HookAwareToolNode（before/after hook，ClarificationNeededError→Command）

    删除节点（相比 V0.3）：
    - tool_dispatcher_node、per-tool Send 节点（make_tool_node）

    保留节点：
    - intend、finish_react_node、analyze_clarify、user_clarify、respond
    """
    from datacloud_analysis.orchestration.execution.hook_aware_tool_node import (  # noqa: PLC0415
        HookAwareToolNode,
    )
    from datacloud_analysis.orchestration.execution.react_loop import finish_react  # noqa: PLC0415

    builder: StateGraph[AgentState] = StateGraph(AgentState)

    # ── system prompt ────────────────────────────────────────────────────────────
    overwrite = prompts_overwrite or {}
    locale = str(overwrite.get("locale") or os.getenv("DATACLOUD_AGENT_LOCALE", "zh_CN"))
    custom_system = str(overwrite.get("system_prompt") or "").strip()
    custom_task = str(overwrite.get("task_prompt") or "").strip()
    base_system = get_system_prompt(locale)
    base_execution = get_execution_prompt(locale)
    system_parts = [custom_system if custom_system else base_system, base_execution]
    if custom_task:
        system_parts.append(custom_task)
    # 注入本体推理规则段（三种机制触发时机 + 持续努力规则）
    try:
        ontology_rules = _build_ontology_rules_zh()
        if ontology_rules:
            system_parts.append(ontology_rules)
    except Exception:  # noqa: BLE001
        logger.debug("_build_prebuilt_graph: ontology_rules injection skipped", exc_info=True)
    # available_skills XML 注入已废弃：Skill 通过 search_ontology + TOOL_POOL 动态发现
    stable_system_prompt = "\n\n".join(p for p in system_parts if p)

    # ── tools_list（含 finish_react sentinel 工具）────────────────────────────────
    tools_list = _build_tools_list(tools)
    # 从 TOOL_POOL 合并 Agent 自身 mounted_objects 范围内的工具
    # （init_agent_conf 的 OBJECT/VIEW 工具走 generic query_objects 路径，
    # 不生成 per-object 工具，而是由 _init_ext_tool_pool 全量加载到 TOOL_POOL。
    # ToolNode 固化 tools_list 后无法感知后续 activate_anchor 解锁的工具，
    # 因此需在构建时合并 TOOL_POOL 中属于当前 Agent scope 的工具。）
    try:
        from langchain_core.tools import BaseTool  # noqa: PLC0415

        from datacloud_analysis.tools.tool_pool import TOOL_POOL, TOOL_TO_OBJECT  # noqa: PLC0415

        _agent_codes: set[str] = {o for o in (mounted_objects or []) if o}
        _existing = {t.name for t in tools_list}
        _added = 0
        # 当 mounted_objects 为空时（纯远程 agent），不合并任何 TOOL_POOL 工具。
        # 远程对象的工具由激活时动态解锁（activate_anchor → _activate_object_with_context），
        # 不通过 TOOL_POOL 静态合并。
        if _agent_codes:
            for _pn, _pt in TOOL_POOL.items():
                if _pn in _existing or not isinstance(_pt, BaseTool):
                    continue
                # 用 TOOL_TO_OBJECT 反查工具归属，只合并属于当前 Agent mounted_objects 范围的工具
                _obj = TOOL_TO_OBJECT.get(_pn, "")
                if _obj and _obj not in _agent_codes:
                    continue
                tools_list.append(_pt)
                _added += 1
        if _added:
            logger.info(
                "[graph_builder] merged %d in-scope tools from TOOL_POOL (tools_list: %d→%d)",
                _added,
                len(tools_list) - _added,
                len(tools_list),
            )
    except Exception:
        pass

    # ── Skill 注册与阈值注入 ─────────────────────────────────────────────────
    # skill_catalog 由 worker.py 通过 prompts_overwrite["skill_catalog"] 传入。
    # ① 全部注册到 TOOL_POOL（供 search_ontology + preconditions 按需解锁）
    # ② 非锚点模式：activate_skill_* wrapper 直接加入 tools_list（LLM 可见）
    #    锚点模式：wrapper 已在 TOOL_POOL，LLM 通过 search_ontology 按需发现
    _skill_catalog: list[dict[str, Any]] = overwrite.get("skill_catalog") or []
    if _skill_catalog:
        try:
            from datacloud_analysis.tools.tool_pool import (  # noqa: PLC0415
                TOOL_POOL as _TOOL_POOL,
            )
            from datacloud_analysis.tools.tool_pool import (
                is_anchor_mode as _is_anchor_mode,
            )
            from datacloud_analysis.tools.tool_pool import (
                register_skill_wrappers,
            )

            # ① 全部注册到 TOOL_POOL
            register_skill_wrappers(_skill_catalog)
            _skill_registered = sum(1 for k in _TOOL_POOL if k.startswith("activate_skill_"))
            logger.info(
                "[graph_builder] registered %d skill wrappers to TOOL_POOL",
                _skill_registered,
            )

            # ② 阈值判断：非锚点模式下直接注入 tools_list
            if not _is_anchor_mode():
                _skill_added = 0
                _existing_names = {t.name for t in tools_list}
                for _pn, _pt in _TOOL_POOL.items():
                    if _pn.startswith("activate_skill_") and _pn not in _existing_names:
                        tools_list.append(_pt)
                        _skill_added += 1
                if _skill_added:
                    logger.info(
                        "[graph_builder] injected %d skill wrappers into tools_list "
                        "(non-anchor mode)",
                        _skill_added,
                    )
            else:
                logger.info(
                    "[graph_builder] anchor mode: skill wrappers in TOOL_POOL, "
                    "LLM discovers via search_ontology"
                )
        except Exception:
            logger.debug("[graph_builder] skill registration skipped", exc_info=True)

    # 附06-V3：锚点模式下，把 activate_anchor / mark_dead_end 加入工具列表
    try:
        if make_anchor_tools is None or is_anchor_mode is None:
            raise ImportError("anchor_tools or tool_pool not available")

        _use_anchor = tool_context.anchor_mode if tool_context is not None else is_anchor_mode()
        if _use_anchor:
            _tc = tool_context  # 闭包捕获（构建期可能为 None）

            def _get_tool_ctx() -> Any:
                # 优先使用模块级注入的运行时 tool_context（由 intend_node 设置）
                from datacloud_analysis.tools.anchor_tools import (
                    _pending_tool_context,  # noqa: PLC0415
                )

                if _pending_tool_context is not None:
                    return _pending_tool_context
                return _tc

            _anchor_tools = make_anchor_tools(
                get_state_fn=lambda: {},
                get_tool_context_fn=_get_tool_ctx,
            )
            tools_list = [*tools_list, *_anchor_tools]
            logger.info(
                "_build_prebuilt_graph: anchor mode active, added %d anchor tools",
                len(_anchor_tools),
            )
    except Exception:  # noqa: BLE001
        logger.debug("_build_prebuilt_graph: anchor tools init skipped", exc_info=True)

    # 仅主 Agent 追加 sub_agent 工具；分身（is_sub_agent=True）不追加，防递归
    if not is_sub_agent:
        try:
            from datacloud_analysis.tools.skill_executor import sub_agent as _sub_agent  # noqa: PLC0415, I001

            tools_list = [*tools_list, _sub_agent]
            logger.info("_build_prebuilt_graph: sub_agent tool added (main agent)")
        except Exception:  # noqa: BLE001
            logger.debug("_build_prebuilt_graph: sub_agent tool init skipped", exc_info=True)

    # finish_react 必须在 ToolNode tools 列表中，ToolNode 才能执行它
    all_tools = [*tools_list, finish_react]
    # redirect_tools（data_query_*）只加入 ToolNode 执行列表，不加入 bind_tools。
    # LLM 看不到这些工具，只有 complex_conditions 触发的内部 redirect 或
    # target_tool 强制路由时才会被执行。
    redirect_list = list((redirect_tools or {}).values())
    executable_tools = [*all_tools, *redirect_list]

    # ── 节点闭包 ─────────────────────────────────────────────────────────────────
    llm_call_fn = make_llm_call_node(
        tools_list=tools_list,
        system_prompt=stable_system_prompt,
        stable_system_prompt=stable_system_prompt,
    )

    hook_tool_node = HookAwareToolNode(executable_tools, loader=loader)

    # ── 节点包装（统一 _as_state_update 校验）────────────────────────────────────
    async def _intend(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await intend_node(state, config)
        return _as_state_update(result, node_name="intend")

    async def _agent(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        # DIAG: logs state messages count entering agent node to debug checkpoint accumulation
        _raw_msgs = list(state.get("messages") or [])
        _raw_count = len(_raw_msgs)
        _msg_preview = []
        for _m in _raw_msgs[-5:]:
            _mt = type(_m).__name__
            _mc = str(getattr(_m, "content", ""))[:50].replace("\n", " ")
            _msg_preview.append(f"{_mt}({_mc})")
        _thread = (config.get("configurable") or {}).get("thread_id", "?")
        _round = state.get("react_round_idx", 0)
        logger.info(
            "[_agent DIAG] ENTER thread=%s round=%s raw_messages=%d preview=%s",
            _thread,
            _round,
            _raw_count,
            _msg_preview[-5:],
        )
        result = await llm_call_fn(state, config)
        return _as_state_update(result, node_name="agent")

    async def _finish_react(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await finish_react_node(state, config)
        return _as_state_update(result, node_name="finish_react_node")

    async def _analyze_clarify(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await analyze_clarify_node(state, config)
        return _as_state_update(result, node_name="analyze_clarify")

    async def _user_clarify(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await user_clarify_node(state, config)
        return _as_state_update(result, node_name="user_clarify")

    async def _respond(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        result = await respond_node(state, config)
        return _as_state_update(result, node_name="respond")

    # ── 注册节点 ─────────────────────────────────────────────────────────────────
    builder.add_node("intend", _intend)
    builder.add_node("agent", _agent)
    builder.add_node("tools", hook_tool_node)  # HookAwareToolNode 直接作为节点
    builder.add_node("finish_react_node", _finish_react)
    builder.add_node("analyze_clarify", _analyze_clarify)
    builder.add_node("user_clarify", _user_clarify)
    builder.add_node("respond", _respond)

    # ── 边 ───────────────────────────────────────────────────────────────────────
    builder.add_edge(START, "intend")
    builder.add_conditional_edges(
        "intend",
        _route_after_intend,
        {"command_done": END, "llm_call": "agent", "tool_dispatcher": "tools"},
    )
    builder.add_conditional_edges(
        "agent",
        should_continue,
        {"tools": "tools", "respond": "respond", "__end__": END},
    )
    builder.add_conditional_edges(
        "tools",
        after_tools_route,
        {"agent": "agent", "finish_react_node": "finish_react_node"},
    )
    # ClarificationNeededError 由 HookAwareToolNode 返回 Command(goto="analyze_clarify")
    # LangGraph 自动路由，无需额外 add_conditional_edges
    builder.add_conditional_edges(
        "analyze_clarify",
        _route_after_analyze,
        {"user_clarify": "user_clarify", "tool_dispatcher": "tools"},
    )
    builder.add_conditional_edges(
        "user_clarify",
        _route_after_user_clarify,
        {"continue": "tools", "__end__": END},
    )
    builder.add_edge("finish_react_node", "respond")
    builder.add_edge("respond", END)

    tool_keys = sorted((tools or {}).keys())
    logger.info(
        "_build_prebuilt_graph: V0.4 pipeline wired — tools count=%d keys=%s",
        len(tool_keys),
        tool_keys,
    )

    return builder
