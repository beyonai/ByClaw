"""OntologyAgent — DataCloud SDK 公开 API（无 Gateway 中间层直调版本）。

设计文档：docs/概要设计/gateway解耦方案/dataCloud重构方案.md
"""

from __future__ import annotations

import logging
import uuid
from collections import OrderedDict
from collections.abc import AsyncGenerator
from dataclasses import dataclass
from dataclasses import field as dc_field
from pathlib import Path
from typing import Any

from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

from datacloud_analysis.reporter import NoOpExecutionReporter

logger = logging.getLogger(__name__)

# ── 平台路由 ──────────────────────────────────────────────────────────────────
from datacloud_platform import get_platform  # noqa: E402
from datacloud_platform.constants import DEFAULT_BASE_ID  # noqa: E402

# ── 进程级图缓存上限（与 worker.py 原有 LRU 上限对齐） ──────────────────────
_CACHE_MAX: int = 32

# ── 事件模型 ─────────────────────────────────────────────────────────────────


class OntologyAgentEvent:
    """所有事件的基类，用于类型注解。"""


@dataclass
class ThinkingEvent(OntologyAgentEvent):
    """LLM 推理中的增量 token（来自非 respond 节点）。"""

    content: str


@dataclass
class StepEvent(OntologyAgentEvent):
    """执行阶段标题或思考过程片段（来自 dc_stream_chunk 自定义事件）。"""

    title: str
    detail: str | None = None
    event_type: str = (
        ""  # 保留 dc_stream_chunk 的原始 event_type（reasoningLogStart / reasoningLogDelta）
    )
    content_type: str = (
        ""  # dc_stream_chunk 的 content_type（如 "1002" think_text / "2020" jsonBlock）
    )
    message_id: str = ""  # dc_stream_chunk 的 message_id，用于前端层级渲染
    parent_message_id: str = ""  # dc_stream_chunk 的 parent_message_id


@dataclass
class OperationFormField:
    """操作确认表单字段，支持通过 children 递归表达对象和对象数组。"""

    form_type: str
    field_code: str
    field_name: str
    field_type: str
    field_path: str = ""
    field_value: Any = None
    children: list[list[OperationFormField]] | None = None
    item_id: str = ""
    description: str = ""
    required: bool = False
    readonly: bool = False
    disabled: bool = False
    is_hidden: bool = False
    default_files: list[str] = dc_field(default_factory=list)
    term: dict[str, Any] | None = None
    term_resolve_notice: dict[str, Any] | None = None
    raw: dict[str, Any] = dc_field(default_factory=dict)


@dataclass
class OperationFormAction:
    """操作确认表单中的单个 action。"""

    tool_call_id: str
    tool_name: str
    action_code: str
    action_name: str = ""
    title: str = ""
    description: str = ""
    confirmed: bool | None = None
    reason: str = ""
    form_mode: str = ""
    summary: dict[str, Any] = dc_field(default_factory=dict)
    rule: list[list[OperationFormField]] = dc_field(default_factory=list)
    raw: dict[str, Any] = dc_field(default_factory=dict)


@dataclass
class OperationForm:
    """操作确认表单，actions 表达单个或多个工具调用表单。"""

    schema_version: str
    form_id: str
    title: str = ""
    description: str = ""
    form_mode: str = ""
    actions: list[OperationFormAction] = dc_field(default_factory=list)
    raw: dict[str, Any] = dc_field(default_factory=dict)

    @property
    def action_code(self) -> str:
        """Compatibility accessor for legacy single-action callers."""
        return self.actions[0].action_code if self.actions else ""

    @property
    def action_name(self) -> str:
        """Compatibility accessor for legacy single-action callers."""
        return self.actions[0].action_name if self.actions else ""

    @property
    def rule(self) -> list[list[OperationFormField]]:
        """Compatibility accessor for legacy single-action callers."""
        return self.actions[0].rule if self.actions else []


@dataclass
class InterruptEvent(OntologyAgentEvent):
    """图在此处暂停，调用方需处理后调用 resume()。"""

    thread_id: str
    reason: str  # "PARADIGM_CLARIFICATION" | "ASK_USER" | ...
    prompt: str
    interrupt_type: str = ""
    paradigm_list: list[ParadigmGroup] | None = None
    query: str = ""
    operation_form: OperationForm | None = None


@dataclass
class AnswerEvent(OntologyAgentEvent):
    """最终答案（完整内容，一次性 yield）。"""

    content: str


@dataclass
class ErrorEvent(OntologyAgentEvent):
    """流异常终止。"""

    message: str
    code: str | None = None


@dataclass
class PerfEvent(OntologyAgentEvent):
    """单次 ask/resume 的性能汇总，在 AnswerEvent 之后 yield。"""

    total_duration_ms: int
    ttft_ms: int | None
    react_turns: int
    llm_call_count: int
    interrupt_count: int
    thinking_chars: int
    thinking_duration_ms: int
    thinking_chars_per_sec: float
    last_tool_called: str = ""


# ── 维度选项模型 ──────────────────────────────────────────────────────────────


@dataclass
class ParadigmOption:
    choice_keyword: str
    recall: list[str]
    keyword: str = ""
    kid: int = 0
    ktype: str = ""
    # 过滤条件（paradigmType='filter'）专用字段
    filter_field: str = ""
    comparison: str = ""
    value: str = ""
    choice_field: str = ""
    choice_comparison: str = ""
    field_recall: list[str] = dc_field(default_factory=list)
    comparison_recall: list[str] = dc_field(default_factory=list)
    value_recall: list[str] = dc_field(default_factory=list)


@dataclass
class ParadigmGroup:
    paradigm_id: str
    paradigm_name: str
    options: list[ParadigmOption] = dc_field(default_factory=list)


@dataclass
class ParadigmGroupSelection:
    paradigm_id: str
    paradigm_name: str
    chosen_options: list[ParadigmOption] = dc_field(default_factory=list)


@dataclass
class ParadigmAnswer:
    """用户选择的维度答案，传给 resume()。"""

    selections: list[ParadigmGroupSelection] = dc_field(default_factory=list)


# ── 配置模型 ──────────────────────────────────────────────────────────────────


@dataclass
class OntologyAgentConfig:
    api_key: str
    model: str
    resource_path: str | Path
    base_url: str | None = None
    locale: str = "zh_CN"
    temperature: float = 0.7
    model_kwargs: dict[str, Any] | None = None
    # 结果文件存储后端（如 byclaw 的 ByclawResultFileStorage）。由调用方注入，
    # OntologyAgent 内不感知具体类型。已通过 LoaderRuntimeManager 统一管理。
    result_file_storage: Any = None
    # HTTP_SQL 后端服务地址。非空时强制走 HttpSqlConnector 并注入此地址，
    # 取代历史的 DATACLOUD_SQL_SERVICE_URL 环境变量。
    sql_execute_url: str | None = None
    # 结果文件（CSV 导出等）的工作目录根路径。None 时退化到 os.getcwd()。
    workspace_dir: str | None = None
    # False 时跳过 KbTermLoader（不连 OpenGauss），适用于 OpenGauss 不可用的环境（如评测 mock 环境）。
    use_kb_term_loader: bool = True
    # base_id 由调用方显式传入，不再依赖模块级 _default_base_id() 隐式推导。
    # 默认 DEFAULT_BASE_ID 与 byclaw-data worker 侧 _runtime_manager.get_loader(DEFAULT_BASE_ID) 对齐。
    base_id: str = DEFAULT_BASE_ID


# ── 缓存 key ──────────────────────────────────────────────────────────────────


def _make_cache_key(
    view_codes: list[str] | None,
    object_codes: list[str] | None,
    base_ids: list[str] | None = None,
) -> tuple[frozenset[str], frozenset[str], frozenset[str]]:
    """构造图缓存 key，view/object 分属两个 frozenset 避免命名空间碰撞；
    base_ids 表示多库场景下参与图构建的本体库集合。"""
    return (
        frozenset(view_codes or []),
        frozenset(object_codes or []),
        frozenset(base_ids or []),
    )


# ── 初始状态构建辅助 ──────────────────────────────────────────────────────────


def _build_input_payload(question: str, workspace_dir: str | None = None) -> dict[str, Any]:
    """构建 AgentState 初始字段，与 runner.py 保持一致。"""
    from langchain_core.messages import HumanMessage  # noqa: PLC0415

    return {
        "messages": [HumanMessage(content=question)],
        "agent_id": None,
        "agent_name": None,
        "workspace_dir": workspace_dir,
        "user_query": "",
        "enriched_query": "",
        "knowledge_payload": {},
        "term_hints": [],
        "knowledge_snippets": [],
        "thinking_log": {},
        "planning_input_source": "",
        "plan": [],
        "todos": [],
        "todo_md": "",
        "todo_md_path": "",
        "intent": None,
        "clarify_needed": False,
        "results": [],
        "execution_status": "",
        "active_tools": [],
        "execution_trace": [],
        "invocation_dedup": [],
        "final_answer": "",
        "artifact_refs": [],
        "execution_summary": None,
        "execution_summary_persistence": None,
        "resume_context": {},
        "query_mode": "analysis",
        "target_tool": "",
        "tool_params": {},
        "concept_terms": [],
        "confirmed_terms": [],
        "ambiguous_terms": [],
        "session_alias_map": {},
        "dynamic_tools": {},
        "prompts_overwrite": {},
        "planned_tasks": [],
        "task_queue": [],
        "results_list": [],
        "results_map": {},
        "final_summary": {},
    }


def _paradigm_answer_to_resume_value(
    answer: ParadigmAnswer,
    raw: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """将 ParadigmAnswer 转换为 user_clarify_node 期望的 resume_value 格式。

    raw 为前端原始 humanInput dict，携带完整的 paradigmList（含 keyword/kid/paradigmId）
    和 metadata（含 clarify_knowledge），优先直接使用，供 user_clarify_node 做 path_mapping 裁剪。
    """
    # raw 存在时直接透传，保留前端提交的完整结构（paradigmId/paradigmResult/keyword/kid）
    if raw and isinstance(raw.get("paradigmList"), list):
        return raw

    # raw 不存在时降级：从 ParadigmAnswer 重建（仅含 choiceKeyword/recall，无 keyword/kid）
    items: list[dict[str, Any]] = []
    for sel in answer.selections:
        for opt in sel.chosen_options:
            item: dict[str, Any] = {
                "choiceKeyword": opt.choice_keyword,
                "recall": opt.recall,
            }
            # 过滤条件选项携带 filter 专用字段
            if opt.filter_field:
                item["field"] = opt.filter_field
                item["choiceField"] = opt.choice_field
            if opt.comparison:
                item["comparison"] = opt.comparison
                item["choiceComparison"] = opt.choice_comparison
            if opt.value:
                item["value"] = opt.value
            items.append(item)
    return {"paradigmList": [{"paradigmList": items}]}


def _interrupt_value_to_paradigm_list(
    ask_user_payload: dict[str, Any],
) -> list[ParadigmGroup] | None:
    """将 interrupt value 中的 paradigmList 解析为 list[ParadigmGroup]。"""
    raw_list = ask_user_payload.get("paradigmList") or []
    if not raw_list:
        return None

    groups: list[ParadigmGroup] = []
    for item in raw_list:
        paradigm_id = str(item.get("paradigmId") or item.get("paradigmCode") or "")
        paradigm_name = str(item.get("paradigmName") or "")
        raw_results = list(item.get("paradigmResult") or [])
        # 过滤条件的结果结构不同于查询值（查询值使用 choiceKeyword/keyword/kid/ktype，
        # 过滤条件使用 field/comparison/value/choiceField 等字段）。
        # 通过检测第一个 result 是否有 "field" 键来判断是否为过滤条件类型。
        is_filter = bool(
            raw_results and isinstance(raw_results[0], dict) and "field" in raw_results[0]
        )
        options: list[ParadigmOption] = [
            ParadigmOption(
                choice_keyword=str(r.get("choiceKeyword") or ""),
                recall=r.get("recall") if isinstance(r.get("recall"), list) else [],
                keyword=str(r.get("keyword") or ""),
                kid=int(r.get("kid") or 0),
                ktype=str(r.get("ktype") or ""),
                filter_field=str(r.get("field") or "") if is_filter else "",
                comparison=str(r.get("comparison") or "") if is_filter else "",
                value=str(r.get("value") or "") if is_filter else "",
                choice_field=str(r.get("choiceField") or "") if is_filter else "",
                choice_comparison=str(r.get("choiceComparison") or "") if is_filter else "",
                field_recall=r.get("fieldRecall")
                if isinstance(r.get("fieldRecall"), list)
                else []
                if is_filter
                else [],
                comparison_recall=r.get("comparisonRecall")
                if isinstance(r.get("comparisonRecall"), list)
                else []
                if is_filter
                else [],
                value_recall=r.get("valueRecall")
                if isinstance(r.get("valueRecall"), list)
                else []
                if is_filter
                else [],
            )
            for r in raw_results
        ]
        groups.append(
            ParadigmGroup(
                paradigm_id=paradigm_id,
                paradigm_name=paradigm_name,
                options=options,
            )
        )
    return groups or None


def _operation_form_from_payload(payload: dict[str, Any]) -> OperationForm:
    """将 operation_form 原始 dict 转为 SDK 公开的轻量强类型结构。"""
    actions_raw = payload.get("actions")
    actions = (
        [_operation_action_from_payload(item) for item in actions_raw if isinstance(item, dict)]
        if isinstance(actions_raw, list)
        else [_operation_action_from_payload(payload)]
    )
    return OperationForm(
        schema_version=str(payload.get("schemaVersion") or ""),
        form_id=str(payload.get("formId") or ""),
        title=str(payload.get("title") or ""),
        description=str(payload.get("description") or ""),
        form_mode=str(payload.get("formMode") or ""),
        actions=actions,
        raw=dict(payload),
    )


def _operation_action_from_payload(payload: dict[str, Any]) -> OperationFormAction:
    confirmed_raw = payload.get("confirmed")
    return OperationFormAction(
        tool_call_id=str(payload.get("tool_call_id") or payload.get("toolCallId") or ""),
        tool_name=str(payload.get("tool_name") or payload.get("toolName") or ""),
        action_code=str(payload.get("actionCode") or ""),
        action_name=str(payload.get("actionName") or ""),
        title=str(payload.get("title") or ""),
        description=str(payload.get("description") or ""),
        confirmed=confirmed_raw if isinstance(confirmed_raw, bool) else None,
        reason=str(payload.get("reason") or ""),
        form_mode=str(payload.get("formMode") or ""),
        summary=dict(payload.get("summary") or {})
        if isinstance(payload.get("summary"), dict)
        else {},
        rule=_operation_rule_from_payload(payload.get("rule")),
        raw=dict(payload),
    )


def _operation_rule_from_payload(value: Any) -> list[list[OperationFormField]]:
    if not isinstance(value, list):
        return []
    rows: list[list[OperationFormField]] = []
    for row in value:
        if not isinstance(row, list):
            continue
        fields = [_operation_field_from_payload(item) for item in row if isinstance(item, dict)]
        if fields:
            rows.append(fields)
    return rows


def _operation_field_from_payload(payload: dict[str, Any]) -> OperationFormField:
    default_files_raw = payload.get("defaultFiles")
    default_files = (
        [str(item) for item in default_files_raw] if isinstance(default_files_raw, list) else []
    )
    term_raw = payload.get("term")
    term_resolve_notice_raw = payload.get("termResolveNotice")
    children = _operation_rule_from_payload(payload.get("children"))
    return OperationFormField(
        form_type=str(payload.get("formType") or ""),
        field_code=str(payload.get("fieldCode") or ""),
        field_name=str(payload.get("fieldName") or ""),
        field_type=str(payload.get("fieldType") or ""),
        field_path=str(payload.get("fieldPath") or ""),
        field_value=payload.get("fieldValue"),
        children=children or None,
        item_id=str(payload.get("itemId") or ""),
        description=str(payload.get("description") or ""),
        required=bool(payload.get("required")),
        readonly=bool(payload.get("readonly")),
        disabled=bool(payload.get("disabled")),
        is_hidden=bool(payload.get("isHidden")),
        default_files=default_files,
        term=dict(term_raw) if isinstance(term_raw, dict) else None,
        term_resolve_notice=dict(term_resolve_notice_raw)
        if isinstance(term_resolve_notice_raw, dict)
        else None,
        raw=dict(payload),
    )


# ── OntologyAgent ─────────────────────────────────────────────────────────────


class OntologyAgent:
    """DataCloud SDK 公开客户端，无需 Gateway 中间层即可直接发起问答。

    实例应长期持有（如应用启动时创建一次），以充分利用进程级图缓存（T6）。
    """

    def __init__(self, config: OntologyAgentConfig) -> None:
        self._config = config
        # 优先使用 bootstrap.setup() 注册的 PG checkpointer（持久化、多进程共享）。
        # 退化到 MemorySaver（单进程、掉电丢失，仅适合独立开发/测试）。
        try:
            from datacloud_analysis.session.checkpointer import get_checkpointer  # noqa: PLC0415

            self._checkpointer = get_checkpointer()
            logger.info("OntologyAgent: using PG checkpointer (registered by bootstrap.setup())")
        except RuntimeError:
            self._checkpointer = MemorySaver()
            logger.warning(
                "OntologyAgent: PG checkpointer not initialized, falling back to MemorySaver. "
                "Multi-turn conversations will NOT survive process restart. "
                "Call `await bootstrap.setup()` before creating OntologyAgent."
            )
        # T6 进程级图缓存：OrderedDict 实现 LRU；key 为 (views, objects, bases) 三元组。
        self._graph_cache: OrderedDict[tuple, Any] = OrderedDict()

    # ── 公开 API ──────────────────────────────────────────────────────────────

    def ask(
        self,
        question: str,
        *,
        view_codes: list[str] | None = None,
        object_codes: list[str] | None = None,
        thread_id: str | None = None,
        user_code: str | None = None,
        session_id: str | None = None,
        locale: str | None = None,
        extras: dict[str, Any] | None = None,
        target_tool: str | None = None,
        skill_dirs: list[str] | None = None,
        rel_skills: set[str] | None = None,
        tool_context: Any | None = None,
    ) -> AsyncGenerator[OntologyAgentEvent, None]:
        """发起一次问答，流式返回事件。

        thread_id 使用规则：
          - 多轮对话：调用方自行生成（如 str(uuid.uuid4())）并在每轮传入相同值。
          - 一次性问答：传 None，SDK 内部生成，调用方无需保存。
          - 中断恢复：resume() 使用与本次 ask() 相同的 thread_id。

        user_code / session_id: datacloud 自己的请求级上下文字段。会被 OntologyAgent
        在内部组装成 duck-typed 容器并注入 LangGraph configurable，供下游
        tool_wrapper / HookAwareToolNode 通过 InvocationContext 透传至 SDK
        result_file_storage 等需要这两个字段的位置。本接口不感知 Gateway 概念。

        target_tool: 强制指定初始工具名（如 "data_query_crm_customer"），跳过 LLM 工具选择，
        直接从该工具开始执行。用于对比实验（Text2SQL vs DSL 路径）。

        tool_context: 请求级授权上下文（RequestToolContext）。非 None 时注入
        configurable["tool_context"]，供 llm_call_node / hook_aware_tool_node 使用。
        """
        effective_tid = thread_id or str(uuid.uuid4())
        return self._iter_events(
            question=question,
            view_codes=view_codes,
            object_codes=object_codes,
            thread_id=effective_tid,
            user_code=user_code,
            session_id=session_id,
            locale=locale,
            resume_input=None,
            extras=extras,
            target_tool=target_tool,
            skill_dirs=skill_dirs,
            rel_skills=rel_skills,
            tool_context=tool_context,
        )

    def resume(
        self,
        thread_id: str,
        user_input: str | ParadigmAnswer | dict[str, Any],
        *,
        view_codes: list[str] | None = None,
        object_codes: list[str] | None = None,
        user_code: str | None = None,
        session_id: str | None = None,
        extras: dict[str, Any] | None = None,
    ) -> AsyncGenerator[OntologyAgentEvent, None]:
        """在中断后恢复图执行，继续流式返回事件。

        view_codes / object_codes 须与触发中断的 ask() 保持一致。
        user_input:
          - str：文本回复（ASK_USER 场景）
          - ParadigmAnswer：维度选择（PARADIGM_CLARIFICATION 场景）
          - dict：结构化恢复值，如操作确认表单 operation_form 场景；操作表单应传回完整
            batch form 原结构，仅修改字段 fieldValue 并在每个 actions[] 下写 confirmed
        user_code / session_id: 同 ask()。
        """
        return self._iter_events(
            question="",
            view_codes=view_codes,
            object_codes=object_codes,
            thread_id=thread_id,
            user_code=user_code,
            session_id=session_id,
            locale=None,
            resume_input=user_input,
            extras=extras,
        )

    # ── 内部实现 ──────────────────────────────────────────────────────────────

    def _build_loader(
        self,
        view_codes: list[str] | None,
        object_codes: list[str] | None,
        base_ids: list[str] | None = None,
    ) -> tuple[list[Any], list[str], list[str]]:
        """通过 LoaderRuntimeManager 获取已配置的 OntologyLoader 快照。

        支持多库场景：base_ids 非空时为每个 base_id 构建一个 loader，
        返回列表；为空时退化到 self._config.base_id 单库模式。
        返回 (loaders, mounted, _ids) 其中 loaders 为列表，_ids 为对应的 base_id 列表。
        """
        from datacloud_platform.config import get_settings  # noqa: PLC0415
        from datacloud_platform.loader_runtime import LoaderRuntimeManager  # noqa: PLC0415

        runtime = LoaderRuntimeManager(platform=get_platform(), settings=get_settings())
        _ids = base_ids if base_ids else [self._config.base_id]
        loaders: list[Any] = []
        for bid in _ids:
            snapshot = runtime.get_loader(bid, object_codes=object_codes, view_codes=view_codes)
            loaders.append(snapshot.loader)

        mounted = list(view_codes or []) + list(object_codes or [])
        return loaders, mounted, _ids

    def _build_and_compile(
        self,
        view_codes: list[str] | None,
        object_codes: list[str] | None,
        base_ids: list[str] | None = None,
    ) -> Any:
        """构建并编译 LangGraph 图（无缓存层，供 T6 缓存逻辑调用）。

        多库支持：base_ids 指定多个本体库时，从每个库分别加载工具并合并，
        使用第一个 loader 作为图的 primary loader。
        """
        from datacloud_analysis.agent import _log_create_agent_diagnostics  # noqa: PLC0415
        from datacloud_analysis.orchestration.graph_builder import (  # noqa: PLC0415
            build_analysis_graph,
        )
        from datacloud_analysis.tools.ontology_tool_loader import (  # noqa: PLC0415
            OntologyToolLoader,
        )

        loaders, mounted, _ids = self._build_loader(view_codes, object_codes, base_ids)

        # 多库合并：从每个 loader 构建工具，union 合并
        all_tools: dict[str, Any] = {}
        all_redirect_tools: dict[str, Any] = {}
        primary_loader = loaders[0] if loaders else None

        for bid, loader in zip(_ids, loaders, strict=True):
            tool_loader = OntologyToolLoader(
                mounted_objects=mounted,
                loader=loader,
                resource_path=self._config.resource_path,
                base_id=bid,
            )
            tools = tool_loader.load()
            for k, v in tools.items():
                if k not in all_tools:
                    all_tools[k] = v
            redirect_tools = tool_loader.build_all_nl_query_tools()
            for k, v in (redirect_tools or {}).items():
                if k not in all_redirect_tools:
                    all_redirect_tools[k] = v

        # 将动态加载的工具接入全局 TOOL_POOL，并构建 ParamLinkGraph /
        # OntologyRelationGraph 单例。否则 get_param_link_graph() 恒为 None、
        # TOOL_POOL 为空，串联提示注入与锚点解锁机制在运行时全程短路。
        try:
            from datacloud_analysis.tools.tool_pool import (  # noqa: PLC0415
                register_runtime_tool_pool,
            )

            register_runtime_tool_pool(
                list(mounted or []),
                primary_loader,
                resource_path=self._config.resource_path,
            )
        except Exception:  # noqa: BLE001
            logger.warning("register_runtime_tool_pool failed", exc_info=True)

        # 与 create_agent() 保持一致：写入 Langfuse span 的 AgentDiag / LLMConfig 等快照
        _log_create_agent_diagnostics(
            agent_id_display="(dynamic)",
            question_context="(ontology_agent dynamic path)",
            merged_tools=all_tools,
            mounted_objects=list(mounted or []),
        )

        graph = build_analysis_graph(
            tools=all_tools, loader=primary_loader, redirect_tools=all_redirect_tools or None
        )
        return graph.compile(checkpointer=self._checkpointer), all_redirect_tools or {}

    def _get_or_build_graph(
        self,
        view_codes: list[str] | None,
        object_codes: list[str] | None,
        base_ids: list[str] | None = None,
    ) -> tuple[Any, dict[str, Any]]:
        """T6：带 LRU 缓存的图获取入口，返回 (compiled_graph, tools_dict)。
        多库支持：base_ids 参与缓存 key 计算。"""
        key = _make_cache_key(view_codes, object_codes, base_ids)
        if key in self._graph_cache:
            self._graph_cache.move_to_end(key)
            logger.debug("ontology_agent: graph cache hit key=%s", key)
            return self._graph_cache[key]

        logger.debug("ontology_agent: graph cache miss, building key=%s", key)
        compiled, tools_dict = self._build_and_compile(view_codes, object_codes, base_ids)
        self._graph_cache[key] = (compiled, tools_dict)
        if len(self._graph_cache) > _CACHE_MAX:
            evicted = self._graph_cache.popitem(last=False)
            logger.debug("ontology_agent: evicted cache entry key=%s", evicted[0])
        return compiled, tools_dict

    async def _iter_events(  # type: ignore[return]
        self,
        *,
        question: str,
        view_codes: list[str] | None,
        object_codes: list[str] | None,
        thread_id: str,
        user_code: str | None,
        session_id: str | None,
        locale: str | None,
        resume_input: str | ParadigmAnswer | dict[str, Any] | None,
        extras: dict[str, Any] | None = None,
        target_tool: str | None = None,
        skill_dirs: list[str] | None = None,
        rel_skills: set[str] | None = None,
        tool_context: Any | None = None,
    ) -> AsyncGenerator[OntologyAgentEvent, None]:
        """核心事件迭代器：构建图、执行、转换事件。"""
        try:
            # 多库支持：从 extras.rel_resource_list 提取唯一的 base_id 列表。
            # 未指定时退化到 self._config.base_id 单库模式。
            _base_ids: list[str] | None = None
            _rel_rl = (extras or {}).get("rel_resource_list")
            if isinstance(_rel_rl, list) and _rel_rl:
                _seen: set[str] = set()
                for _item in _rel_rl:
                    if not isinstance(_item, dict):
                        continue
                    _biz_type = str(
                        _item.get("resourceBizType") or _item.get("resource_biz_type") or ""
                    )
                    _code = str(
                        _item.get("resourceCode") or _item.get("resource_code") or ""
                    ).strip()
                    _base_code = str(
                        _item.get("ontologyBaseCode") or _item.get("ontology_base_code") or ""
                    ).strip()
                    if _biz_type == "ONTOLOGY_BASE" and _code:
                        _seen.add(_code)
                    elif _base_code:
                        _seen.add(_base_code)
                if _seen:
                    _base_ids = sorted(_seen)
                    logger.info("ontology_agent: multi-base mode base_ids=%s", _base_ids)
            compiled, tools_dict = self._get_or_build_graph(view_codes, object_codes, _base_ids)
        except Exception as exc:
            logger.exception("ontology_agent: failed to build graph")
            yield ErrorEvent(message=str(exc))
            return

        effective_locale = locale or self._config.locale

        _effective_extras: dict[str, Any] = dict(extras or {})
        # skill_dirs 参数已废弃：Skill 通过 TOOL_POOL + search_ontology 进程级发现
        # tools_dict 仍写入 extras 供 sub_agent 克隆分身时使用
        if tools_dict:
            _effective_extras["tools_dict"] = tools_dict
        # llm_config 写入 extras，供 sub_agent 工具函数克隆分身时读取
        # 若 extras 已提供 llm_config（per-agent model override），优先使用
        if not _effective_extras.get("llm_config"):
            _effective_extras["llm_config"] = {
                "model": self._config.model,
                "api_key": self._config.api_key,
                "base_url": self._config.base_url,
                "temperature": self._config.temperature,
                "model_kwargs": self._config.model_kwargs,
            }

        # 无 Gateway 部署使用 NoOpExecutionReporter（实现 ExecutionReporter 协议），
        # 让 tool_wrapper.py 等业务代码不需感知是否有真实 Gateway。
        # 真实 Gateway（如 byclaw-data 的 AgentContext）走另一条路径直接被注入到
        # configurable["gateway_context"]，duck-type 自然满足同一协议。
        user_name = ""
        if extras and extras.get("user_name"):
            user_name = extras.get("user_name")
        ctx_container: Any = NoOpExecutionReporter(
            user_id=user_code or "",
            user_name=user_name,
            session_id=session_id or "",
            extras=_effective_extras or None,
        )
        run_config: dict[str, Any] = {
            "configurable": {
                "thread_id": thread_id,
                "user_code": user_code,
                "gateway_context": ctx_container,
                "tool_context": tool_context,
                "llm_config": _effective_extras.get("llm_config")
                or {
                    "model": self._config.model,
                    "api_key": self._config.api_key,
                    "base_url": self._config.base_url,
                    "temperature": self._config.temperature,
                    "model_kwargs": self._config.model_kwargs,
                },
            },
            "recursion_limit": 100,
        }

        from datacloud_analysis.langfuse_handler import make_langfuse_callback  # noqa: PLC0415

        # 优先使用 worker 层传入的 biz trace_id（32位 hex），
        # 避免 thread_id（"agent_id:session_id:parent_msg_id" 格式）导致的 trace 断链。
        _biz_trace_id = str((_effective_extras or {}).get("langfuse_trace_id", "") or "")
        _lf_trace_id = _biz_trace_id if _biz_trace_id else None
        _parent_span_id = str((_effective_extras or {}).get("langfuse_parent_span_id", "") or "")
        _lf_handler = make_langfuse_callback(_lf_trace_id, parent_span_id=_parent_span_id or None)
        if _lf_handler is not None:
            run_config["callbacks"] = [_lf_handler]
            run_config["metadata"] = {
                "thread_id": thread_id,
                "view_codes": view_codes or [],
                "object_codes": object_codes or [],
            }

        if resume_input is None:
            graph_input: Any = _build_input_payload(
                question, workspace_dir=self._config.workspace_dir
            )
            graph_input["prompts_overwrite"] = {"locale": effective_locale}
            # 注入 skill task_prompt（请求级，不影响图缓存）
            _task_prompt = str(_effective_extras.get("task_prompt") or "").strip()
            if _task_prompt:
                graph_input["prompts_overwrite"]["task_prompt"] = _task_prompt
            # 注入 skill_workspace_dir 供 read_file tool 使用
            _skill_ws = str(_effective_extras.get("skill_workspace_dir") or "").strip()
            if _skill_ws:
                graph_input["prompts_overwrite"]["skill_workspace_dir"] = _skill_ws
            # available_skills XML 注入已废弃：Skill 通过 search_ontology + TOOL_POOL 动态发现
            if target_tool:
                graph_input["target_tool"] = target_tool
            # 首次调用后 messages 交由 checkpoint 累积，不从 _build_input_payload 覆盖。
            # 保留 user_query 供 knowledge_enhance 节点使用，但不清空其他 checkpoint 字段。
            graph_input["user_query"] = question
        elif isinstance(resume_input, str | dict):
            graph_input = Command(resume=resume_input)
        else:
            resume_value = _paradigm_answer_to_resume_value(
                resume_input,
                raw=getattr(resume_input, "_raw_dict", None),
            )
            graph_input = Command(resume=resume_value)

        try:
            import time as _time

            _t_start = _time.monotonic()
            _ttft_ms: int | None = None
            _react_turns = 0
            _llm_call_count = 0
            _thinking_chars = 0
            _thinking_t_start: float | None = None
            _thinking_duration_ms = 0
            _in_thinking = False
            _current_node = ""
            _last_tool_called = ""

            async for event in compiled.astream_events(
                graph_input,
                config=run_config,
                version="v2",
            ):
                event_type = event.get("event", "")
                metadata = event.get("metadata") or {}
                node = metadata.get("langgraph_node", "")

                # ReAct 轮次计数
                if event_type == "on_chain_start" and node and node != _current_node:
                    _current_node = node
                    if node not in ("respond", "__start__", "__end__"):
                        _react_turns += 1

                # LLM 调用计数
                if event_type == "on_chat_model_start":
                    _llm_call_count += 1

                # 工具调用采集（finish_react 不算）
                if event_type == "on_tool_start":
                    tool_name = str(
                        (event.get("data") or {}).get("input", {}).get("tool", "")
                        or event.get("name", "")
                        or ""
                    )
                    if tool_name and tool_name != "finish_react":
                        _last_tool_called = tool_name

                if event_type == "on_chat_model_stream" and node != "respond":
                    # agent 节点由 react_loop 通过 dc_stream_chunk 自定义事件
                    # 发送 thinking token（含 message_id/parent_message_id），
                    # 在此跳过 on_chat_model_stream 的原始 chunk，避免重复
                    # reasoningLogDelta。仅跳过 ThinkingEvent yield，保留计时。
                    _is_agent_stream = node == "agent"
                    chunk = (event.get("data") or {}).get("chunk")
                    content = getattr(chunk, "content", "") or ""
                    if content:
                        if _ttft_ms is None:
                            _ttft_ms = int((_time.monotonic() - _t_start) * 1000)
                        if not _in_thinking:
                            _in_thinking = True
                            _thinking_t_start = _time.monotonic()
                        _thinking_chars += len(content)
                        if not _is_agent_stream:
                            yield ThinkingEvent(content=content)
                    else:
                        if _in_thinking and _thinking_t_start is not None:
                            _thinking_duration_ms += int(
                                (_time.monotonic() - _thinking_t_start) * 1000
                            )
                            _in_thinking = False
                            _thinking_t_start = None

                elif event_type == "on_custom_event" and event.get("name") == "dc_stream_chunk":
                    data = event.get("data") or {}
                    text = str(data.get("content") or "").strip()
                    if text:
                        ev_type = str(data.get("event_type") or "").strip()
                        ct = str(data.get("content_type") or "").strip()
                        msg_id = str(data.get("message_id") or "").strip()
                        p_msg_id = str(data.get("parent_message_id") or "").strip()
                        yield StepEvent(
                            title=text,
                            event_type=ev_type,
                            content_type=ct,
                            message_id=msg_id,
                            parent_message_id=p_msg_id,
                        )

        except Exception as exc:
            logger.exception("ontology_agent: stream error thread_id=%s", thread_id)
            yield ErrorEvent(message=str(exc))
            return

        # ── 流结束后检查是否中断 ────────────────────────────────────────────
        snapshot_config: dict[str, Any] = {"configurable": dict(run_config["configurable"].items())}
        snapshot_config["configurable"].pop("checkpoint_id", None)

        try:
            snapshot = await compiled.aget_state(snapshot_config)
        except Exception as exc:
            logger.exception("ontology_agent: aget_state failed thread_id=%s", thread_id)
            yield ErrorEvent(message=f"aget_state failed: {exc}")
            return

        if snapshot.interrupts:
            interrupt = snapshot.interrupts[0]
            iv = interrupt.value if hasattr(interrupt, "value") else interrupt
            interrupt_value = dict(iv or {}) if isinstance(iv, dict) else {}
            reason_code = str(interrupt_value.get("reason_code") or "UNKNOWN")
            prompt = str(interrupt_value.get("prompt") or "")
            interrupt_type = str(interrupt_value.get("interrupt_type") or "")
            ask_payload: dict[str, Any] = dict(interrupt_value.get("ask_user_payload") or {})
            paradigm_list = _interrupt_value_to_paradigm_list(ask_payload)
            query = str(ask_payload.get("query") or "")
            operation_form_raw = interrupt_value.get("operation_form") or ask_payload.get(
                "operation_form"
            )
            operation_form = (
                _operation_form_from_payload(operation_form_raw)
                if isinstance(operation_form_raw, dict)
                else None
            )

            yield InterruptEvent(
                thread_id=thread_id,
                reason=reason_code,
                prompt=prompt,
                interrupt_type=interrupt_type,
                paradigm_list=paradigm_list,
                query=query,
                operation_form=operation_form,
            )
            return

        # 收尾：如果思考还在进行中，补算时长
        if _in_thinking and _thinking_t_start is not None:
            _thinking_duration_ms += int((_time.monotonic() - _thinking_t_start) * 1000)

        final_answer = str(snapshot.values.get("final_answer") or "")
        logger.warning(
            "_iter_events: final_answer from snapshot thread_id=%s len=%d preview=%r",
            thread_id,
            len(final_answer),
            final_answer[:200],
        )
        yield AnswerEvent(content=final_answer)

        # 性能汇总事件
        _total_ms = int((_time.monotonic() - _t_start) * 1000)
        _chars_per_sec = (
            round(_thinking_chars / (_thinking_duration_ms / 1000), 1)
            if _thinking_duration_ms > 0
            else 0.0
        )
        yield PerfEvent(
            total_duration_ms=_total_ms,
            ttft_ms=_ttft_ms,
            react_turns=_react_turns,
            llm_call_count=_llm_call_count,
            interrupt_count=0,
            thinking_chars=_thinking_chars,
            thinking_duration_ms=_thinking_duration_ms,
            thinking_chars_per_sec=_chars_per_sec,
            last_tool_called=_last_tool_called,
        )

    # 让 async generator 方法可被直接调用并返回 AsyncGenerator
    # _iter_events 是 async def + yield，Python 自动使其成为 async generator function。
    # ask()/resume() 直接 return self._iter_events(...)，此调用返回 AsyncGenerator 对象。
