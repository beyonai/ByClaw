"""召回工具：读取被 SummarizationMiddleware 压缩的历史对话记录。

LLM 在需要查阅已压缩的早期对话细节时主动调用此工具。
thread_id 通过 LangGraph InjectedState 从 AgentState 自动注入，无需 LLM 传递。
"""

from __future__ import annotations

import logging
from typing import Annotated, Any

from langchain_core.tools import tool
from langgraph.prebuilt import InjectedState

logger = logging.getLogger(__name__)

_MAX_LIMIT = 200
_DEFAULT_LIMIT = 50


@tool("read_conversation_history")
async def read_conversation_history(
    offset: int = 0,
    limit: int = _DEFAULT_LIMIT,
    state: Annotated[dict[str, Any], InjectedState] = None,  # type: ignore[assignment]
) -> str:
    """读取被摘要压缩的历史对话记录。

    当你需要查找之前对话中的具体细节（例如早期的分析结论、用户提供的参数、
    前几轮的工具执行结果）时调用此工具。

    Args:
        offset: 跳过前 N 个字符（用于分页），默认 0（从头读取）。
        limit: 最多返回的字符数，默认 50，最大 200。
        state: 由 LangGraph 自动注入，无需手动传递。

    Returns:
        历史对话的 Markdown 文本；若无记录则返回提示信息。
    """
    # 参数边界校验
    offset = max(0, offset)
    limit = max(1, min(limit, _MAX_LIMIT))

    # 从 state 取 thread_id
    _state: dict[str, Any] = state or {}
    thread_id = str(_state.get("agent_id") or "").strip()
    if not thread_id:
        # 降级：尝试从 config 路径取（state 是 dict，没有 configurable）
        logger.warning("[read_conversation_history] thread_id not found in state")
        return "错误：无法确定会话 ID，历史记录不可用。"

    try:
        from datacloud_analysis.bootstrap import get_pg_pool  # noqa: PLC0415

        pool = get_pg_pool()
        async with pool.connection() as conn, conn.cursor() as cur:
            await cur.execute(
                "SELECT content FROM conversation_history WHERE thread_id = %s ORDER BY created_at",
                (thread_id,),
            )
            rows = await cur.fetchall()
    except Exception as exc:  # noqa: BLE001
        logger.exception("[read_conversation_history] db error thread_id=%r: %s", thread_id, exc)
        return f"错误：读取历史记录失败（{exc}）"

    if not rows:
        return "当前会话暂无被压缩的历史记录。"

    full_content = "".join(row[0] for row in rows)
    total = len(full_content)

    if offset >= total:
        return f"offset={offset} 超出历史记录总长度（{total} 字符），无更多内容。"

    chunk = full_content[offset : offset + limit]
    remaining = total - offset - len(chunk)

    footer_parts = [
        f"\n\n---\n*历史记录片段：offset={offset}，本段 {len(chunk)} 字符，总长 {total} 字符*"
    ]
    if remaining > 0:
        footer_parts.append(
            f"*仍有 {remaining} 字符未读，可用 offset={offset + len(chunk)} 继续查询*"
        )

    return chunk + "\n".join(footer_parts)
