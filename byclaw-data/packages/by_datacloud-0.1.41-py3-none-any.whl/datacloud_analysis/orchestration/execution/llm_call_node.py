"""llm_call_node：ReAct LLM 调用节点（V0.3 阶段 3）。

每轮从 state["messages"] 读取完整对话历史，调用 LLM，将 AIMessage 写入 state["messages"]。
LangGraph MessagesState 的 add_messages reducer 自动累积并 checkpoint，无需 react_messages_log。
interrupt() 只重跑工具节点，本节点作为独立图节点不受影响。
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import uuid
from collections.abc import Callable
from datetime import datetime
from typing import Any

from langchain_core.messages import HumanMessage
from langchain_core.runnables import RunnableConfig

from datacloud_analysis.i18n.prompts import get_execution_prompt, get_system_prompt
from datacloud_analysis.orchestration.execution.llm_retry import _build_fallback_llm
from datacloud_analysis.orchestration.execution.react_loop import (
    _build_llm,
    _build_system_message,
    _invoke_llm_with_fallback,
    _trim_messages_window,
    finish_react,
)
from datacloud_analysis.orchestration.state import AgentState

logger = logging.getLogger(__name__)

_DEFAULT_MAX_ROUNDS = int(os.getenv("DATACLOUD_REACT_MAX_ROUNDS", "10"))
# LLM 单次调用超时（秒），超时后抛 asyncio.TimeoutError，由 llm_retry 捕获重试或上抛
_LLM_CALL_TIMEOUT = float(os.getenv("DATACLOUD_LLM_CALL_TIMEOUT", "120"))


# ── 附05 3.3 Todo 机制辅助函数 ─────────────────────────────────────────────────


def _original_query_visible(messages: list[Any], user_query: str) -> bool:
    """检查原始 user_query 是否仍在消息窗口内（裁剪后检查）。"""
    for msg in messages:
        content = str(getattr(msg, "content", "") or "")
        if user_query in content:
            return True
    return False


def _format_todo_snapshot(active_todos: list[dict[str, Any]], user_query: str) -> str:
    """将 pending/in_progress 的 todos 格式化为消息快照。"""
    status_mark = {"in_progress": "[>]", "pending": "[ ]"}
    lines = ["[任务列表快照]"]
    for i, t in enumerate(active_todos, 1):
        mark = status_mark.get(t.get("status", ""), "[ ]")
        content = t.get("content", "")
        status_cn = "进行中" if t.get("status") == "in_progress" else "待执行"
        lines.append(f"- {mark} {i}. {content}（{status_cn}）")
    if user_query:
        lines.append(f"原始任务：{user_query}")
    return "\n".join(lines)


def _build_message_tail(state: AgentState, user_query: str) -> str | None:
    """构建每轮消息末尾追加的 L3 动态内容。

    包含：findings 收敛引导 + task_objects 摘要 + 任务锚定 + todos 快照。
    注入消息末尾而非 system，不破坏 Anthropic prompt cache。
    """
    parts: list[str] = []
    rg = state.get("reasoning_graph") or {}

    # 1. findings 收敛引导（从 system 移出，每轮变化）
    findings = list(rg.get("findings") or [])
    if findings:
        parts.append(
            f"**已确认 {len(findings)} 条结论。**"
            "如证据足够回答用户问题，直接调用 finish_react 输出结论。"
        )

    # 2. task_objects 摘要（物化后才出现）
    task_objects = list(rg.get("task_objects") or [])
    if task_objects:
        lines = ["**已物化任务级对象：**"]
        for t_obj in task_objects:
            summary = str(t_obj.get("summary") or "")[:80]
            lines.append(f"  - {t_obj.get('code', '')}（{t_obj.get('row_count', 0)}行）：{summary}")
        parts.append("\n".join(lines))

    # 3. 任务锚定（防止原始任务被消息窗口裁剪丢失）
    if user_query:
        parts.append(f"[任务锚定] 原始任务：{user_query}")

    # 4. todos 快照（pending/in_progress 项）
    todos = list(state.get("todos") or [])
    active_todos = [t for t in todos if t.get("status") in ("pending", "in_progress")]
    if active_todos:
        parts.append(_format_todo_snapshot(active_todos, user_query))

    if not parts:
        return None
    return "\n\n".join(parts)


def _build_runtime_dynamic_prompt(state: AgentState, gateway_context: Any) -> str | None:
    """从 state 的 knowledge_snippets 和 gateway_context 构建每次请求的动态 prompt 部分。"""
    parts: list[str] = []

    knowledge_snippets = list(state.get("knowledge_snippets") or [])
    if knowledge_snippets:
        parts.append("\n\n## 数据查询知识增强\n" + "\n".join(str(s) for s in knowledge_snippets))

    _header_meta: dict[str, Any] = {}
    with contextlib.suppress(AttributeError):
        _header_meta = gateway_context.current_command.header.metadata or {}  # type: ignore[union-attr]

    _current_command = (
        getattr(gateway_context, "current_command", None) if gateway_context is not None else None
    )
    _header = getattr(_current_command, "header", None)
    # 优先读 header 直接字段，缺失时回退到 header.metadata dict（两处存储路径均支持）
    _user_code = str(
        getattr(_header, "user_code", "") or _header_meta.get("user_code") or ""
    ).strip()
    _user_name = str(
        getattr(_header, "user_name", "") or _header_meta.get("user_name") or ""
    ).strip()
    logger.info(
        "[_build_runtime_dynamic_prompt] gateway_context=%s header=%s user_code=%r user_name=%r",
        type(gateway_context).__name__,
        type(_header).__name__ if _header is not None else "None",
        _user_code,
        _user_name,
    )
    _now_str: str
    _locale = str((state.get("prompts_overwrite") or {}).get("locale") or "zh_CN")
    if _locale == "en_US":
        _now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
        _runtime_lines = ["\n\n## Current session", f"- Current time: {_now_str}"]
        if _user_name and _user_code:
            _runtime_lines.append(f"- Current user: {_user_name} (ID: {_user_code})")
        elif _user_name:
            _runtime_lines.append(f"- Current user: {_user_name}")
        elif _user_code:
            _runtime_lines.append(f"- Current user ID: {_user_code}")
    else:
        _now_str = datetime.now().strftime("%Y年%m月%d日 %H:%M")
        _runtime_lines = ["\n\n## 当前会话信息", f"- 当前时间：{_now_str}"]
        if _user_name and _user_code:
            _runtime_lines.append(f"- 当前用户：{_user_name}（工号：{_user_code}）")
        elif _user_name:
            _runtime_lines.append(f"- 当前用户：{_user_name}")
        elif _user_code:
            _runtime_lines.append(f"- 当前用户工号：{_user_code}")
    parts.append("\n".join(_runtime_lines))

    # ── 附06-V3 锚点模式：注入本体对象列表 + 已排除路径 + 收敛引导 ─────────────
    try:
        from datacloud_analysis.tools.tool_pool import (  # noqa: PLC0415
            TOOL_POOL,
            TOOL_TO_OBJECT,
            is_anchor_mode,
        )

        if is_anchor_mode():
            rg: dict[str, Any] = state.get("reasoning_graph") or {}
            dead_end_codes = {d["object_code"] for d in (rg.get("dead_ends") or [])}
            active_tools_set = set(state.get("active_tools") or [])

            obj_tools: dict[str, list[str]] = {}
            for tname, ocode in TOOL_TO_OBJECT.items():
                if tname in TOOL_POOL:
                    obj_tools.setdefault(ocode, []).append(tname)

            # 尝试从 loader 读取对象/视图的中文名称，供 LLM 理解选择
            _obj_names: dict[str, str] = {}
            try:
                from datacloud_analysis.tools.tool_pool import _get_shared_loader  # noqa: PLC0415

                _loader = _get_shared_loader()
                if _loader is not None:
                    for ocode in obj_tools:
                        try:
                            _cls = _loader.get_ontology_class(ocode)
                            _obj_names[ocode] = getattr(_cls, "object_name", "") or ""
                        except Exception:  # noqa: BLE001
                            try:
                                _view = _loader.get_view(ocode)
                                _obj_names[ocode] = getattr(_view, "view_name", "") or ""
                            except Exception:  # noqa: BLE001
                                pass
            except Exception:  # noqa: BLE001
                pass

            available_objs = []
            for ocode, tools in sorted(obj_tools.items()):
                if ocode in dead_end_codes:
                    continue
                if any(t in active_tools_set for t in tools):
                    continue
                name = _obj_names.get(ocode, "")
                label = f"{ocode}（{name}）" if name else ocode
                available_objs.append(f"  - {label}")

            if available_objs:
                parts.append(
                    "\n\n## 可选本体对象（锚点模式）\n"
                    "当前工具池对象数超过阈值，需先选择最相关的本体对象作为锚点。\n"
                    "调用 activate_anchor(object_code) 激活后开始推理。\n"
                    "路径走不通时调用 mark_dead_end(object_code, reason) 标记后换锚点。\n\n"
                    "可用对象：\n" + "\n".join(available_objs)
                )

            dead_ends_info: list[dict[str, str]] = rg.get("dead_ends") or []
            if dead_ends_info:
                dead_str = "\n".join(
                    f"  - {d['object_code']}：{d['reason']}" for d in dead_ends_info
                )
                parts.append(f"\n\n## 已排除路径\n{dead_str}")

            findings: list[str] = rg.get("findings") or []
            if findings:
                parts.append(
                    f"\n\n**收敛判断：** 已确认 {len(findings)} 条结论。"
                    "如证据足够回答用户问题，直接调用 finish_react 输出结论。"
                    "如仍需继续，选择新锚点或沿当前路径继续探索。"
                )
    except Exception:  # noqa: BLE001
        pass  # TOOL_POOL 未初始化时静默跳过

    result = "".join(parts) if parts else None
    logger.info("[_build_runtime_dynamic_prompt] dynamic_prompt=%r", result)
    return result


def make_llm_call_node(
    *,
    tools_list: list[Any],
    system_prompt: str,
    stable_system_prompt: str | None = None,
    dynamic_prompt: str | None = None,
    max_rounds: int = _DEFAULT_MAX_ROUNDS,
    gateway_context: Any = None,
) -> Callable[[AgentState, RunnableConfig], Any]:
    """返回 llm_call_node 闭包（在 build_analysis_graph 中调用）。"""

    async def _llm_call(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
        """ReAct LLM 节点：每轮调用 LLM，将 AIMessage 写入 state["messages"]。

        从 state["messages"] 读取完整对话历史（含前几轮 AIMessage + ToolMessage），
        追加系统提示后调用 LLM，返回 AIMessage。
        通过 {"messages": [ai_msg]} 正常 return，MessagesState reducer 自动累积 checkpoint。
        """
        current_round = int(state.get("react_round_idx") or 0)
        if current_round >= max_rounds:
            logger.warning(
                "[llm_call] max_rounds=%d exceeded at round=%d", max_rounds, current_round
            )
            return {"execution_status": "max_rounds_exceeded", "react_round_idx": current_round}

        # ── Agent checkpoint replay guard ──────────────────────────────────────────────────────
        # OpenGauss checkpoint blob 丢失时，agent 节点可能与 user_clarify 同时被错误激活。
        # 检测特征：pending_clarification_context 已设置（等待澄清）+ clarification_formatted_params 未设置
        # （user_clarify_node 尚未运行写入格式化参数），说明当前 agent 调用属于脏 checkpoint replay。
        # 直接设置 agent_abort=True 信号跳过 LLM 调用；should_continue 据此路由到 END 终止该路径。
        _pending_ctx_ac: dict[str, Any] | None = state.get("pending_clarification_context")
        _clarify_fp_ac: Any = state.get("clarification_formatted_params")
        if _pending_ctx_ac and not _clarify_fp_ac:
            logger.warning(
                "[llm_call] AGENT REPLAY GUARD: pending_clarification_context set"
                " clarification_formatted_params=None → aborting bad agent activation"
                " (skipping LLM call) round=%d",
                current_round,
            )
            return {"agent_abort": True}

        # Per-request gateway_context: prefer config over factory closure
        _gateway_context = (config.get("configurable") or {}).get(
            "gateway_context"
        ) or gateway_context

        # 运行时按 state locale 动态选择 system prompt，覆盖 build-time 闭包值
        _runtime_locale = str((state.get("prompts_overwrite") or {}).get("locale") or "zh_CN")
        _overwrite = state.get("prompts_overwrite") or {}
        _custom_system = str(_overwrite.get("system_prompt") or "").strip()
        _custom_task = str(_overwrite.get("task_prompt") or "").strip()
        _base_system = get_system_prompt(_runtime_locale)
        _base_exec = get_execution_prompt(_runtime_locale)
        _system_parts = [_custom_system if _custom_system else _base_system, _base_exec]
        if _custom_task:
            _system_parts.append(_custom_task)
        _runtime_system_prompt = "\n\n".join(p for p in _system_parts if p)
        logger.debug(
            "[i18n-diag] llm_call_node: runtime_locale=%r system_prompt_prefix=%r",
            _runtime_locale,
            _runtime_system_prompt[:80],
        )

        tools_map = {t.name: t for t in tools_list}
        # ★ 附05 3.2.3：从 TOOL_POOL 按名合并已解锁工具（active_tools 只存名字，TOOL_POOL 存对象）
        try:
            from datacloud_analysis.tools.tool_pool import (
                get_tools as _get_unlocked,  # noqa: PLC0415
            )

            _active_names: list[str] = state.get("active_tools") or []
            tools_map.update(_get_unlocked(_active_names))
        except Exception:  # noqa: BLE001
            pass  # TOOL_POOL 未初始化（非运维诊断 Agent）时静默跳过
        tools_map["finish_react"] = finish_react
        _llm_config: dict[str, Any] | None = (config.get("configurable") or {}).get("llm_config")
        llm = _build_llm(state, llm_config=_llm_config)
        fallback_llm = _build_fallback_llm()
        llm_with_tools = llm.bind_tools(list(tools_map.values()))
        fallback_with_tools = (
            fallback_llm.bind_tools(list(tools_map.values())) if fallback_llm else None
        )

        # 每轮从 state["messages"] 重建消息列表（系统提示 + 对话历史）
        _dynamic = dynamic_prompt or _build_runtime_dynamic_prompt(state, _gateway_context)
        logger.info(
            "[llm_call] round=%d gateway_context=%s dynamic_preview=%r",
            current_round,
            type(_gateway_context).__name__ if _gateway_context is not None else "None",
            (_dynamic or "")[:120],
        )
        # Anthropic: dynamic 由 _build_system_message 注入 system（带 cache_control）。
        # 其他 provider: system message 保持纯静态（最大化可缓存前缀），
        # dynamic 注入第一条 HumanMessage，不影响 system + tools 的缓存命中。
        _provider = os.getenv("DATACLOUD_LLM_MODEL_PROVIDER", "openai").strip().lower()
        system_msg = _build_system_message(
            _runtime_system_prompt,
            _runtime_system_prompt,
            _dynamic if _provider == "anthropic" else None,
        )
        conv = list(state.get("messages") or [])
        if conv:
            if _dynamic and _provider != "anthropic" and isinstance(conv[0], HumanMessage):
                patched = HumanMessage(content=_dynamic + "\n\n" + str(conv[0].content))
                messages = [system_msg, patched, *conv[1:]]
            else:
                messages = [system_msg, *conv]
        else:
            messages = [system_msg]
            if query := str(state.get("user_query") or state.get("enriched_query") or ""):
                _content = (_dynamic + "\n\n" + query) if _dynamic else query
                messages.append(HumanMessage(content=_content))

        thinking_id = uuid.uuid4().hex[:12]
        messages_window = _trim_messages_window(messages)

        # ★ 附05 3.3：user_query 强制锚定——裁剪后若原始任务丢失则重新插入
        _user_query = str(state.get("user_query") or "")
        if _user_query and not _original_query_visible(messages_window, _user_query):
            anchor = HumanMessage(content=f"[任务锚定] 原始任务：{_user_query}")
            messages_window.insert(1, anchor)

        # ★ 附05 3.3：todos 快照注入——裁剪后追加 pending/in_progress 项（防止任务遗忘）
        _todos: list[dict] = state.get("todos") or []
        _active_todos = [t for t in _todos if t.get("status") in ("pending", "in_progress")]
        if _active_todos:
            _snapshot = _format_todo_snapshot(_active_todos, _user_query)
            messages_window.append(HumanMessage(content=_snapshot))
        logger.debug(
            "[i18n-diag] llm_call_node messages_window: count=%d "
            "system_preview=%r "
            "first_human_preview=%r "
            "dynamic_preview=%r",
            len(messages_window),
            str(getattr(messages_window[0], "content", "") if messages_window else "")[:120],
            str(
                next(
                    (
                        getattr(m, "content", "")
                        for m in messages_window
                        if type(m).__name__ == "HumanMessage"
                    ),
                    "",
                )
            )[:120],
            (_dynamic or "")[:120],
        )
        try:
            ai_msg, _did_stream = await asyncio.wait_for(
                _invoke_llm_with_fallback(
                    llm_with_tools,
                    fallback_with_tools,
                    messages_window,
                    _gateway_context,
                    state=state,
                    round_idx=current_round,
                    thinking_message_id=thinking_id,
                    config=config,
                ),
                timeout=_LLM_CALL_TIMEOUT,
            )
        except TimeoutError:
            logger.error(
                "[llm_call] TIMEOUT round=%d timeout=%.0fs session=%s — aborting",
                current_round,
                _LLM_CALL_TIMEOUT,
                (config.get("configurable") or {}).get("session_id", ""),
            )
            return {"execution_status": "llm_timeout", "react_round_idx": current_round}

        calls = list(getattr(ai_msg, "tool_calls", None) or [])
        _usage = getattr(ai_msg, "usage_metadata", None) or {}
        _resp_meta = getattr(ai_msg, "response_metadata", None) or {}

        # token 用量由 LangfuseCallbackHandler（on_llm_end）自动记录到 Langfuse generation span。
        # 此处仅做日志，不再手动调 update_current_span（会因无 span 上下文而静默失败）。
        _input_tokens = (
            _usage.get("input_tokens")
            or _usage.get("prompt_tokens")
            or (_resp_meta.get("token_usage") or {}).get("prompt_tokens", 0)
        )
        _output_tokens = (
            _usage.get("output_tokens")
            or _usage.get("completion_tokens")
            or (_resp_meta.get("token_usage") or {}).get("completion_tokens", 0)
        )
        if _input_tokens or _output_tokens:
            logger.info(
                "[llm_call] round=%d token_usage input=%d output=%d total=%d",
                current_round,
                _input_tokens,
                _output_tokens,
                _input_tokens + _output_tokens,
            )
        # 诊断：打印 finish_react 的 answer 参数，确认 LLM 用哪种语言回答
        for _tc in calls:
            if _tc.get("name") == "finish_react":
                logger.debug(
                    "[i18n-diag] finish_react answer preview: %r",
                    str(_tc.get("args", {}).get("answer") or "")[:200],
                )
        logger.info(
            "[llm_call] round=%d tool_calls=%d streamed=%s usage=%s resp_meta_keys=%s",
            current_round,
            len(calls),
            _did_stream,
            _usage,
            sorted(_resp_meta.keys()),
        )

        return {
            "messages": [ai_msg],
            "react_round_idx": current_round + 1,
            "execution_status": None,
            "answer_streamed": _did_stream,
            "agent_abort": False,
            # 新 turn 开始（round=0）时清除上一 turn 残留的 react_final，
            # 防止 LLM 直接回答（不调 finish_react）时 respond_node 读到陈旧值。
            **({"react_final": None} if current_round == 0 else {}),
        }

    return _llm_call
