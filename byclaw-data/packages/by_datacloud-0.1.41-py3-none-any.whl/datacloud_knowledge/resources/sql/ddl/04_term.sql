CREATE TABLE IF NOT EXISTS term (
    term_id        VARCHAR(1000) NOT NULL PRIMARY KEY,
    term_code      VARCHAR(256) NOT NULL,
    term_name      VARCHAR(256) NOT NULL,
    desc_summary   TEXT,
    parent_term_id VARCHAR(1000),
    domain_ids     VARCHAR(64)[] NOT NULL DEFAULT '{}',
    term_type_code VARCHAR(256)  NOT NULL,
    library_id     VARCHAR(64),
    term_tags      JSONB        NOT NULL DEFAULT '{}'::jsonb,
    ext_attrs      JSONB        NOT NULL DEFAULT '{}'::jsonb,
    created_time   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_time   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE term IS '术语主表：存储所有术语及其核心属性';
COMMENT ON COLUMN term.term_id        IS '术语ID，主键';
COMMENT ON COLUMN term.term_code      IS '术语编码';
COMMENT ON COLUMN term.term_name      IS '术语标准名称';
COMMENT ON COLUMN term.desc_summary   IS '术语描述摘要，约100字，用于快速展示；完整知识在 term_knowledge 表';
COMMENT ON COLUMN term.parent_term_id IS '父术语ID';
COMMENT ON COLUMN term.domain_ids     IS '所属领域ID数组，支持术语多领域归属';
COMMENT ON COLUMN term.term_type_code IS '术语类型编码，外键关联 term_type(type_code)';
COMMENT ON COLUMN term.library_id     IS '所属术语库ID，外键关联 term_library 表，允许为空';
COMMENT ON COLUMN term.term_tags      IS '术语标签属性，JSONB 格式；key=标签维度术语ID，value={type, value}';
COMMENT ON COLUMN term.ext_attrs      IS '自定义扩展属性，JSON 键值对，供业务/产品扩展；与 term_tags（标签、别名）分离';
COMMENT ON COLUMN term.created_time   IS '创建时间';
COMMENT ON COLUMN term.updated_time   IS '更新时间';
