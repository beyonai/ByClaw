-- term_library
CREATE INDEX IF NOT EXISTS idx_lib_name
    ON term_library(library_name);

-- domain
CREATE INDEX IF NOT EXISTS idx_domain_parent
    ON domain(parent_id);

CREATE INDEX IF NOT EXISTS idx_domain_name
    ON domain(domain_name);

-- domain_library
CREATE INDEX IF NOT EXISTS idx_dl_library
    ON domain_library(library_id);

-- domain_term_type
CREATE INDEX IF NOT EXISTS idx_dtt_type
    ON domain_term_type(type_code);

-- term_type
CREATE INDEX IF NOT EXISTS idx_type_name
    ON term_type(type_name);

CREATE INDEX IF NOT EXISTS idx_type_category
    ON term_type(type_category);

-- term
CREATE INDEX IF NOT EXISTS idx_term_tags
    ON term USING GIN (term_tags);

CREATE INDEX IF NOT EXISTS idx_term_ext_attrs
    ON term USING GIN (ext_attrs);

CREATE INDEX IF NOT EXISTS idx_term_name
    ON term(term_name);

CREATE INDEX IF NOT EXISTS idx_term_parent
    ON term(parent_term_id);

-- 术语领域ID数组 GIN 索引（支持 && 交集查询 和 @> 包含查询）
CREATE INDEX IF NOT EXISTS idx_term_domain_ids ON term USING GIN (domain_ids);

CREATE INDEX IF NOT EXISTS idx_term_type
    ON term(term_type_code);

CREATE INDEX IF NOT EXISTS idx_term_library
    ON term(library_id);

-- term_knowledge
CREATE INDEX IF NOT EXISTS idx_tk_term
    ON term_knowledge(term_id);

-- 外挂知识库引用去重：同一术语不重复引用同一条外部文档
CREATE UNIQUE INDEX IF NOT EXISTS uq_tk_ext_ref
    ON term_knowledge(term_id, ext_system, ext_kb_id, ext_doc_id)
    WHERE ext_doc_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_tk_summary_fts
    ON term_knowledge
    USING GIN (to_tsvector('simple', COALESCE(desc_summary, '')));

CREATE INDEX IF NOT EXISTS idx_tk_desc_fts
    ON term_knowledge
    USING GIN (to_tsvector('simple', COALESCE("desc", '')));

CREATE INDEX IF NOT EXISTS idx_tk_ext_doc
    ON term_knowledge(ext_system, ext_kb_id, ext_doc_id)
    WHERE ext_doc_id IS NOT NULL;

-- term_relation
CREATE UNIQUE INDEX IF NOT EXISTS idx_tr_unique_relation
    ON term_relation(source_term_id, target_term_id, relation_name);

CREATE INDEX IF NOT EXISTS idx_tr_source
    ON term_relation(source_term_id);

CREATE INDEX IF NOT EXISTS idx_tr_target
    ON term_relation(target_term_id);

CREATE INDEX IF NOT EXISTS idx_tr_category
    ON term_relation(relation_category);

CREATE INDEX IF NOT EXISTS idx_tr_ext_attrs
    ON term_relation USING GIN (ext_attrs);

-- term_name
CREATE INDEX IF NOT EXISTS idx_tn_name_text
    ON term_name(name_text);

CREATE INDEX IF NOT EXISTS idx_tn_term
    ON term_name(term_id);

-- 根术语：库内唯一（library_id + term_type_code + term_code）
CREATE UNIQUE INDEX IF NOT EXISTS uq_term_root
    ON term(library_id, term_type_code, term_code)
    WHERE parent_term_id IS NULL AND library_id IS NOT NULL;

-- 子术语：父节点内唯一（parent_term_id + term_code）
CREATE UNIQUE INDEX IF NOT EXISTS uq_term_child
    ON term(parent_term_id, term_code)
    WHERE parent_term_id IS NOT NULL;

-- 术语名称：同一术语同一作用域下名称不重复。
-- 允许同一字段别名分别挂在不同 view/object scope 下。
DROP INDEX IF EXISTS uq_term_name_text;
CREATE UNIQUE INDEX IF NOT EXISTS uq_term_name_scope
    ON term_name(term_id, name_text, search_scope);

-- term_vocabulary：唯一索引保障去重查询极速（不依赖实时 DISTINCT）
CREATE UNIQUE INDEX IF NOT EXISTS idx_vocab_word
    ON term_vocabulary(word);

-- term_vocabulary 自动维护触发器：term_name INSERT 时自动去重写入 vocabulary
CREATE OR REPLACE FUNCTION maintain_term_vocabulary() RETURNS trigger AS $$
BEGIN
    INSERT INTO term_vocabulary (word)
    SELECT NEW.name_text
    WHERE NOT EXISTS (
        SELECT 1 FROM term_vocabulary WHERE word = NEW.name_text
    );
    RETURN NEW;
END
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_term_name_vocab ON term_name;
CREATE TRIGGER trg_term_name_vocab
    AFTER INSERT ON term_name
    FOR EACH ROW
    EXECUTE PROCEDURE maintain_term_vocabulary();

-- term_name
CREATE INDEX IF NOT EXISTS idx_tn_search_scope
    ON term_name USING GIN (search_scope);

-- term_name BM25 GIN 索引
CREATE INDEX IF NOT EXISTS idx_tn_name_keywords
    ON term_name USING GIN (name_keywords);

-- term_name 向量 HNSW 索引（余弦距离）
CREATE INDEX IF NOT EXISTS idx_tn_name_embedding_hnsw
    ON term_name
    USING hnsw (name_embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

-- term_name jieba 分词 BM25 GIN 索引
CREATE INDEX IF NOT EXISTS idx_tn_name_keywords_jieba
    ON term_name USING GIN (name_keywords_jieba);
