"""No-op backends — return empty/null results, write operations raise PermissionError.

Used as fallback when a backend type has no implementation configured for a base.
"""

from __future__ import annotations

from typing import Any


class _NoopOntologyBackend:
    """Ontology backend where all reads return empty and all writes are forbidden."""

    def parse_owl(self, directory: Any) -> Any:
        """Return empty ParsedOwlContent."""
        from datacloud_platform.models.shared import ParsedOwlContent

        return ParsedOwlContent(objects=[], views=[], relations=[])

    def load_ontology(self, base_path: Any) -> Any:
        """Raise PermissionError — no ontology available."""
        raise PermissionError("Ontology not available")

    def load_terms(self, loader: Any, *, library_id: str = "PERSONAL_LIB") -> Any:
        """Return None."""
        return None

    def batch_import_ontology(
        self,
        base_path: Any,
        objects: list[dict[str, Any]],
        views: list[dict[str, Any]],
        relations: list[dict[str, Any]],
        actions: list[dict[str, Any]],
        dbsources: list[dict[str, Any]],
    ) -> dict[str, int]:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def create_table(self, object_code: str, fields: list[dict[str, Any]]) -> None:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def drop_table(self, object_code: str) -> None:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def get_objects(self, loader: Any, base_id: str) -> list[Any]:
        """Return empty list."""
        return []

    def get_object_detail(self, loader: Any, object_code: str) -> Any | None:
        """Return None."""
        return None

    # -- View CRUD (no-op) --

    def get_views(self, loader: Any, base_id: str) -> list[Any]:
        """Return empty list."""
        _ = loader
        _ = base_id
        return []

    def get_view_detail(self, loader: Any, base_id: str, view_code: str) -> Any | None:
        """Return None."""
        _ = loader
        _ = base_id
        _ = view_code
        return None

    def create_view(self, base_id: str, view: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def update_view(self, base_id: str, view_code: str, view: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def delete_view(self, base_id: str, view_code: str) -> None:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    # -- Relation CRUD (no-op) --

    def get_relations(self, loader: Any, base_id: str) -> list[Any]:
        """Return empty list."""
        _ = loader
        _ = base_id
        return []

    def get_relation_detail(
        self, loader: Any, base_id: str, rel_code: str
    ) -> Any | None:
        """Return None."""
        _ = loader
        _ = base_id
        _ = rel_code
        return None

    def create_relation(self, base_id: str, rel: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def update_relation(self, base_id: str, rel_code: str, rel: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def delete_relation(self, base_id: str, rel_code: str) -> None:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    # -- Action CRUD (no-op) --

    def get_actions(self, loader: Any, base_id: str, object_code: str) -> list[Any]:
        """Return empty list."""
        _ = loader
        _ = base_id
        _ = object_code
        return []

    def get_action_detail(
        self, loader: Any, base_id: str, object_code: str, action_code: str
    ) -> Any | None:
        """Return None."""
        _ = loader
        _ = base_id
        _ = object_code
        _ = action_code
        return None

    def create_action(self, base_id: str, object_code: str, action: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def update_action(
        self,
        base_id: str,
        object_code: str,
        action_code: str,
        action: Any,
    ) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def delete_action(self, base_id: str, object_code: str, action_code: str) -> None:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    # -- Datasource CRUD (no-op) --

    def get_datasources(self, loader: Any, base_id: str) -> list[Any]:
        """Return empty list."""
        _ = loader
        _ = base_id
        return []

    def get_datasource_detail(
        self, loader: Any, base_id: str, db_id: str
    ) -> Any | None:
        """Return None."""
        _ = loader
        _ = base_id
        _ = db_id
        return None

    def create_datasource(self, base_id: str, ds: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def delete_datasource(self, base_id: str, db_id: str) -> None:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    # -- Object CRUD (no-op) --

    def create_object(self, base_id: str, obj: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def update_object(self, base_id: str, object_code: str, obj: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def delete_object(self, base_id: str, object_code: str) -> None:
        """No-op — delete is safe to be idempotent."""

    # -- Scene reverse-lookup queries (no-op) --

    def get_object_scene_count(self, base_id: str, object_code: str) -> int:
        """Return 0."""
        _ = base_id
        _ = object_code
        return 0

    def get_view_scene_count(self, base_id: str, view_code: str) -> int:
        """Return 0."""
        _ = base_id
        _ = view_code
        return 0

    def remove_object_from_all_scenes(self, base_id: str, object_code: str) -> int:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def remove_view_from_all_scenes(self, base_id: str, view_code: str) -> int:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def get_scenes_containing_object(self, base_id: str, object_code: str) -> list[str]:
        """Return empty list."""
        _ = base_id
        _ = object_code
        return []

    # -- Scene management (no-op) --

    def list_scenes(self, base_id: str) -> list[Any]:
        """Return empty list."""
        return []

    def query_scenes(self, base_id: str, keyword: str | None) -> list[Any]:
        """Return empty list."""
        return []

    def count_scenes(self, base_id: str, keyword: str | None) -> int:
        """Return 0."""
        return 0

    def get_term_scope_info(self, base_id: str, object_code: str) -> dict[str, Any]:
        """Return default scope info — no ontology available."""
        return {"library_id": "PERSONAL_LIB", "scene_id": ""}

    def get_scene_details(
        self,
        loader: object,
        base_id: str,
        scene_id: str,
        *,
        view_code: list[str] | None = None,
        object_code: list[str] | None = None,
    ) -> dict[str, Any]:
        """Return empty scene details."""
        _ = loader
        return {
            "scene": None,
            "views": [],
            "objects": [],
            "actions": [],
            "relations": [],
            "dbsources": [],
            "version": None,
        }

    def query_ontologies_by_scene(
        self,
        loader: object,
        base_id: str,
        scene_id: str,
        *,
        page: int = 1,
        page_size: int = 20,
        keyword: str | None = None,
    ) -> dict[str, Any]:
        """Return empty result."""
        _ = loader
        return {"data": {"objects": [], "views": []}, "totalCount": 0}

    # -- Scene CRUD (no-op) --

    def create_scene(self, base_id: str, scene: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def update_scene(self, base_id: str, scene_id: str, updates: Any) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def delete_scene(self, base_id: str, scene_id: str) -> None:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def add_scene_members(
        self,
        base_id: str,
        scene_id: str,
        object_codes: list[str],
        view_codes: list[str],
    ) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    def remove_scene_members(
        self,
        base_id: str,
        scene_id: str,
        object_codes: list[str],
        view_codes: list[str],
    ) -> Any:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Ontology not available")

    # -- Property term bindings (no-op) --

    def get_object_property_term_bindings(
        self,
        loader: Any,
        object_codes: list[str],
        *,
        term_master_type: str | None = None,
        property_codes: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Return empty list — no ontology available."""
        _ = loader
        return []

    def get_view_property_term_bindings(
        self,
        loader: Any,
        view_codes: list[str],
        *,
        term_master_type: str | None = None,
        property_codes: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Return empty list — no ontology available."""
        _ = loader
        return []

    # -- Property name / alias resolution (no-op) --

    def resolve_property_name(
        self,
        loader: Any,
        name_text: str,
        scope_code: str,
    ) -> tuple[str, str] | None:
        """Return None — no ontology available."""
        _ = loader
        return None

    def resolve_property_names(
        self,
        loader: Any,
        name_texts: list[str],
        scope_code: str,
    ) -> dict[str, tuple[str, str]]:
        """Return empty dict — no ontology available."""
        _ = loader
        return {}

    def get_property_aliases(
        self,
        loader: Any,
        field_code: str,
        scope_code: str,
    ) -> list[str]:
        """Return empty list — no ontology available."""
        _ = loader
        return []

    def get_view_included_objects(
        self,
        loader: Any,
        ontology_code: str,
    ) -> list[str]:
        _ = loader, ontology_code
        return []

    def get_joinkey_related_objects(
        self,
        loader: Any,
        ontology_code: str,
        field_codes: list[str],
    ) -> list[str]:
        _ = loader, ontology_code, field_codes
        return []

    # -- Ontology search & graph (no-op) --

    def search_ontology(
        self,
        base_id: str,
        scene_ids: list[str],
        *,
        keyword: str,
        query_type: str = "vector",
        search_scope: str = "all",
        ontology_type: list[str] | None = None,
        object_code: list[str] | None = None,
        view_code: list[str] | None = None,
        property_code: list[str] | None = None,
        limit: int = 20,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return empty result."""
        return {"data": [], "totalCount": 0}

    def search_ontology_batch(
        self,
        base_id: str,
        keyword: str,
        limit: int = 20,
    ) -> dict[str, Any]:
        """Return empty result."""
        return {"data": [], "totalCount": 0}

    def graph_query(
        self,
        base_id: str,
        scene_id: str,
        *,
        object_code: list[str],
        match_by: str = "name",
        values: list[str] | None = None,
        step: int = 1,
    ) -> dict[str, Any]:
        """Return empty result."""
        return {"data": [], "totalCount": 0}

    def graph_path(
        self,
        base_id: str,
        scene_id: str,
        *,
        match_by: str = "name",
        start_node: str,
        end_node: str = "",
        direction: str = "forward",
    ) -> dict[str, Any]:
        """Return empty result."""
        return {"data": [], "totalCount": 0}

    def search_instances(
        self,
        base_id: str,
        *,
        object_code: str,
        select: list[str] | None = None,
        where: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Return empty result."""
        return {"data": [], "totalCount": 0}


class _NoopTermBackend:
    """Term backend where all reads return empty/null and mutations are no-ops."""

    # ── Term ────────────────────────────────────────────────────────────

    def search_terms(
        self,
        *,
        dataset_ids: list[str] | None = None,
        keyword: str | None = None,
        term_name: str | None = None,
        term_type: str | None = None,
        query_type: str = "fulltext",
        parent_term_code: str | None = None,
        label_filters: list[dict[str, Any]] | None = None,
        label_condition: str = "and",
        term_ids: list[str] | None = None,
        top_k: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Return empty search result."""
        return {"data": [], "totalCount": 0}

    def get_term_detail(
        self, *, dataset_id: str, term_id: str
    ) -> dict[str, Any] | None:
        """Return None."""
        return None

    def list_terms(
        self,
        *,
        dataset_id: str,
        term_type: str | None = None,
        term_type_no_eq: str | None = None,
        page_index: int = 1,
        page_size: int = 50,
    ) -> dict[str, Any]:
        """Return empty list."""
        return {
            "data": [],
            "totalCount": 0,
            "pageIndex": page_index,
            "pageSize": page_size,
        }

    def create_term(self, *, term: dict[str, Any]) -> dict[str, Any]:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Term backend not available")

    def import_terms(
        self, *, dataset_id: str, terms: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Term backend not available")

    def update_term(
        self, *, dataset_id: str, term_id: str, updates: dict[str, Any]
    ) -> None:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Term backend not available")

    def delete_term(self, *, term_id: str) -> None:
        """Raise PermissionError — write forbidden."""
        raise PermissionError("Term backend not available")

    def query_term_relations(
        self,
        *,
        term_id: str,
        relation_category: str | None = None,
        direction: str = "both",
        depth: int = 1,
    ) -> dict[str, Any]:
        """Return empty result."""
        return {"data": [], "totalCount": 0}

    # ── TermRelation ────────────────────────────────────────────────────

    def list_term_relations(
        self,
        *,
        source_term_id: str | None = None,
        target_term_id: str | None = None,
        relation_category: str | None = None,
    ) -> list[dict[str, Any]]:
        return []

    def get_term_relation(self, *, relation_id: str) -> dict[str, Any] | None:
        return None

    def create_term_relation(self, *, relation: dict[str, Any]) -> dict[str, Any]:
        raise PermissionError("Term backend not available")

    def update_term_relation(
        self, *, relation_id: str, updates: dict[str, Any]
    ) -> None:
        raise PermissionError("Term backend not available")

    def delete_term_relation(self, *, relation_id: str) -> None:
        raise PermissionError("Term backend not available")

    # ── TermName ────────────────────────────────────────────────────────

    def list_term_names(
        self, *, term_id: str | None = None, name_text: str | None = None
    ) -> list[dict[str, Any]]:
        return []

    def get_term_name(self, *, name_id: str) -> dict[str, Any] | None:
        return None

    def create_term_name(self, *, name: dict[str, Any]) -> dict[str, Any]:
        raise PermissionError("Term backend not available")

    def update_term_name(self, *, name_id: str, updates: dict[str, Any]) -> None:
        raise PermissionError("Term backend not available")

    def delete_term_name(self, *, name_id: str) -> None:
        raise PermissionError("Term backend not available")

    # ── TermKnowledge ───────────────────────────────────────────────────

    def list_term_knowledges(
        self, *, term_id: str | None = None, ext_system: str | None = None
    ) -> list[dict[str, Any]]:
        return []

    def get_term_knowledge(self, *, knowledge_id: str) -> dict[str, Any] | None:
        return None

    def create_term_knowledge(self, *, knowledge: dict[str, Any]) -> dict[str, Any]:
        raise PermissionError("Term backend not available")

    def update_term_knowledge(
        self, *, knowledge_id: str, updates: dict[str, Any]
    ) -> None:
        raise PermissionError("Term backend not available")

    def delete_term_knowledge(self, *, knowledge_id: str) -> None:
        raise PermissionError("Term backend not available")

    # ── TermLibrary ─────────────────────────────────────────────────────

    def list_term_libraries(
        self,
        *,
        library_code: str | None = None,
        library_name: str | None = None,
    ) -> list[dict[str, Any]]:
        return []

    def get_term_library(self, *, library_id: str) -> dict[str, Any] | None:
        return None

    def create_term_library(self, *, library: dict[str, Any]) -> dict[str, Any]:
        raise PermissionError("Term backend not available")

    def update_term_library(self, *, library_id: str, updates: dict[str, Any]) -> None:
        raise PermissionError("Term backend not available")

    def delete_term_library(self, *, library_id: str) -> None:
        raise PermissionError("Term backend not available")

    # ── TermType ────────────────────────────────────────────────────────

    def list_term_types(
        self, *, type_category: int | None = None
    ) -> list[dict[str, Any]]:
        return []

    def get_term_type(self, *, type_code: str) -> dict[str, Any] | None:
        return None

    def create_term_type(self, *, term_type: dict[str, Any]) -> dict[str, Any]:
        raise PermissionError("Term backend not available")

    def update_term_type(self, *, type_code: str, updates: dict[str, Any]) -> None:
        raise PermissionError("Term backend not available")

    def delete_term_type(self, *, type_code: str) -> None:
        raise PermissionError("Term backend not available")

    # ── Domain ──────────────────────────────────────────────────────────

    def list_domains(self, *, parent_id: str | None = None) -> list[dict[str, Any]]:
        return []

    def get_domain(self, *, domain_id: str) -> dict[str, Any] | None:
        return None

    def create_domain(self, *, domain: dict[str, Any]) -> dict[str, Any]:
        raise PermissionError("Term backend not available")

    def update_domain(self, *, domain_id: str, updates: dict[str, Any]) -> None:
        raise PermissionError("Term backend not available")

    def delete_domain(self, *, domain_id: str) -> None:
        raise PermissionError("Term backend not available")

    def list_domain_term_types(self, *, domain_id: str) -> list[dict[str, Any]]:
        return []

    # ── Vector ──────────────────────────────────────────────────────────

    def embed(self, text: str) -> list[float]:
        """Return zero vector."""
        return [0.0] * 768

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Return zero vectors."""
        return [[0.0] * 768 for _ in texts]

    def search_by_embedding(
        self, vector: list[float], term_types: list[str], limit: int = 20
    ) -> list[Any]:
        """Return empty list."""
        return []

    # ── Sync ────────────────────────────────────────────────────────────

    def sync_terms(
        self,
        entity_code: str,
        entity_name: str,
        entity_source: str,
        fields: list[dict[str, Any]],
        *,
        backfill_vectors: bool = True,
    ) -> None:
        """No-op."""

    def remove_terms(self, entity_code: str) -> None:
        """No-op."""


class _NoopExecutionBackend:
    """Execution backend where all operations are forbidden."""

    async def execute_action(
        self, loader: Any, object_code: str, action_code: str, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        """Raise PermissionError — execution not available."""
        raise PermissionError("Execution not available")

    def generate_action_tools(
        self, loader: Any, object_code: str
    ) -> list[dict[str, Any]]:
        """Return empty list."""
        return []

    def generate_dynamic_query_tools(
        self, loader: Any, object_code: str
    ) -> list[dict[str, Any]]:
        """Return empty list."""
        return []

    def generate_virtual_actions(
        self, loader: Any, mounted_objects: list[str]
    ) -> list[dict[str, Any]]:
        """Return empty list."""
        return []

    def inject_virtual_actions(self, loader: Any) -> None:
        """No-op."""

    def generate_plan(self, query: str, loader: Any, context: Any) -> Any:
        """Return empty plan."""
        return {"steps": []}

    def build_filters_schema(self, fields: list[Any]) -> dict[str, Any]:
        """Return empty schema."""
        return {}


class _NoopStorageBackend:
    """Storage backend where all operations are forbidden."""

    def store_result(
        self, key: str, data: bytes, *, metadata: dict[str, Any] | None = None
    ) -> str:
        """Raise PermissionError — storage not available."""
        raise PermissionError("Storage not available")

    def get_result(self, file_id: str) -> bytes:
        """Raise PermissionError — storage not available."""
        raise PermissionError("Storage not available")

    def delete_result(self, file_id: str) -> None:
        """Raise PermissionError — storage not available."""
        raise PermissionError("Storage not available")

    def list_results(self, prefix: str = "") -> list[Any]:
        """Return empty list."""
        return []
