"""Provide locale-specific system prompts for DataCloud agent.

虚拟工具前缀（query_/compute_）由 ``datacloud_data_service.config.Settings``
配置决定，可通过环境变量 ``DATACLOUD_VIRTUAL_ACTION_QUERY_PREFIX`` /
``DATACLOUD_VIRTUAL_ACTION_COMPUTE_PREFIX`` 覆盖。
"""

from __future__ import annotations

import os

from datacloud_data_service.config import get_settings


def _virtual_prefixes() -> tuple[str, str]:
    """返回 (query_prefix, compute_prefix)，与工具生成层共享同一配置源。"""
    s = get_settings()
    return s.virtual_action_query_prefix, s.virtual_action_compute_prefix


def _bare_prefix(prefix: str) -> str:
    """剥离尾部下划线，得到提示词中"裸名"形态；前缀本身无下划线时原样返回。"""
    return prefix.rstrip("_") if prefix.endswith("_") else prefix


_SYSTEM_PROMPTS: dict[str, str] = {
    "zh_CN": (
        "你是 DataCloud 数据分析助手，负责帮助用户完成数据分析与业务洞察。\n\n"
        "## 工具使用规则\n"
        "- 当用户询问业务数据（如商机、客户、订单、成交或任意业务记录）时，"
        "应优先使用当前 Agent 已挂载的动态查询工具，不要转交给子代理。\n"
        "- 对自然语言数据分析问题，优先选择最匹配的动态查询工具。\n"
        "- 请用中文回答，表达简洁、准确。"
    ),
    "en_US": (
        "You are a DataCloud data analysis assistant. \n\n"
        "- Please respond in concise and accurate English."
    ),
}


_FALLBACK_LOCALE = "zh_CN"


def _get_query_tool_hint_zh() -> str:
    """返回统一查询工具命名规则提示（前缀由 Settings 决定）。"""
    q, c = _virtual_prefixes()
    qb, cb = _bare_prefix(q), _bare_prefix(c)
    return (
        "## 查询工具命名规则\n"
        f"- 查询工具名称格式为 {q}{{对象编码}}（如 {q}ads_enterprise_analysis），"
        f"聚合计算工具格式为 {c}{{对象编码}}（如 {c}ads_enterprise_analysis）。\n"
        "- 复杂查询（complex_conditions 非空）系统后端自动处理，agent 无需手动调用其他工具。\n"
        f"- 禁止调用不含对象编码的裸工具名（如直接调用 {qb} 或 {cb}）。\n"
    )


def _get_query_tool_hint_en() -> str:
    """Return query tool naming hint with prefixes resolved from Settings."""
    q, c = _virtual_prefixes()
    qb, cb = _bare_prefix(q), _bare_prefix(c)
    return (
        "## Query tool naming\n"
        f"- Tool format: {q}{{object_code}} (e.g. {q}ads_enterprise_analysis), "
        f"{c}{{object_code}} (e.g. {c}ads_enterprise_analysis).\n"
        "- Complex queries (complex_conditions non-empty) are handled automatically by the backend.\n"
        f"- Do NOT call bare names like '{qb}' or '{cb}' without the object suffix.\n"
    )


def _disable_ask_user_tool() -> bool:
    """Match ``execution/node.py``: when True, builtin ``ask_user`` is not mounted."""

    return os.environ.get("DATACLOUD_DISABLE_ASK_USER_TOOL", "1").strip().lower() in (
        "1",
        "true",
        "yes",
    )


def get_system_prompt(locale: str | None = None) -> str:
    """Return locale-specific system prompt with fallback support."""

    resolved_locale_raw = locale or os.getenv("DATACLOUD_AGENT_LOCALE", _FALLBACK_LOCALE)

    resolved_locale = resolved_locale_raw or _FALLBACK_LOCALE

    return _SYSTEM_PROMPTS.get(resolved_locale, _SYSTEM_PROMPTS[_FALLBACK_LOCALE])


def get_supported_locales() -> list[str]:
    """Return all supported locale codes."""

    return list(_SYSTEM_PROMPTS.keys())


def _build_exec_zh() -> str:
    no_ask = _disable_ask_user_tool()
    parts = [
        "## 执行规则\n",
        "- 你具备工具调用能力，请通过工具完成用户任务。\n",
        "- 分析结束时必须调用 finish_react 工具提交最终答案，禁止直接输出。\n",
        "- 工具返回中包含 _hint 字段时，必须立即按照 _hint 指示调用 finish_react，禁止将数据整理为文字回复。\n",
    ]
    if not no_ask:
        parts.append("- 仅当问题含义不清或工具明确要求追问时，才使用 ask_user（详见下方规则）。\n")
    else:
        parts.append(
            "- 当前未挂载 ask_user 工具：禁止试图调用 ask_user。"
            "若需用户补充信息，请直接调用 finish_react（result_type=text）"
            "在 answer 中用中文写清楚需要用户提供什么。\n"
        )
    parts.extend(
        [
            "- 每次工具调用必须填写 reason 字段，说明选择该工具的理由。\n",
            "- 工具调用失败时，先诊断再行动：\n"
            "  相同参数失败 → 不许盲目重试，分析原因后换参数或换对象；\n"
            "  工具返回空结果 → 换策略重试（不同过滤条件或不同对象）；\n"
            "  工具被用户拒绝 → 不许重试同一调用，思考原因后调整方案。\n",
        ]
    )
    # 插入模式感知的查询工具命名提示
    query_tool_hint = _get_query_tool_hint_zh()
    if query_tool_hint:
        parts.append(query_tool_hint)
    if not no_ask:
        parts.extend(
            [
                "## ask_user 使用规则（重要）\n",
                "- ask_user 工具只能用于以下情形：\n",
                "  1. 用户问题本身含义不清，无法确定要查什么数据；\n",
                "  2. 查询工具返回 result_type=ask_user，要求追问用户。\n",
                "- 禁止将 ask_user 用于礼貌性确认，例如询问是否需要进一步分析或其他帮助。\n",
                "- 查询工具成功返回数据后，应直接调用 finish_react，不得再询问用户。\n",
            ]
        )
    else:
        parts.append("- 查询工具成功返回数据后，应直接调用 finish_react，不得再试图追问用户。\n")

    ask_user_result_line = (
        "- 如果 result_type=ask_user，需要向用户追问，使用 ask_user 工具。\n"
        if not no_ask
        else (
            "- 如果 result_type=ask_user 或接口要求追问用户："
            "未挂载追问工具，请调用 finish_react（result_type=text）"
            "并在 answer 中写出要问用户的内容，勿再试图调用 ask_user。\n"
        )
    )
    q, c = _virtual_prefixes()
    parts.extend(
        [
            "## compute 统计工具参数规则\n",
            f"- 调用 {c}{{对象编码}} 时，`metrics` 数组每项必须包含：`field`（字段中文名如'企业总营收（万元）'或字段编码如 total_revenue，系统自动识别映射）、"
            "**`agg`**（聚合名，如 count、sum、count_distinct）、`as`（结果列别名）。\n",
            "- metrics 和 dimensions 中指定字段使用 `field` 键，可填中文名或字段编码，系统自动映射。\n",
            "- 禁止使用 `func` 作为聚合键名；协议与校验只识别 **`agg`**。\n",
            "## 查询工具参数规则\n",
            "- 调用数据查询工具时，query 参数必须是完整的自然语言问题，描述用户真正想查询的内容，例如「查询企业分析表的全部字段」。\n",
            "- 禁止使用 *、%、ALL 等通配符或占位符作为 query 参数。\n",
            "- 如果用户原始问题较短，应结合上下文将其改写为完整、清晰的自然语言查询。\n",
            "## 工具选择引导\n",
            "- 调用工具前，先在心中完成贪心预判：\n",
            f"  1. 目标对象：从问题中识别要查询的本体（如'企业'→{q}enterprise_view）。\n",
            f"  2. 任务类型：明细查询 → {q}*；统计聚合 → {c}*。\n",
            "  3. 参数预填：对照工具描述中的字段能力表，提前确定 select/filters/dimensions/metrics。\n",
            f"## {q}*/{c}* 核心参数规则\n",
            "- **query（必填）**：完整自然语言问题，不得为空，不得使用 */%/ALL 等通配符。\n",
            "  如用户原始问题较短，结合上下文改写为完整清晰的查询描述。\n",
            "- **limit（可选）**：用户没有明确要求返回条数时，不要填写 limit；"
            "只有用户明确提出前 N 条、最多 N 条、返回 N 条、limit N 或分页大小时，才填写 limit。\n",
            "- **标准参数**（select / filters / dimensions / metrics）：\n",
            "  填写时可使用 field_code 或中文字段名，系统自动映射；不确定时留空，结合 query 自动推断。\n",
            "  filters 的 value 只填字面常量（已知的具体数值、日期、枚举值）。\n",
            "  字段有术语值且 filters.op 为 eq 或 in 时，filters.value 必须填写该字段描述/Schema 中列出的具体术语值；"
            "禁止填写未出现在术语值列表中的同义词、口语词、编码或自造值。\n",
            "  ⚠️ **字段名不存在时必须透传原词**：若某个词（如'贡献率'、'地块'）在工具的字段列表中\n",
            "  找不到精确对应，禁止猜测替换为相近字段名；必须将用户的原始词直接填入对应参数\n",
            "  （如 select: ['贡献率']、order_by: [{'field': '贡献率', 'direction': 'asc'}]），\n",
            "  系统后端会做语义解析。字段透传与 complex_conditions 是独立规则，互不影响。\n",
            "- **complex_conditions（溢出过滤区）**：\n",
            "  满足以下条件时，必须将该条件用自然语言写入此列表：\n",
            "  1. 过滤条件的值在填参时无法确定为字面常量（如'后30%'、'高于平均'、'排名前10名'）。\n",
            "  ⚠️ 字段名在字段列表中找不到时，不触发 complex_conditions——直接透传原词到标准参数即可。\n",
            "  示例：'亩产效益后30%的地块'、'营收高于行业平均值'。\n",
            "  此列表非空时系统后端自动路由到全能查询路径，无需手动调用其他工具。\n",
            "- **禁止**：同时将同一条件既写入 filters 又写入 complex_conditions。\n",
            "## 查询工具返回结构规则\n",
            f"- {q}*/{c}* 返回结构：{{data: {{result_type, records, file: {{file_url}}, meta}}}}。\n",
            "- 如果返回中包含 file_url 字段或顶层 _hint 字段，说明数据已存入本地文件，直接使用该文件路径。\n",
            "- 如果 result_type=rejected，数据查询被拒绝，应告知用户并说明原因。\n",
            ask_user_result_line,
            "## 结果类型规则\n",
            f"- 调用 {q}*/{c}* 工具后，返回中含 _hint 字段：必须使用 result_type=query_result，"
            "系统会自动透传完整的 records/pagination/meta/file 结构。\n",
            "- 如需同时返回文字分析+结构化数据：result_type=query_result，answer 填写文字分析，系统会先推文字再推 6001 内容。\n",
            "- 禁止将查询工具返回的 records 序列化后填入 data 字段，会丢失 meta/pagination/file 信息。\n",
            "- CSV 文件：result_type=csv_file。\n",
            "- 纯文字结论：result_type=text。",
        ]
    )
    return "".join(parts)


def _build_exec_en() -> str:

    hint = _get_query_tool_hint_en()
    q, c = _virtual_prefixes()

    return (
        "## Execution rules\n"
        "- Use tools to complete tasks. Call finish_react when done.\n"
        "- Each tool call must include a reason field.\n"
        + (hint if hint else "")
        + "## Compute tool rules\n"
        + f"- For {c}{{object}}, each metrics item must use the key **`agg`** "
        "(e.g. count_distinct), never `func`.\n"
        + "## Query tool return structure\n"
        + f"- {q}*/{c}* return: {{data: {{result_type, records, file: {{file_url}}, meta}}}}.\n"
        "- If file_url or _hint present, data is saved. Do NOT call write_file.\n"
        "## Result type rules\n"
        "- records: result_type=json. file_url or _result: result_type=json_file.\n"
        "- CSV: result_type=csv_file. Text: result_type=text."
    )


def get_execution_prompt(locale: str | None = None) -> str:
    """Return locale-specific execution rules prompt with fallback support.



    Chinese rules are built per call so ``DATACLOUD_DISABLE_ASK_USER_TOOL`` reflects

    the current process environment (after ``load_dotenv``), not import-time env.

    """

    resolved_locale = locale or os.getenv("DATACLOUD_AGENT_LOCALE", _FALLBACK_LOCALE)

    if resolved_locale == "en_US":
        return _build_exec_en()

    return _build_exec_zh()


def _build_ontology_rules_zh() -> str:
    """本体推理规则段（中文，XML 结构化）。

    当前针对 Anthropic Claude 优化（XML 标签格式、cache_control 友好）。
    未来接入 GPT/Gemini 时，在 graph_builder.py 的 ontology_rules 拼装处
    根据 model_provider 选择对应规则段（参考 Hermes OPENAI_MODEL_EXECUTION_GUIDANCE）。
    """
    return (
        "## 本体推理规则\n\n"
        "### 任务分解（可选）\n"
        "<task_decomposition>\n"
        "问题需要经过 3 步以上本体对象推理时，先调 manage_todo 分解为步骤，全部设为 pending。\n"
        "每完成一步立即标记 completed。单对象简单查询无需分解。\n"
        "</task_decomposition>\n\n"
        "### 锚点工具\n"
        "<anchor_tools>\n"
        'search_ontology(query, scope="all", type="all")\n'
        "  不确定从哪个对象入手时调用。冷启动时框架已自动调用一次，结果工具已解锁。\n"
        "  推理中发现当前工具不够用时再次调用。\n\n"
        "goto_ontology(object_code, reason)\n"
        "  工具返回结果中出现关联对象的 ID 字段，且需要继续分析该对象时调用。\n"
        "  已知目标时用此工具，跳过搜索直接解锁。reason 写入推理轨迹。\n\n"
        "get_reasoning_map()\n"
        "  当前路径无法解答问题（dead_end）→ 调此工具换方向。\n"
        "  推理接近完成需要汇总 → 调此工具回顾所有 findings 整合输出。\n\n"
        "mark_dead_end(object_code, reason)\n"
        "  沿某个对象展开后发现无相关信号时调用，避免后续重复尝试。\n"
        "  标记后立即调 get_reasoning_map() 或 search_ontology 换方向。\n"
        "</anchor_tools>\n\n"
        "### 结论记录\n"
        "<finding_tools>\n"
        "record_finding(summary)\n"
        "  推理出阶段性发现时立即调用，写入推理轨迹。\n"
        "  不要等到最后才汇总——每步有结论就记录。\n"
        "  纯文字结论用此工具，不要物化数据。\n"
        "</finding_tools>\n\n"
        "### 数据物化（自举）\n"
        "<task_materialization>\n"
        "工具返回含 file_id（数据超阈值）时：\n"
        "  后续需多次引用或联合分析 → create_task_object(file_id, object_code, description)\n"
        "  一次性用完 → 忽略 file_id，直接推理\n\n"
        "create_task_object 提示'无法自动推断关系'时：\n"
        "  → create_task_relation(from_object, to_object, join_keys, description)\n\n"
        "多个任务对象已建立关系后需联合分析：\n"
        "  → query_task_graph(sql)\n"
        "</task_materialization>\n\n"
        "### 推理执行纪律（持续努力 + 验证）\n"
        "<reasoning_discipline>\n"
        "完成性要求：\n"
        "  推理结果必须真正回答用户问题——不要过度分析，但不许半途而废。\n\n"
        "不许只描述意图，必须立即调工具执行：\n"
        "  说'我需要查询 xxx'时，必须在同一轮次内调用对应工具。\n\n"
        "不确定时继续探索，而不是停下来等：\n"
        "  问自己：我还不知道什么？哪里可能出问题？结束前我想验证什么？\n"
        "  遇到模糊场景，主动调 search_ontology 探索，而不是等用户指示。\n\n"
        "工具调用失败时，区分处理：\n"
        "  相同参数调同一工具失败 → 不许盲目重试，换参数或换对象\n"
        "  工具返回空结果 → 换策略重试，不能直接 finish_react\n"
        "  路径走不通 → mark_dead_end + get_reasoning_map 换方向，不是放弃\n\n"
        "行动优先，不许等确认：\n"
        "  两种方案都合理时，选一个执行，可以纠偏，不要停下来等用户选择。\n\n"
        "结束前自检（调 finish_react 之前必须完成）：\n"
        "  findings 是否直接回答了用户的原始问题？\n"
        "  是否还有明显未探索的相关本体对象？\n"
        "  结论是否有工具调用数据支撑，而不只是推断？\n"
        "</reasoning_discipline>\n\n"
        "### 推理终止\n"
        "<reasoning_termination>\n"
        "finish_react(summary)\n"
        "  通过结束前自检后调用，summary 写核心结论。\n"
        "  所有方向均为 dead_end → 调用，说明无法得出结论的原因。\n"
        "  禁止直接输出文字回复，必须通过 finish_react 提交。\n"
        "</reasoning_termination>\n"
    )


# ── UI 运行时文本（推送给用户可见的进度/状态字符串）────────────────────────────

_UI_TEXT: dict[str, dict[str, str]] = {
    "thinking_done": {
        "zh_CN": "久等了，我思考了 {elapsed:.0f} 秒，继续干活",
        "en_US": "Took {elapsed:.0f}s to think, let's continue",
    },
    "tool_input": {
        "zh_CN": "工具入参",
        "en_US": "Tool input",
    },
    "tool_output": {
        "zh_CN": "工具返回",
        "en_US": "Tool output",
    },
    "tool_error": {
        "zh_CN": "工具错误",
        "en_US": "Tool error",
    },
    "received_message": {
        "zh_CN": "已接收到用户消息，开始处理",
        "en_US": "Message received, processing...",
    },
    "summarizing": {
        "zh_CN": "正在整理结果...",
        "en_US": "Summarizing results...",
    },
    "understanding": {
        "zh_CN": "正在理解问题并补充上下文...\n\n",
        "en_US": "Understanding your question...\n\n",
    },
    "planning": {
        "zh_CN": "正在生成任务计划...\n\n",
        "en_US": "Generating task plan...\n\n",
    },
    "executing": {
        "zh_CN": "正在执行任务...\n\n",
        "en_US": "Executing tasks...\n\n",
    },
    "processing": {
        "zh_CN": "正在处理，请稍候...\n\n",
        "en_US": "Processing, please wait...\n\n",
    },
    "phase_understanding": {
        "zh_CN": "问题理解",
        "en_US": "Understanding",
    },
    "phase_execution": {
        "zh_CN": "任务执行",
        "en_US": "Execution",
    },
    "phase_result": {
        "zh_CN": "结果生成",
        "en_US": "Result",
    },
    "phase_planning": {
        "zh_CN": "任务生成",
        "en_US": "Planning",
    },
    "err_query_data_empty": {
        "zh_CN": "(query_data 为空)",
        "en_US": "(query_data is empty)",
    },
    "err_csv_path_empty": {
        "zh_CN": "(CSV 路径为空，无法输出)",
        "en_US": "(CSV path is empty, cannot output)",
    },
    "err_csv_not_found": {
        "zh_CN": "(CSV 文件不存在: {path})",
        "en_US": "(CSV file not found: {path})",
    },
    "err_csv_read_failed": {
        "zh_CN": "(读取 CSV 文件失败: {exc})",
        "en_US": "(Failed to read CSV file: {exc})",
    },
    "err_json_path_empty": {
        "zh_CN": "(JSON 文件路径为空)",
        "en_US": "(JSON file path is empty)",
    },
    "err_file_not_found": {
        "zh_CN": "(文件不存在: {path})",
        "en_US": "(File not found: {path})",
    },
    "err_json_read_failed": {
        "zh_CN": "(读取 JSON 文件失败: {exc})",
        "en_US": "(Failed to read JSON file: {exc})",
    },
    "err_json_data_empty": {
        "zh_CN": "(JSON 数据为空)",
        "en_US": "(JSON data is empty)",
    },
    "clarify_interrupt_prompt": {
        "zh_CN": "查询条件存在歧义，请确认查询维度",
        "en_US": "The query has ambiguous terms — please clarify the selections below",
    },
    "operation_form_title": {
        "zh_CN": "确认执行：{action_name}",
        "en_US": "Confirm execution: {action_name}",
    },
    "operation_form_description": {
        "zh_CN": "请确认以下表单信息，确认后将继续执行。",
        "en_US": "Please confirm the form below. Execution will continue after confirmation.",
    },
    "operation_batch_title": {
        "zh_CN": "确认执行 {count} 个操作",
        "en_US": "Confirm {count} operations",
    },
    "operation_batch_single_title": {
        "zh_CN": "确认执行操作",
        "en_US": "Confirm operation",
    },
    "operation_form_interrupt_prompt": {
        "zh_CN": "请确认操作表单。",
        "en_US": "Please confirm the operation form.",
    },
    "operation_cancelled_reason": {
        "zh_CN": "用户取消操作",
        "en_US": "Operation cancelled by user",
    },
    "operation_cancelled_hint": {
        "zh_CN": "用户已取消本次操作，不再执行业务提交。",
        "en_US": "The user cancelled this operation. The business submission will not run.",
    },
    "operation_term_ambiguous_recommended": {
        "zh_CN": "模型识别为“{original}”，匹配到多个，已默认选择“{display}”（code: {code}）",
        "en_US": 'The model recognized "{original}" and found multiple matches. "{display}" (code: {code}) was selected by default',
    },
    "operation_term_recommended": {
        "zh_CN": "模型识别为“{original}”，未精确命中，已推荐“{display}”（code: {code}）",
        "en_US": 'The model recognized "{original}" but did not find an exact match. "{display}" (code: {code}) is recommended',
    },
    "operation_term_not_found": {
        "zh_CN": "模型识别为“{original}”，未能找到可推荐值，请重新选择。",
        "en_US": 'The model recognized "{original}", but no recommended value was found. Please choose again.',
    },
}


def get_ui_text(key: str, locale: str | None = None, **kwargs: object) -> str:
    """Return a localized UI string by key, with optional format kwargs.

    Falls back to zh_CN when the key or locale is not found.
    """
    resolved = locale or os.getenv("DATACLOUD_AGENT_LOCALE", _FALLBACK_LOCALE) or _FALLBACK_LOCALE
    entry = _UI_TEXT.get(key, {})
    template = entry.get(resolved) or entry.get(_FALLBACK_LOCALE) or key
    if kwargs:
        try:
            return template.format(**kwargs)
        except (KeyError, ValueError):
            return template
    return template
