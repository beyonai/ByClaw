"""DataCloud deep agent — core graph factory.

Persistence (checkpointing) is handled externally:
- langgraph dev: injected by the platform via ``langgraph.json`` / ``checkpointer.py``
  which references ``datacloud_analysis.session.pg_opengauss.get_checkpointer``.
- Standalone SDK: call ``create_agent()`` then compile with your own checkpointer,
  or use ``datacloud_analysis.session.pg_opengauss.make_opengauss_saver`` directly.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from datacloud_analysis.i18n import get_supported_locales
from datacloud_analysis.orchestration.graph_builder import build_analysis_graph
from datacloud_analysis.orchestration.graph_compile_policy import compile_graph_with_policy

logger = logging.getLogger(__name__)

_DIAG_QUESTION_KEYS = (
    "user_message",
    "latest_user_text",
    "question",
    "input",
    "task_prompt",
)


def _truncate_text(text: str, max_len: int) -> str:
    stripped = (text or "").strip()
    if len(stripped) <= max_len:
        return stripped
    return stripped[: max_len - 3] + "..."


def _extract_question_context_for_log(
    *,
    user_message: str | None,
    prompts_overwrite: dict[str, Any] | None,
    system_prompt: str | None,
) -> str:
    """Best-effort 本轮/配置侧「问题」摘要，供核查日志使用。"""

    if user_message and str(user_message).strip():
        return _truncate_text(str(user_message), 800)
    po = prompts_overwrite or {}
    for key in _DIAG_QUESTION_KEYS:
        val = po.get(key)
        if isinstance(val, str) and val.strip():
            return _truncate_text(val, 800)
    if system_prompt and str(system_prompt).strip():
        return _truncate_text(str(system_prompt), 400)
    return (
        "(未提供 user_message；prompts_overwrite 中亦无常见问题字段。"
        "create_agent 多在建图时调用，若需对齐某轮提问请在调用处传入 user_message=...)"
    )


def _format_tools_for_diag(tool_map: dict[str, Any] | None) -> str:
    """将合并后的工具表格式化为多行字符串，便于日志检索。"""

    if not tool_map:
        return "  (无工具)"
    rows: list[str] = []
    for name in sorted(tool_map.keys()):
        obj = tool_map[name]
        kind = type(obj).__name__
        desc = ""
        for attr in ("description", "description_text"):
            raw = getattr(obj, attr, None)
            if isinstance(raw, str) and raw.strip():
                desc = _truncate_text(raw, 140)
                break
        rows.append(f"  - {name} [{kind}] {desc}")
    return "\n".join(rows)


def _resolve_agent_id_for_log(
    *,
    agent_id: str | None,
    prompts_overwrite: dict[str, Any] | None,
) -> str:
    """解析日志用的 agent 标识：显式参数优先，其次 prompts_overwrite。"""

    if agent_id is not None and str(agent_id).strip():
        return str(agent_id).strip()
    po = prompts_overwrite or {}
    for key in ("agent_id", "agentId", "resourceId"):
        val = po.get(key)
        if val is not None and str(val).strip():
            return str(val).strip()
    return "(未提供 agent_id)"


def _log_create_agent_diagnostics(
    *,
    agent_id_display: str,
    question_context: str,
    merged_tools: dict[str, Any] | None,
    mounted_objects: list[str] | None,
) -> None:
    """打印建图时的「agent_id + 问题上下文 + 工具清单」，便于线上对照核查。"""

    tool_block = _format_tools_for_diag(merged_tools)
    tool_names = sorted((merged_tools or {}).keys())
    logger.info(
        "[create_agent diagnostics] ----------\n"
        "agent_id=%s\n"
        "问题/提示上下文:\n%s\n"
        "mounted_objects=%s\n"
        "合并后工具数=%d，清单:\n%s\n"
        "[create_agent diagnostics] ----------",
        agent_id_display,
        question_context,
        mounted_objects,
        len(merged_tools or {}),
        tool_block,
    )

    # 同步写入当前 Langfuse span metadata，故障场景（tool_count=0）直接可见
    try:
        from langfuse import Langfuse  # noqa: PLC0415

        _tool_count = len(merged_tools or {})
        lf = Langfuse(
            secret_key=os.getenv("LANGFUSE_SECRET_KEY"),
            public_key=os.getenv("LANGFUSE_PUBLIC_KEY"),
            host=os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com"),
        )
        api_key = os.getenv("DATACLOUD_LLM_API_KEY", "")
        lf.update_current_span(
            metadata={
                "object_type": "early_span",
                "AgentDiag": {
                    "agent_id": agent_id_display,
                    "tool_count": _tool_count,
                    "tool_names": tool_names[:50],
                    "mounted_objects": list(mounted_objects or []),
                },
                "LLMConfig": {
                    "model": os.getenv("DATACLOUD_LLM_MODEL", ""),
                    "base_url": os.getenv("DATACLOUD_LLM_API_BASE", ""),
                    "api_key_status": "present" if api_key else "missing",
                },
                "DatacloudConfig": {
                    "ontology_path": os.getenv("DATACLOUD_ONTOLOGY_PATH", ""),
                    "react_max_rounds": os.getenv("DATACLOUD_REACT_MAX_ROUNDS", "30"),
                    "history_message_limit": os.getenv("DATACLOUD_HISTORY_MESSAGE_LIMIT", "16"),
                },
                "DBConfig": {
                    "db_host": os.getenv("DATACLOUD_DB_HOST", ""),
                    "db_port": os.getenv("DATACLOUD_DB_PORT", ""),
                    "db_schema": os.getenv("DATACLOUD_DB_SCHEMA", ""),
                },
                "MinioConfig": {
                    "mid_ftp_path": os.getenv("DATACLOUD_MID_FTP_PATH", ""),
                    "minio_mount_path": os.getenv("FILE_STORAGE_MINIO_MOUNT_PATH", ""),
                },
                "RedisConfig": {
                    "redis_host": os.getenv("DATACLOUD_GATEWAY_REDIS_HOST", ""),
                    "redis_port": os.getenv("DATACLOUD_GATEWAY_REDIS_PORT", ""),
                },
                "DeployInfo": {
                    "host": os.getenv("HOST", ""),
                    "container_name": os.getenv("CONTAINER_NAME", "byclaw-data-standalone"),
                    "worker_id": os.getenv("DATACLOUD_GATEWAY_WORKER_ID", ""),
                },
            }
        )
        # 工具挂载评分：tool_count=0 说明 OWL 路径配错或无本体，必然幻觉
        lf.score_current_trace(
            name="tool_mounted",
            value=1.0 if _tool_count > 0 else 0.0,
            data_type="BOOLEAN",
            comment=f"tool_count={_tool_count}",
        )
    except Exception:  # noqa: BLE001
        pass


def create_agent(
    *,
    model: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
    temperature: float = 0.7,
    locale: str | None = None,
    system_prompt: str | None = None,
    prompts_overwrite: dict[str, Any] | None = None,
    tools: dict[str, Any] | None = None,
    mounted_objects: list[str] | None = None,
    loader: Any | None = None,
    skip_action_families: frozenset[str] = frozenset(),
    user_message: str | None = None,
    agent_id: str | None = None,
) -> Any:
    """Create a deep agent for DataCloud, usable with langgraph dev and deep-agents-ui.

    Args:
        tools: 调用方预构建的工具字典，key 为工具名，value 为可调用对象或 BaseTool。
        mounted_objects: OBJECT / VIEW / ONTOLOGY 编码列表。若提供，则通过
            ``OntologyToolLoader`` 从本体定义自动生成 query_{code} /
            compute_{code} / action 工具，再与 ``tools`` 合并（``tools``
            中同名工具优先，即调用方可覆盖自动生成的工具）。
        loader: ``datacloud_data_sdk.OntologyLoader`` 实例。``mounted_objects``
            非空时必须提供；未提供则跳过本体工具生成并记录 debug 日志。
        user_message: 可选。传入时写入核查日志的「当前提问」；否则从
            ``prompts_overwrite`` 的 ``user_message`` / ``task_prompt`` 等键推断。
        agent_id: 可选。写入核查日志；未传时尝试 ``prompts_overwrite`` 中的
            ``agent_id`` / ``agentId`` / ``resourceId``。
    """

    # 语言和环境的日志预警可以保留，这里为了兼容现有 SDK 初始化
    resolved_locale = locale or os.getenv("DATACLOUD_AGENT_LOCALE", "zh_CN")
    supported = get_supported_locales()
    if resolved_locale not in supported:
        logger.warning(
            "create_agent: locale=%r is not supported (supported: %s). Falling back to zh_CN.",
            resolved_locale,
            supported,
        )
        resolved_locale = "zh_CN"

    # --- 本体工具生成 ---
    from datacloud_analysis.tools.ontology_tool_loader import OntologyToolLoader  # noqa: PLC0415

    ontology_tools = OntologyToolLoader(
        mounted_objects=mounted_objects,
        loader=loader,
        skip_action_families=skip_action_families,
    ).load()

    # 合并工具：本体工具为基础，caller 传入的 tools 优先覆盖同名工具。
    # data_query_* 工具（redirect_tools）不加入 LLM 可见的 merged_tools，
    # 单独通过 redirect_tools 传入 graph，仅供 before_callback redirect 使用。
    extra_tools = tools or {}
    redirect_tools: dict[str, Any] = {
        k: v for k, v in extra_tools.items() if k.startswith("data_query_")
    }
    llm_visible_tools: dict[str, Any] = {
        k: v for k, v in extra_tools.items() if not k.startswith("data_query_")
    }
    merged_tools: dict[str, Any] | None = {**ontology_tools, **llm_visible_tools} or None

    question_ctx = _extract_question_context_for_log(
        user_message=user_message,
        prompts_overwrite=prompts_overwrite,
        system_prompt=system_prompt,
    )
    agent_id_display = _resolve_agent_id_for_log(
        agent_id=agent_id,
        prompts_overwrite=prompts_overwrite,
    )
    _log_create_agent_diagnostics(
        agent_id_display=agent_id_display,
        question_context=question_ctx,
        merged_tools=merged_tools,
        mounted_objects=mounted_objects,
    )

    logger.info("create_agent: locale=%s (Custom StateGraph)", resolved_locale)
    logger.info(
        "create_agent: tools summary — "
        "ontology=%d extra=%d llm_visible=%d redirect=%d merged=%d mounted_objects=%s prompts_overwrite_keys=%s",
        len(ontology_tools),
        len(extra_tools),
        len(llm_visible_tools),
        len(redirect_tools),
        len(merged_tools or {}),
        mounted_objects,
        sorted((prompts_overwrite or {}).keys()),
    )

    graph = build_analysis_graph(
        prompts_overwrite=prompts_overwrite,
        tools=merged_tools,
        loader=loader,
        redirect_tools=redirect_tools or None,
    )

    compiled = compile_graph_with_policy(graph, caller_name="create_agent")

    try:
        nodes = list(compiled.get_graph().nodes.keys())
        logger.info("[dbg] compiled graph nodes: %s", nodes)
    except Exception as exc:  # noqa: BLE001
        logger.warning("[dbg] get_graph failed: %s", exc)

    return compiled
