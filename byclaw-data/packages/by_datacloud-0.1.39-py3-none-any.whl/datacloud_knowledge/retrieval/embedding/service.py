"""Embedding 服务实现。

基于 OpenAI 兼容 API 的向量生成服务，支持：
- embedding 模型 (1024 维)
- 批量 embedding 生成
- 可配置的 API 端点
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

if TYPE_CHECKING:
    from collections.abc import Sequence

log = logging.getLogger(__name__)


class EmbeddingConfig(BaseSettings):
    """Embedding 服务配置。

    环境变量（优先级低于显式传参）：
        DATACLOUD_EMBEDDING_API_BASE: API 基础 URL
        DATACLOUD_EMBEDDING_API_KEY: API 密钥
        DATACLOUD_EMBEDDING_MODEL: 模型名称
        DATACLOUD_EMBEDDING_BATCH_SIZE: 批量处理大小
        DATACLOUD_EMBEDDING_DIMS: 向量维度
    """

    embedding_api_base: str = Field(default="", alias="DATACLOUD_EMBEDDING_API_BASE")
    embedding_api_key: str = Field(default="", alias="DATACLOUD_EMBEDDING_API_KEY")
    embedding_model: str = Field(default="", alias="DATACLOUD_EMBEDDING_MODEL")
    embedding_batch_size: int = Field(default=10, alias="DATACLOUD_EMBEDDING_BATCH_SIZE")
    embedding_dims: int = Field(default=1024, alias="DATACLOUD_EMBEDDING_DIMS")

    model_config = SettingsConfigDict(env_prefix="", env_file=".env", extra="ignore")

    @classmethod
    def from_params(
        cls,
        *,
        api_base: str = "",
        api_key: str = "",
        model: str = "",
        batch_size: int | None = None,
        dims: int | None = None,
    ) -> EmbeddingConfig:
        """从显式参数构造配置（显式值优先，缺失字段回退到环境变量默认值）。"""
        values: dict[str, str | int] = {
            "embedding_api_base": api_base,
            "embedding_api_key": api_key,
            "embedding_model": model,
        }
        if batch_size is not None:
            values["embedding_batch_size"] = batch_size
        if dims is not None:
            values["embedding_dims"] = dims
        return cls(**values)  # type: ignore[arg-type]


class EmbeddingService:
    """Embedding 服务类。

    提供文本向量化能力，支持批量处理。
    """

    def __init__(self, config: EmbeddingConfig | None = None) -> None:
        """初始化 Embedding 服务。

        Args:
            config: 配置对象，默认从环境变量加载
        """
        self._config = config or EmbeddingConfig()
        self._model = None

    def _init_model(self) -> None:
        """延迟初始化模型。"""
        if self._model is not None:
            return
        missing = [
            name
            for name, value in (
                ("DATACLOUD_EMBEDDING_API_BASE", self._config.embedding_api_base),
                ("DATACLOUD_EMBEDDING_API_KEY", self._config.embedding_api_key),
                ("DATACLOUD_EMBEDDING_MODEL", self._config.embedding_model),
            )
            if not value
        ]
        if missing:
            raise RuntimeError("Missing embedding configuration: " + ", ".join(missing))

        try:
            from llama_index.embeddings.openai import OpenAIEmbedding

            self._model = OpenAIEmbedding(
                model_name=self._config.embedding_model,
                api_base=self._config.embedding_api_base,
                api_key=self._config.embedding_api_key,
                embed_batch_size=self._config.embedding_batch_size,
            )
            log.info(
                "Initialized embedding model: %s (dims=%d)",
                self._config.embedding_model,
                self._config.embedding_dims,
            )
        except ImportError:
            log.error("llama-index-embeddings-openai not installed")
            raise

    def get_text_embedding(self, text: str) -> list[float]:
        """获取单个文本的向量。

        Args:
            text: 输入文本

        Returns:
            向量列表 (float)
        """
        self._init_model()
        if self._model is None:
            raise RuntimeError("Embedding model not initialized")

        return self._model.get_text_embedding(text)

    def get_text_embedding_batch(self, texts: Sequence[str]) -> list[list[float]]:
        """批量获取文本向量。

        Args:
            texts: 文本列表

        Returns:
            向量列表的列表
        """
        self._init_model()
        if self._model is None:
            raise RuntimeError("Embedding model not initialized")

        return self._model.get_text_embedding_batch(list(texts))

    @property
    def dims(self) -> int:
        """返回向量维度。"""
        return self._config.embedding_dims

    @property
    def model_name(self) -> str:
        """返回模型名称。"""
        return self._config.embedding_model


# 单例模式
_embedding_service: EmbeddingService | None = None


def get_embedding_service() -> EmbeddingService:
    """获取 Embedding 服务单例。

    Returns:
        EmbeddingService 实例
    """
    global _embedding_service
    if _embedding_service is None:
        _embedding_service = EmbeddingService()
    return _embedding_service


def reset_embedding_service() -> None:
    """重置 Embedding 服务单例（用于测试）。"""
    global _embedding_service
    _embedding_service = None
