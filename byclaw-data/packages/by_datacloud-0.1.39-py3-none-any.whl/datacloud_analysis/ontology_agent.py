"""OntologyAgent — DataCloud SDK 公开 API（无 Gateway 中间层直调版本）。

设计文档：docs/概要设计/gateway解耦方案/dataCloud重构方案.md
"""

from __future__ import annotations

import logging
import uuid
from collections import OrderedDict
from collections.abc import AsyncGenerator
from dataclasses import dataclass
from dataclasses import field as dc_field
from pathlib import Path
from typing import Any

from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

from datacloud_analysis.reporter import NoOpExecutionReporter

logger = logging.getLogger(__name__)

# ── 进程级图缓存上限（与 worker.py 原有 LRU 上限对齐） ──────────────────────
_CACHE_MAX: int = 32

# ── 事件模型 ─────────────────────────────────────────────────────────────────


class OntologyAgentEvent:
    """所有事件的基类，用于类型注解。"""


@dataclass
class ThinkingEvent(OntologyAgentEvent):
    """LLM 推理中的增量 token（来自非 respond 节点）。"""

    content: str


@dataclass
class StepEvent(OntologyAgentEvent):
    """执行阶段标题或思考过程片段（来自 dc_stream_chunk 自定义事件）。"""

    title: str
    detail: str | None = None


@dataclass
class OperationFormField:
    """操作确认表单字段，支持通过 children 递归表达对象和对象数组。"""

    form_type: str
    field_code: str
    field_name: str
    field_type: str
    field_path: str = ""
    field_value: Any = None
    children: list[list[OperationFormField]] | None = None
    item_id: str = ""
    description: str = ""
    required: bool = False
    readonly: bool = False
    disabled: bool = False
    is_hidden: bool = False
    default_files: list[str] = dc_field(default_factory=list)
    term: dict[str, Any] | None = None


@dataclass
class OperationForm:
    """操作确认表单，rule 使用二维字段数组表达一组或多组表单。"""

    schema_version: str
    form_id: str
    action_code: str
    action_name: str = ""
    title: str = ""
    description: str = ""
    rule: list[list[OperationFormField]] = dc_field(default_factory=list)
    raw: dict[str, Any] = dc_field(default_factory=dict)


@dataclass
class InterruptEvent(OntologyAgentEvent):
    """图在此处暂停，调用方需处理后调用 resume()。"""

    thread_id: str
    reason: str  # "PARADIGM_CLARIFICATION" | "ASK_USER" | ...
    prompt: str
    interrupt_type: str = ""
    paradigm_list: list[ParadigmGroup] | None = None
    query: str = ""
    operation_form: OperationForm | None = None


@dataclass
class AnswerEvent(OntologyAgentEvent):
    """最终答案（完整内容，一次性 yield）。"""

    content: str


@dataclass
class ErrorEvent(OntologyAgentEvent):
    """流异常终止。"""

    message: str
    code: str | None = None


@dataclass
class PerfEvent(OntologyAgentEvent):
    """单次 ask/resume 的性能汇总，在 AnswerEvent 之后 yield。"""

    total_duration_ms: int
    ttft_ms: int | None
    react_turns: int
    llm_call_count: int
    interrupt_count: int
    thinking_chars: int
    thinking_duration_ms: int
    thinking_chars_per_sec: float
    last_tool_called: str = ""


# ── 维度选项模型 ──────────────────────────────────────────────────────────────


@dataclass
class ParadigmOption:
    choice_keyword: str
    recall: list[str]
    keyword: str = ""
    kid: int = 0
    ktype: str = ""
    # 过滤条件（paradigmType='filter'）专用字段
    filter_field: str = ""
    comparison: str = ""
    value: str = ""
    choice_field: str = ""
    choice_comparison: str = ""
    field_recall: list[str] = dc_field(default_factory=list)
    comparison_recall: list[str] = dc_field(default_factory=list)
    value_recall: list[str] = dc_field(default_factory=list)


@dataclass
class ParadigmGroup:
    paradigm_id: str
    paradigm_name: str
    options: list[ParadigmOption] = dc_field(default_factory=list)


@dataclass
class ParadigmGroupSelection:
    paradigm_id: str
    paradigm_name: str
    chosen_options: list[ParadigmOption] = dc_field(default_factory=list)


@dataclass
class ParadigmAnswer:
    """用户选择的维度答案，传给 resume()。"""

    selections: list[ParadigmGroupSelection] = dc_field(default_factory=list)


# ── 配置模型 ──────────────────────────────────────────────────────────────────


@dataclass
class OntologyAgentConfig:
    api_key: str
    model: str
    resource_path: str | Path
    base_url: str | None = None
    locale: str = "zh_CN"
    temperature: float = 0.7
    model_kwargs: dict[str, Any] | None = None
    # 结果文件存储后端（如 byclaw 的 ByclawResultFileStorage）。由调用方注入，
    # OntologyAgent 内不感知具体类型，仅透传给 configure_loader。
    result_file_storage: Any = None
    # HTTP_SQL 后端服务地址。非空时强制走 HttpSqlConnector 并注入此地址，
    # 取代历史的 DATACLOUD_SQL_SERVICE_URL 环境变量。
    sql_execute_url: str | None = None
    # 结果文件（CSV 导出等）的工作目录根路径。None 时退化到 os.getcwd()。
    workspace_dir: str | None = None
    # False 时跳过 KbTermLoader（不连 OpenGauss），适用于 OpenGauss 不可用的环境（如评测 mock 环境）。
    use_kb_term_loader: bool = True


# ── 缓存 key ──────────────────────────────────────────────────────────────────


def _make_cache_key(
    view_codes: list[str] | None,
    object_codes: list[str] | None,
) -> tuple[frozenset[str], frozenset[str]]:
    """构造图缓存 key，view/object 分属两个 frozenset 避免命名空间碰撞。"""
    return (frozenset(view_codes or []), frozenset(object_codes or []))


# ── 初始状态构建辅助 ──────────────────────────────────────────────────────────


def _build_input_payload(question: str, workspace_dir: str | None = None) -> dict[str, Any]:
    """构建 AgentState 初始字段，与 runner.py 保持一致。"""
    from langchain_core.messages import HumanMessage  # noqa: PLC0415

    return {
        "messages": [HumanMessage(content=question)],
        "agent_id": None,
        "agent_name": None,
        "workspace_dir": workspace_dir,
        "user_query": "",
        "enriched_query": "",
        "knowledge_payload": {},
        "term_hints": [],
        "knowledge_snippets": [],
        "thinking_log": {},
        "planning_input_source": "",
        "plan": [],
        "todos": [],
        "todo_md": "",
        "todo_md_path": "",
        "intent": None,
        "clarify_needed": False,
        "results": [],
        "execution_status": "",
        "todo_active_id": "",
        "todo_tool_plan": [],
        "active_tools": [],
        "execution_trace": [],
        "invocation_dedup": [],
        "final_answer": "",
        "artifact_refs": [],
        "execution_summary": None,
        "execution_summary_persistence": None,
        "resume_context": {},
        "query_mode": "analysis",
        "target_tool": "",
        "tool_params": {},
        "concept_terms": [],
        "confirmed_terms": [],
        "ambiguous_terms": [],
        "session_alias_map": {},
        "dynamic_tools": {},
        "prompts_overwrite": {},
        "planned_tasks": [],
        "task_queue": [],
        "results_list": [],
        "results_map": {},
        "final_summary": {},
    }


def _paradigm_answer_to_resume_value(
    answer: ParadigmAnswer,
    raw: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """将 ParadigmAnswer 转换为 user_clarify_node 期望的 resume_value 格式。

    raw 为前端原始 humanInput dict，携带完整的 paradigmList（含 keyword/kid/paradigmId）
    和 metadata（含 clarify_knowledge），优先直接使用，供 user_clarify_node 做 path_mapping 裁剪。
    """
    # raw 存在时直接透传，保留前端提交的完整结构（paradigmId/paradigmResult/keyword/kid）
    if raw and isinstance(raw.get("paradigmList"), list):
        return raw

    # raw 不存在时降级：从 ParadigmAnswer 重建（仅含 choiceKeyword/recall，无 keyword/kid）
    items: list[dict[str, Any]] = []
    for sel in answer.selections:
        for opt in sel.chosen_options:
            item: dict[str, Any] = {
                "choiceKeyword": opt.choice_keyword,
                "recall": opt.recall,
            }
            # 过滤条件选项携带 filter 专用字段
            if opt.filter_field:
                item["field"] = opt.filter_field
                item["choiceField"] = opt.choice_field
            if opt.comparison:
                item["comparison"] = opt.comparison
                item["choiceComparison"] = opt.choice_comparison
            if opt.value:
                item["value"] = opt.value
            items.append(item)
    return {"paradigmList": [{"paradigmList": items}]}


def _interrupt_value_to_paradigm_list(
    ask_user_payload: dict[str, Any],
) -> list[ParadigmGroup] | None:
    """将 interrupt value 中的 paradigmList 解析为 list[ParadigmGroup]。"""
    raw_list = ask_user_payload.get("paradigmList") or []
    if not raw_list:
        return None

    groups: list[ParadigmGroup] = []
    for item in raw_list:
        paradigm_id = str(item.get("paradigmId") or item.get("paradigmCode") or "")
        paradigm_name = str(item.get("paradigmName") or "")
        raw_results = list(item.get("paradigmResult") or [])
        # 过滤条件的结果结构不同于查询值（查询值使用 choiceKeyword/keyword/kid/ktype，
        # 过滤条件使用 field/comparison/value/choiceField 等字段）。
        # 通过检测第一个 result 是否有 "field" 键来判断是否为过滤条件类型。
        is_filter = bool(
            raw_results and isinstance(raw_results[0], dict) and "field" in raw_results[0]
        )
        options: list[ParadigmOption] = [
            ParadigmOption(
                choice_keyword=str(r.get("choiceKeyword") or ""),
                recall=r.get("recall") if isinstance(r.get("recall"), list) else [],
                keyword=str(r.get("keyword") or ""),
                kid=int(r.get("kid") or 0),
                ktype=str(r.get("ktype") or ""),
                filter_field=str(r.get("field") or "") if is_filter else "",
                comparison=str(r.get("comparison") or "") if is_filter else "",
                value=str(r.get("value") or "") if is_filter else "",
                choice_field=str(r.get("choiceField") or "") if is_filter else "",
                choice_comparison=str(r.get("choiceComparison") or "") if is_filter else "",
                field_recall=r.get("fieldRecall")
                if isinstance(r.get("fieldRecall"), list)
                else []
                if is_filter
                else [],
                comparison_recall=r.get("comparisonRecall")
                if isinstance(r.get("comparisonRecall"), list)
                else []
                if is_filter
                else [],
                value_recall=r.get("valueRecall")
                if isinstance(r.get("valueRecall"), list)
                else []
                if is_filter
                else [],
            )
            for r in raw_results
        ]
        groups.append(
            ParadigmGroup(
                paradigm_id=paradigm_id,
                paradigm_name=paradigm_name,
                options=options,
            )
        )
    return groups or None


def _operation_form_from_payload(payload: dict[str, Any]) -> OperationForm:
    """将 operation_form 原始 dict 转为 SDK 公开的轻量强类型结构。"""
    return OperationForm(
        schema_version=str(payload.get("schemaVersion") or ""),
        form_id=str(payload.get("formId") or ""),
        action_code=str(payload.get("actionCode") or ""),
        action_name=str(payload.get("actionName") or ""),
        title=str(payload.get("title") or ""),
        description=str(payload.get("description") or ""),
        rule=_operation_rule_from_payload(payload.get("rule")),
        raw=dict(payload),
    )


def _operation_rule_from_payload(value: Any) -> list[list[OperationFormField]]:
    if not isinstance(value, list):
        return []
    rows: list[list[OperationFormField]] = []
    for row in value:
        if not isinstance(row, list):
            continue
        fields = [_operation_field_from_payload(item) for item in row if isinstance(item, dict)]
        if fields:
            rows.append(fields)
    return rows


def _operation_field_from_payload(payload: dict[str, Any]) -> OperationFormField:
    default_files_raw = payload.get("defaultFiles")
    default_files = (
        [str(item) for item in default_files_raw] if isinstance(default_files_raw, list) else []
    )
    term_raw = payload.get("term")
    children = _operation_rule_from_payload(payload.get("children"))
    return OperationFormField(
        form_type=str(payload.get("formType") or ""),
        field_code=str(payload.get("fieldCode") or ""),
        field_name=str(payload.get("fieldName") or ""),
        field_type=str(payload.get("fieldType") or ""),
        field_path=str(payload.get("fieldPath") or ""),
        field_value=payload.get("fieldValue"),
        children=children or None,
        item_id=str(payload.get("itemId") or ""),
        description=str(payload.get("description") or ""),
        required=bool(payload.get("required")),
        readonly=bool(payload.get("readonly")),
        disabled=bool(payload.get("disabled")),
        is_hidden=bool(payload.get("isHidden")),
        default_files=default_files,
        term=dict(term_raw) if isinstance(term_raw, dict) else None,
    )


# ── OntologyAgent ─────────────────────────────────────────────────────────────


class OntologyAgent:
    """DataCloud SDK 公开客户端，无需 Gateway 中间层即可直接发起问答。

    实例应长期持有（如应用启动时创建一次），以充分利用进程级图缓存（T6）。
    """

    def __init__(self, config: OntologyAgentConfig) -> None:
        self._config = config
        self._checkpointer = MemorySaver()
        # T6 进程级图缓存：OrderedDict 实现 LRU
        self._graph_cache: OrderedDict[tuple[frozenset[str], frozenset[str]], Any] = OrderedDict()

    # ── 公开 API ──────────────────────────────────────────────────────────────

    def ask(
        self,
        question: str,
        *,
        view_codes: list[str] | None = None,
        object_codes: list[str] | None = None,
        thread_id: str | None = None,
        user_code: str | None = None,
        session_id: str | None = None,
        locale: str | None = None,
        extras: dict[str, Any] | None = None,
        target_tool: str | None = None,
    ) -> AsyncGenerator[OntologyAgentEvent, None]:
        """发起一次问答，流式返回事件。

        thread_id 使用规则：
          - 多轮对话：调用方自行生成（如 str(uuid.uuid4())）并在每轮传入相同值。
          - 一次性问答：传 None，SDK 内部生成，调用方无需保存。
          - 中断恢复：resume() 使用与本次 ask() 相同的 thread_id。

        user_code / session_id: datacloud 自己的请求级上下文字段。会被 OntologyAgent
        在内部组装成 duck-typed 容器并注入 LangGraph configurable，供下游
        tool_wrapper / HookAwareToolNode 通过 InvocationContext 透传至 SDK
        result_file_storage 等需要这两个字段的位置。本接口不感知 Gateway 概念。

        target_tool: 强制指定初始工具名（如 "data_query_crm_customer"），跳过 LLM 工具选择，
        直接从该工具开始执行。用于对比实验（Text2SQL vs DSL 路径）。
        """
        effective_tid = thread_id or str(uuid.uuid4())
        return self._iter_events(
            question=question,
            view_codes=view_codes,
            object_codes=object_codes,
            thread_id=effective_tid,
            user_code=user_code,
            session_id=session_id,
            locale=locale,
            resume_input=None,
            extras=extras,
            target_tool=target_tool,
        )

    def resume(
        self,
        thread_id: str,
        user_input: str | ParadigmAnswer | dict[str, Any],
        *,
        view_codes: list[str] | None = None,
        object_codes: list[str] | None = None,
        user_code: str | None = None,
        session_id: str | None = None,
        extras: dict[str, Any] | None = None,
    ) -> AsyncGenerator[OntologyAgentEvent, None]:
        """在中断后恢复图执行，继续流式返回事件。

        view_codes / object_codes 须与触发中断的 ask() 保持一致。
        user_input:
          - str：文本回复（ASK_USER 场景）
          - ParadigmAnswer：维度选择（PARADIGM_CLARIFICATION 场景）
          - dict：结构化恢复值，如操作确认表单 operation_form 场景
        user_code / session_id: 同 ask()。
        """
        return self._iter_events(
            question="",
            view_codes=view_codes,
            object_codes=object_codes,
            thread_id=thread_id,
            user_code=user_code,
            session_id=session_id,
            locale=None,
            resume_input=user_input,
            extras=extras,
        )

    # ── 内部实现 ──────────────────────────────────────────────────────────────

    def _build_loader(
        self,
        view_codes: list[str] | None,
        object_codes: list[str] | None,
    ) -> tuple[Any, list[str]]:
        """解析 OWL 文件，返回 (OntologyLoader, mounted_objects)。"""
        from datacloud_data_sdk.ontology.loader import OntologyLoader  # noqa: PLC0415
        from datacloud_data_service.tools.virtual_action_injector import (  # noqa: PLC0415
            inject_virtual_actions,
        )

        from datacloud_analysis.tools.ontology_tool_loader import configure_loader  # noqa: PLC0415

        resource_path = Path(self._config.resource_path)
        loader = OntologyLoader()
        loader.load_from_owl_resource_directory(
            resource_path, object_codes=object_codes, view_codes=view_codes
        )

        # for view_code in view_codes or []:
        #     loader.load_view_with_deps(resource_path, view_code)
        # for obj_code in object_codes or []:
        #     loader.load_object_with_deps(resource_path, obj_code)

        inject_virtual_actions(loader)
        configure_loader(
            loader,
            model=self._config.model,
            api_key=self._config.api_key,
            base_url=self._config.base_url,
            temperature=self._config.temperature,
            result_file_storage=self._config.result_file_storage,
            sql_execute_url=self._config.sql_execute_url,
            use_kb_term_loader=self._config.use_kb_term_loader,
        )

        mounted = list(view_codes or []) + list(object_codes or [])
        return loader, mounted

    def _build_and_compile(
        self,
        view_codes: list[str] | None,
        object_codes: list[str] | None,
    ) -> Any:
        """构建并编译 LangGraph 图（无缓存层，供 T6 缓存逻辑调用）。"""
        from datacloud_analysis.orchestration.graph_builder import (  # noqa: PLC0415
            build_analysis_graph,
        )
        from datacloud_analysis.tools.ontology_tool_loader import (  # noqa: PLC0415
            OntologyToolLoader,
        )

        loader, mounted = self._build_loader(view_codes, object_codes)
        tool_loader = OntologyToolLoader(
            mounted_objects=mounted,
            loader=loader,
            resource_path=self._config.resource_path,
        )
        tools = tool_loader.load()
        redirect_tools = tool_loader.build_all_nl_query_tools()
        graph = build_analysis_graph(
            tools=tools, loader=loader, redirect_tools=redirect_tools or None
        )
        return graph.compile(checkpointer=self._checkpointer)

    def _get_or_build_graph(
        self,
        view_codes: list[str] | None,
        object_codes: list[str] | None,
    ) -> Any:
        """T6：带 LRU 缓存的图获取入口。"""
        key = _make_cache_key(view_codes, object_codes)
        if key in self._graph_cache:
            self._graph_cache.move_to_end(key)
            logger.debug("ontology_agent: graph cache hit key=%s", key)
            return self._graph_cache[key]

        logger.debug("ontology_agent: graph cache miss, building key=%s", key)
        compiled = self._build_and_compile(view_codes, object_codes)
        self._graph_cache[key] = compiled
        if len(self._graph_cache) > _CACHE_MAX:
            evicted = self._graph_cache.popitem(last=False)
            logger.debug("ontology_agent: evicted cache entry key=%s", evicted[0])
        return compiled

    async def _iter_events(  # type: ignore[return]
        self,
        *,
        question: str,
        view_codes: list[str] | None,
        object_codes: list[str] | None,
        thread_id: str,
        user_code: str | None,
        session_id: str | None,
        locale: str | None,
        resume_input: str | ParadigmAnswer | dict[str, Any] | None,
        extras: dict[str, Any] | None = None,
        target_tool: str | None = None,
    ) -> AsyncGenerator[OntologyAgentEvent, None]:
        """核心事件迭代器：构建图、执行、转换事件。"""
        try:
            compiled = self._get_or_build_graph(view_codes, object_codes)
        except Exception as exc:
            logger.exception("ontology_agent: failed to build graph")
            yield ErrorEvent(message=str(exc))
            return

        effective_locale = locale or self._config.locale
        # 无 Gateway 部署使用 NoOpExecutionReporter（实现 ExecutionReporter 协议），
        # 让 tool_wrapper.py 等业务代码不需感知是否有真实 Gateway。
        # 真实 Gateway（如 byclaw-data 的 AgentContext）走另一条路径直接被注入到
        # configurable["gateway_context"]，duck-type 自然满足同一协议。
        ctx_container: Any = NoOpExecutionReporter(
            user_id=user_code or "",
            session_id=session_id or "",
            extras=extras,
        )
        run_config: dict[str, Any] = {
            "configurable": {
                "thread_id": thread_id,
                "user_code": user_code,
                "gateway_context": ctx_container,
                "llm_config": {
                    "model": self._config.model,
                    "api_key": self._config.api_key,
                    "base_url": self._config.base_url,
                    "temperature": self._config.temperature,
                    "model_kwargs": self._config.model_kwargs,
                },
            },
            "recursion_limit": 100,
        }

        if resume_input is None:
            graph_input: Any = _build_input_payload(
                question, workspace_dir=self._config.workspace_dir
            )
            graph_input["prompts_overwrite"] = {"locale": effective_locale}
            if target_tool:
                graph_input["target_tool"] = target_tool
        elif isinstance(resume_input, str | dict):
            graph_input = Command(resume=resume_input)
        else:
            resume_value = _paradigm_answer_to_resume_value(
                resume_input,
                raw=getattr(resume_input, "_raw_dict", None),
            )
            graph_input = Command(resume=resume_value)

        try:
            import time as _time

            _t_start = _time.monotonic()
            _ttft_ms: int | None = None
            _react_turns = 0
            _llm_call_count = 0
            _thinking_chars = 0
            _thinking_t_start: float | None = None
            _thinking_duration_ms = 0
            _in_thinking = False
            _current_node = ""
            _last_tool_called = ""

            async for event in compiled.astream_events(
                graph_input,
                config=run_config,
                version="v2",
            ):
                event_type = event.get("event", "")
                metadata = event.get("metadata") or {}
                node = metadata.get("langgraph_node", "")

                # ReAct 轮次计数
                if event_type == "on_chain_start" and node and node != _current_node:
                    _current_node = node
                    if node not in ("respond", "__start__", "__end__"):
                        _react_turns += 1

                # LLM 调用计数
                if event_type == "on_chat_model_start":
                    _llm_call_count += 1

                # 工具调用采集（finish_react 不算）
                if event_type == "on_tool_start":
                    tool_name = str(
                        (event.get("data") or {}).get("input", {}).get("tool", "")
                        or event.get("name", "")
                        or ""
                    )
                    if tool_name and tool_name != "finish_react":
                        _last_tool_called = tool_name

                if event_type == "on_chat_model_stream" and node != "respond":
                    chunk = (event.get("data") or {}).get("chunk")
                    content = getattr(chunk, "content", "") or ""
                    if content:
                        if _ttft_ms is None:
                            _ttft_ms = int((_time.monotonic() - _t_start) * 1000)
                        if not _in_thinking:
                            _in_thinking = True
                            _thinking_t_start = _time.monotonic()
                        _thinking_chars += len(content)
                        yield ThinkingEvent(content=content)
                    else:
                        if _in_thinking and _thinking_t_start is not None:
                            _thinking_duration_ms += int(
                                (_time.monotonic() - _thinking_t_start) * 1000
                            )
                            _in_thinking = False
                            _thinking_t_start = None

                elif event_type == "on_custom_event" and event.get("name") == "dc_stream_chunk":
                    data = event.get("data") or {}
                    text = str(data.get("content") or "").strip()
                    if text:
                        yield StepEvent(title=text)

        except Exception as exc:
            logger.exception("ontology_agent: stream error thread_id=%s", thread_id)
            yield ErrorEvent(message=str(exc))
            return

        # ── 流结束后检查是否中断 ────────────────────────────────────────────
        snapshot_config: dict[str, Any] = {"configurable": dict(run_config["configurable"].items())}
        snapshot_config["configurable"].pop("checkpoint_id", None)

        try:
            snapshot = await compiled.aget_state(snapshot_config)
        except Exception as exc:
            logger.exception("ontology_agent: aget_state failed thread_id=%s", thread_id)
            yield ErrorEvent(message=f"aget_state failed: {exc}")
            return

        if snapshot.interrupts:
            interrupt = snapshot.interrupts[0]
            iv = interrupt.value if hasattr(interrupt, "value") else interrupt
            interrupt_value = dict(iv or {}) if isinstance(iv, dict) else {}
            reason_code = str(interrupt_value.get("reason_code") or "UNKNOWN")
            prompt = str(interrupt_value.get("prompt") or "")
            interrupt_type = str(interrupt_value.get("interrupt_type") or "")
            ask_payload: dict[str, Any] = dict(interrupt_value.get("ask_user_payload") or {})
            paradigm_list = _interrupt_value_to_paradigm_list(ask_payload)
            query = str(ask_payload.get("query") or "")
            operation_form_raw = interrupt_value.get("operation_form") or ask_payload.get(
                "operation_form"
            )
            operation_form = (
                _operation_form_from_payload(operation_form_raw)
                if isinstance(operation_form_raw, dict)
                else None
            )

            yield InterruptEvent(
                thread_id=thread_id,
                reason=reason_code,
                prompt=prompt,
                interrupt_type=interrupt_type,
                paradigm_list=paradigm_list,
                query=query,
                operation_form=operation_form,
            )
            return

        # 收尾：如果思考还在进行中，补算时长
        if _in_thinking and _thinking_t_start is not None:
            _thinking_duration_ms += int((_time.monotonic() - _thinking_t_start) * 1000)

        final_answer = str(snapshot.values.get("final_answer") or "")
        yield AnswerEvent(content=final_answer)

        # 性能汇总事件
        _total_ms = int((_time.monotonic() - _t_start) * 1000)
        _chars_per_sec = (
            round(_thinking_chars / (_thinking_duration_ms / 1000), 1)
            if _thinking_duration_ms > 0
            else 0.0
        )
        yield PerfEvent(
            total_duration_ms=_total_ms,
            ttft_ms=_ttft_ms,
            react_turns=_react_turns,
            llm_call_count=_llm_call_count,
            interrupt_count=0,
            thinking_chars=_thinking_chars,
            thinking_duration_ms=_thinking_duration_ms,
            thinking_chars_per_sec=_chars_per_sec,
            last_tool_called=_last_tool_called,
        )

    # 让 async generator 方法可被直接调用并返回 AsyncGenerator
    # _iter_events 是 async def + yield，Python 自动使其成为 async generator function。
    # ask()/resume() 直接 return self._iter_events(...)，此调用返回 AsyncGenerator 对象。
