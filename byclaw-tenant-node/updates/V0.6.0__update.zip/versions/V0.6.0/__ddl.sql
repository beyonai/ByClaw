-- Forwarded public snapshots own their lifetime independently of source messages.

CREATE TABLE IF NOT EXISTS byai.byai_group_chat_forward_request (
    request_id BIGINT PRIMARY KEY,
    enterprise_id BIGINT NOT NULL,
    actor_user_id BIGINT NOT NULL,
    backend VARCHAR(16) NOT NULL CHECK (backend IN ('LEGACY','TENANT')),
    source_session_id BIGINT NOT NULL,
    client_request_id VARCHAR(64) NOT NULL,
    mode VARCHAR(16) NOT NULL CHECK (mode IN ('SINGLE','MERGED')),
    request_hash CHAR(64) NOT NULL,
    state VARCHAR(32) NOT NULL DEFAULT 'RUNNING' CHECK (state IN ('RUNNING','SUCCEEDED','PARTIAL_FAILED','FAILED')),
    snapshot_version INTEGER NOT NULL,
    frozen_json TEXT NOT NULL,
    source_manifest_json TEXT NOT NULL DEFAULT '[]',
    sources_frozen BOOLEAN NOT NULL DEFAULT FALSE,
    lease_owner VARCHAR(128),
    fencing_version BIGINT NOT NULL DEFAULT 0 CHECK (fencing_version >= 0),
    lease_until TIMESTAMP,
    create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_forward_request_actor_key UNIQUE (enterprise_id, actor_user_id, client_request_id),
    CONSTRAINT uq_forward_request_tenant UNIQUE (enterprise_id, request_id)
);

CREATE TABLE IF NOT EXISTS byai.byai_group_chat_forward_target (
    target_id BIGINT PRIMARY KEY,
    enterprise_id BIGINT NOT NULL,
    request_id BIGINT NOT NULL,
    target_session_id BIGINT NOT NULL,
    state VARCHAR(16) NOT NULL DEFAULT 'PENDING' CHECK (state IN ('PENDING','COPYING','READY','SUCCEEDED','FAILED')),
    lease_owner VARCHAR(128),
    fencing_version BIGINT NOT NULL DEFAULT 0 CHECK (fencing_version >= 0),
    lease_until TIMESTAMP,
    checkpoint_json TEXT NOT NULL DEFAULT '{}',
    message_ids_json TEXT NOT NULL DEFAULT '[]',
    error_code VARCHAR(128),
    retryable BOOLEAN NOT NULL DEFAULT FALSE,
    pending_delivery BOOLEAN NOT NULL DEFAULT FALSE,
    create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_forward_target_group UNIQUE (request_id, target_session_id),
    CONSTRAINT uq_forward_target_tenant UNIQUE (enterprise_id, request_id, target_id),
    CONSTRAINT fk_forward_target_request FOREIGN KEY (enterprise_id, request_id)
        REFERENCES byai.byai_group_chat_forward_request (enterprise_id, request_id)
);

CREATE TABLE IF NOT EXISTS byai.byai_group_chat_forward_item (
    item_id BIGINT PRIMARY KEY,
    enterprise_id BIGINT NOT NULL,
    request_id BIGINT NOT NULL,
    target_id BIGINT NOT NULL,
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    selected_message_id BIGINT NOT NULL,
    selected_merged_card BOOLEAN NOT NULL,
    source_message_id BIGINT NOT NULL,
    content TEXT NOT NULL,
    speaker_json TEXT NOT NULL,
    source_created_at TIMESTAMP NOT NULL,
    references_json TEXT NOT NULL DEFAULT '[]',
    attachments_json TEXT NOT NULL DEFAULT '[]',
    bound_message_id BIGINT,
    create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_forward_item_ordinal UNIQUE (target_id, ordinal),
    CONSTRAINT fk_forward_item_target FOREIGN KEY (enterprise_id, request_id, target_id)
        REFERENCES byai.byai_group_chat_forward_target (enterprise_id, request_id, target_id)
);

COMMENT ON COLUMN byai.byai_group_chat_forward_request.frozen_json IS 'Immutable public template fields only; never serialize raw locator candidate metadata';
COMMENT ON COLUMN byai.byai_group_chat_forward_request.source_manifest_json IS 'Validated minimal source identities and immutable proofs; no credentials or signed URLs';
COMMENT ON COLUMN byai.byai_group_chat_forward_target.checkpoint_json IS 'Attempt-owned object manifest with attachmentId, attemptId, storageType, scopeId/root and path/key, plus progress and attachment mapping';
COMMENT ON COLUMN byai.byai_group_chat_forward_item.source_message_id IS 'Historical provenance, intentionally no source-message foreign key';
COMMENT ON COLUMN byai.byai_group_chat_forward_item.attachments_json IS 'Public target attachments; physical locators remain server-only in the target checkpoint';

CREATE INDEX IF NOT EXISTS idx_forward_request_recovery ON byai.byai_group_chat_forward_request (enterprise_id, state, lease_until);
CREATE INDEX IF NOT EXISTS idx_forward_target_recovery ON byai.byai_group_chat_forward_target (enterprise_id, state, lease_until);
CREATE INDEX IF NOT EXISTS idx_forward_target_delivery ON byai.byai_group_chat_forward_target (enterprise_id, pending_delivery, target_id);
CREATE INDEX IF NOT EXISTS idx_forward_item_message ON byai.byai_group_chat_forward_item (enterprise_id, bound_message_id, ordinal);
